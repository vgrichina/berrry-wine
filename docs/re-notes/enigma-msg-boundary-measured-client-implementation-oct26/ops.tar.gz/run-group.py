from common import *
group=sys.argv[1]
b=pool([NODE,'--max-old-space-size=64',str(R/'test/test-message-boundary-trace.js'),group,str(O)],label=group)
print(b[:8192].decode())
completed=[n for n in ['production','limits','noninterference'] if (O/(n+'-result.json')).exists()]
save('checkpoint.json',dict(candidateSHA256=sha((R/'test/run.js').read_bytes()),helperSHA256=sha((R/'test/message-boundary-trace.js').read_bytes()),fixtureSHA256=sha((R/'test/test-message-boundary-trace.js').read_bytes()),completed=completed,remaining=[n for n in ['production','limits','noninterference'] if n not in completed]+['canonical invocation-owned post-result hook; separately assigned runtime qualification'],successfulReturnMSG=False,sourceResults={n:str(O/(n+'-result.json')) for n in completed}))
