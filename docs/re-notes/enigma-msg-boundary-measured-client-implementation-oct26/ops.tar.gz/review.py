from common import *
import zlib,difflib
base=(SRC/'test/run.js').read_text();candidate=(R/'test/run.js').read_text();s=candidate
changes=[
("const { createInputConsumptionTrace } = require('./input-consumption-trace');\nconst { createMessageBoundaryTrace } = require('./message-boundary-trace');","const { createInputConsumptionTrace } = require('./input-consumption-trace');"),
("const TRACE_MESSAGE_BOUNDARY = hasFlag('trace-message-boundary'); // 128 records/64KiB; returned MSG unavailable\n",''),
('!TRACE_INPUT_DISPATCH && !TRACE_MESSAGE_BOUNDARY && !ESP_DELTA','!TRACE_INPUT_DISPATCH && !ESP_DELTA'),
('    messageBoundaryTrace.api(t);\n',''),
('    messageBoundaryTrace.dequeue(evt, source);\n',''),
]
for a,b in changes:assert s.count(a)==1;s=s.replace(a,b)
a=s.index('  // BEGIN message-boundary installation:');b=s.index('  // END message-boundary installation',a)+len('  // END message-boundary installation\n');s=s[:a]+s[b:]
a=s.index("    if (cmd.action === 'message-boundary') {");b=s.index("    if (cmd.action === 'eval')",a);s=s[:a]+s[b:]
assert s==base
save('unchanged-boundaries.json',dict(baseSHA256=sha(base.encode()),candidateSHA256=sha(candidate.encode()),inverseDiagnosticOnlyDeltaSHA256=sha(s.encode()),byteExactBaselineRestored=True,unchanged=['canonical parser','atomic transaction/ACK','ordinary click','renderer input','main execution/initializers/control ordering'],reusedParent=dict(path='/tmp/enigma-start-game-input-delivery-repair-oct26/ops/boundary-results.json',sha256=sha(pathlib.Path('/tmp/enigma-start-game-input-delivery-repair-oct26/ops/boundary-results.json').read_bytes()),fixtureSHA256=sha(pathlib.Path('/tmp/enigma-start-game-input-delivery-repair-oct26/ops/input-boundary.cjs').read_bytes())),qualifications='New imports and diagnostic callback/control are tested separately. No guest execution; source-order check only for initializer installation.'))
line=g('ls-tree',REV,'--','test/run.js').decode().strip();oid=line.split()[2] if line else None
raw=base.encode();obj=b'blob '+str(len(raw)).encode()+b'\0'+raw;actual=hashlib.sha1(obj).hexdigest()
save('base-runner-git-provenance.json',dict(parentEntry=line,sourceGitBlob=actual,sha256=sha(raw),same=oid==actual))
if oid is not None:
 assert oid==actual,'Need exact immutable parent runner blob; no missing-blob retry authorized'
 p=R/'.git/objects'/oid[:2]/oid[2:];p.parent.mkdir(exist_ok=True);p.write_bytes(zlib.compress(obj))
else:save('parent-evidence-only.json',dict(parent=REV,testRunEntryAbsent=True,sourceRecovery='Full exact verified runner materialized from supplied source239 immutable local file; parent missing entry not retried. This branch adds source/test files; later integration must apply diagnostic delta against its independently reconciled tree.'))
(O/'runner.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='pinned/test/run.js',tofile='candidate/test/run.js')))
print((O/'runner.patch').read_text()[:7500])
