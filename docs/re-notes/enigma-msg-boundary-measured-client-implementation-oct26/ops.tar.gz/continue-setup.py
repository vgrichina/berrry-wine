from common import *
save('setup-incident.json',dict(command=['git','read-tree','-i','HEAD'],exit=128,reason='Owned plumbing command missing --reset; no missing-blob retry or admission denial. Correct to read-tree --reset -i HEAD; preserve original receipt.'))
g('read-tree','--reset','-i','HEAD');g('remote','add','origin','git@github.com:vgrichina/wine-assembly.git')
(R/'test').mkdir();shutil.copyfile(SRC/'test/run.js',R/'test/run.js')
save('checkout.json',dict(base=REV,branch=BR,selectiveBytes=(R/'test/run.js').stat().st_size,gitAlternatesRemoved=not (R/'.git/objects/info/alternates').exists()))
startup='const fs=require("fs");console.log(JSON.stringify({execPath:process.execPath,execArgv:process.execArgv,limits:fs.readFileSync("/proc/self/limits","utf8"),env:{TMPDIR:process.env.TMPDIR,NODE_OPTIONS:process.env.NODE_OPTIONS||null}}))'
b=pool([NODE,'--max-old-space-size=64','-e',startup],label='node-startup');print(b[:4000].decode())
save('startup-configuration.json',dict(executable=NODE,sha256=sha(pathlib.Path(NODE).read_bytes()),flags=['--max-old-space-size=64'],environment=dict(TMPDIR=str(O),NODE_OPTIONS=os.environ.get('NODE_OPTIONS')),cpu=90,wall=120,file=25165824,physical=134217728,output=2097152,excerpt=8192,gitDATAAppliesOnlyToGit=True))
print('SELECTIVE RECOVERY AND NODE STARTUP PASS')
