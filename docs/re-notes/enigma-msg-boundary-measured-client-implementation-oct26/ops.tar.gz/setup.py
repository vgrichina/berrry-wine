from common import *
import zlib
# Background board watcher is owned; output bounded by task allocation and stopped at closeout.
f=open(O/'board-watch.log','ab');p=subprocess.Popen(['tail','-n','0','-f',str(ROOT/'messageboard.txt')],stdout=f,stderr=f,start_new_session=True);f.close();save('watcher.json',dict(pid=p.pid))
manifest=json.load(open(ROOT/'scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json'))
required=['test/run.js','src/01-header.wat','src/09b-dispatch.wat','src/09a5-handlers-window.wat','src/09a5b-handlers-window-late.wat','src/09a-handlers4-late.wat','src/13-exports.wat','test/input-consumption-trace.js']
verified=[]
for path in required:
 x=next(x for x in manifest['files'] if x['path']==path);b=(SRC/path).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];verified.append(x)
assert sha((SRC/'test/run.js').read_bytes())=='87ab63d768eb59a09a8b69df2ccb3843270dd867a67405abd82f02c25c1628e7'
assert (SRC/'test/run.js').read_bytes()==pathlib.Path('/tmp/enigma-tracked-runner-pin-repair-oct26/repo/docs/reviews/enigma-uncertainty-independent-publication-oct26/tracked-run.js').read_bytes()
save('source-provenance.json',dict(revision=manifest['revision'],root=str(SRC),manifestSHA=sha((ROOT/'scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json').read_bytes()),files=verified,base=REV,sourceRecovery='Evidence-only parent can lack runner blob. Verified immutable local source is authoritative, no missing blob retry.',rootReadOnly=True))
R.mkdir();g('init','-q',str(R),cwd=H)
D=pathlib.Path('/tmp/enigma-start-game-input-delivery-repair-oct26/repo')
seen=set();ordered=[]
def visit(p):
 p=p.resolve()
 if p in seen or not p.exists():return
 seen.add(p);a=p/'info/alternates'
 if a.exists():
  for line in a.read_text().splitlines():visit(pathlib.Path(line) if line.startswith('/') else p/line)
 ordered.append(str(p))
visit(D/'.git/objects');(R/'.git/objects/info/alternates').write_text('\n'.join(ordered)+'\n')
assert g('rev-parse',REV).decode().strip()==REV
listing=g('ls-tree','-r','-t',REV).decode().splitlines()
objects=[REV,g('rev-parse',REV+'^{tree}').decode().strip()]+[l.split()[2] for l in listing if l.split()[1]=='tree']
(O/'object-request.txt').write_text('\n'.join(dict.fromkeys(objects))+'\n')
b=pool(['git','cat-file','--batch'],git=True,label='git-object-recovery',inputPath=O/'object-request.txt');off=0
while off<len(b):
 end=b.index(b'\n',off);oid,kind,size=b[off:end].decode().split();size=int(size);raw=b[end+1:end+1+size];assert b[end+1+size]==10
 obj=(kind+' '+str(size)+'\0').encode()+raw;assert hashlib.sha1(obj).hexdigest()==oid
 dest=R/'.git/objects'/oid[:2]/oid[2:];dest.parent.mkdir(exist_ok=True);dest.write_bytes(zlib.compress(obj));off=end+size+2
(R/'.git/objects/info/alternates').unlink();(R/'.git/shallow').write_text(REV+'\n')
for k,v in [('core.sparseCheckout','true'),('core.sparseCheckoutCone','false'),('core.sshCommand',SSH),('user.name','Wine Ops'),('user.email','wine-ops@local')]:g('config',k,v)
(R/'.git/info/sparse-checkout').write_text('/test/run.js\n/test/message-boundary-trace.js\n/test/test-message-boundary-trace.js\n/docs/re-notes/'+H.name+'/\n')
g('update-ref','refs/heads/'+BR,REV);g('symbolic-ref','HEAD','refs/heads/'+BR);g('read-tree','-i','HEAD');g('remote','add','origin','git@github.com:vgrichina/wine-assembly.git')
(R/'test').mkdir();shutil.copyfile(SRC/'test/run.js',R/'test/run.js')
# Keep a verified read-only-baseline receipt; no broad checkout/assets.
save('checkout.json',dict(base=REV,branch=BR,recoveredCommitAndTrees=len(objects),selectiveBytes=(R/'test/run.js').stat().st_size,gitAlternatesRemoved=True))
startup='const fs=require("fs");console.log(JSON.stringify({execPath:process.execPath,execArgv:process.execArgv,limits:fs.readFileSync("/proc/self/limits","utf8"),env:{TMPDIR:process.env.TMPDIR,NODE_OPTIONS:process.env.NODE_OPTIONS||null}}))'
b=pool([NODE,'--max-old-space-size=64','-e',startup],label='node-startup');print(b[:4000].decode())
save('startup-configuration.json',dict(executable=NODE,sha256=sha(pathlib.Path(NODE).read_bytes()),flags=['--max-old-space-size=64'],environment=dict(TMPDIR=str(O),NODE_OPTIONS=os.environ.get('NODE_OPTIONS')),cpu=90,wall=120,file=25165824,physical=134217728,output=2097152,excerpt=8192,gitDATAAppliesOnlyToGit=True))
print('SELECTIVE RECOVERY AND NODE STARTUP PASS')
