from work import *
assert jread('canonical-parser.json')['exit']==0
git('init','-q',str(REPO),repo=H)
for k,v in [('user.name','Wine Ops'),('user.email','wine-ops@local'),('core.sshCommand',SSH),('gc.auto','0')]:git('config',k,v)
git('symbolic-ref','HEAD','refs/heads/'+BRANCH)
git('remote','add','origin',URL)
save('git-prepared.json',dict(branch=BRANCH,independentEvidenceRoot=True,noSourceCheckout=True,ssh=SSH))
print('isolated evidence Git ready')
