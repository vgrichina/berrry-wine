from work import *
ri=py('''import pathlib,json,shutil,importlib.util,os
h=pathlib.Path('''+repr(R)+''');spec=importlib.util.spec_from_file_location('s',h/'bounded-staging.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
print(json.dumps(dict(memAvailable=mem,diskFree=shutil.disk_usage('/tmp').free,inventory=s.inventory(h),uid=os.getuid())))''')
save('remote-preguest.json',ri);r=json.loads(ri['stdout'])
assert r['uid']==1000 and r['memAvailable']>=3758096384 and r['diskFree']-4194304>=2982150144
admission('preguest',r['inventory']['physicalOwnedBytes']+4194304)
save('guest-started-local.json',dict(at=time.time()))
save('guest-detach.json',remote('cd '+shlex.quote(R)+' && python3 supervisor.py',detach=True))
ready=py('''import pathlib,time,json
h=pathlib.Path('''+repr(R)+''')
for _ in range(200):
 p=h/'guest/output.log'
 if p.exists() and '[control] listening on http://127.0.0.1:18127/ctl' in p.read_text(errors='replace'):break
 if (h/'guest/terminal.json').exists():raise RuntimeError((h/'guest/terminal.json').read_text())
 time.sleep(.025)
else:raise RuntimeError('control readiness did not arrive in5seconds')
print(json.dumps(dict(ready=True,at=time.time(),command=json.loads((h/'guest/command.json').read_text()))))''',8)
save('guest-ready.json',ready)
print('GUEST READY',flush=True)
