from work import *
dest=O/'retained';dest.mkdir(exist_ok=True)
meta=py('import pathlib,json,hashlib;h=pathlib.Path('+repr(R)+');rows=[]\nfor p in list((h/"guest").glob("*"))+[h/"wire-receipt.json",h/"node-startup.json",h/"guest-args.json"]:\n if p.is_file():rows.append(dict(path=str(p.relative_to(h)),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open("rb"),"sha256").hexdigest()))\nprint(json.dumps(rows))')
rows=json.loads(meta['stdout']);save('remote-evidence-manifest.json',rows)
for x in rows:
 assert x['bytes']<=2097152 if x['path'].endswith('.png') else x['bytes']<=25165824
 p=dest/pathlib.Path(x['path']).name
 with p.open('wb') as f:
  for off in range(0,x['bytes'],5000):
   j=py('import pathlib,base64;p=pathlib.Path('+repr(R+'/'+x['path'])+');f=p.open("rb");f.seek('+str(off)+');print(base64.b64encode(f.read(5000)).decode())');f.write(base64.b64decode(j['stdout']))
 assert p.stat().st_size==x['bytes'] and sha(p.read_bytes())==x['sha256']
print(json.dumps(rows))
