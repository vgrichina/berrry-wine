from work import *
requests=[];pending=False;batch=None;controllerUsed=False
def control(c,timeout=5):
 global pending
 at=time.time();raw=json.dumps(c,separators=(',',':')).encode()
 j=py('import json,urllib.request,time;start=time.time();r=urllib.request.Request("http://127.0.0.1:18127/ctl",data='+repr(raw)+',headers={"Content-Type":"application/json"})\ntry:\n with urllib.request.urlopen(r,timeout='+str(timeout)+') as f:body=f.read(8192)\n print(json.dumps(dict(at=start,ended=time.time(),body=body.decode())))\nexcept Exception as e:\n print(json.dumps(dict(at=start,ended=time.time(),error=repr(e))));raise',timeout+3,allow_exit=True)
 row=dict(submittedAt=at,receivedAt=time.time(),request=c,originalRequest=raw.decode(),startingBatch=batch,pendingBefore=pending,api=j)
 requests.append(row);save('control-requests.json',requests)
 assert j.get('exitCode')==0,'first control transport failure: '+j.get('stdout','')[:1000]
 transport=json.loads(j['stdout']);assert 'body' in transport,transport
 envelope=json.loads(transport['body']);assert envelope.get('ok') is True and 'value' in envelope,envelope
 return envelope['value']
def snapshot():
 global batch
 s=control(dict(action='snapshot'))
 assert s['frozen']['frozen'] is True and s['frozen']['credits']==0 and s['frozen']['recording'] is False,s
 assert not pending
 batch=s['batch'];return s
def step(n):
 global pending,batch
 assert not pending and 1<=n<=256
 start=batch;pending=True
 r=control(dict(action='step',n=n))
 assert r.get('ran')==n and r.get('steps')==n and r.get('frozen') is True,r
 assert r['batch']>=start,r
 pending=False;s=snapshot()
 assert s['batch']==r['batch'],(r,s)
 return s
try:
 # Exactly one exclusive client. Acknowledgement clears the production waiter
 # before resolve (run.js finishPreviousControlBatch); snapshots cannot expose it.
 s=snapshot();save('initial-snapshot.json',s)
 s=step(1);save('first-n1-completion-gate.json',dict(passGate=True,snapshot=s,noPendingEstablishedBy='original acknowledgement and production waiter-clear-before-resolve contract; exclusive sequential client',requests=requests.copy()))
 for n in [4,16,64]+[256]*80:
  if any(w['title']=='Enigma - Main Menu' for w in s.get('windows',[])):break
  assert time.time()-jread('guest-started-local.json')['at']<65,'bounded menu progress budget exhausted'
  s=step(n)
 assert any(w['title']=='Enigma - Main Menu' for w in s.get('windows',[])),'no menu within bounded small increments'
 save('pre-controller-snapshot.json',s)
 controllerUsed=True
 j=remote('cd '+shlex.quote(R)+' && timeout 12 '+shlex.quote(NODE)+' --max-old-space-size=192 click.cjs',15,allow_exit=True);save('click-api.json',j)
 assert j.get('exitCode')==0,'first controller rejection'
 r=json.loads(j['stdout']);assert r.get('enqueueOutcome')=='acknowledged',r
 s=step(1);save('after-click-n1.json',s)
 # At most two post-input PNGs; controller used the first lossless frame slot.
 for i in range(2):
  for _ in range(4):
   if time.time()-jread('guest-started-local.json')['at']>=76:break
   s=step(64)
  save('after-'+str(i)+'-snapshot.json',s)
  save('after-'+str(i)+'-png.json',control(dict(action='png',path=R+'/guest/after-'+str(i)+'.png')))
 save('runtime-outcome.json',dict(status='INPUT_ACKNOWLEDGED_REQUIRES_VISUAL_INSPECTION',controllerUsed=controllerUsed,pending=pending,lastBatch=batch))
except Exception as e:
 save('first-runtime-blocker.json',dict(at=time.time(),error=repr(e),controllerUsed=controllerUsed,pending=pending,lastBatch=batch,requestCount=len(requests),noFurtherInput=True))
 print('BLOCKED',repr(e),flush=True)
finally:
 save('stop-api.json',py('import pathlib;pathlib.Path('+repr(R+'/guest/stop')+').touch()'))
