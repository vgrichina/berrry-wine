from work import *
import tarfile,datetime
rows=jread('control-requests.json');steps=[];snapshots=[]
for row in rows:
 assert row['api']['exitCode']==0
 transport=json.loads(row['api']['stdout']);r=json.loads(transport['body']);assert r['ok'] is True
 v=r['value']
 if row['request']['action']=='step':
  n=row['request']['n'];assert v['ran']==n and v['steps']==n and v['frozen'] is True
  steps.append(dict(n=n,startingBatch=row['startingBatch'],result=v,submittedAt=row['submittedAt'],receivedAt=row['receivedAt']))
 else:
  assert v['frozen']['frozen'] is True and v['frozen']['credits']==0 and v['frozen']['recording'] is False
  snapshots.append(v)
assert len(steps)==84 and sum(x['n'] for x in steps)==20565 and len(snapshots)==85
save('batch-completion-summary.json',dict(stepRequests=len(steps),snapshotRequests=len(snapshots),totalAcknowledgedBatches=sum(x['n'] for x in steps),sequence=[x['n'] for x in steps],steps=steps,finalSnapshot=snapshots[-1],noTransportFailure=True,noPendingStep=True,pendingEvidence='exclusive sequential client; production waiter cleared before acknowledgement resolve; all original replies retained'))
ri=json.loads(jread('cleanup.json')['stdout']);assert not ri['remainingOwnedLive']
receipt=dict(status='BOUNDED_PROGRESS_INCOMPLETE_NO_MENU_GATE',
 result='Exact production small-step completion boundary passed. The helper ended its declared finite sequence after20565 acknowledged batches; final snapshot still Enigma v1.01 while assets initialized. No production error, timeout, lost acknowledgement or authentic guest trap was observed. This is a bounded-progress limitation, not an established runtime defect or exhausted90second hard limit. The target menu/presented-frame gate was not reached, so the controller was never invoked and no input/PNG/gameplay acceptance is claimed.',
 exactBoundary=dict(firstRequest=dict(action='step',n=1),firstGate=jread('first-n1-completion-gate.json'),stepRequests=84,zeroCreditSnapshots=85,totalAcknowledgedBatches=20565,lastSnapshot=snapshots[-1],maxIncrement=256,noOutstandingCredits=True,noReplay=True),
 controllerInvocations=0,clickDispatches=0,gameplayObserved=False,pngs=[],screenshotsInspected=False,
 identity=dict(productionCommit='754c97d3ff22ce0a0cd06d08ac06dc0446fbcbb2',runnerSHA256='87ab63d768eb59a09a8b69df2ccb3843270dd867a67405abd82f02c25c1628e7',controllerSHA256='c4d6c24cc8c0d321b8e6dd17e299116ef4b94fb71899e0f4801e4330cf1adac6',wiredDerivativeSHA256='a9625e1d102883c27b1bd2de0bab560a44ab3bc7eb589b18e7a736100eb2a0da',moduleSHA256='8fac39936b6df2418ad86cab118cef19a65a727f649fbc14c412b37818904686',moduleQualification='historical static-unpack diagnostic; not untouched original/current-main build',inputs=jread('input-verification.json'),sourceModes='original pinned source modes validated; recovered production-file bytes used readonly',route='production headless runner, accepted presented-menu derivative, frozen HTTP control, full tree VFS; no emulator transform/state patch'),
 actualCommand=jread('retained/command.json'),startup=jread('retained/node-startup.json'),wire=jread('retained/wire-receipt.json'),
 runtime=ri['terminal'],resources=dict(cap=67108864,reserve=8388608,remotePhysicalRequired=3758096384,localCivIIReserve=1879048192,localGLReserve=268435456,hostRemainder=805306368,prestage=jread('admission-prestage.json'),preguest=jread('admission-preguest.json'),prepublication=jread('admission-prepublication.json'),remoteAccounting=ri,GitDATA='512MiB Git subprocess only',NodeHeap='2048MiB old space; physical RSS independently monitored, not a cap'),
 incidents=[
 'First local preflight compared recovered-file permission bits to original Git modes and rejected runner/test/run.js. No transfer/guest yet; corrected metadata comparison to exact original pinned Git modes while retaining recovered byte source. All2661 hashes/modes subsequently passed.',
 'Transfer used original bounded30k raw-chunk API recipe. Explicit remote CPU90/file24MiB/wall120 wrapper was added after transfer and before startup/guest. Earlier transfer commands were API-wall-bounded30s and hash/readback verified; no retrospective claim that their inheritedCPU limit was90.',
 'Finite helper sequence1,4,16,64,80x256 ended before menu. Helper assertion is retained as first-runtime-blocker.json; this is not an authentic production rejection. Session stopped once; no new guest/retry/timeout extension.',
 'Postguest conservative hostRAM admission rejected while independent local work still held RAM. No publication Git operation ran after that rejection. Once independent compile completed and measured MemAvailable increased, unchanged cap/reserves passed prepublication gate; original rejection retained.'
 ],
 reusedGroups='29 independent and prior13transform/9protocol/7ambiguity groups reused; no replay, build or source repair',
 lifecycle=dict(box='bx_eugbptb7',state='RUNNING confirmed successful APIexec after guest cleanup',expiry='2026-10-26T22:23:15Z',expirySource='coordinator messageboard supplied',cutoff='2026-10-26T21:35:00Z',handback='immediate on completion',shutdownOwner='coordinator',scheduledShutdown='2026-10-26T21:45:00Z',remainingOwnedGuestProcesses=[],noBoxLifecycleMutation=True),
 remaining=['Menu/presented-frame proof and accepted one-shot atomic Start Game dispatch','ordinary input consumption and gameplay PNG inspection','production renderer qualification; historical static-unpack module limitation remains'],
 recovery='ops.tar.gz contains exact compressed source manifests, source modes, argv, original batch requests/responses/times, destination and startup receipts, API commands/chunk hashes and adapted helpers. Recover binaries only from listed pinned existing sources, reverify all hashes/modes, do not execute against this/old box or replay old100000 request. New execution requires coordinator assignment. No binaries or screenshot claims included.')
save('final-receipt.json',receipt)
e=REPO/E;e.mkdir(parents=True,exist_ok=True)
(e/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(e/'README.md').write_text('Enigma bounded small-step production runtime\n\nExact production n=1 acknowledgement/zero-credit gate PASS.84 sequential steps and85 idle snapshots:20565 acknowledged batches, increments no larger than256. Finite helper sequence ended while final title remained Enigma v1.01 and asset initialization continued. No timeout, production rejection or guest trap was observed; this is incomplete bounded progress, not an established runtime defect.\n\nController invocations0; clicks0; PNGs0; no gameplay acceptance. Guest stopped after41.575s, peak process-tree RSS301293568B/CPU7.08s; no live owned guest processes. bx_eugbptb7 remains RUNNING for coordinator handback, expiry22:23:15UTC, coordinator shutdown21:45. Historical static-unpack wasm identity remains explicit.\n\nreceipt.json and ops.tar.gz retain identities, original request/response timestamps, full input/mode/hash metadata, resource/incident receipts and recovery recipes. No source/game binaries, main merge, installations or other boxes. No new runtime may be inferred from these recipes; coordinator assigns follow-up.\n')
with tarfile.open(e/'ops.tar.gz','w:gz',compresslevel=9) as t:
 for p in sorted(O.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts or p.name.startswith('board-watch') or p.name=='git-commands.jsonl':continue
  t.add(p,arcname=str(p.relative_to(O)),recursive=False)
manifest=[dict(path=str(p.relative_to(e)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(e.iterdir())]
(e/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
remoteBytes=ri['inventory']['physicalOwnedBytes']+sum(x['allocated'] for x in ri['detachedLogs'])
admission('packaged',remoteBytes)
git('add',E);changed=git('diff','--cached','--name-only').splitlines();assert changed and all(x.startswith(E+'/') for x in changed)
git('commit','-m','docs: retain Enigma acknowledged small-step runtime evidence')
commit=git('rev-parse','HEAD');git('push','origin','refs/heads/'+BRANCH+':refs/heads/'+BRANCH)
remoteRef=git('ls-remote','origin','refs/heads/'+BRANCH);assert remoteRef.split()[0]==commit
save('publication.json',dict(commit=commit,branch=BRANCH,remoteRef=remoteRef,changed=changed,evidenceManifestSHA256=sha((e/'evidence-manifest.json').read_bytes())))
print(json.dumps(jread('publication.json')))
