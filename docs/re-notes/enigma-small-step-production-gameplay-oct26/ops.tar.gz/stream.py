from work import *
m=json.loads(gzip.decompress((O/'resolved-inputs.json.gz').read_bytes()));modes=jread('source-modes.json')
send((O/'manifest.json.gz').read_bytes(),'manifest.json.gz');send((D/'tools/enigma-bounded-staging.py').read_bytes(),'bounded-staging.py');send(json.dumps(modes).encode(),'modes.json')
old=(pathlib.Path('/tmp/enigma-verified-input-menu-gameplay-api-oct26/ops/stage.py')).read_text()
driver=old[old.index("driver='''")+10:old.index("'''.replace('ROOT'")].replace('ROOT',repr(R))
send(driver.encode(),'stream-stage.py');remote('mkfifo '+shlex.quote(R+'/stream.fifo'));save('stage-detach.json',remote('python3 '+shlex.quote(R+'/stream-stage.py'),detach=True))
spec=importlib.util.spec_from_file_location('staging',D/'tools/enigma-bounded-staging.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
buf=bytearray();receipts=[]
def flush(force=False):
 while buf and (force or len(buf)>=30000):
  n=min(len(buf),30000)
  while True:
   raw=bytes(buf[:n]);enc=base64.b64encode(zlib.compress(raw)).decode()
   if len(enc)<56000:break
   n//=2
  j=py('import os,base64,zlib,hashlib;data=zlib.decompress(base64.b64decode('+repr(enc)+'));f=os.open('+repr(R+'/stream.fifo')+',os.O_WRONLY);v=memoryview(data)\nwhile v:\n n=os.write(f,v);v=v[n:]\nos.close(f);print(hashlib.sha256(data).hexdigest())')
  assert j['stdout'].strip()==sha(raw);receipts.append(dict(commandId=j.get('commandId'),bytes=n,sha256=sha(raw)));del buf[:n]
for i,x in enumerate(m):
 with s.source(x) as f:
  h=hashlib.sha256();size=0
  while b:=f.read(8192):h.update(b);size+=len(b);buf.extend(b);flush()
  assert size==x['bytes'] and h.hexdigest()==x['sha256'],x
 if i%500==0:print('streamed',i,flush=True)
flush(True);save('stream-transfer.json',receipts)
j=py('import pathlib,time;h=pathlib.Path('+repr(R)+')\nfor i in range(200):\n if (h/"stage-receipt.json").exists():break\n time.sleep(.05)\nprint((h/"stage-receipt.json").read_text())');save('stage-receipt.json',j)
py('import pathlib;h=pathlib.Path('+repr(R)+');[(p.rename(h/p.name)) for p in (h/"payload").iterdir()];(h/"payload").rmdir();(h/"stream.fifo").unlink()')
print('STAGED',flush=True)
