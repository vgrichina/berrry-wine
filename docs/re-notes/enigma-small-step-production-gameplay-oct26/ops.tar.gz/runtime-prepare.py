from work import *
DON=pathlib.Path('/tmp/enigma-tracked-pin-independent-publication-oct26/repo')
REV='754c97d3ff22ce0a0cd06d08ac06dc0446fbcbb2'
ctl=(DON/'tools/enigma-presented-menu-controller.cjs').read_bytes()
assert sha(ctl)=='c4d6c24cc8c0d321b8e6dd17e299116ef4b94fb71899e0f4801e4330cf1adac6'
send(ctl,'controller.cjs')
a=jread('guest-args.json');send(json.dumps(a).encode(),'guest-args.json')
send((pathlib.Path('/tmp/enigma-recovered-lossless-startup-oct24/capture.cjs')).read_bytes(),'capture.cjs')
send((pathlib.Path('/tmp/enigma-accepted-mode-api-single-frame-oct26/repo/tools/lossless-capture-png.cjs')).read_bytes(),'lossless-capture-png.cjs')
wrapper="""const fs=require('fs'),assert=require('assert'),{PNG}=require('./runner/node_modules/pngjs');
const lossless=require('./lossless-capture-png.cjs');const write=fs.writeFileSync;let count=0,total=0;
fs.writeFileSync=function(file,data,...args){if(typeof file==='string'&&file.endsWith('.png')){assert(++count<=3,'capture frame limit');data=lossless.encode(PNG,data,'single-frame');total+=data.length;assert(total<=1048576,'task cumulative capture allocation');process.stderr.write('[capture] lossless '+count+' '+data.length+' bytes\\n');}return write.call(this,file,data,...args)};
"""
send(wrapper.encode(),'capture-wrapper.cjs')
wire="""const fs=require('fs'),crypto=require('crypto'),c=require('./controller.cjs');const src=fs.readFileSync('./runner/test/run.js','utf8');const b=c.wireRunner(src);const hash=crypto.createHash('sha256').update(b).digest('hex');if(hash!=='a9625e1d102883c27b1bd2de0bab560a44ab3bc7eb589b18e7a736100eb2a0da')throw Error('derivative mismatch');fs.writeFileSync('./runner/test/run-presented.cjs',b);console.log(JSON.stringify({source:crypto.createHash('sha256').update(src).digest('hex'),derivative:hash}));"""
send(wire.encode(),'wire.cjs')
send((O/'supervisor.py').read_bytes(),'supervisor.py')
send((O/'click.cjs').read_bytes(),'click.cjs')
code='''import pathlib,json,subprocess,resource,os,hashlib
h=pathlib.Path(ROOT);(h/'guest').mkdir();p=h/'guest/logger-probe';p.open('ab').write(b'append verified\\n');assert p.read_bytes()==b'append verified\\n';p.unlink()
m=json.loads(__import__('gzip').decompress((h/'manifest.json.gz').read_bytes()));modes=json.loads((h/'modes.json').read_text());
for x,mode in zip(m,modes):
 p=h/x['target'];assert (p.stat().st_mode & 0o777)==(0o444 if x['target'].startswith(('runner/fonts/','runtime/fonts/')) else mode),x['target'];assert p.stat().st_size==x['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==x['sha256'],x['target']
a=json.loads((h/'guest-args.json').read_text());env=dict(os.environ);env.pop('WINE_RUN_EXTRA_ARGS',None);env.pop('WINE_REGION_MAP',None)
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
for args in [[a[0],a[1],str(h/'wire.cjs')],[a[0],a[1],a[2],'-e',"console.log(JSON.stringify({executable:process.execPath,version:process.version,argv:process.execArgv,limits:require('fs').readFileSync('/proc/self/limits','utf8'),environment:Object.fromEntries(Object.entries(process.env).filter(([k])=>/^(NODE|ENIGMA|WINE|MAELSTROM)/.test(k))),memory:process.memoryUsage()}))"]]:
 p=subprocess.run(args,cwd=h,env=env,preexec_fn=limits,capture_output=True,text=True,timeout=25);assert len(p.stdout)+len(p.stderr)<8192;(h/('wire-receipt.json' if 'wire.cjs' in args[-1] else 'node-startup.json')).write_text(json.dumps(dict(args=args,exit=p.returncode,stdout=p.stdout,stderr=p.stderr)));assert p.returncode==0,p.stderr
print('PASS destination hashes, logger append, exact wire and Node startup')
'''.replace('ROOT',repr(R))
save('runtime-startup-api.json',py(code,60))
print('RUNTIME PREPARED',flush=True)
