from work import *
OLDOPS=pathlib.Path('/tmp/enigma-accepted-production-click-gameplay-oct26/ops')
save('sqlite-baseline.json',{str(p):allocated(p) for p in pathlib.Path('/home/user/.codex').glob('*sqlite*')})
session=json.loads((L/'events.jsonl').open().readline())['thread_id']
argv=pathlib.Path('/proc/3101879/cmdline').read_bytes().split(b'\0')
assert all(x.encode() in argv for x in ['gpt-6.1-sol','model_reasoning_effort="medium"','model_auto_compact_token_limit=200000','model_auto_compact_token_limit_scope="total"'])
save('launch.json',dict(pid=3101879,session=session,argv=[x.decode() for x in argv if x]))
save('trusted-ssh-config.json',dict(command=SSH,source='user exact trusted launcher checkpoint',rootRefReceipt=json.loads((L/'root-ref-digest.json').read_text())))
b=(OLDOPS/'manifest.json.gz').read_bytes();assert sha(b)=='d5538651a5bfaa9293ee80da79d77d4bcc2cb1172ecab89d9f1f2a9e65a9976e'
(O/'manifest.json.gz').write_bytes(b)
m=json.loads(gzip.decompress(b)); modes=json.loads((OLDOPS/'source-modes.json').read_text())
spec=importlib.util.spec_from_file_location('staging',D/'tools/enigma-bounded-staging.py');st=importlib.util.module_from_spec(spec);spec.loader.exec_module(st);st.validate(m)
# Resolve accepted production files through the already recovered readonly closure.
resolved=[]
for x,mode in zip(m,modes):
 y=dict(x)
 if x['kind']=='git' and x['revision']=='754c97d3ff22ce0a0cd06d08ac06dc0446fbcbb2':
  y=dict(x,kind='file',path='/tmp/civ2-win16-ordinary-gameplay-oct26/source/'+x['path'])
 assert (None if st.font(x['target']) else st.regular_mode(x))==mode,x['target']
 with st.source(y) as f:st.consume(y,f)
 resolved.append(y)
save('resolved-inputs.json.gz.tmp',{})
(O/'resolved-inputs.json.gz.tmp').unlink()
(O/'resolved-inputs.json.gz').write_bytes(gzip.compress(json.dumps(resolved).encode(),mtime=0))
(O/'source-modes.json').write_text(json.dumps(modes))
(O/'replacements.json.gz').write_bytes(gzip.compress((OLDOPS/'replacements.json').read_bytes(),mtime=0))
save('input-verification.json',dict(rows=len(m),logicalBytes=sum(x['bytes'] for x in m),verifiedAll=True,productionFilesFromReadonlyRecoveredClosure=98,originalCompressedManifestSHA256=sha(b),resolvedCompressedManifestSHA256=sha((O/'resolved-inputs.json.gz').read_bytes())))
a=[x.replace(str(OLDOPS.parent),R) for x in json.loads((OLDOPS/'guest-args.json').read_text())];save('guest-args.json',a)
src=pathlib.Path(resolved[0]['path']).read_text();parser=src[src.index('const getArg ='):src.index('// Was `--name=...`')]
idx=a.index(R+'/runner/test/run-presented.cjs')
code='const assert=require("assert"),args='+json.dumps(a[idx+1:])+';'+parser+';assert.deepEqual(getArgs("vfs-tree"),['+json.dumps(R+'/vfs')+']);assert.equal(getArgs("vfs-mount").length,0);assert.equal(getArgs("dlls").length,8);assert(hasFlag("no-build"));assert(hasFlag("frozen"));console.log("PASS exact filename-bearing production argv")'
p=subprocess.run(['node','--max-old-space-size=192','-e',code],capture_output=True,text=True,timeout=25)
save('canonical-parser.json',dict(exit=p.returncode,stdout=p.stdout,stderr=p.stderr,parserSHA256=sha(parser.encode()),argv=a,enumeration=[x['target'] for x in m if x['target'].startswith('vfs/')],commaFilenames=[x['target'] for x in m if ',' in x['target']]))
assert p.returncode==0,p.stderr
admission('prestage',45973504)
save('remote-prestage.json',py('import pathlib,json,shutil,resource,os;print(json.dumps(dict(uid=os.getuid(),memAvailable=int(pathlib.Path("/proc/meminfo").read_text().split("MemAvailable:")[1].split()[0])*1024,diskFree=shutil.disk_usage("/tmp").free,limits={k:resource.getrlimit(getattr(resource,k)) for k in ["RLIMIT_DATA","RLIMIT_AS","RLIMIT_FSIZE","RLIMIT_CPU"]})))'))
r=json.loads(jread('remote-prestage.json')['stdout']);assert r['uid']==1000 and r['memAvailable']>=3758096384 and r['diskFree']-67108864>=2982150144
remote('test ! -e '+shlex.quote(R)+' && mkdir '+shlex.quote(R))
b=os.urandom(32769);r=send(b,'transfer-control.bin');assert json.loads(r['stdout'])==dict(bytes=len(b),sha256=sha(b));save('transfer-control.json',dict(bytes=len(b),sha256=sha(b),readback=r))
py('import pathlib;pathlib.Path('+repr(R+'/transfer-control.bin')+').unlink()')
print('PASS all2661 exact source hashes/modes, canonical argv, local/remote admission, transfer readback',flush=True)
