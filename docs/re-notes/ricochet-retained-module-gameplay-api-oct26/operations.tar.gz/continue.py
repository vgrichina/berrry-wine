from work import *
OLD='/tmp/ricochet-current-gameplay-api-oct26'
SESSION='01a17a1a-854a-7fa2-9f81-754914eef19a'
L=ROOT/'scratch/usage-watch/ricochet-retained-module-gameplay-api-oct26'
def gate(stage,remoteBytes,future=33554432):
 base=json.loads(pathlib.Path(OLD+'/ops/sqlite-baseline.json').read_text())
 wal=sum(max(0,allocated(pathlib.Path(p))-v) for p,v in base.items() if p.endswith('-wal'))
 session=next(pathlib.Path('/home/user/.codex/sessions/2026/10/26').glob('*'+SESSION+'.jsonl'))
 charges=dict(retainedAndNewRemote=remoteBytes,localIncludingGit=allocated(H),launcherEvents=allocated(L)+sum(allocated(pathlib.Path(str(L)+s)) for s in ['.task.txt','.task.runtime.json','-dispatch.json']),session=allocated(session),positiveWALOnce=wal,prospectiveGrowthPublicationGitSession=future,reserve=8388608)
 mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
 free=shutil.disk_usage(H).free
 r=dict(stage=stage,charges=charges,total=sum(charges.values()),cap=134217728,memAvailable=mem,aggregateRAMMinimum=2550136832,ramReservations=dict(Civ=805306368,GL=268435456,localHelper=67108864,remoteHelper=67108864,prospectiveClient=335544320,host=805306368),residentClientsAlreadyDeducted=True,hostFree=free,hostProjectedFree=free-future,hostFloor=2982150144,walBaseline=OLD+'/ops/sqlite-baseline.json',cacheCountedOnce=True)
 r['pass']=r['total']<=r['cap'] and free-future>=r['hostFloor'] and mem>=r['aggregateRAMMinimum'];save('admission-'+stage+'.json',r);assert r['pass'],r;return r
if __name__=='__main__':
 gate('before-recovery',50524160+1880280+131072)
 b=pathlib.Path('/home/user/wine-assembly/scratch/recovery/civ2-win16-retained-canonical-oct26/canonical.wasm').read_bytes()
 assert len(b)==1880280 and sha(b)=='f3f3cd439c50a2bc441de67c5f138e32cc060186d84d37d85de2b200ca806d75'
 # Only the authorized retained module writes to predecessor's expected runtime path.
 import work
 work.R=OLD
 save('module-recovery-api.json',send(b,'canonical.wasm'))
 work.R=str(H)
 manifest=jread('assets.json')+jread('runner.json')
 send(json.dumps(manifest).encode(),'validation.json')
 code='''import pathlib,json,hashlib,time
h=pathlib.Path(OLD);n=pathlib.Path(NEW);a=json.loads((n/'validation.json').read_text())
for x in a:
 p=h/x['target'];assert p.stat().st_size==x['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==x['sha256'],x['target'];assert p.stat().st_mode&511==x['mode'],x['target']
print(json.dumps(dict(verified=len(a),at=time.time(),moduleSHA256=hashlib.file_digest((h/'canonical.wasm').open('rb'),'sha256').hexdigest(),missingAPITable=not (h/'runner/src/api_table.json').exists(),remoteAllocated=sum(p.lstat().st_blocks*512 for root in [h,n] for p in [root,*root.rglob('*')]),memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024)))
'''.replace('OLD',repr(OLD)).replace('NEW',repr(str(H)))
 r=py(code);save('runtime-identity-api.json',r);v=json.loads(r['stdout']);gate('after-recovery',v['remoteAllocated'])
 print(json.dumps(v))
