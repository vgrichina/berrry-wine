from work import *
# Adapt the bounded identity-aware process-tree supervisor to both compile and guest.
s=pathlib.Path('/tmp/enigma-small-step-production-gameplay-oct26/ops/supervisor.py').read_text().replace("CUTOFF=1793050500","CUTOFF=1793051400").replace("a=json.loads((H/'guest-args.json').read_text());env=dict(os.environ)","name=sys.argv[1];a=json.loads((H/(name+'-args.json')).read_text());E=H/name;env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/home/user','LANG':'C.UTF-8','TZ':'UTC','NODE_PATH':str(H/'runner/node_modules')};E.mkdir(exist_ok=True)")
s=s.replace("wallGuest=89","wallGuest=(89 if name=='guest' else 119)").replace("time.monotonic()-start>=89","time.monotonic()-start>=(89 if name=='guest' else 119)").replace("if n+len(b)>131072","if n+len(b)>2097152").replace("box='bx_eugbptb7'","box='bx_ex22dvm8'")
(O/'supervisor.py').write_text(s);send(s.encode(),'supervisor.py')
compilecode="const fs=require('fs'),crypto=require('crypto');const b=require('./runner/test/compile-src').compileSrcWasm();fs.writeFileSync(__dirname+'/canonical.wasm',b);console.log(JSON.stringify({bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),method:'compileSrcWasm()',transform:null}));"
send(compilecode.encode(),'compile.cjs')
# Same executable/heap/env/limits for startup, compilation and production runner.
a=[NODE,'--max-old-space-size=2048',R+'/compile.cjs'];save('compile-args.json',a);send(json.dumps(a).encode(),'compile-args.json')
code='''import pathlib,subprocess,resource,json,os
h=pathlib.Path(ROOT);(h/'diagnostics').mkdir();p=h/'diagnostics/append.txt';p.open('ab').write(b'probe\\n');assert p.read_bytes()==b'probe\\n'
a=json.loads((h/'compile-args.json').read_text());env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/home/user','LANG':'C.UTF-8','TZ':'UTC','NODE_PATH':str(h/'runner/node_modules')}
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
p=subprocess.run(a[:2]+['-e',"console.log(JSON.stringify({executable:process.execPath,version:process.version,flags:process.execArgv,limits:require('fs').readFileSync('/proc/self/limits','utf8'),environment:process.env,memory:process.memoryUsage()}))"],env=env,preexec_fn=limits,capture_output=True,text=True,timeout=20);r=dict(exit=p.returncode,stdout=p.stdout,stderr=p.stderr);(h/'node-startup.json').write_text(json.dumps(r));print(json.dumps(r));assert p.returncode==0
'''.replace('ROOT',repr(R))
save('node-startup-api.json',py(code));save('compile-launch.json',remote('cd '+shlex.quote(R)+' && python3 supervisor.py compile',detach=True))
