from work import *
import importlib
c=importlib.import_module('continue')
OLD=c.OLD
# Predecessor explicitly removed this optional browser bundle for publication;
# the Node pngjs entry and closure remain required and are verified below.
a=[x for x in jread('assets.json')+jread('runner.json') if x['target']!='runner/node_modules/pngjs/browser.js']
save('validation.json',a);send(json.dumps(a).encode(),'validation.json')
code='''import pathlib,json,hashlib,time
h=pathlib.Path(OLD);n=pathlib.Path(NEW);a=json.loads((n/'validation.json').read_text())
for x in a:
 p=h/x['target'];assert p.stat().st_size==x['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==x['sha256'],x['target'];assert p.stat().st_mode&511==x['mode'],x['target']
(n/'diagnostics').mkdir(exist_ok=True);p=n/'diagnostics/append.txt';p.open('ab').write(b'probe\\n');assert p.read_bytes().endswith(b'probe\\n')
print(json.dumps(dict(verified=len(a),at=time.time(),moduleSHA256=hashlib.file_digest((h/'canonical.wasm').open('rb'),'sha256').hexdigest(),missingAPITable=not (h/'runner/src/api_table.json').exists(),remoteAllocated=sum(p.lstat().st_blocks*512 for root in [h,n] for p in [root,*root.rglob('*')]),memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024)))
'''.replace('OLD',repr(OLD)).replace('NEW',repr(str(H)))
r=jread('runtime-identity-api.json');v=json.loads(r['stdout']);assert v['memAvailable']>=3758096384
args=jread('guest-args.json')
parser=jread('canonical-parser.json');assert args[3:]==parser['argv']
src=pathlib.Path('/tmp/civ2-win16-ordinary-gameplay-oct26/source/test/run.js').read_text();part=src[src.index('const getArg ='):src.index('// Was `--name=...`')]
assert sha(part.encode())==parser['parserSHA256']
save('configuration-reuse.json',dict(argv=args,canonicalParserReceipt='canonical-parser.json',parserSHA256=sha(part.encode()),manifestFiles=len(parser['enumerated']),commaFiles=parser['commaFilenames'],startupReceipt=OLD+'/ops/guest-preflight-api.json',startupReused=True,unchangedExecutableFlagsEnvironmentLimits=True,optionalOmittedDocumentedFile='runner/node_modules/pngjs/browser.js',firstHelperIncident='first-api-rejection.json'))
send(json.dumps(args).encode(),'guest-args.json');send((O/'supervisor.py').read_bytes(),'supervisor.py')
c.gate('before-execution',v['remoteAllocated']+65536)
assert time.time()+120<1793051400
r=remote('python3 '+shlex.quote(str(H/'supervisor.py'))+' guest',timeout=20,allow_exit=True)
save('production-invocation-api.json',r)
print(json.dumps(r))
