from work import *
a=jread('guest-args.json');send(json.dumps(a).encode(),'guest-args.json')
# Enforce requested lossless PNG bounds without modifying runner or guest state.
wrapper="""const fs=require('fs'),assert=require('assert'),write=fs.writeFileSync;let count=0,total=0;fs.writeFileSync=function(p,b,...a){if(typeof p==='string'&&p.endsWith('.png')){assert(b.readUInt32BE(16)<=800&&b.readUInt32BE(20)<=600);assert(b.length<=2097152);assert(++count<=3);total+=b.length;assert(total<=786432,'task capture allocation');}return write.call(this,p,b,...a)};"""
send(wrapper.encode(),'capture-bounds.cjs');a.insert(2,'--require='+R+'/capture-bounds.cjs');save('guest-args.json',a);send(json.dumps(a).encode(),'guest-args.json')
# Startup again only because require flag changes executable configuration.
code='''import pathlib,json,subprocess,resource,os,hashlib,shutil
h=pathlib.Path(ROOT);a=json.loads((h/'guest-args.json').read_text());assert int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024>=3758096384
assets=json.loads(ASSETS)
for x in assets:
 p=h/x['target'];assert p.stat().st_size==x['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==x['sha256'];assert (p.stat().st_mode&0o777)==x['mode']
env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/home/user','LANG':'C.UTF-8','TZ':'UTC','NODE_PATH':str(h/'runner/node_modules')}
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
p=subprocess.run(a[:3]+['-e',"console.log(JSON.stringify({executable:process.execPath,version:process.version,flags:process.execArgv,limits:require('fs').readFileSync('/proc/self/limits','utf8'),environment:process.env,memory:process.memoryUsage()}))"],env=env,preexec_fn=limits,capture_output=True,text=True,timeout=20);r=dict(exit=p.returncode,stdout=p.stdout,stderr=p.stderr);(h/'guest-node-startup.json').write_text(json.dumps(r));assert p.returncode==0,p.stderr
(h/'guest-validation.json').unlink()
print(json.dumps(dict(destinationVerified=len(assets),startup=r,allocated=sum(p.lstat().st_blocks*512 for p in [h,*h.rglob('*')]))))
'''.replace('ROOT',repr(R)).replace('ASSETS',repr(json.dumps(jread('assets.json')+jread('runner.json'))))
# Bound request under60k: put validation manifest separately.
send(json.dumps(jread('assets.json')+jread('runner.json')).encode(),'guest-validation.json');start=code.index('assets=json.loads(');end=code.index('\nfor x in assets:',start);code=code[:start]+"assets=json.loads((h/'guest-validation.json').read_text())"+code[end:]
r=py(code);save('guest-preflight-api.json',r);v=json.loads(r['stdout']);admission('preguest',v['allocated']+786432+131072)
print('PASS preguest destination hashes/modes/startup/admission')
