from work import *
import importlib,datetime,tarfile
c=importlib.import_module('continue');work=importlib.import_module('work')
E='docs/re-notes/ricochet-retained-module-gameplay-api-oct26';BRANCH='task/ricochet-retained-module-gameplay-api-oct26'
work.E=E
stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
hand=py('''import pathlib,json,hashlib,time
roots=[pathlib.Path('/tmp/ricochet-current-gameplay-api-oct26'),pathlib.Path('/tmp/ricochet-retained-module-gameplay-api-oct26')]
t=json.loads((roots[1]/'guest/terminal.json').read_text());live=[]
for pid,s in t['identities'].items():
 p=pathlib.Path('/proc')/pid/'stat'
 if p.exists():
  q=p.read_text();a=q[q.rfind(')')+2:].split()
  if a[19]==s['start'] and a[0]!='Z':live.append(pid)
assert not live
print(json.dumps(dict(at=time.time(),remoteAllocated=sum(p.lstat().st_blocks*512 for h in roots for p in [h,*h.rglob('*')]),ownedLive=live,box='bx_ex22dvm8',state='RUNNING APIexec',moduleSHA256=hashlib.file_digest((roots[0]/'canonical.wasm').open('rb'),'sha256').hexdigest(),shutdownOwner='coordinator',expiry='2026-10-26T22:31:02.949Z')))
''');save('handback-api.json',hand);remoteBytes=json.loads(hand['stdout'])['remoteAllocated']
gate=c.gate('publication',remoteBytes)
REPO.mkdir(exist_ok=True);git('init','-b',BRANCH);git('remote','add','origin',URL)
git('config','user.name','Wine Ops');git('config','user.email','wine-ops@local')
e=REPO/E;e.mkdir(parents=True)
receipt=dict(status='HARNESS_STARTUP_ENOENT_BEFORE_GUEST',productionInvocations=1,guestLaunches=0,guestSeconds=0,batches=0,inputTransitions=[],PNGs=[],gameplayObserved=False,sourceMain=C,productionRunnerSHA256='87ab63d768eb59a09a8b69df2ccb3843270dd867a67405abd82f02c25c1628e7',moduleRecovery=jread('module-recovery-api.json'),runtimeIdentity=jread('runtime-identity-api.json'),configuration=jread('configuration-reuse.json'),terminal=jread('terminal.json'),command=jread('command.json'),firstRuntimeFailure=(O/'output.log').read_text(),resourceAdmission=gate,handback=hand,historical=dict(commit='a4bd44da43adbbdc0aff3e1a2541ca6cb63e9806',branch='task/ricochet-current-gameplay-api-oct26',preguestProjection=70623232,oldCap=67108864,preguestDeficit=3514368,finalAccounting=67223552,finalOverrun=114688,retrospectiveCompliance=False,cacheCountedOnce=True),incidents=['Initial verification used original509-file manifest including optional pngjs/browser.js explicitly deleted by predecessor; corrected to508 unchanged retained files, no restaging. First API failure retained.','Local guest-args receipt had been archived by predecessor; corrected own helper to use already extracted receipt, no runtime attempt consumed.'],qualification='Actual guest/gameplay not reached. Pinned test/run.js unconditionally reads absent runner/src/api_table.json at2719 before instantiation. This is a missing runtime metadata prerequisite, not an allocation failure, guest trap, timeout, loading result or missing game asset. Scope authorizes retained module recovery only; no supplemental source JSON staged. No repeated build, full staging or runtime retry.',remaining='Coordinator may authorize supplemental exact pinned src/api_table.json and another bounded actual gameplay attempt, reusing recovered module and unchanged staged inputs.',lifecycle=dict(guestCutoff='2026-10-26T21:50:00Z',handback=stamp,shutdown='2026-10-26T22:00:00Z',expiry='2026-10-26T22:31:02.949Z',watchPID=3114879,watchUntouched=True,box='bx_ex22dvm8',state='RUNNING',shutdownOwner='coordinator'))
(e/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(e/'README.md').write_text('Ricochet retained-module production invocation: startup blocked\n\nRecovered exactly1880280B canonical wasm SHA256 f3f3cd439c50a2bc441de67c5f138e32cc060186d84d37d85de2b200ca806d75 to predecessor expected path by bounded API and verified readback. No compilation/source checkout/full asset restaging. Verified508 retained runtime/asset files and modes; optional Node-unused pngjs/browser.js was previously documented deleted. Exact production registered ricochet_xtreme argv, manifest parser and unchanged Node24.22.1 heap2048/startup/environment/limits receipt reused. Required IFC22.dll and Ricochet.exe verified.\n\nFresh complete128MiB admission passed, retained cache counted once; ledger includes local/remote/Git/session/events/positive WAL once,32MiB prospective growth and8MiB reserve. No historical64MiB compliance claim: prior projection70623232 exceeded67108864 by3514368; prior final67223552 exceeded by114688.\n\nONE actual production invocation naturally exits1 after0.182805338s, CPU0.13s, sampled peak process-treeRSS80551936B,972 log bytes. ENOENT runner/src/api_table.json at unchanged test/run.js2719 before guest instantiation. Guest0s, batches0, inputs0, PNG0; no gameplay/guest trap/hang claim. No unchanged retry or additional file staging.\n\noperations.tar.gz retains exact recovery/transfer/supervision/publication recipes and metadata, identities, argv, limits reuse and failures. No game/source/module binary published. Supplemental exact pinned src/api_table.json is the next prerequisite requiring coordinator assignment. bx_ex22dvm8 remainsRUNNING; owned guest childrenNONE, retained module preserved; coordinator owns22:00UTC shutdown, expiry22:31:02.949Z, watch3114879 untouched.\n')
with tarfile.open(e/'operations.tar.gz','w:gz') as t:
 for p in sorted(O.iterdir()):
  if p.is_file() and p.name!='api-history.jsonl':t.add(p,arcname=p.name)
# Keep complete transport request metadata too; commands over1800B are hashes only.
with tarfile.open(e/'transport.tar.gz','w:gz') as t:t.add(O/'api-history.jsonl',arcname='api-history.jsonl')
runid='20261026T212734Z-reflexive-ricochet-xtreme-retained-module';run=ROOT/'scratch/runs'/runid;run.mkdir(exist_ok=False)
shutil.copy2(O/'output.log',run/'output.log');shutil.copy2(O/'terminal.json',run/'terminal.json')
r=dict(candidateId='reflexive-ricochet-xtreme',agentId='codex:'+c.SESSION,startedAt='2026-10-26T21:27:34.569Z',finishedAt='2026-10-26T21:27:34.803Z',outcome='harness-error',route='production runner startup before guest',appId='ricochet_xtreme',command=jread('command.json')['argv'],build=dict(commit=C,wasmSha256=receipt['runtimeIdentity'] and json.loads(receipt['runtimeIdentity']['stdout'])['moduleSHA256']),environment=dict(box='bx_ex22dvm8',node='24.22.1',renderer='not initialized'),summary='One actual production invocation: ENOENT runner/src/api_table.json at test/run.js2719 before guest. Guest0/batches0/input0/PNG0; no gameplay or game failure. Exact retained module recovered;128MiB resource gate passed.',verification='reviewed',artifacts=['output.log','terminal.json'])
(run/'result.json.tmp').write_text(json.dumps(r,indent=2)+'\n');(run/'result.json.tmp').rename(run/'result.json');save('dashboard.json',dict(runId=runid,path=str(run)))
manifest=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in e.iterdir()];(e/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for x in manifest:assert sha((e/x['path']).read_bytes())==x['sha256']
# Existing containment/schema checker, isolated to this run; no behavioral rerun.
check=H/'check';(check/'scratch/runs').mkdir(parents=True);shutil.copytree(run,check/'scratch/runs'/runid)
p=subprocess.run(['node','--max-old-space-size=32',str(ROOT/'ops/check-run-evidence.js'),str(check)],capture_output=True,text=True,timeout=25);save('evidence-check.json',dict(exit=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stderr;shutil.rmtree(check)
c.gate('before-commit',remoteBytes);git('add',E);files=git('diff','--cached','--name-only').splitlines();assert len(files)==5 and all(x.startswith(E+'/') for x in files)
git('commit','-m','docs: record Ricochet module recovery and runner startup blocker');commit=git('rev-parse','HEAD');c.gate('before-push',remoteBytes)
git('push','origin','refs/heads/'+BRANCH+':refs/heads/'+BRANCH);ref=git('ls-remote','origin','refs/heads/'+BRANCH);assert ref.split()[0]==commit
save('publication.json',dict(commit=commit,branch=BRANCH,remoteRef=ref,evidence=str(e),dashboard=str(run),gitDataLimit=536870912,trustedSSH=SSH));c.gate('final',remoteBytes);print(json.dumps(jread('publication.json')))
