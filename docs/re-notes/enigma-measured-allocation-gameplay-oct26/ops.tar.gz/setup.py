from work import *
OLDOPS=pathlib.Path('/tmp/enigma-small-step-production-gameplay-oct26/ops')
N=R+'/presented-menu';save('sqlite-baseline.json',{str(p):allocated(p) for p in pathlib.Path('/home/user/.codex').glob('*sqlite*')})
session=json.loads((L/'events.jsonl').open().readline())['thread_id']
save('launch.json',dict(session=session,worker='fresh single-task; no descendants launched'))
save('trusted-ssh-config.json',dict(command=SSH,rootRefReceipt=json.loads((L/'root-ref-digest.json').read_text())))
for name in ['canonical-parser.json','input-verification.json','guest-args.json','runtime-startup-api.json']:
 save('reused-'+name,dict(path=str(OLDOPS/name),sha256=sha((OLDOPS/name).read_bytes()),unchangedReceipt=True))
# No mount/runner/capture arguments change. Reuse exact canonical enumeration,
# including comma-bearing filenames, and verify the remote argv byte-for-byte.
code='''import pathlib,json,hashlib,resource,shutil,os,importlib.util
h=pathlib.Path(ROOT);n=h/'measured-allocation';assert not n.exists();n.mkdir();(n/'guest').mkdir()
p=n/'guest/logger-probe';p.open('ab').write(b'append verified\\n');assert p.read_bytes()==b'append verified\\n';p.unlink()
pins={'runner/test/run.js':'87ab63d768eb59a09a8b69df2ccb3843270dd867a67405abd82f02c25c1628e7','runner/test/run-presented.cjs':'a9625e1d102883c27b1bd2de0bab560a44ab3bc7eb589b18e7a736100eb2a0da','controller.cjs':'c4d6c24cc8c0d321b8e6dd17e299116ef4b94fb71899e0f4801e4330cf1adac6','click.cjs':'8574aa3a46e9b969083cca5d85e2ace502d8e7dc4241ed352bf594e097c2e7d9','runtime/build/wine-assembly.wasm':'8fac39936b6df2418ad86cab118cef19a65a727f649fbc14c412b37818904686'}
for p,want in pins.items():assert hashlib.file_digest((h/p).open('rb'),'sha256').hexdigest()==want,p
assert json.loads((h/'guest-args.json').read_text())==ARGV
old=json.loads((h/'bounded-progress/guest/terminal.json').read_text());assert not old['remainingOwnedLive']
for pid,s in old['identities'].items():
 p=pathlib.Path('/proc')/pid/'stat'
 if p.exists():
  t=p.read_text();v=t[t.rfind(')')+2:].split();assert v[19]!=s['start'] or v[0]=='Z'
m=json.loads(__import__('gzip').decompress((h/'manifest.json.gz').read_bytes()));modes=json.loads((h/'modes.json').read_text())
for x,mode in zip(m,modes):
 p=h/x['target'];assert (p.stat().st_mode & 0o777)==(0o444 if x['target'].startswith(('runner/fonts/','runtime/fonts/')) else mode),x['target'];assert p.stat().st_size==x['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==x['sha256'],x['target']
assert len(m)==len(modes)==2661
spec=importlib.util.spec_from_file_location('s',h/'bounded-staging.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
print(json.dumps(dict(pins=pins,argvUnchanged=True,loggerAppend=True,oldGuestClean=True,inventory=s.inventory(h),memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024,diskFree=shutil.disk_usage('/tmp').free,limits={k:resource.getrlimit(getattr(resource,k)) for k in ['RLIMIT_DATA','RLIMIT_AS','RLIMIT_CPU','RLIMIT_FSIZE']})))
'''.replace('ROOT',repr(R)).replace('ARGV',repr(jread('guest-args.json')) if (O/'guest-args.json').exists() else repr(json.loads((OLDOPS/'guest-args.json').read_text())))
save('readback.json',py(code))
for name in ['supervisor.py','operate.py','click.cjs']:
 b=(O/name).read_bytes();save('adapter-'+name+'.json',dict(sha256=sha(b),bytes=len(b)));send(b,'measured-allocation/'+name)
print('retained readback and adapters ready')
