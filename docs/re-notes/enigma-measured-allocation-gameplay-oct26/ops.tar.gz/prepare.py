import pathlib,json,shutil
OLD=pathlib.Path('/tmp/enigma-presented-menu-progress-gameplay-oct26/ops')
O=pathlib.Path(__file__).parent
for name in ['work.py','setup.py','supervisor.py','operate.py','click.cjs','exact-closeout.py']:
 s=(OLD/name).read_text().replace('enigma-presented-menu-progress-gameplay-oct26','enigma-measured-allocation-gameplay-oct26')
 if name in ['setup.py','exact-closeout.py']:
  s=s.replace("'presented-menu'","'measured-allocation'").replace("'presented-menu/","'measured-allocation/")
 if name=='supervisor.py':
  s=s.replace('CUTOFF=1793050500','CUTOFF=1793050680').replace('free-67108864','free-134217728')
 (O/name).write_text(s)
