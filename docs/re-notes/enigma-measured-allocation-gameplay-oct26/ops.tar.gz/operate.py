import pathlib,json,time,subprocess,urllib.request,gzip,os
H=pathlib.Path(__file__).parent;E=H/'guest';R=H.parent
def save(name,j):(E/name).write_text(json.dumps(j,separators=(',',':')))
requests=0;steps=0;total=0;snapshots=0;pending=False;batch=None;clicked=False
trace=gzip.open(E/'requests.jsonl.gz','wt',compresslevel=6)
def control(c):
 global requests
 raw=json.dumps(c,separators=(',',':'));row=dict(at=time.time(),request=raw,startingBatch=batch,pending=pending)
 try:
  req=urllib.request.Request('http://127.0.0.1:18127/ctl',data=raw.encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=2) as f:b=f.read(8193)
  assert len(b)<=8192,'response limit'
  row['originalResponse']=b.decode();v=json.loads(b);assert v.get('ok') is True,v
  return v['value']
 except Exception as ex:
  row['error']=repr(ex);raise
 finally:
  row['ended']=time.time();trace.write(json.dumps(row,separators=(',',':'))+'\n');trace.flush();requests+=1
def snapshot():
 global batch,snapshots
 assert not pending
 s=control({'action':'snapshot'});assert s['frozen']['frozen'] is True and s['frozen']['credits']==0 and s['frozen']['recording'] is False,s
 batch=s['batch'];snapshots+=1;return s
def step(n):
 global pending,steps,total
 assert not pending and 1<=n<=256
 pending=True;r=control(dict(action='step',n=n))
 assert r['ran']==n and r['steps']==n and r['frozen'] is True,r
 pending=False;s=snapshot();assert s['batch']==r['batch'];steps+=1;total+=n
 return s
def elapsed():return time.time()-json.loads((E/'command.json').read_text())['at']
p=subprocess.Popen(['python3',str(H/'supervisor.py')],stdout=subprocess.DEVNULL,stderr=(E/'supervisor-error.log').open('wb'))
status='NOT_STARTED'
try:
 start=time.monotonic()
 while not (E/'output.log').exists() or '[control] listening on http://127.0.0.1:18127/ctl' not in (E/'output.log').read_text(errors='replace'):
  assert time.monotonic()-start<5,'control readiness';assert p.poll() is None,'supervisor ended';time.sleep(.01)
 s=snapshot();save('initial-snapshot.json',s);s=step(1);save('first-n1-completion-gate.json',dict(snapshot=s,acknowledged=True,noOutstandingCredits=True))
 # No title-based exit: bounded elapsed progression to a canonical read-only frame.
 while elapsed()<65:
  s=step(256)
  assert not s.get('quit'), 'guest quit/trap'
  assert (E/'requests.jsonl.gz').stat().st_size<1048576,'compressed trace allocation'
 save('pre-qualification-snapshot.json',s)
 qualified=control(dict(action='png',path=str(E/'qualification.png')))
 frame=control(dict(action='eval',code="(()=>{const f=process.getBuiltinModule('fs'),c=process.getBuiltinModule('crypto'),p="+json.dumps(str(E/'qualification.png'))+";const b=f.readFileSync(p);return {batch:tickState.batch,bytes:b.length,width:b.readUInt32BE(16),height:b.readUInt32BE(20),sha256:c.createHash('sha256').update(b).digest('hex')}})()"))
 save('read-only-frame-qualification.json',dict(png=qualified,readback=frame,snapshot=s,expectedSHA256='8ffead1b04adbe5fac8d82c5a374375f5883898b29e87962d72c3c3e26da18d5'))
 matched=frame['sha256']=='8ffead1b04adbe5fac8d82c5a374375f5883898b29e87962d72c3c3e26da18d5' and frame['width']==640 and frame['height']==480 and frame['batch']==s['batch']==qualified['batch']
 if matched and elapsed()<77:
  save('pre-controller-snapshot.json',s)
  a=json.loads((R/'guest-args.json').read_text());q=subprocess.run([a[0],'--max-old-space-size=192',str(H/'click.cjs')],cwd=H,capture_output=True,text=True,timeout=min(6,82-elapsed()))
  save('controller-process-result.json',dict(exit=q.returncode,stdout=q.stdout,stderr=q.stderr));assert q.returncode==0,'controller rejection'
  result=json.loads(q.stdout);assert result['enqueueOutcome']=='acknowledged';clicked=True
  s=step(1);save('after-click-n1.json',s)
  until=min(elapsed()+5,82)
  while elapsed()<until:s=step(256)
  save('after-gameplay-snapshot.json',s);control(dict(action='png',path=str(E/'after-gameplay.png')))
  status='INPUT_ACKNOWLEDGED_REQUIRES_PIXEL_INSPECTION'
 else:
  # Expected loading is an observation, not a rejected dispatch. Continue the
  # same exclusive acknowledged progression to the elapsed budget, no input.
  while elapsed()<82:s=step(256)
  save('bounded-final-snapshot.json',s)
  control(dict(action='png',path=str(E/'bounded-final.png')))
  status='ELAPSED_PROGRESS_NO_QUALIFIED_MENU_NO_DISPATCH'
except Exception as ex:
 status='FIRST_RUNTIME_REJECTION';save('first-runtime-rejection.json',dict(error=repr(ex),at=time.time(),pending=pending,clicked=clicked))
finally:
 trace.close();save('outcome.json',dict(status=status,stepRequests=steps,acknowledgedBatches=total,snapshots=snapshots,requests=requests,pending=pending,lastBatch=batch,controllerAcknowledged=clicked,elapsed=elapsed() if (E/'command.json').exists() else None))
 (E/'stop').touch();p.wait(timeout=3)
