from work import *
from gate import gate
v=json.loads(jread('cleanup-readback.json')['stdout']);rb=v['inventory']['physicalOwnedBytes']+sum(x['allocated'] for x in v['detachedLogs'])
gate('immediate-prepublication',remoteBytes=rb,future=33554432)
def smallgit(*args,repo=REPO):
 out=git(*args,repo=repo)
 rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss*1024
 save('git-peak-rss.json',dict(peakChildRSS=rss,cap=67108864,DATA=536870912,parentDATA=resource.getrlimit(resource.RLIMIT_DATA),parentAS=resource.getrlimit(resource.RLIMIT_AS)))
 assert rss<=67108864,'Git child RSS cap'
 return out
assert not (REPO/'.git').exists()
smallgit('init','-q',str(REPO),repo=H)
for k,vv in [('user.name','Wine Ops'),('user.email','wine-ops@local'),('core.sshCommand',SSH),('gc.auto','0')]:smallgit('config',k,vv)
smallgit('symbolic-ref','HEAD','refs/heads/'+BRANCH);smallgit('remote','add','origin',URL)
smallgit('add',E);changed=smallgit('diff','--cached','--name-only').splitlines();assert all(x.startswith(E+'/') for x in changed)
smallgit('diff','--cached','--check')
smallgit('commit','-m','docs: record measured Enigma gameplay attempt and predecessor receipts')
commit=smallgit('rev-parse','HEAD');smallgit('push','origin','refs/heads/'+BRANCH+':refs/heads/'+BRANCH)
ref=smallgit('ls-remote','origin','refs/heads/'+BRANCH);assert ref.split()[0]==commit
save('publication.json',dict(commit=commit,branch=BRANCH,remoteRef=ref,changed=changed,normalPush=True,independentEvidenceRoot=True))
print(json.dumps(jread('publication.json')))
