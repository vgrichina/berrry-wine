from work import *
from gate import gate
assert time.time()+100<1793050680,'insufficient useful window'
assert pathlib.Path('/proc/3103171/cmdline').exists(),'shutdown watch absent'
readback=json.loads(jread('readback.json')['stdout'])
assert readback['argvUnchanged'] and readback['oldGuestClean'] and readback['loggerAppend']
v=json.loads(jread('exact-remote-accounting.json')['stdout'])
assert v['memAvailable']>=3758096384 and not v['ownedGuestLive']
assert all(v['limits'][k]==[-1,-1] for k in ['RLIMIT_DATA','RLIMIT_AS'])
rb=v['inventory']['physicalOwnedBytes']+sum(x['allocated'] for x in v['logs'])
gate('immediate-preguest',remoteBytes=rb,future=33554432)
save('startup-reuse.json',dict(path='/tmp/enigma-retained-bounded-progress-gameplay-oct26/ops/fresh-node-startup.json',sha256=sha(pathlib.Path('/tmp/enigma-retained-bounded-progress-gameplay-oct26/ops/fresh-node-startup.json').read_bytes()),reason='Exact executable flags capture wrapper env CPU90/file24MiB/DATA-ASunlimited unchanged; guest args byte-identical'))
save('guest-detach.json',remote('python3 '+shlex.quote(R+'/measured-allocation/operate.py'),detach=True))
print('ONE fresh bounded guest launched')
