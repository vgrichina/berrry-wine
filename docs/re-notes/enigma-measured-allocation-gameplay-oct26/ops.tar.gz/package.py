from work import *
import tarfile,io
dest=REPO/E;dest.mkdir(parents=True,exist_ok=True)
priors=[]
for task in ['enigma-retained-bounded-progress-gameplay-oct26','enigma-presented-menu-progress-gameplay-oct26']:
 p=pathlib.Path('/tmp')/task/'repo/docs/re-notes'/task/'receipt.json'
 b=p.read_bytes();q=dest/(task+'-receipt.json');q.write_bytes(b)
 assert q.read_bytes()==b
 priors.append(dict(path=str(p),publishedCopy=q.name,sha256=sha(b),bytes=len(b)))
r=O/'retained'
out=json.loads((r/'outcome.json').read_text());term=json.loads((r/'terminal.json').read_text())
rows=[json.loads(x) for x in gzip.open(r/'requests.jsonl.gz','rt')]
steps=[];snaps=[]
for i,row in enumerate(rows):
 c=json.loads(row['request']);v=json.loads(row['originalResponse']).get('value') if 'originalResponse' in row else None
 if c['action']=='step' and v:
  assert 1<=c['n']<=256 and v['ran']==v['steps']==c['n'] and v['frozen'] is True
  s=json.loads(rows[i+1]['originalResponse'])['value'];assert json.loads(rows[i+1]['request'])['action']=='snapshot' and s['frozen']['credits']==0 and s['batch']==v['batch']
  steps.append(c['n'])
 if c['action']=='snapshot' and v:assert v['frozen']['credits']==0;snaps.append(v)
 assert i==0 or rows[i-1]['ended']<=row['at'],'overlap'
assert steps[0]==1 and sum(steps)==out['acknowledgedBatches']
imgs=[]
for p in r.glob('*.png'):
 b=p.read_bytes();assert len(b)<=2097152
 imgs.append(dict(name=p.name,sha256=sha(b),bytes=len(b),width=int.from_bytes(b[16:20],'big'),height=int.from_bytes(b[20:24],'big')))
 assert imgs[-1]['width']<=800 and imgs[-1]['height']<=600
assert len(imgs)<=3
save('trace-verification.json',dict(allStepsAcknowledged=True,noOverlap=True,noStepTimeout=not any('error' in x and json.loads(x['request'])['action']=='step' for x in rows),firstRejection=rows[-1] if 'error' in rows[-1] else None,steps=len(steps),batches=sum(steps),zeroCreditSnapshots=len(snaps),firstN1=steps[0],firstOriginal=rows[:3],lastSnapshot=snaps[-1]))
receipt=dict(task=H.name,status=out['status'],outcome=out,terminal=term,images=imgs,pixelInspection=jread('pixel-inspection.json'),traceVerification=jread('trace-verification.json'),priorReceipts=priors,admission=jread('admission-immediate-preguest.json'),readback=jread('readback.json'),cleanup=jread('cleanup-readback.json'),pins='Exact2661 files/hash/mode and argv unchanged; original full manifest retained remotely in place, no compilation/restaging',reused=dict(offlineGroups='29/13/9/7 unchanged passing groups, none replayed',parser=jread('reused-canonical-parser.json'),startup=jread('startup-reuse.json')),lifecycle=dict(box=BOX,state='RUNNING API confirmed',guestCutoff='2026-10-26T21:38:00Z',handback='2026-10-26T21:42:00Z',shutdown='2026-10-26T21:45:00Z',expiry='2026-10-26T22:23:15.028Z',shutdownOwner='coordinator',watchPID=3103171,watchUntouched=True),historicalAllocationIncidents='Previous runtime69128192B and publication67571712B exceeded then64MiB task allocation; preserved unchanged as internal allocation incidents, not game prerequisites/failures',publication='Assigned isolated evidence branch; no main merge',remaining='No further guest attempt authorized; coordinator owns next assignment and shutdown')
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(dest/'start-game-menu.png').write_bytes((r/'qualification.png').read_bytes())
with tarfile.open(dest/'ops.tar.gz','w:gz') as t:
 for p in O.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.name not in ['ops.tar.gz']:t.add(p,arcname=str(p.relative_to(O)),recursive=False)
with tarfile.open(dest/'ops.tar.gz') as t:
 for p in r.iterdir():
  if p.is_file():assert t.extractfile('retained/'+p.name).read()==p.read_bytes()
(dest/'README.md').write_text('''# Enigma presented Start Game and acknowledged click

The inspected640x480 PNG shows the real Start Game menu. Its exact SHA matched the unchanged controller requirement at batch130305; the controller acknowledged one atomic click at344,212. Fresh n1 and every following serial step completed with frozen zero-credit snapshots:541 step requests,137986 batches,542 snapshots, no step timeout or overlap.

After five seconds of acknowledged post-click progression, the final PNG request returned `task cumulative capture allocation`. The retained unchanged capture wrapper allows1048576 cumulative PNG bytes; qualification and controller-before captures each consumed389913 bytes. The third image was rejected before write. This is an internal capture-budget blocker; gameplay was not visually established and no game failure is claimed. No retry or additional guest attempt followed the first rejection.

The supervisor ended at70.634s, peak tree RSS404537344B and CPU71.09s, with no owned live processes. bx_eugbptb7 remains RUNNING; coordinator owns shutdown21:45UTC, expiry22:23:15.028UTC, watcher3103171 untouched.

Immediate measured complete projection102047744B fits explicit134217728B allocation, including prospective33554432B and separate8MiB reserve. MemAvailable3818299392B exceeds aggregate2550136832B; projected host free3600818176B exceeds2982150144B. Prior64MiB allocation incidents are retained exactly in both predecessor receipts and do not describe game prerequisites.

`receipt.json` records identities, reusable29/13/9/7 groups, admission and cleanup. `ops.tar.gz` contains original serial request/response trace, screenshots, diagnostics and adapted operational recipes. Full2661-file manifest and standing staged inputs remain on the box; no compilation, restaging, passed-control reruns, source changes or main merge occurred. No further runtime authorized by this evidence.
''')
print(json.dumps(out));print(json.dumps(imgs))
