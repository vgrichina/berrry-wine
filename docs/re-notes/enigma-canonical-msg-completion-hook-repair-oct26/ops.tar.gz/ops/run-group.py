from common import *
group=sys.argv[1]
b=pool([NODE,'--max-old-space-size=64',str(R/'test/test-message-completion.js'),group,str(O)],label=group)
print(b[:8192].decode())
completed=[n for n in ['production','continuations','challenges','noninterference','limits','baseline-semantics'] if (O/(n+'-result.json')).exists()]
save('checkpoint.json',dict(base=REV,candidateFiles={str(p.relative_to(R)):sha(p.read_bytes()) for p in R.rglob('*') if p.is_file() and '.git' not in p.parts},completed=completed,remaining=[n for n in ['production','continuations','challenges','noninterference','limits','baseline-semantics'] if n not in completed]+['independent canonical build/import closure validation','separately authorized canonical runtime acceptance including real initializers/thunk/decoded entry'],canonicalRuntimeQualified=False,compiled=False,evidence={n:str(O/(n+'-result.json')) for n in completed}))
