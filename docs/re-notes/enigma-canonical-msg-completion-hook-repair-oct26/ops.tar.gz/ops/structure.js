'use strict';
const fs=require('fs'),crypto=require('crypto'),assert=require('assert/strict'),path=require('path');
const R=path.resolve(__dirname,'../repo');
const files=['src/01-header.wat','src/09a5-handlers-window.wat','src/09a5b-handlers-window-late.wat','src/09a-handlers4-late.wat','src/13-exports.wat'];
const hashes={};
for(const f of files){
 const s=fs.readFileSync(path.join(R,f),'utf8');let depth=0,block=0,line=false,str=false;
 for(let i=0;i<s.length;i++){
  const c=s[i],n=s[i+1];
  if(line){if(c==='\n')line=false;continue;}
  if(str){if(c==='\\'){i++;continue;}if(c==='"')str=false;continue;}
  if(block){if(c==='('&&n===';'){block++;i++;}else if(c===';'&&n===')'){block--;i++;}continue;}
  if(c===';'&&n===';'){line=true;i++;continue;}
  if(c==='('&&n===';'){block++;i++;continue;}
  if(c==='"'){str=true;continue;}
  if(c==='(')depth++;if(c===')')depth--;assert(depth>=0,f+' underflow');
 }
 assert.equal(depth,0,f);assert.equal(block,0);assert.equal(str,false);
 hashes[f]=crypto.createHash('sha256').update(s).digest('hex');
}
const out={pass:true,compiled:false,hashes};fs.writeFileSync(__dirname+'/structure-result.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({pass:true,compiled:false,fragments:files.length}));
