from common import *
import zlib
D=pathlib.Path('/tmp/enigma-msg-boundary-measured-client-implementation-oct26/repo')
manifest=json.load(open(ROOT/'scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json'))
paths=['src/01-header.wat','src/09a5-handlers-window.wat','src/09a5b-handlers-window-late.wat','src/09a-handlers4-late.wat','src/13-exports.wat','lib/host-imports.js']
verified=[]
for path in paths:
 x=next(x for x in manifest['files'] if x['path']==path);b=(SRC/path).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];verified.append(x)
save('source-provenance.json',dict(revision=manifest['revision'],manifestSHA=sha((ROOT/'scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json').read_bytes()),files=verified,partialJS=REV,partialFiles={p:sha((D/p).read_bytes()) for p in ['test/run.js','test/message-boundary-trace.js','test/test-message-boundary-trace.js']},mainClosureSHA=sha((SRC/'src/main.watx').read_bytes())))
R.mkdir();g('init','-q',str(R),cwd=H)
# Recover only immutable commit/tree objects directly; no broad checkout, no missing-blob fetch.
seen=set()
def recover(oid):
 if oid in seen:return
 seen.add(oid);p=D/'.git/objects'/oid[:2]/oid[2:];b=p.read_bytes();raw=zlib.decompress(b);assert hashlib.sha1(raw).hexdigest()==oid
 header,body=raw.split(b'\0',1);kind,size=header.split();assert len(body)==int(size)
 if kind==b'commit':recover(body.splitlines()[0].split()[1].decode())
 elif kind==b'tree':
  off=0
  while off<len(body):
   end=body.index(b'\0',off);mode=body[off:end].split(b' ',1)[0];child=body[end+1:end+21].hex();off=end+21
   if mode==b'40000':recover(child)
 else:raise AssertionError(kind)
 out=R/'.git/objects'/oid[:2]/oid[2:];out.parent.mkdir(exist_ok=True);out.write_bytes(b)
recover(REV);(R/'.git/shallow').write_text(REV+'\n')
for k,v in [('core.sparseCheckout','true'),('core.sparseCheckoutCone','false'),('core.sshCommand',SSH),('user.name','Wine Ops'),('user.email','wine-ops@local')]:g('config',k,v)
(R/'.git/info/sparse-checkout').write_text('/src/\n/lib/host-imports.js\n/test/\n/docs/re-notes/'+H.name+'/\n')
g('update-ref','refs/heads/'+BR,REV);g('symbolic-ref','HEAD','refs/heads/'+BR);g('read-tree','--reset','-i','HEAD');g('remote','add','origin','git@github.com:vgrichina/wine-assembly.git')
for p in paths:
 dest=R/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SRC/p,dest)
for p in ['test/run.js','test/message-boundary-trace.js','test/test-message-boundary-trace.js']:
 dest=R/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(D/p,dest)
# Parent blobs needed for changed files, copied verified, not donor alternates.
for p in ['test/run.js','test/message-boundary-trace.js','test/test-message-boundary-trace.js']:
 b=(D/p).read_bytes();raw=b'blob '+str(len(b)).encode()+b'\0'+b;oid=hashlib.sha1(raw).hexdigest();dest=R/'.git/objects'/oid[:2]/oid[2:];dest.parent.mkdir(exist_ok=True);dest.write_bytes(zlib.compress(raw))
save('checkout.json',dict(base=REV,branch=BR,commitAndTreeObjects=len(seen),paths=paths,selective=True,noAlternates=True,sourceRevision=manifest['revision']))
startup='const fs=require("fs");console.log(JSON.stringify({execPath:process.execPath,execArgv:process.execArgv,limits:fs.readFileSync("/proc/self/limits","utf8"),env:{TMPDIR:process.env.TMPDIR,NODE_OPTIONS:process.env.NODE_OPTIONS||null}}))'
b=pool([NODE,'--max-old-space-size=64','-e',startup],label='node-startup');print(b[:4000].decode())
save('startup-configuration.json',dict(executable=NODE,sha256=sha(pathlib.Path(NODE).read_bytes()),flags=['--max-old-space-size=64'],environment=dict(TMPDIR=str(O),NODE_OPTIONS=os.environ.get('NODE_OPTIONS')),cpu=90,wall=120,file=25165824,physical=134217728,output=2097152,excerpt=8192,gitDATAOnlyGit=True))
print('SELECTIVE RECOVERY AND NODE STARTUP PASS')
