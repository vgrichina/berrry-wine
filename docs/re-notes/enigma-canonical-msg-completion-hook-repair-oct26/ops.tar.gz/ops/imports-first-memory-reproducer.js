'use strict';
const fs = require('fs'), path = require('path'), crypto = require('crypto'), assert = require('assert/strict');
const R = path.join(__dirname, '../repo'), S = '/tmp/civ2-win16-ordinary-gameplay-oct26/source';
const ROOT = '/home/user/wine-assembly';
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
// Execute the unchanged installed generator's exact parser, with file-at-a-time
// input to avoid materializing the full 20MiB closure in this 128MiB allocation.
const tool = fs.readFileSync(ROOT + '/tools/gen-host-import-sigs.js', 'utf8');
const start = tool.indexOf('function parse(text) {'), end = tool.indexOf('\nfunction main()', start);
assert(start >= 0 && end > start);
const parserText = tool.slice(start, end), parse = new Function(parserText + '\nreturn parse;')();
const manifest = JSON.parse(fs.readFileSync(ROOT + '/scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json'));
const main = fs.readFileSync(S + '/src/main.watx', 'utf8');
const parts = [...main.matchAll(/\(include "([^"]+)"\)/g)].map(m => m[1]);
const before = {}, after = {}, closure = [];
for (const part of parts) {
  const p = 'src/' + part, bytes = fs.readFileSync(S + '/' + p), pin = manifest.files.find(x => x.path === p);
  assert(pin); assert.equal(sha(bytes), pin.sha256); assert.equal(bytes.length, pin.bytes);
  const changed = fs.existsSync(R + '/' + p), candidate = changed ? fs.readFileSync(R + '/' + p) : bytes;
  closure.push({ path: p, baseline: pin.sha256, candidate: sha(candidate), changed: sha(candidate) !== pin.sha256 });
  for (const [dest, input] of [[before, bytes], [after, candidate]]) {
    // Reject duplicate declarations even when Object.assign would overwrite.
    const decl = input.toString().match(/\(import\s+"host"\s+"[A-Za-z_0-9]+"\s+\(func/g) || [];
    const parsed = parse(input.toString()); assert.equal(Object.keys(parsed).length, decl.length);
    for (const [name, signature] of Object.entries(parsed)) { assert(!(name in dest)); dest[name] = signature; }
  }
}
const expected = { message_begin: [8, 1], message_park: [1, 0], message_bind: [3, 0], message_resume: [2, 1], message_complete: [2, 0] };
assert.equal(Object.keys(after).length, Object.keys(before).length + 5);
for (const [k, v] of Object.entries(before)) assert.deepEqual(after[k], v);
for (const [k, [params, results]] of Object.entries(expected)) {
  assert.deepEqual(after[k], { params: Array(params).fill('i32'), results: Array(results).fill('i32') });
}
const output = JSON.stringify({ generated_from: 'src/main.watx include closure', count: Object.keys(after).length, sigs: after }, null, 2) + '\n';
fs.writeFileSync(R + '/lib/host-import-sigs.generated.json', output);
const receipt = { pass: true, compiled: false, canonicalRuntimeQualified: false, donorRevision: manifest.revision,
  mainSHA256: sha(main), toolPath: ROOT + '/tools/gen-host-import-sigs.js', toolSHA256: sha(tool),
  parserBytes: Buffer.byteLength(parserText), parserSHA256: sha(parserText),
  beforeCount: Object.keys(before).length, afterCount: Object.keys(after).length,
  signatureSHA256: sha(output), closure, method: 'exact parser per self-contained fragment, distinct-import merge in canonical include order' };
fs.writeFileSync(__dirname + '/imports-result.json', JSON.stringify(receipt, null, 2) + '\n');
fs.writeFileSync(__dirname + '/baseline-import-sigs.json', JSON.stringify({ generated_from: 'src/main.watx include closure', count: Object.keys(before).length, sigs: before }, null, 2) + '\n');
console.log(JSON.stringify({ pass: true, before: receipt.beforeCount, after: receipt.afterCount, compiled: false }));
