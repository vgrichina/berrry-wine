from common import *
def edit(path,old,new):
 p=R/path;s=p.read_text();assert s.count(old)==1,(path,old[:100],s.count(old));p.write_text(s.replace(old,new))
edit('src/01-header.wat','  (import "host" "log_api_exit" (func $host_log_api_exit))','''  (import "host" "log_api_exit" (func $host_log_api_exit))
  ;; Optional main-instance diagnostics. Explicit tokens survive deferred USER
  ;; continuations in host-owned metadata; no guest stack/MSG bytes are added.
  (import "host" "message_begin" (func $host_message_begin (param i32 i32 i32 i32 i32 i32 i32 i32) (result i32)))
  (import "host" "message_park" (func $host_message_park (param i32)))
  (import "host" "message_bind" (func $host_message_bind (param i32 i32 i32)))
  (import "host" "message_resume" (func $host_message_resume (param i32 i32) (result i32)))
  (import "host" "message_complete" (func $host_message_complete (param i32 i32)))
  (global $message_completion_on (mut i32) (i32.const 0))
  (global $message_completion_active (mut i32) (i32.const 0))''')
p=R/'src/09a5-handlers-window.wat';s=p.read_text()
for name,kind,cleanup in [('Get',1,20),('Peek',3,24)]:
 start=s.index('  (func $handle_'+name+'MessageA (');end=s.index('\n  (func ',start+5)
 old=s[start:end];new=old.replace('$handle_'+name+'MessageA (','$handle_'+name+'Message_observed (param $diagnostic_api i32) (',1)
 new=new.replace('    (local $sp i32) (local $ret i32)','    (local $sp i32) (local $ret i32) (local $token i32) (local $outer i32)',1)
 marker='    (local.set $ret (call $gl32 (local.get $sp)))'
 new=new.replace(marker,marker+'''
    (if (global.get $message_completion_on)
      (then
        (local.set $outer (global.get $message_completion_active))
        (local.set $token (call $host_message_begin (local.get $diagnostic_api)
          (global.get $current_thread_id) (local.get $sp) (local.get $arg0)
          (local.get $arg1) (local.get $arg2) (local.get $arg3) (local.get $arg4)))
        (global.set $message_completion_active (local.get $token))))''',1)
 # Remove only the function-closing parenthesis, retaining its original body.
 assert new.rstrip().endswith(')');new=new.rstrip()[:-1]+'''
    (if (global.get $message_completion_on)
      (then
        ;; An intact call frame yielded on its own thunk: keep this invocation
        ;; parked, never mistake the handler's stale EAX for a returned result.
        (if (i32.and (i32.ne (global.get $yield_flag) (i32.const 0))
                     (i32.eq (i32.load offset=16 (global.get $reg_base)) (local.get $sp)))
          (then (call $host_message_park (local.get $token)))
          (else
            (if (i32.and (i32.eqz (global.get $yield_flag))
                         (i32.eq (i32.load offset=16 (global.get $reg_base))
                                 (i32.add (local.get $sp) (i32.const CLEANUP))))
              (then (call $host_message_complete (local.get $token) (i32.load (global.get $reg_base)))))))
        (global.set $message_completion_active (local.get $outer)))))
'''.replace('CLEANUP',str(cleanup))
 wrapper='''  (func $handle_NAMEMessageA (param $arg0 i32) (param $arg1 i32) (param $arg2 i32) (param $arg3 i32) (param $arg4 i32) (param $name_ptr i32)
    (call $handle_NAMEMessage_observed (i32.const KIND) (local.get $arg0) (local.get $arg1) (local.get $arg2)
      (local.get $arg3) (local.get $arg4) (local.get $name_ptr)))

'''.replace('NAME',name).replace('KIND',str(kind))
 s=s[:start]+wrapper+new+s[end:]
# The context address is explicitly bound while this invocation owns entry.
needle='    (global.set $eip (call $hook_dispatch_enter (i32.const 2)))'
assert s.count(needle)==1
s=s.replace(needle,'''    (if (global.get $message_completion_on)
      (then (call $host_message_bind (global.get $message_completion_active) (i32.const 1)
        (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 16)))))
'''+needle)
p.write_text(s)
for name,kind in [('Get',2),('Peek',4)]:
 edit('src/09a5b-handlers-window-late.wat',
      '(call $handle_'+name+'MessageA (local.get $arg0)',
      '(call $handle_'+name+'Message_observed (i32.const '+str(kind)+') (local.get $arg0)')
edit('src/09a-handlers4-late.wat',
 '    (global.set $hook_active_node (local.get $node))\n    (global.set $eip (call $hook_node_proc (local.get $node)))',
 '''    (if (global.get $message_completion_on)
      (then (call $host_message_bind (global.get $message_completion_active) (i32.const 2)
        (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 16)))))
    (global.set $hook_active_node (local.get $node))
    (global.set $eip (call $hook_node_proc (local.get $node)))''')
edit('src/09a-handlers4-late.wat',
 '  (func $getmessage_hook_continue\n    (local $sp i32) (local $tid i32)\n    (local.set $sp (i32.load offset=16 (global.get $reg_base)))',
 '''  (func $getmessage_hook_continue
    (local $sp i32) (local $tid i32) (local $token i32)
    (local.set $sp (i32.load offset=16 (global.get $reg_base)))
    (if (global.get $message_completion_on)
      (then (local.set $token (call $host_message_resume (i32.const 2) (local.get $sp)))))''')
edit('src/09a-handlers4-late.wat',
 '    (call $getmessage_hook_leave (local.get $tid)))',
 '''    (call $getmessage_hook_leave (local.get $tid))
    ;; The saved BOOL, caller ESP/EIP and hook ownership are restored. MSG now
    ;; includes all guest hook mutations, before the next guest instruction.
    (if (global.get $message_completion_on)
      (then (call $host_message_complete (local.get $token) (i32.load (global.get $reg_base))))))''')
edit('src/09a-handlers4-late.wat',
 '    (local $sp i32) (local $ret i32) (local $msg i32) (local $remove i32)\n    (local.set $sp (i32.load offset=16 (global.get $reg_base)))',
 '''    (local $sp i32) (local $ret i32) (local $msg i32) (local $remove i32)
    (local $token i32) (local $outer i32)
    (local.set $sp (i32.load offset=16 (global.get $reg_base)))
    (if (global.get $message_completion_on)
      (then
        (local.set $outer (global.get $message_completion_active))
        (local.set $token (call $host_message_resume (i32.const 1) (local.get $sp)))
        (global.set $message_completion_active (local.get $token))))''')
edit('src/09a-handlers4-late.wat',
 '    (call $getmessage_hook_begin (local.get $ret) (local.get $msg) (local.get $remove) (i32.const 1)))',
 '''    (call $getmessage_hook_begin (local.get $ret) (local.get $msg) (local.get $remove) (i32.const 1))
    (if (global.get $message_completion_on)
      (then
        ;; complete refuses a token just rebound to WH_GETMESSAGE.
        (call $host_message_complete (local.get $token) (i32.load (global.get $reg_base)))
        (global.set $message_completion_active (local.get $outer)))))''')
with (R/'src/13-exports.wat').open('a') as f:f.write('''
  ;; Per-instance, deliberately absent from inherited worker setters. Enable
  ;; once before initializers; arming is host-side and cannot reset the budget.
  (func (export "set_message_completion") (param $on i32)
    (global.set $message_completion_on (i32.ne (local.get $on) (i32.const 0))))
''')
edit('lib/host-imports.js','    log_api_exit: () => {},','''    log_api_exit: () => {},
    // Canonical message completion is off per instance. CLI main overrides
    // these; browser/worker hosts safely retain the disabled defaults.
    message_begin: () => 0,
    message_park: () => {},
    message_bind: () => {},
    message_resume: () => 0,
    message_complete: () => {},''')
edit('test/run.js',"  h.log_api_exit = messageBoundaryTrace.wrapPostHandler(h.log_api_exit);",'''  h.log_api_exit = messageBoundaryTrace.wrapPostHandler(h.log_api_exit);
  const { createMessageCompletionOwner } = require('./message-completion-owner.js');
  const messageCompletionOwner = createMessageCompletionOwner({
    enabled: () => TRACE_MESSAGE_BOUNDARY && messageBoundaryTrace.status().armed,
    observe: detail => messageBoundaryTrace.completed(detail),
  });
  Object.assign(h, messageCompletionOwner.imports);''')
edit('test/run.js','  ctx.exports = instance.exports;','''  ctx.exports = instance.exports;
  // Install on the main instance before any guest initializer executes. An
  // older module is explicitly unqualified, never silently called complete.
  if (TRACE_MESSAGE_BOUNDARY && instance.exports.set_message_completion) {
    instance.exports.set_message_completion(1);
    messageBoundaryTrace.qualifyCompletion();
  }''')
edit('test/message-boundary-trace.js','  let armed = false;','  let completionWired = false;\n  let armed = false;')
edit('test/message-boundary-trace.js','    dequeue(evt, source) {','''    qualifyCompletion() { completionWired = true; },
    completed(detail) {
      if (!completionWired) return;
      emit('message-completion', () => {
        const { read } = context();
        const success = detail.api <= 2 ? detail.result >= 0 : detail.result !== 0;
        return { ...detail, api: ['GetMessageA', 'GetMessageW', 'PeekMessageA', 'PeekMessageW'][detail.api - 1],
          correlation: 'invocation-owned', successfulReturn: success,
          msg: success ? msg(read, detail.msgPointer) : null,
          scope: 'main-instance; canonical build/runtime qualification still required' };
      });
    },
    dequeue(evt, source) {''')
edit('test/message-boundary-trace.js','armed, successfulReturnMSG: false','armed, successfulReturnMSG: completionWired, canonicalRuntimeQualified: false')
print('OWNED SOURCE EDIT COMPLETE')
