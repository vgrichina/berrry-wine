from work import *
old=pathlib.Path('/tmp/enigma-accepted-lossless-startup-oct24')
# Exact original argv is unchanged; execute canonical parser in this task before checkout.
args=json.load(open(old/'guest-args.json'));save('guest-args.json',args)
m=json.load(open(P/'manifest.json'));s=payload(m[0]).decode();assert sha(s.encode())=='4d7b9587676db38fcf3314807acb2b2a42b5f09d2c98fcf3dccb8a6cde9e1809'
parser=s[s.index('const getArg ='):s.index('// Was `--name=...`')]
code='const assert=require("assert"),args='+json.dumps(args[7:])+';'+parser+';assert.deepEqual(getArgs("vfs-tree"),['+json.dumps(R+'/vfs')+']);assert.equal(getArgs("vfs-mount").length,0);assert.equal(getArgs("dlls").length,8);assert(hasFlag("no-build"));console.log("PASS actual filename-bearing argv canonical parser eight providers/tree")'
r=subprocess.run(['node','--max-old-space-size=256','-e',code],capture_output=True,text=True,timeout=60,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_CPU,(60,60)))
save('precheckout-parser.json',dict(status=r.returncode,stdout=r.stdout,stderr=r.stderr,argv=args,parserSHA256=sha(parser.encode()),enumeratedFiles=len([x for x in m if x['target'].startswith('vfs/')]),commaFilenames=[x['target'] for x in m if ',' in x['target']],standingFullEnumeration=str(P/'manifest.json')));assert r.returncode==0
r=subprocess.run(['git','ls-remote','git@github.com:vgrichina/wine-assembly.git','refs/heads/main'],env=dict(os.environ,GIT_SSH_COMMAND=SSH),capture_output=True,text=True,timeout=30)
save('trusted-donor.json',dict(ssh=SSH,status=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0 and r.stdout.split()[0]==REV
measure('precheckout')
repo=H/'repo';repo.mkdir()
def git(*args):
 r=subprocess.run(['git','-C',str(repo),*args],capture_output=True,text=True);assert r.returncode==0,r.stderr;return r.stdout
pins=json.load(open(old/'standing-identities.json'))['acceptedPaths'];paths=list(pins)
git('init');(repo/'.git/objects/info/alternates').write_text(str(D/'.git/objects')+'\n');git('config','core.sparseCheckout','true');git('config','core.sparseCheckoutCone','false')
(repo/'.git/info/sparse-checkout').write_text('\n'.join('/'+p for p in paths)+'\n/docs/re-notes/enigma-recovered-lossless-startup-20261024.md\n/docs/re-notes/enigma-recovered-lossless-startup-20261024/\n')
git('checkout','-b','task/enigma-recovered-lossless-startup-oct24',REV);git('config','user.name','Wine Ops');git('config','user.email','wine-ops@local');git('remote','add','origin','git@github.com:vgrichina/wine-assembly.git')
for p,pin in pins.items():assert sha((repo/p).read_bytes())==pin
save('standing-identities.json',json.load(open(old/'standing-identities.json')))
for name in ['capture.cjs','preflight.py','validate-tree.cjs','supervise-original.py','supervise-transformed.py']:(H/name).write_bytes((old/name).read_bytes())
assert sha((H/'capture.cjs').read_bytes())=='6d64a146f2daf8b598dbf13e3c13f890dbc783d8f5286aacba6d343758d22079'
assert sha((H/'supervise-original.py').read_bytes())=='73be15954cedc19340779ff6bda2397cb94927ca702d2baebdccd5e763cf7b73'
code='const fs=require("fs"),t=require('+json.dumps(str(repo/'tools/enigma-terminal-capture-guard.cjs'))+');fs.writeFileSync('+json.dumps(str(H/'supervise-transformed-current.py'))+',t.transformSupervisor(fs.readFileSync('+json.dumps(str(H/'supervise-original.py'))+',"utf8")));'
subprocess.run(['node','--max-old-space-size=256','-e',code],check=True,timeout=60,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_CPU,(60,60)))
assert (H/'supervise-transformed-current.py').read_bytes()==(H/'supervise-transformed.py').read_bytes()
env=json.load(open(old/'next-env.json'));assert env['ENIGMA_LOSSLESS_CAPTURE']=='1';save('next-env.json',env)
info=json.load(open(H/'ops/box-initial.json'));save('schedule-correction.json',dict(latestGuestStart='2026-10-24T13:32:00Z',guestFinish='2026-10-24T13:33:00Z',handback='2026-10-24T13:35:00Z',coordinatorWatchdog='2026-10-24T13:38:00Z',boxActualInfo=info,supersedesAllCopiedHistoricalLabels=True))
s=(H/'supervise-transformed.py').read_text();assert "1792835520,'latest start09:52UTC'" in s
expiry='2026-10-24T13:43:15Z'
# Only deployment labels and deadline change; complete accepted behavior stays intact.
s=s.replace("1792835520,'latest start09:52UTC'","1792848720,'latest start13:32UTC'").replace('bx_fvkjwxap',BOX).replace('shutdown09:57UTC','shutdown13:38UTC').replace('2026-10-24T10:02:44.741Z',expiry)
(H/'supervise.py').write_text(s)
save('supervisor-identity.json',dict(original=sha((H/'supervise-original.py').read_bytes()),acceptedTransformed=sha((H/'supervise-transformed.py').read_bytes()),deployed=sha(s.encode()),configurationOnly=['lateststart13:32UTC','box','shutdown13:38UTC','expiry13:43:15UTC']))
(H/'manifest.json').write_bytes((P/'manifest.json').read_bytes())
measure('prepared');print('PREPARED canonical parser PASS trusted MAIN PASS focused pins PASS full accepted supervisor transform PASS')
