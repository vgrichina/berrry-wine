from work import *
import gzip,difflib
E=H/'repo/docs/re-notes/enigma-recovered-lossless-startup-20261024';E.mkdir(parents=True,exist_ok=True)
for p in (H/'retained/guest').iterdir():shutil.copyfile(p,E/p.name)
for n in ['guest-attempt.json','guest-args.json','next-env.json','first-rejection.json','guest-supervisor-api.json','standing-identities.json','precheckout-parser.json','trusted-donor.json','schedule-correction.json','supervisor-identity.json','resource-pretransfer.json','resource-ready.json','resource-immediate-before-guest.json','resource-immediate-api.json','resource-post-guest.json','resource-prepackage.json','preflight-api.json','tree-validation-api.json','sibling-resolution-api.json','remote-rehash.json','guest-artifact-inventory.json']:
 shutil.copyfile(H/n,E/n)
for n in ['accepted-evidence-reuse.json','box-initial.json','box-handback.json','cleanup-api.json','handoff.json','wrapper-exit-note.json']:
 shutil.copyfile(H/'ops'/n,E/n)
for n in ['manifest.json','transfer-receipts.json','api-history.jsonl','capture-history.json','capture-current.json','supervise-original.py','supervise-transformed.py','supervise.py','capture.cjs','work.py','prepare.py','stage.py','stage-and-validate.py','launch.py','collect.py','preflight.py','validate-tree.cjs']:
 (E/(n+'.gz')).write_bytes(gzip.compress((H/n).read_bytes(),mtime=0))
for n in ['preflight.json','tree-validation.json.gz']:shutil.copyfile(H/'retained'/n,E/n)
diff=''.join(difflib.unified_diff((H/'supervise-transformed.py').read_text().splitlines(True),(H/'supervise.py').read_text().splitlines(True),fromfile='accepted-transformed',tofile='deployed-config'))
(E/'supervisor-config.diff.gz').write_bytes(gzip.compress(diff.encode(),mtime=0))
log=(E/'output.log').read_text();api=[l for l in log.splitlines() if l.startswith('[API #')];(E/'api-traces.json').write_text(json.dumps(api,indent=2)+'\n')
terminal=json.load(open(E/'terminal.json'));denial=json.load(open(E/'capture-terminal.json'));remote_result=json.load(open(E/'guest-supervisor-api.json'));cleanup=json.loads(json.load(open(E/'cleanup-api.json'))['stdout'])
assert terminal['reason']=='capture-byte-limit' and terminal['remainingGroup'] is False
assert terminal['TERM'] and not terminal['KILL'] and terminal['returncode']==-15
assert denial['artifactAccepted'] is False and denial['message']=='capture byte limit'
assert remote_result['exitCode']==1 and not cleanup['dependentExists'] and not cleanup['taskNode']
assert len(api)==16
assert not list(E.glob('*.png')) and not any(r['path'].endswith('.png') for r in json.load(open(E/'guest-artifact-inventory.json')))
assert 'accepted/tools/lossless-capture-png.cjs:55:10' in log
assert '[input] png FAILED' not in log and 'Invalid regular expression' not in log
assert json.load(open(E/'guest-attempt.json'))['guestAttempts']==1
assert json.load(open(E/'next-env.json'))['ENIGMA_LOSSLESS_CAPTURE']=='1'
assert json.load(open(E/'precheckout-parser.json'))['status']==0
assert json.loads(json.load(open(E/'remote-rehash.json'))['stdout'])['files']==2659
assert json.load(open(E/'preflight.json'))['probe']['codec']=='7.0.0'
assert sha(gzip.decompress((E/'capture.cjs.gz').read_bytes()))=='6d64a146f2daf8b598dbf13e3c13f890dbc783d8f5286aacba6d343758d22079'
assert sha(gzip.decompress((E/'supervise-original.py.gz').read_bytes()))=='73be15954cedc19340779ff6bda2397cb94927ca702d2baebdccd5e763cf7b73'
obs=dict(firstRejection='capture byte limit',batch=30000,actualCodecStack='accepted/tools/lossless-capture-png.cjs:55:10',boundedStrategiesExhausted=[3,0],exactEncodedSizes=None,acceptedPNG=None,pixelsRetained=False,scene=None,menuAccepted=False,LuaDynamicLoaderEntry=None,counters=None,apiRecords=api,ordinaryFSReadLogs=len([l for l in log.splitlines() if l.startswith('[FS]')]),laterRegexFailure=False,gameplayAccepted=False,packedOriginalAccepted=False,guestAttempts=1)
(E/'observations.json').write_text(json.dumps(obs,indent=2)+'\n')
(E/'bundle-tests.json').write_text(json.dumps(dict(passGate=True,assertions='one guest, unchanged capture/supervisor originals, actual encoder stack, exit1+shellAND blocked, cleanup reaped,16APIs,2659files, realpngjs7, no acceptedPNG/no later regex',testsNotGuest=True),indent=2)+'\n')
seals=[dict(path=str(p.relative_to(E)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(E.iterdir()) if p.is_file()]
(E/'artifact-seals.json').write_text(json.dumps(seals,indent=2)+'\n')
measure('packaged');print(json.dumps(dict(packagedFiles=len(seals)+1,packagedBytes=sum(x['bytes'] for x in seals),bundleChecks='PASS',apiRecords=len(api),rejection='capture byte limit')))
