  ;; Opt-in NULL boundary diagnostics. Existing log_eip import only; no arena.
  ;; Negative tags -1..-6 belong to this protocol only while explicitly armed.
  (global $null_diag_on (mut i32) (i32.const 0))
  (global $null_diag_count (mut i32) (i32.const 0))
  (global $null_diag_saved_eip (mut i32) (i32.const 0))
  (global $null_diag_saved_esp (mut i32) (i32.const 0))
  (func (export "set_null_diag") (param $on i32)
    (global.set $null_diag_on (i32.ne (local.get $on) (i32.const 0)))
    (global.set $null_diag_count (i32.const 0)))
  (func $null_diag_event (param $kind i32) (param $saved_eip i32) (param $saved_esp i32)
    (if (global.get $null_diag_on) (then
      (global.set $null_diag_saved_eip (local.get $saved_eip))
      (global.set $null_diag_saved_esp (local.get $saved_esp))
      (global.set $null_diag_count (i32.add (global.get $null_diag_count) (i32.const 1)))
      (if (i32.gt_u (global.get $null_diag_count) (i32.const 32))
        (then (call $host_log_eip (i32.const -6)) (unreachable)))
      (call $host_log_eip (i32.sub (i32.const 0) (local.get $kind)))
      ;; A returning/misconfigured observer must never resume a zero guest.
      (if (i32.eq (local.get $kind) (i32.const 5)) (then (unreachable))))))
  (func (export "null_diag_field") (param $field i32) (result i32)
    (if (i32.eq (local.get $field) (i32.const 0)) (then (return (global.get $null_diag_saved_eip))))
    (if (i32.eq (local.get $field) (i32.const 1)) (then (return (global.get $null_diag_saved_esp))))
    (if (i32.eq (local.get $field) (i32.const 2)) (then (return (global.get $dlg_pump_hwnd))))
    (if (i32.eq (local.get $field) (i32.const 3)) (then (return (global.get $dlg_ret_addr))))
    (if (i32.eq (local.get $field) (i32.const 4)) (then (return (global.get $dlg_ended))))
    (if (i32.eq (local.get $field) (i32.const 5)) (then (return (i32.load (global.get $SHARED_DLG_PUMP_HWND)))))
    (if (i32.eq (local.get $field) (i32.const 6)) (then (return (i32.load (global.get $SHARED_DLG_ENDED)))))
    (if (i32.eq (local.get $field) (i32.const 7)) (then (return (global.get $sync_msg_depth))))
    (if (i32.eq (local.get $field) (i32.const 8)) (then (return (global.get $null_diag_count))))
    (i32.const -1))
  (func (export "null_diag_token") (result i64) (call $invocation_current))
  (func (export "null_diag_root") (result i64) (global.get $invocation_root))
  ;; End opt-in NULL boundary diagnostic declarations.
  ;; ============================================================
  ;; MAIN RUN LOOP
  ;; ============================================================
  ;; JS COM frames retain this exact i64 child token, never a depth surrogate.
  ;; A failed/aborted call deliberately leaves its child live: only explicit
  ;; process/thread retirement may discard it, not a JS exception handler.
  (func $com_callback_enter (export "com_callback_enter") (result i64)
    (call $sync_depth_enter)
    (call $invocation_current))
  (func $com_callback_check (export "com_callback_check") (param $expected i64)
    (if (i64.ne (local.get $expected) (call $invocation_current))
      (then (unreachable))))
  (func $com_callback_leave (export "com_callback_leave") (param $expected i64)
    (call $com_callback_check (local.get $expected))
    (call $sync_depth_leave))
  ;; Sequential JS callbacks must re-enter with the suspended stream's IP:
  ;; sync_depth_enter uses it to pin spill code. Guest EIP is not this cursor.
  (func $com_callback_get_ip (export "com_callback_get_ip") (result i32)
    (global.get $ip))
  (func $com_callback_set_ip (export "com_callback_set_ip") (param $value i32)
    (global.set $ip (local.get $value)))
  (func $com_callback_get_thunk (export "com_callback_get_thunk") (result i32)
    (global.get $current_thunk_eip))
  (func $com_callback_set_thunk (export "com_callback_set_thunk") (param $value i32)
    (global.set $current_thunk_eip (local.get $value)))

  (func $cdecl_return
    (global.set $eip (call $gl32 (i32.load offset=16 (global.get $reg_base))))
    (i32.store offset=16 (global.get $reg_base) (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 4))))

  (func $run (export "run") (param $max_blocks i32)
    (local $thread i32)
    (local $hc_i i32) (local $hc_slot i32) (local $hc_fp i32)
    (local $prev_eip i32) (local $prev_esp i32)
    (local $saved_budget i32) (local $saved_start i32) (local $shared_cache_generation i32)
    (local $saved_api_depth i32)
    ;; A global rather than a local because $branch_end spends it too — see the
    ;; comment on $block_budget in 01-header.wat. Saved and restored because
    ;; run() is re-entrant: a COM class-factory callback is driven by calling
    ;; run() again from inside the API thunk the outer run() is still executing
    ;; (lib/storage.js _runComCallback). A plain global would hand the outer
    ;; loop whatever the nested one left behind, and it would halt early.
    (local.set $saved_budget (global.get $block_budget))
    (local.set $saved_start (global.get $run_budget_start))
    (local.set $saved_api_depth (global.get $api_handler_depth))
    (global.set $api_handler_depth (i32.const 0))
    (global.set $block_budget (local.get $max_blocks))
    (global.set $run_budget_start (local.get $max_blocks))
    ;; A Win16 task started by WinExec: its first slice turns the fresh thread
    ;; instance into that task (08c $win16_task_boot).
    (if (i32.eq (global.get $eip) (global.get $WIN16_TASK_ENTRY))
      (then (call $win16_task_boot)))
    ;; Animate controls playing on comctl32's "thread" (09c3-wndprocs6).
    (call $anim_service)
    ;; Resuming from an alertable SleepEx with an APC queued: run it first.
    (call $apc_resume_alert_sleep)
    ;; FlushInstructionCache broadcasts through shared memory because decoded
    ;; blocks are instance-local. Check once per host/Worker slice, not once per
    ;; x86 block; the API is rare and a slice boundary is the first point at
    ;; which another Worker can observe the caller's memory writes anyway.
    (local.set $shared_cache_generation
      (i32.atomic.load offset=4 (global.get $SHARED_COUNTERS)))
    (if (i32.ne (local.get $shared_cache_generation)
                (global.get $code_cache_generation_seen))
      (then
        (global.set $code_cache_generation_seen
          (local.get $shared_cache_generation))
        (global.set $thread_flush_pending (i32.const 1))))
    (block $halt (loop $main
      (if (i32.eqz (global.get $eip))
        (then
          (call $null_diag_event (i32.const 5) (i32.const 0) (i32.const 0))
          (global.set $last_run_halt (i32.const 2)) (br $halt)))
      ;; A block whose quantum expired part-way through. Give it a fresh one and
      ;; carry on from the op $next declined to run — looking $eip up again would
      ;; restart the block and re-run everything before that op. Finish it even
      ;; when the block budget has just expired: resume_ip is a pointer into the
      ;; decoded stream, not architectural x86 state, and must never escape this
      ;; run() call. The host may inject a cooperative timer/wave callback between
      ;; calls by replacing EIP/ESP; a leftover resume_ip would take precedence
      ;; over that callback EIP and continue the interrupted block on its callback
      ;; stack. No block is spent from the budget: this is the same block, still
      ;; in progress, and its terminator will return here before another starts.
      ;; Consumed: we are back at the top of the loop with the handler's $eip in
      ;; place, which is exactly what the flag was protecting.
      (global.set $eip_redirected (i32.const 0))
      (if (global.get $resume_ip)
        (then
          (global.set $ip (global.get $resume_ip))
          (global.set $resume_ip (i32.const 0))
          (global.set $steps (i32.const 256))
          (call $next)
          (if (global.get $page_chunk_deferred)
            (then (call $page_chunk_reclaim_deferred)))
          (br $main)))
      ;; A complete cache flush can only recycle its arena between decoded
      ;; blocks. This also services an arena-pressure flush promptly instead of
      ;; waiting until a later cache miss happens to call $decode_block.
      (if (global.get $thread_flush_pending)
        (then (drop (call $thread_arena_flush_if_safe))))
      ;; Browser input can arrive while slot 0 is part-way through a long real-
      ;; Worker slice. Repaint publication is intentionally held until a slice
      ;; boundary so WM_PAINT erase/text sequences cannot flicker, but waiting
      ;; for the remaining 100k-block budget makes typed edit text visibly lag.
      ;; The host pulses this process-shared word when it queues input. Consume
      ;; it once on the guest main thread and return at the next complete x86
      ;; block; the following slice processes the input normally. Guest-created
      ;; threads must not consume slot 0's wake.
      (if (i32.eq (global.get $current_thread_id) (i32.const 1))
        (then
          (if (i32.ne
                (i32.atomic.rmw.xchg offset=36
                  (global.get $THREAD_RPC) (i32.const 0))
                (i32.const 0))
            (then
              (global.set $last_run_halt (i32.const 3))
              (br $halt)))))
      (if (i32.le_s (global.get $block_budget) (i32.const 0))
        (then (global.set $last_run_halt (i32.const 1)) (br $halt)))
      (global.set $block_budget (i32.sub (global.get $block_budget) (i32.const 1)))
      ;; Reset thread buffer if approaching cache region (leave 4KB margin)
      ;; Not under a reserved-page fault: that nested run is inside a block
      ;; that is still executing, and rewinding the arena would recycle it.
      (if (i32.and (i32.ge_u (global.get $thread_alloc) (i32.sub (global.get $THREAD_END) (i32.const 4096)))
                   (i32.eqz (global.get $fault_sync_active)))
        (then
          (call $thread_arena_rewind)
          (call $clear_cache)))
      ;; Yield flag — host needs control (e.g. after WM_TIMER delivery)
      (if (global.get $yield_flag)
        (then
          (global.set $yield_flag (i32.const 0))
          (global.set $last_run_halt (i32.const 3))
          (br $halt)))
      ;; Everything below to the end of this block is a debug facility, and all
      ;; of them are off in a normal run. $dbg_any is the OR of the six arming
      ;; flags, so the common case pays one test instead of six.
      (if (global.get $dbg_any) (then
      ;; Watchpoint: break when watched region (1/2/4 bytes) changes
      (if (global.get $watch_addr)
        (then
          (if (i32.ne (call $watch_load (global.get $watch_addr)) (global.get $watch_val))
            (then
              (global.set $watch_val (call $watch_load (global.get $watch_addr)))
              (global.set $last_run_halt (i32.const 5))
              (br $halt)))))
      ;; EIP breakpoint. On halt we set $bp_skip_once so re-entry (same $eip)
      ;; dispatches the block once before the bp can fire again — without this,
      ;; JS-driven re-arm (e.g. --trace-at) spins halting at the same address.
      (if (i32.eq (global.get $eip) (global.get $bp_addr))
        (then
          ;; Capture caller eip on FIRST hit only (sticky — never overwritten).
          ;; Reading get_bp_first_caller from JS returns the true prev_eip
          ;; from the iteration before bp first matched, even if subsequent
          ;; halts overwrite $dbg_prev_eip with the bp address itself.
          (if (i32.eqz (global.get $bp_first_caller))
            (then (global.set $bp_first_caller (global.get $dbg_prev_eip))))
          (if (global.get $bp_skip_once)
            (then (global.set $bp_skip_once (i32.const 0)))
            (else (global.set $bp_skip_once (i32.const 1))
                  (global.set $last_run_halt (i32.const 5))
                  (br $halt)))))
      ;; EIP hit counters (passive): increment count for any slot whose addr==eip.
      ;; Early-out via $hit_count_n (0 when no --count= flags active).
      (if (global.get $hit_count_n)
        (then
          (local.set $hc_i (i32.const 0))
          (block $hc_done (loop $hc_loop
            (br_if $hc_done (i32.ge_u (local.get $hc_i) (global.get $hit_count_n)))
            (local.set $hc_slot (i32.add (global.get $HIT_COUNT_BASE)
                                         (i32.shl (local.get $hc_i) (i32.const 3))))
            (if (i32.eq (i32.load (local.get $hc_slot)) (global.get $eip))
              (then
                (i32.store offset=4 (local.get $hc_slot)
                  (i32.add (i32.load offset=4 (local.get $hc_slot)) (i32.const 1)))
                (if (i32.eqz (local.get $hc_i))
                  (then
                    (if (i32.eqz (global.get $hit0_first_caller))
                      (then (global.set $hit0_first_caller (global.get $dbg_prev_eip))))
                    (global.set $hit0_last_caller (global.get $dbg_prev_eip))
                    (global.set $hit0_last_ebp (i32.load offset=20 (global.get $reg_base)))
                    ;; The eight GPRs at the latest hit, for a host that has no
                    ;; --trace-at (the page): get_hit0_reg(0..7) = EAX..EDI.
                    (global.set $hit0_r0 (i32.load offset=0 (global.get $reg_base)))
                    (global.set $hit0_r1 (i32.load offset=4 (global.get $reg_base)))
                    (global.set $hit0_r2 (i32.load offset=8 (global.get $reg_base)))
                    (global.set $hit0_r3 (i32.load offset=12 (global.get $reg_base)))
                    (global.set $hit0_r4 (i32.load offset=16 (global.get $reg_base)))
                    (global.set $hit0_r5 (i32.load offset=20 (global.get $reg_base)))
                    (global.set $hit0_r6 (i32.load offset=24 (global.get $reg_base)))
                    (global.set $hit0_r7 (i32.load offset=28 (global.get $reg_base)))
                    (local.set $hc_fp (i32.load offset=20 (global.get $reg_base)))
                    (global.set $hit0_f1 (call $gl32 (i32.add (local.get $hc_fp) (i32.const 4))))
                    (local.set $hc_fp (call $gl32 (local.get $hc_fp)))
                    (global.set $hit0_f2 (call $gl32 (i32.add (local.get $hc_fp) (i32.const 4))))
                    (local.set $hc_fp (call $gl32 (local.get $hc_fp)))
                    (global.set $hit0_f3 (call $gl32 (i32.add (local.get $hc_fp) (i32.const 4))))
                    (local.set $hc_fp (call $gl32 (local.get $hc_fp)))
                    (global.set $hit0_f4 (call $gl32 (i32.add (local.get $hc_fp) (i32.const 4))))))))
            (local.set $hc_i (i32.add (local.get $hc_i) (i32.const 1)))
            (br $hc_loop))))
        )
      ))
      ;; Catch a 16-bit task leaving the selector arena here, before
      ;; $dbg_prev_eip is advanced — at this point it still names the block
      ;; that just ran and produced the bad EIP, which is the only thing that
      ;; identifies the transfer. The decoder makes the same check, but by then
      ;; this assignment has happened and the answer is one step worse.
      (if (global.get $code16)
        (then
          (if (i32.or
                (i32.lt_u (global.get $eip) (call $win16_arena_base))
                (i32.ge_u (global.get $eip)
                  (i32.add (call $win16_arena_base)
                    (i32.mul (global.get $WIN16_SEG_MAX) (i32.const 0x10000)))))
            (then
              (call $host_log_i32 (i32.const 0xCA165E21))
              (call $host_log_i32 (global.get $eip))
              (call $host_log_i32 (global.get $dbg_prev_eip))
              (call $host_log_i32 (global.get $dbg_prev2_eip))
              (call $host_log_i32 (global.get $win16_last_module))
              (call $host_log_i32 (global.get $win16_last_ordinal))
              (call $host_log_i32 (i32.load offset=16 (global.get $reg_base)))
              (unreachable)))))

      ;; Exit if a blocking API yielded. JS owns resuming these waits.
      ;; 16 = render_wait: immutable command already submitted; retry consumes
      ;; its broker token only after the host has observed actual completion.
      (if (i32.eq (global.get $yield_reason) (i32.const 16))
        (then (global.set $last_run_halt (i32.const 4)) (br $halt)))
      (if (i32.eq (global.get $yield_reason) (i32.const 18))
        (then (global.set $last_run_halt (i32.const 4)) (br $halt)))
      (if (i32.or
        (i32.eq (global.get $yield_reason) (i32.const 1))
        (i32.or
          (i32.eq (global.get $yield_reason) (i32.const 5))
          (i32.or
            (i32.eq (global.get $yield_reason) (i32.const 7))
            (i32.or
              (i32.eq (global.get $yield_reason) (i32.const 8))
              (i32.or
                (i32.eq (global.get $yield_reason) (i32.const 9))
                (i32.or
                  (i32.eq (global.get $yield_reason) (i32.const 10))
                  ;; 12 = io_wait: a lazily mounted file needs a chunk the host
                  ;; has not read yet. Same contract as 8/9 — EIP is parked on
                  ;; the thunk, so clearing the yield re-enters the call.
                  (i32.or
                    (i32.eq (global.get $yield_reason) (i32.const 12))
                    ;; 13 = vblank_wait: a DirectDraw call is waiting for the
                    ;; display. Same contract again — the host clears the
                    ;; yield on the next refresh and the call re-tests.
                    (i32.or
                      (i32.eq (global.get $yield_reason) (i32.const 13))
                      ;; 14/15 = a clock or message-queue spin the detectors in
                      ;; src/09a-handlers.wat caught. Same contract once more:
                      ;; the frame is intact and EIP is on the thunk, so the
                      ;; host sleeps to the deadline and the call re-runs. They
                      ;; belong on THIS list rather than the plain yield_flag
                      ;; path so --batch-stats attributes them to "blocking
                      ;; wait" — the batch stopped because the guest is
                      ;; waiting, not because it ran out of budget.
                      (i32.or
                        (i32.eq (global.get $yield_reason) (i32.const 14))
                        (i32.eq (global.get $yield_reason) (i32.const 15)))))))))))
        (then (global.set $last_run_halt (i32.const 4)) (br $halt)))
      ;; The 16-bit twin of the thunk-zone check below. A far call or return
      ;; into the thunk segment is caught at the transfer, but EIP can also be
      ;; *parked* there — a modal message box owns the task until it is
      ;; dismissed and is re-entered here on every pass. Decoding the segment
      ;; would find nothing but zeros.
      (if (global.get $code16)
        (then
          (if (i32.and
                (i32.ne (global.get $WIN16_THUNK_SEL) (i32.const 0))
                (i32.eq (global.get $sreg_cs) (global.get $WIN16_THUNK_SEL)))
            (then
              (call $win16_dispatch
                (i32.sub (global.get $eip) (global.get $seg_base_cs)) (i32.const 0))
              (br $main)))))
      ;; If EIP landed in thunk zone (e.g. ret-to-thunk for sync message continuation),
      ;; dispatch the thunk directly instead of trying to decode it as x86
      (if (thunk-contains (global.get $eip))
        (then
          (local.set $prev_eip (global.get $eip))
          (local.set $prev_esp (i32.load offset=16 (global.get $reg_base)))
          (global.set $current_thunk_eip (global.get $eip))
          (global.set $handler_set_eip (i32.const 0))
          (call $win32_dispatch (i32.div_u
            (i32.sub (global.get $eip) (global.get $thunk_guest_base)) (i32.const 8)))
          ;; If handler didn't redirect EIP, pop the saved return address.
          ;; Normal API handlers do `esp += 4 + nargs*4` but never set EIP;
          ;; without this, re-entry to the same thunk loops forever and
          ;; bleeds ESP by the handler's pop each pass. Continuation thunks
          ;; (CACA*) that deliberately re-enter by setting EIP to the same
          ;; thunk addr raise $handler_set_eip to opt out of the auto-pop.
          (if (i32.and
                (i32.eq (global.get $eip) (local.get $prev_eip))
                (i32.eqz (global.get $handler_set_eip)))
            (then (global.set $eip (call $gl32 (local.get $prev_esp)))))
          (br $main)))
      ;; A wndproc marker (0xFFFE____/0xFFFF____) called directly as code.
      (if (i32.ge_u (global.get $eip) (i32.const 0xFFFE0000))
        (then
          (if (call $wndproc_marker_direct_call) (then (br $main)))))
      ;; $dbg_prev_eip is set to the block about to run, so anything reading it
      ;; *during* that block sees the block itself, not its predecessor. That
      ;; is what $bp_first_caller and the debug prompt want, because they run
      ;; earlier in the same iteration. A trap raised by the decoder does not:
      ;; by then the assignment has happened, and it would report itself. So
      ;; the value being overwritten is kept one step longer.
      (global.set $dbg_prev2_eip (global.get $dbg_prev_eip))
      (global.set $dbg_prev_eip (global.get $eip))
      (if (global.get $dbg_any) (then
      ;; --trace-esp: emit (eip, esp) at block entry for in-range EIPs.
      (if (global.get $trace_esp_flag)
        (then
          (if (i32.and
                (i32.ge_u (global.get $eip) (global.get $trace_esp_lo))
                (i32.or (i32.eqz (global.get $trace_esp_hi))
                        (i32.le_u (global.get $eip) (global.get $trace_esp_hi))))
            (then (call $host_log_block (global.get $eip) (i32.load offset=16 (global.get $reg_base)))))))
      ;; --trace-eip-range: emit eip at block entry for in-range EIPs.
      (if (global.get $trace_eip_flag)
        (then
          (if (i32.and
                (i32.ge_u (global.get $eip) (global.get $trace_eip_lo))
                (i32.or (i32.eqz (global.get $trace_eip_hi))
                        (i32.le_u (global.get $eip) (global.get $trace_eip_hi))))
            (then (call $host_log_eip (global.get $eip))))))
      (if (global.get $handler_hist_enabled)
        (then (call $hot_block_hist_record (global.get $eip))))
      ))
      ;; Two compares against addresses the decoder recognized, instead of the
      ;; 17-load byte-signature scan this used to run ahead of every block.
      (if (i32.or (i32.eq (global.get $eip) (global.get $sbh_eip_a))
                  (i32.eq (global.get $eip) (global.get $sbh_eip_b)))
        (then
          (if (call $fast_msvc_sbh_scan)
            (then (br $main)))))
      ;; The page index is the only lookup there is now: it is exact, so a miss
      ;; here really does mean nothing is compiled at this address. The hash
      ;; cache that used to sit between these two rungs is gone --
      ;; docs/page-compile-design.md section 4.
      (local.set $thread (i32.and (call $page_resolve (global.get $eip)) (i32.const -2)))
      (if (i32.eqz (local.get $thread))
        (then (local.set $thread (call $decode_run (global.get $eip)))))
      (global.set $ip (local.get $thread))
      (if (global.get $handler_hist_enabled)
        (then (global.set $handler_hist_last (i32.const -1))))
      ;; 256 BLOCKS per visit to this loop (see $next): the bound on nested
      ;; $jcc_end fall-through frames and on how long the input-wake check
      ;; above waits, both of which used to be 1000 ops.
      (global.set $steps (i32.const 256))
      (call $next)
      (if (global.get $page_chunk_deferred)
        (then (call $page_chunk_reclaim_deferred)))
      (br $main)))
    (if (i32.and (global.get $wave_callback_saved)
          (i32.or (i32.eqz (global.get $eip))
            (i32.eq (global.get $yield_reason) (i32.const 2))))
      (then
        (global.set $wave_callback_saved (i32.const 0))
        (global.set $mm_timer_in_cb (i32.const 0))))
    ;; What this call actually got through. $block_budget can end up negative --
    ;; a fold retires k blocks in one go and subtracts all k -- so this can read
    ;; slightly above the budget it was given; that is honest, not a wrap.
    (global.set $last_run_blocks
      (i32.sub (local.get $max_blocks) (global.get $block_budget)))
    ;; Bank this call's blocks and give an outer (re-entrant) call its own
    ;; start back, so $blocks_now stays monotonic across nesting.
    (global.set $blocks_retired_base
      (i32.add (global.get $blocks_retired_base) (global.get $last_run_blocks)))
    (global.set $run_budget_start (local.get $saved_start))
    (global.set $api_handler_depth (local.get $saved_api_depth))
    (global.set $block_budget (local.get $saved_budget)))

  ;; Blocks retired since the instance started, including the running call's
  ;; progress so far. Wraps; only ever used as a difference.
  (func $blocks_now (result i32)
    (i32.add (global.get $blocks_retired_base)
      (i32.sub (global.get $run_budget_start) (global.get $block_budget))))

  ;; Blocks the last run() call retired, and the halt reason behind it (see the
  ;; $last_run_halt comment in 01-header.wat for the codes).
  (func (export "get_last_run_blocks") (result i32) (global.get $last_run_blocks))
  (func (export "get_last_run_halt")   (result i32) (global.get $last_run_halt))
  (func (export "get_block_budget")    (result i32) (global.get $block_budget))

  ;; Diagnostic switch, see $virtual_leak_small_releases in 01-header.wat. The
  ;; argument is the largest release, in bytes, to turn into a no-op; 0 restores
  ;; normal behaviour. Nothing in the product calls this.
  (func (export "set_virtual_leak_small_releases") (param $bytes i32)
    (global.set $virtual_leak_small_releases (local.get $bytes)))
  (func (export "get_virtual_leak_small_releases") (result i32)
    (global.get $virtual_leak_small_releases))
  ;; Same diagnostic narrowed to one guest call site: the runtime return address
  ;; of the VirtualFree caller whose MEM_RELEASE should be ignored. 0 disarms.
  (func (export "set_virtual_leak_release_caller") (param $ret i32)
    (global.set $virtual_leak_release_caller (local.get $ret)))
  (func (export "get_virtual_leak_release_caller") (result i32)
    (global.get $virtual_leak_release_caller))
  (func (export "get_virtual_leak_hits") (result i32)
    (global.get $virtual_leak_hits))

  ;; Hook for test/test-shift-equivalence.js, which checks the unified
  ;; $do_shift against an independent model of the x86 semantics over every
  ;; (width, op, count) and a spread of values. Runs one shift with a chosen
  ;; carry-in and leaves CF/ZF/SF readable.
  (func (export "test_shift") (param $bits i32) (param $type i32)
        (param $val i32) (param $count i32) (param $cf_in i32) (param $res_in i32) (result i32)
    ;; flag_op 8 with a/b is the raw-carry form, which is how a carry-in is
    ;; seeded without disturbing the result flags. $res_in seeds the ZF/SF
    ;; source, which a rotate must leave alone.
    (global.set $flag_op (i32.const 8))
    (global.set $flag_sign_shift (i32.const 31))
    (global.set $flag_a (local.get $cf_in))
    (global.set $flag_b (i32.const 0))
    (global.set $flag_res (local.get $res_in))
    (call $do_shift (local.get $bits) (local.get $type) (local.get $val) (local.get $count)))

  (func (export "test_shift_flags") (result i32)
    (i32.or (call $get_cf)
      (i32.or (i32.shl (call $get_zf) (i32.const 1))
              (i32.or (i32.shl (call $get_sf) (i32.const 2))
                      (i32.shl (call $get_of) (i32.const 3))))))

  ;; ============================================================
  ;; DEBUG EXPORTS
  ;; ============================================================
  (func (export "get_eip") (result i32) (global.get $eip))
  (func (export "get_dbg_prev_eip") (result i32) (global.get $dbg_prev_eip))
  ;; The block before that one. When a thread jumps into blank memory, prev_eip
  ;; is already inside the blank memory — the useful address is the block that
  ;; jumped, which is one further back.
  (func (export "get_dbg_prev2_eip") (result i32) (global.get $dbg_prev2_eip))
  (func (export "get_esp") (result i32) (i32.load offset=16 (global.get $reg_base)))
  (func (export "get_eax") (result i32) (i32.load offset=0 (global.get $reg_base)))
  (func (export "get_ecx") (result i32) (i32.load offset=4 (global.get $reg_base)))
  (func (export "get_edx") (result i32) (i32.load offset=8 (global.get $reg_base)))
  (func (export "get_ebx") (result i32) (i32.load offset=12 (global.get $reg_base)))
  (func (export "get_ebp") (result i32) (i32.load offset=20 (global.get $reg_base)))
  (func (export "get_esi") (result i32) (i32.load offset=24 (global.get $reg_base)))
  (func (export "get_edi") (result i32) (i32.load offset=28 (global.get $reg_base)))
  ;; The segment registers a 16-bit task is holding. Invisible everywhere until
  ;; now, and a wrong one is what a whole class of Win16 bug looks like: the
  ;; task pushes DS as half of a far pointer and the API on the other side
  ;; reads a string out of nowhere. --trace-at prints these.
  (func (export "get_sreg_ds") (result i32) (global.get $sreg_ds))
  (func (export "get_sreg_es") (result i32) (global.get $sreg_es))
  (func (export "get_sreg_ss") (result i32) (global.get $sreg_ss))
  (func (export "get_sreg_cs") (result i32) (global.get $sreg_cs))
  (func (export "get_staging") (result i32) (global.get $PE_STAGING))
  (func (export "get_staging_size") (result i32) (global.get $PE_STAGING_SIZE))
  (func (export "get_fs_base") (result i32) (global.get $fs_base))
  (func (export "set_fs_base") (param i32) (global.set $fs_base (local.get 0)))
  ;; Turn the CPUID MMX advertisement off to force guests down their scalar
  ;; fallbacks. The MMX handlers stay in the build either way, so this is an
  ;; A/B of the code the guest chooses, which is the only comparison that means
  ;; anything -- a Pentium-MMX-era app does not have a "use MMX" switch, it has
  ;; a CPUID check.
  (func (export "set_cpu_mmx") (param i32) (global.set $cpu_mmx_enable (local.get 0)))
  (func (export "get_cpu_mmx") (result i32) (global.get $cpu_mmx_enable))
  (func (export "set_cpu_sse") (param i32) (global.set $cpu_sse_enable (local.get 0)))
  (func (export "get_cpu_sse") (result i32) (global.get $cpu_sse_enable))
  (func (export "get_mmx_exec_count") (result i32) (global.get $mmx_exec_count))
  ;; Test seam for tools/mmx-check.js. $mmx_binop is pure -- two 64-bit inputs
  ;; and a subop id in, one 64-bit result out -- so it can be checked against a
  ;; reference model exhaustively without booting a guest, which is the only
  ;; way to be sure about lane order in the shuffles and pack instructions.
  (func (export "mmx_binop") (param $a i64) (param $b i64) (param $sub i32) (result i64)
    (call $mmx_binop (local.get $a) (local.get $b) (local.get $sub)))
  (func (export "get_current_thread_id") (result i32) (global.get $current_thread_id))
  ;; Sections this thread took from a holder that never released one. Nonzero
  ;; means a real bug happened and was worked around, so runs report it.
  (func (export "get_cs_steals") (result i32) (global.get $cs_steals))
  ;; How many times this thread parked on a held section. Cheap contention
  ;; meter: a run whose thread count went up and whose throughput went down
  ;; should be read here first.
  (func (export "get_cs_waits") (result i32) (global.get $cs_waits))
  ;; LeaveCriticalSection calls from a thread that did not own the section.
  (func (export "get_cs_bad_leaves") (result i32) (global.get $cs_bad_leaves))
  ;; Sections entered while already held, because a nested synchronous wndproc
  ;; was running and could not be parked. Exclusion was not honoured for these.
  (func (export "get_cs_barges") (result i32) (global.get $cs_barges))
  ;; Parked EnterCriticalSection calls the guest never returned to, where it
  ;; went instead, and any ESP movement across a park that did come back.
  ;; For test/test-wat-critical-section.js: a unit test calls the handler
  ;; directly, so nothing has recorded which thunk the guest is inside. Setting
  ;; it lets the test assert the property that actually broke — that a park
  ;; sends EIP back to the CALL, not to wherever the block began.
  (func (export "set_current_thunk_eip") (param i32)
    (global.set $current_thunk_eip (local.get 0)))
  (func (export "get_cs_park_eip") (result i32) (global.get $cs_park_eip))
  (func (export "get_cs_abandoned") (result i32) (global.get $cs_abandoned))
  (func (export "get_cs_abandoned_eip") (result i32) (global.get $cs_abandoned_eip))
  (func (export "get_cs_resume_esp_delta") (result i32) (global.get $cs_resume_esp_delta))
  (func (export "get_cs_bad_leave_addr") (result i32) (global.get $cs_bad_leave_addr))
  (func (export "get_cs_bad_leave_owner") (result i32) (global.get $cs_bad_leave_owner))
  (func (export "get_cs_wait_addr") (result i32) (global.get $cs_wait_addr))
  (func (export "get_cs_wait_owner") (result i32) (global.get $cs_wait_owner))
  (func (export "set_cs_steal_after") (param i32) (global.set $cs_steal_after (local.get 0)))
  (func (export "set_guest_can_block") (param i32) (global.set $guest_can_block (local.get 0)))
  ;; The registry itself, so a run can print WHICH sections are held and by whom
  ;; at exit rather than only that somebody is waiting. It lives in shared memory
  ;; and holds WASM addresses, so any instance — or the host, reading directly —
  ;; sees the same table.
  (func (export "get_cs_table") (result i32) (global.get $CS_TABLE))
  (func (export "get_cs_table_entries") (result i32) (global.get $CS_TABLE_ENTRIES))
  ;; Release every critical section still owned by a thread that has ended, and
  ;; say how many. The argument is that thread's $current_thread_id (main is 1, a
  ;; spawned thread is tid+1), NOT its tid — the guest field holds the former,
  ;; because GetCurrentThreadId does. Safe to call from any instance: the registry
  ;; holds WASM addresses, so no image-base translation is involved.
  (func (export "release_cs_owned_by") (param i32) (result i32)
    (call $cs_release_owned (local.get 0)))
  (func (export "get_process_id") (result i32) (call $current_process_id))
  (func (export "set_process_id") (param $pid i32)
    ;; PID zero is reserved by Win32 and means "use the compatibility default"
    ;; internally, so hosts should always assign a positive value.
    (i32.store (global.get $SHARED_PROCESS_ID) (local.get $pid)))
  ;; CRITICAL_SECTION handlers, callable without a guest stack, so the semantics
  ;; can be asserted directly instead of inferred from an app that hangs. The
  ;; handlers pop a stdcall frame that is not there, hence the ESP save/restore;
  ;; a park also sets the yield state, which these clear and report as 1 so a
  ;; test can assert "this Enter blocked" without unwinding an interpreter run.
  ;; See test/test-wat-critical-section.js.
  (func (export "test_cs_init") (param $cs i32)
    (local $saved_esp i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (call $handle_InitializeCriticalSection
      (local.get $cs) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp)))
  (func (export "test_cs_init_spin") (param $cs i32) (param $spin i32) (result i32)
    (local $saved_esp i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (call $handle_InitializeCriticalSectionAndSpinCount
      (local.get $cs) (local.get $spin) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp))
    (i32.load offset=0 (global.get $reg_base)))
  (func (export "test_cs_enter") (param $cs i32) (result i32)
    (local $saved_esp i32) (local $bits i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (call $handle_EnterCriticalSection
      (local.get $cs) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (if (i32.eq (global.get $yield_reason) (i32.const 9))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 1)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (local.get $saved_esp))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 2)))))
    (if (global.get $handler_set_eip)
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 4)))))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (global.set $handler_set_eip (i32.const 0))
    (local.get $bits))
  (func (export "test_cs_delete") (param $cs i32)
    (local $saved_esp i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (call $handle_DeleteCriticalSection
      (local.get $cs) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp)))
  (func (export "test_cs_leave") (param $cs i32)
    (local $saved_esp i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (call $handle_LeaveCriticalSection
      (local.get $cs) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp)))
  ;; The window and class table claims, callable without a guest at all, so two
  ;; OS threads can race them directly. See test/test-wat-window-tables.js.
  (func (export "test_wnd_table_set") (param $hwnd i32) (param $wndproc i32)
    (call $wnd_table_set (local.get $hwnd) (local.get $wndproc)))
  (func (export "test_class_register") (param $name_wa i32) (result i32)
    (call $class_table_register (local.get $name_wa)))
  (func (export "test_class_register_data") (param $name_wa i32) (param $wndclass_wa i32) (result i32)
    (call $class_table_register_data (local.get $name_wa) (local.get $wndclass_wa)))
  (func (export "test_class_lookup") (param $name_wa i32) (result i32)
    (call $class_table_lookup (local.get $name_wa)))
  (func (export "test_shared_post")
    (param $hwnd i32) (param $msg i32) (param $wparam i32) (param $lparam i32) (result i32)
    (call $shared_post_queue_enqueue
      (local.get $hwnd) (local.get $msg) (local.get $wparam) (local.get $lparam)))
  (func (export "test_shared_post_read") (param $msg_ptr i32) (param $remove i32) (result i32)
    (call $shared_post_queue_read (local.get $msg_ptr) (local.get $remove)))
  (func (export "reset_thread_message_queue") (param $tid i32)
    (call $getmessage_hook_reset (local.get $tid))
    (call $shared_post_queue_reset_tid (local.get $tid)))
  (func (export "test_timer_set")
    (param $hwnd i32) (param $id i32) (param $interval i32) (param $callback i32)
    (call $timer_set (local.get $hwnd) (local.get $id) (local.get $interval) (local.get $callback)))
  (func (export "test_timer_check") (param $msg_ptr i32) (param $consume i32) (result i32)
    (call $timer_check_due (local.get $msg_ptr) (local.get $consume)))
  (func (export "test_timer_kill") (param $hwnd i32) (param $id i32) (result i32)
    (call $timer_kill (local.get $hwnd) (local.get $id)))
  (func (export "test_timer_next_auto_id") (result i32) (call $timer_next_auto_id))

  (func (export "test_help_dispatch_a")
    (param $caller i32) (param $path_ga i32) (param $command i32)
    (param $data i32) (result i32)
    (call $help_dispatch_api_a
      (local.get $caller) (local.get $path_ga) (local.get $command) (local.get $data)))

  (func (export "test_help_dispatch_w")
    (param $caller i32) (param $path_ga i32) (param $command i32)
    (param $data i32) (result i32)
    (call $help_dispatch_api_w
      (local.get $caller) (local.get $path_ga) (local.get $command) (local.get $data)))
  (func (export "get_help_window") (result i32) (global.get $help_hwnd))
  (func (export "get_help_view_topic_ptr") (result i32) (global.get $help_topic_wa))
  (func (export "get_help_view_topic_len") (result i32) (global.get $help_topic_len))
  (func (export "get_help_view_title_ptr") (result i32) (global.get $help_title_wa))
  (func (export "get_help_view_title_len") (result i32) (global.get $help_title_len))
  (func (export "get_help_view_topic_index") (result i32)
    (if (result i32) (global.get $help_cur_topic)
      (then (i32.sub (global.get $help_cur_topic) (i32.const 1)))
      (else (i32.const -1))))
  (func (export "get_help_view_back_count") (result i32) (global.get $help_back_count))
  (func (export "test_help_view_go_back") (call $help_go_back))

  (func (export "get_sync_msg_depth") (result i32) (global.get $sync_msg_depth))
  (func (export "get_window_thread") (param $hwnd i32) (result i32)
    (call $wnd_get_thread (local.get $hwnd)))
  (func (export "set_current_thread_id") (param i32) (global.set $current_thread_id (local.get 0)))
  (func (export "set_host_shadow") (param i32)
    (global.set $host_shadow (i32.ne (local.get 0) (i32.const 0))))
  (func (export "get_image_base") (result i32) (global.get $image_base))
  ;; Read-only host bridge for guest pointers embedded in GPU command
  ;; arguments. Unlike image-relative arithmetic, $g2w also resolves sparse
  ;; VirtualAlloc and the high CreateDIBSection arena.
  (func (export "guest_to_wasm") (param $guest i32) (result i32)
    (call $g2w (local.get $guest)))
  ;; The g2w-fast macro's miss path on its own, so test/test-g2w-fast-macro.js
  ;; can check that the macro hands every non-direct address to the same
  ;; DIB -> page table -> miss chain the old single $g2w ran.
  (func (export "test_g2w_slow") (param $guest i32) (result i32)
    (call $g2w_slow (local.get $guest)))
  (func (export "get_rsrc_rva") (result i32) (global.get $rsrc_rva))
  (func (export "get_thread_alloc") (result i32) (global.get $thread_alloc))
  (func (export "get_cache_clears") (result i32) (global.get $cache_clears))
  (func (export "get_cache_stores") (result i32) (global.get $cache_stores))
  (func (export "get_cache_evicts") (result i32) (global.get $cache_evicts))
  (func (export "get_cache_invals") (result i32) (global.get $cache_invals))
  (func (export "get_cache_inval_hits") (result i32) (global.get $cache_inval_hits))
  (func (export "get_cache_inval_page") (result i32) (global.get $cache_inval_page))
  (func (export "get_wndproc") (result i32) (global.get $wndproc_addr))
  (func (export "get_thunk_base") (result i32) (global.get $thunk_guest_base))
  (func (export "get_thunk_end") (result i32) (global.get $thunk_guest_end))
  ;; The thunk record at a thunk-zone guest address: word 0 is the import's
  ;; name RVA (or a 0xCACA____ continuation marker), word 1 the api_table id.
  ;; -1 outside the zone. For naming --edge-hist thunk edges in run.js.
  (func (export "thunk_word") (param $addr i32) (param $w i32) (result i32)
    (if (i32.or (i32.lt_u (local.get $addr) (global.get $thunk_guest_base))
                (i32.ge_u (local.get $addr) (global.get $thunk_guest_end)))
      (then (return (i32.const -1))))
    (i32.load (i32.add (call $thunk_metadata_addr
                                (i32.shr_u (i32.sub (local.get $addr) (global.get $thunk_guest_base)) (i32.const 3)))
                       (i32.shl (i32.and (local.get $w) (i32.const 1)) (i32.const 2)))))
  (func (export "get_num_thunks") (result i32) (global.get $num_thunks))
  ;; Update thunk end to match current allocation count
  ;; Raise the process-wide thunk cursor to at least this instance's count.
  ;; Load-time allocation (the PE loader, before any thread exists) bumps the
  ;; local global directly and reaches the shared cell only through here.
  (func $thunk_publish
    (local $cur i32)
    (block $done (loop $retry
      (local.set $cur (i32.atomic.load (global.get $THUNK_NEXT_SHARED)))
      (br_if $done (i32.ge_u (local.get $cur) (global.get $num_thunks)))
      (br_if $done (i32.eq (local.get $cur)
        (i32.atomic.rmw.cmpxchg (global.get $THUNK_NEXT_SHARED)
          (local.get $cur) (global.get $num_thunks))))
      (br $retry))))

  ;; Reserve one thunk index for this instance, exclusively. Callers set
  ;; $num_thunks to the returned index, write the thunk at it, and then bump the
  ;; local global as they always did — which lands back on the value the shared
  ;; cursor already holds.
  (func $thunk_reserve (result i32)
    (call $thunk_publish)
    (i32.atomic.rmw.add (global.get $THUNK_NEXT_SHARED) (i32.const 1)))

  ;; Publish this instance's count, adopt the process-wide one, and derive the
  ;; guest-visible end from it. Adopting matters as much as publishing: a thunk
  ;; another instance allocated is inside the zone but PAST a local count, and
  ;; $run bounds-checks EIP against $thunk_guest_end before dispatching it.
  (func $update_thunk_end (export "seal_thunks")
    (local $shared i32)
    (call $thunk_publish)
    (local.set $shared (i32.atomic.load (global.get $THUNK_NEXT_SHARED)))
    (if (i32.gt_u (local.get $shared) (global.get $num_thunks))
      (then (global.set $num_thunks (local.get $shared))))
    (global.set $thunk_guest_end
      (i32.add (global.get $thunk_guest_base)
        (i32.mul (global.get $num_thunks) (i32.const 8)))))
  ;; Cold membership path: never decode a newly published thunk as x86 just
  ;; because this worker has not reached its next host synchronization point.
  ;; Refresh the count too: dispatch aliases and continuation discovery share it.
  (func $thunk_contains_new (param $target i32) (result i32)
    (if (i32.ge_u (i32.sub (local.get $target) (global.get $thunk_guest_base))
          (global.get $THUNK_BASE_SIZE))
      (then (return (i32.const 0))))
    (call $update_thunk_end)
    (if (i32.lt_u (local.get $target) (global.get $thunk_guest_end))
      (then
        (call $sync_thread_thunk_globals)
        (return (call $thunk_entry_original (local.get $target)))))
    (i32.const 0))

  (func (export "sync_thunk_state") (param $thunk_ge i32) (param $num_th i32)
    (global.set $thunk_guest_end (local.get $thunk_ge))
    (global.set $num_thunks (local.get $num_th))
    (call $sync_thread_thunk_globals))

  ;; Flag debugging exports
  (func (export "get_flag_res") (result i32) (global.get $flag_res))
  (func (export "get_flag_op") (result i32) (global.get $flag_op))
  (func (export "get_flag_a") (result i32) (global.get $flag_a))
  (func (export "get_flag_b") (result i32) (global.get $flag_b))
  (func (export "get_flag_sign_shift") (result i32) (global.get $flag_sign_shift))

  ;; Read-only: these bound one instance's private arena. There are deliberately
  ;; no setters — JS used to marshal them between instances around every slice to
  ;; fake shared state, and that is exactly what $heap_low_reserve replaces.
  (func (export "get_heap_ptr") (result i32) (global.get $heap_ptr))
  ;; Callers take the whole list (the worker publish), so the bins join it.
  (func (export "get_free_list") (result i32) (call $heap_bins_flush) (global.get $free_list))
  (func (export "get_heap_end") (result i32) (global.get $heap_end))
  (func (export "get_heap_sparse_ptr") (result i32) (global.get $heap_sparse_ptr))
  (func (export "get_heap_sparse_end") (result i32) (global.get $heap_sparse_end))
  ;; Publish the process heap base + chunk cursor. The PE loader calls the same
  ;; function; exported so a harness can set a heap up without a real image.
  (func (export "heap_init") (param i32) (call $heap_init (local.get 0)))
  (func (export "get_virtual_alloc_top") (result i32) (global.get $virtual_alloc_top))
  (func (export "set_virtual_alloc_top") (param i32) (global.set $virtual_alloc_top (local.get 0)))
  (func (export "get_heap_base") (result i32) (global.get $heap_base))
  ;; Compatibility high-water metadata; reusable allocation lives in sync.

  (func (export "get_tls_next_index") (result i32)
    (i32.atomic.load (global.get $TLS_NEXT_INDEX_SHARED)))
  (func (export "set_tls_next_index") (param i32)
    (call $tls_publish_minimum (local.get 0)))
  (func (export "test_reserve_tls_index") (result i32) (call $tls_reserve))
  (func (export "get_tls_slots") (result i32) (global.get $tls_slots))
  (func (export "set_tls_slots") (param i32) (drop (call $tls_attach_slots (local.get 0))))
  (export "ensure_tls_slots" (func $tls_ensure_slots))
  ;; Post queue exports for IPC injection
  (func (export "get_main_hwnd") (result i32) (global.get $main_hwnd))
  (func (export "get_dx_primary_pal_wa") (result i32) (call $dx_primary_pal_get))
  (func (export "get_dx_scroll_hold_slot") (result i32)
    (if (result i32) (global.get $dx_scroll_hold_wa)
      (then (call $dx_slot_of (global.get $dx_scroll_hold_wa)))
      (else (i32.const -1))))
  ;; The window DirectDraw currently owns the whole screen through, or 0.
  ;; A DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN app's primary surface *is* the display,
  ;; so its window shows no caption, border or menu bar however it was styled
  ;; -- the DX SDK's own samples keep WS_CAPTION and a menu and rely on that.
  ;; The compositor cannot infer this from the style bits alone.
  ;; 1 when the DirectDraw surface in SLOT has a clipper bound to a window
  ;; (SetClipper + IDirectDrawClipper::SetHWnd). A Blt through such a clipper
  ;; is clipped to the window's visible region, so it does not paint over that
  ;; window's child controls; the compositor uses this to keep GDI children on
  ;; top of clipped presents (Age of Empires' name EDIT) while an unclipped
  ;; present still covers them.
  (func (export "dx_surface_window_clipped") (param $slot i32) (result i32)
    (local $entry i32) (local $clipper i32) (local $clip_entry i32)
    (if (i32.ge_u (local.get $slot) (global.get $DX_MAX)) (then (return (i32.const 0))))
    (local.set $entry (i32.add (global.get $DX_OBJECTS) (i32.mul (local.get $slot) (i32.const 32))))
    (local.set $clipper (call $dx_surface_clipper_get (local.get $entry)))
    (if (i32.eqz (local.get $clipper)) (then (return (i32.const 0))))
    (local.set $clip_entry (call $dx_from_this (local.get $clipper)))
    (i32.and
      (i32.eq (load.field DxObject type (local.get $clip_entry)) (i32.const 10))
      (i32.ne (load.field DxObject misc0 (local.get $clip_entry)) (i32.const 0))))

  (func (export "get_dx_exclusive_hwnd") (result i32)
    (if (result i32) (call $dx_exclusive_get)
      (then (call $dx_target_hwnd))
      (else (i32.const 0))))
  ;; 1 while the guest holds a ChangeDisplaySettings(CDS_FULLSCREEN) mode.
  ;; This is the explicit signal from an app that does not use DirectDraw:
  ;; without it the compositor would have to guess a fullscreen takeover from
  ;; window geometry, which a maximized ordinary app matches.
  ;; Process state, not a per-instance global -- see $dx_display_fullscreen_get.
  ;; The renderer calls this on whatever instance it has a handle to, which in
  ;; the browser's worker backend is NOT the instance the guest ran on.
  (func (export "get_display_fullscreen") (result i32)
    (call $dx_display_fullscreen_get))
  ;; The display mode the guest asked for with ChangeDisplaySettings, or 0
  ;; when it never asked. This is the LOGICAL DESKTOP the app laid itself out
  ;; for -- GetSystemMetrics(SM_CXSCREEN) already answers from here -- so the
  ;; presentation layer sizes the screen canvas to it and scales that to the
  ;; viewport, which is what real hardware does with a mode change. Without
  ;; it the canvas keeps its viewport-derived size and the app draws an
  ;; 800x600 frame into a surface that is some other shape.
  ;; 0 when no mode is in effect; callers must check before using w/h.
  (func (export "get_display_mode_active") (result i32)
    (call $dx_display_mode_get))
  (func (export "get_display_mode_w") (result i32)
    (call $dx_display_w_get))
  (func (export "get_display_mode_h") (result i32)
    (call $dx_display_h_get))
  ;; The device window of a windowed Direct3D9 device, or 0. Tells the
  ;; compositor that the surface it is presenting is that window's client
  ;; area at (0,0) rather than a screen-coordinate DirectDraw primary.
  (func (export "get_d3d9_windowed_hwnd") (result i32)
    (global.get $d3d9_windowed_hwnd))

  ;; Vertex declarations $d3d9_declaration_create refused. It refuses by
  ;; returning D3DERR_INVALIDCALL with *out left at 0, which a guest that does
  ;; not check HRESULTs turns into a NULL declaration and, much later, a draw
  ;; dropped for having neither a declaration nor an FVF. Without these there
  ;; is nothing to read: the count says whether it happens at all, the mask
  ;; says which of the renderer's rules refused (the 0x001..0x4000 bits set in
  ;; 09ae-d3d9-resources.wat), and the two element words are the first
  ;; offending D3DVERTEXELEMENT9, which tools/d3d9-decl-decode.js reads.
  (func (export "get_d3d9_decl_reject_count") (result i32)
    (global.get $d3d9_decl_reject_count))
  (func (export "get_d3d9_decl_reject_mask") (result i32)
    (global.get $d3d9_decl_reject_mask))
  (func (export "get_d3d9_decl_reject_element") (result i32)
    (global.get $d3d9_decl_reject_element))
  (func (export "get_d3d9_decl_reject_element_hi") (result i32)
    (global.get $d3d9_decl_reject_element_hi))
  ;; The second slot holds the first refusal whose rule differs from the first
  ;; one's, with its own reason beside it. B&W2 needs both: it trips stream!=0
  ;; in its menus and type>4 as the land loads, and one slot reported the
  ;; second rule as a bare bit with no element to decode.
  (func (export "get_d3d9_decl_reject_reason") (result i32)
    (global.get $d3d9_decl_reject_reason))
  (func (export "get_d3d9_decl_reject_element2") (result i32)
    (global.get $d3d9_decl_reject_element2))
  (func (export "get_d3d9_decl_reject_element2_hi") (result i32)
    (global.get $d3d9_decl_reject_element2_hi))
  (func (export "get_d3d9_decl_reject_reason2") (result i32)
    (global.get $d3d9_decl_reject_reason2))
  ;; Shader creation, counted the same way and for the same reason: a refused
  ;; CreateVertexShader hands the game NULL, the game binds nothing, and the
  ;; draw silently falls back to fixed-function vertex processing over a
  ;; declaration that was written for a shader. The two version words are the
  ;; first refused first-dword per stage, so they name the profile the game was
  ;; compiled for (0xfffe0200 = vs_2_0, 0xffff0200 = ps_2_0, and so on).
  (func (export "get_d3d9_shader_made") (result i32)
    (global.get $d3d9_shader_made))
  (func (export "get_d3d9_shader_refused") (result i32)
    (global.get $d3d9_shader_refused))
  (func (export "get_d3d9_shader_refused_vs") (result i32)
    (global.get $d3d9_shader_refused_vs))
  (func (export "get_d3d9_shader_refused_ps") (result i32)
    (global.get $d3d9_shader_refused_ps))
  ;; Zero means the version gate refused the profile outright; anything else is
  ;; $d3d_ir_error from the validator, with _at the dword offset it stopped at.
  (func (export "get_d3d9_shader_error_vs") (result i32)
    (global.get $d3d9_shader_error_vs))
  (func (export "get_d3d9_shader_error_ps") (result i32)
    (global.get $d3d9_shader_error_ps))
  (func (export "get_d3d9_shader_error_at") (result i32)
    (global.get $d3d9_shader_error_at))
  ;; The token stream dword the validator stopped on. "519 dwords in" names no
  ;; instruction; this word's opcode field does.
  (func (export "get_d3d9_shader_error_token") (result i32)
    (global.get $d3d9_shader_error_token))
  ;; The refused vertex shader's whole token stream: a WASM address and a dword
  ;; count, so a host can read it back and disassemble it. Zero until a vertex
  ;; shader has actually been refused.
  (func (export "get_d3d9_shader_error_copy") (result i32)
    (global.get $d3d9_shader_error_copy))
  (func (export "get_d3d9_shader_error_copy_words") (result i32)
    (global.get $d3d9_shader_error_copy_words))
  ;; Refusals split by requested profile, so the total can be attributed.
  (func (export "get_d3d9_shader_refused_vs11") (result i32)
    (global.get $d3d9_shader_refused_vs11))
  (func (export "get_d3d9_shader_refused_vs20") (result i32)
    (global.get $d3d9_shader_refused_vs20))
  (func (export "get_d3d9_shader_refused_ps1x") (result i32)
    (global.get $d3d9_shader_refused_ps1x))
  (func (export "get_d3d9_shader_refused_ps20") (result i32)
    (global.get $d3d9_shader_refused_ps20))
  (func (export "get_d3d9_shader_refused_other") (result i32)
    (global.get $d3d9_shader_refused_other))
  ;; ...and the first validator error in each 1.x bucket. Those are the
  ;; profiles the front end implements, so a refusal there names a gap inside
  ;; a compiler we have, not a profile we lack.
  (func (export "get_d3d9_shader_err_vs11") (result i32)
    (global.get $d3d9_shader_err_vs11))
  (func (export "get_d3d9_shader_err_vs11_at") (result i32)
    (global.get $d3d9_shader_err_vs11_at))
  (func (export "get_d3d9_shader_err_ps1x") (result i32)
    (global.get $d3d9_shader_err_ps1x))
  (func (export "get_d3d9_shader_err_ps1x_at") (result i32)
    (global.get $d3d9_shader_err_ps1x_at))
  ;; The window a DirectDraw/Direct3D frame should be presented into.
  ;;
  ;; Normally that is $main_hwnd, but $main_hwnd is a *per-instance* mutable
  ;; global and a worker thread is a separate WASM instance sharing only the
  ;; linear memory. Liquid War (Allegro) creates its window on T1, so the main
  ;; instance -- the one the compositor asks -- reports $main_hwnd == 0 and
  ;; every finished frame was dropped before it reached a window surface:
  ;; --trace-dx showed 17 `Present` lines and zero `Upload` lines.
  ;;
  ;; WND_RECORDS *is* shared memory, so when this instance has no main window
  ;; of its own, fall back to the topmost visible top-level window recorded
  ;; there. The process-wide cooperative HWND may name a hidden helper, so the
  ;; visible-window scan remains the compositor's correct fallback.
  (func (export "get_dx_present_hwnd") (result i32)
    (local $i i32) (local $hwnd i32) (local $best i32) (local $best_z i32)
    (local $z i32)
    (if (global.get $main_hwnd)
      (then (return (global.get $main_hwnd))))
    ;; No $main_hwnd in this instance (the window was made on another guest
    ;; thread, or this is the page's shadow of a Worker guest). The window
    ;; DirectDraw was told to present to is process-shared, so ask it first.
    (local.set $hwnd (call $dx_coop_hwnd_get))
    (if (i32.and (i32.ne (local.get $hwnd) (i32.const 0))
                 (i32.ne (call $wnd_table_find (local.get $hwnd)) (i32.const -1)))
      (then (return (local.get $hwnd))))
    ;; Otherwise the topmost visible top-level window that nobody OWNS: an
    ;; owned window is a dialog over the app, and the topmost one used to win
    ;; here -- the D3D viewer's frame was presented into its modal Open dialog
    ;; in threads mode (D3DIM-VIEWER-THREADS-DIALOG-OCCLUDED-20261011).
    (local.set $i (i32.const 0))
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (global.get $MAX_WINDOWS)))
      (local.set $hwnd (call $wnd_slot_hwnd (local.get $i)))
      (if (i32.and
            (i32.and (i32.ne (local.get $hwnd) (i32.const 0))
                     (i32.and (i32.eqz (call $wnd_get_parent (local.get $hwnd)))
                              (i32.eqz (call $wnd_get_owner (local.get $hwnd)))))
            (i32.ne (i32.and (call $wnd_get_style (local.get $hwnd))
                             (i32.const 0x10000000))          ;; WS_VISIBLE
                    (i32.const 0)))
        (then
          (local.set $z (call $wnd_z_get (local.get $hwnd)))
          (if (i32.or (i32.eqz (local.get $best))
                      (i32.gt_s (local.get $z) (local.get $best_z)))
            (then (local.set $best (local.get $hwnd))
                  (local.set $best_z (local.get $z))))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (local.get $best))
  (func (export "get_flash_state") (param $hwnd i32) (result i32)
    (local $slot i32)
    (local.set $slot (call $wnd_table_find (local.get $hwnd)))
    (if (result i32) (i32.eq (local.get $slot) (i32.const -1))
      (then (i32.const 0))
      (else (i32.load8_u (i32.add (global.get $FLASH_TABLE) (local.get $slot))))))
  (func (export "get_post_queue_count") (result i32)
    (i32.add (call $post_queue_total_count)
      (call $shared_post_queue_total_count)))
  (func (export "set_post_queue_count") (param i32)
    (if (i32.eqz (local.get 0))
      (then
        (call $post_queue_reset)
        (call $shared_post_queue_reset_tid (global.get $current_thread_id)))
      (else (global.set $post_queue_count (local.get 0)))))
  (func (export "wnd_table_set") (param i32) (param i32) (call $wnd_table_set (local.get 0) (local.get 1)))
  (func (export "wnd_get_proc_export") (param $hwnd i32) (result i32)
    (call $wnd_table_get (local.get $hwnd)))
  (func (export "dialog_get_proc_export") (param $hwnd i32) (result i32)
    (call $dialog_proc_get (local.get $hwnd)))
  (func (export "wnd_set_style_export") (param $hwnd i32) (param $style i32) (result i32)
    (call $wnd_set_style (local.get $hwnd) (local.get $style)))
  (func (export "wnd_region_set_export") (param $hwnd i32) (param $val i32)
    (call $wnd_region_set (local.get $hwnd) (local.get $val)))
  (func (export "wnd_region_get_export") (param $hwnd i32) (result i32)
    (call $wnd_region_get (local.get $hwnd)))

  ;; Cross-instance locking probes (docs/design-real-threads.md §3.1b). Two
  ;; guest threads are two WASM instances over one memory, so the tables they
  ;; share can only be tested by driving them from two real OS threads at once —
  ;; which is what test/test-wat-locks.js does with these.
  (func (export "test_lock_addr") (param $which i32) (result i32)
    (if (i32.eq (local.get $which) (i32.const 1))
      (then (return (global.get $LOCK_DX))))
    (if (i32.eq (local.get $which) (i32.const 2))
      (then (return (global.get $LOCK_SOCKET))))
    (global.get $LOCK_VIRTUAL_MAP))
  ;; A read-modify-write with a deliberate gap between the read and the write.
  ;; Unlocked, two instances lose updates; locked, they must not. The gap is what
  ;; makes the test fail reliably instead of once in a million runs.
  (func (export "test_lock_bump") (param $lock i32) (param $cell i32) (param $iters i32)
    (local $i i32) (local $v i32) (local $spin i32)
    (block $done (loop $again
      (br_if $done (i32.ge_u (local.get $i) (local.get $iters)))
      (call $lock_acquire (local.get $lock))
      (local.set $v (i32.load (local.get $cell)))
      (local.set $spin (i32.const 0))
      (block $paused (loop $pause
        (br_if $paused (i32.ge_u (local.get $spin) (i32.const 40)))
        (local.set $spin (i32.add (local.get $spin) (i32.const 1)))
        (br $pause)))
      (i32.store (local.get $cell) (i32.add (local.get $v) (i32.const 1)))
      (call $lock_release (local.get $lock))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $again))))
  ;; The same loop with no lock at all. It exists so the locked test above has a
  ;; negative control that lives in the tree rather than in someone's memory of
  ;; having tried it once: if this one ever stops losing updates, the platform
  ;; stopped running the two instances concurrently and every other check in
  ;; test/test-wat-locks.js has quietly become vacuous.
  (func (export "test_bump_unlocked") (param $cell i32) (param $iters i32)
    (local $i i32) (local $v i32) (local $spin i32)
    (block $done (loop $again
      (br_if $done (i32.ge_u (local.get $i) (local.get $iters)))
      (local.set $v (i32.load (local.get $cell)))
      (local.set $spin (i32.const 0))
      (block $paused (loop $pause
        (br_if $paused (i32.ge_u (local.get $spin) (i32.const 40)))
        (local.set $spin (i32.add (local.get $spin) (i32.const 1)))
        (br $pause)))
      (i32.store (local.get $cell) (i32.add (local.get $v) (i32.const 1)))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $again))))
  ;; Recursion must not deadlock: a critical section that reaches a function
  ;; taking the same lock is a bug we would rather survive than hang on.
  (func (export "test_lock_reentrant") (param $lock i32) (result i32)
    (call $lock_acquire (local.get $lock))
    (call $lock_acquire (local.get $lock))
    (call $lock_release (local.get $lock))
    ;; Still held by us after the inner release, or the nesting is not counted.
    (if (i32.ne (i32.atomic.load (local.get $lock)) (call $lock_owner_id))
      (then (call $lock_release (local.get $lock)) (return (i32.const 0))))
    (call $lock_release (local.get $lock))
    ;; Released means "not ours any more", not "zero": another thread may have
    ;; taken it between the release and this load, and asserting zero here made
    ;; the check fail for whichever thread happened to lose that footrace.
    (i32.ne (i32.atomic.load (local.get $lock)) (call $lock_owner_id)))
  (func (export "test_dx_alloc") (param $type i32) (result i32)
    (call $dx_alloc (local.get $type)))
  (func (export "test_vsock_alloc") (result i32) (call $vsock_alloc))
  (func (export "test_vsock_alloc_port") (result i32) (call $vsock_alloc_port))
  (func (export "test_virtual_map_commit") (param $guest i32) (param $size i32) (result i32)
    (call $virtual_map_commit (local.get $guest) (local.get $size)))
  (func (export "test_virtual_reserve_down") (param $size i32) (result i32)
    (call $virtual_reserve_down (local.get $size)))

  ;; Software-GDI migration probes. Production API handlers call the same
  ;; WAT-owned region registry; these exports keep its ownership testable
  ;; without driving the x86 stdcall dispatcher.
  (func (export "test_gdi_rgn_alloc_rect")
        (param i32) (param i32) (param i32) (param i32) (result i32)
    (call $gdi_rgn_alloc_rect
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)))
  (func (export "test_gdi_rgn_alloc_ellipse")
        (param i32) (param i32) (param i32) (param i32) (result i32)
    (call $gdi_rgn_alloc_ellipse
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)))
  (func (export "test_gdi_rgn_set_rect")
        (param i32) (param i32) (param i32) (param i32) (param i32) (result i32)
    (call $gdi_rgn_set_rect
      (local.get 0) (local.get 1) (local.get 2) (local.get 3) (local.get 4)))
  (func (export "test_gdi_rgn_get_box") (param i32) (param i32) (result i32)
    (call $gdi_rgn_get_box (local.get 0) (local.get 1)))
  (func (export "test_gdi_rgn_offset") (param i32) (param i32) (param i32) (result i32)
    (call $gdi_rgn_offset (local.get 0) (local.get 1) (local.get 2)))
  (func (export "test_gdi_rgn_combine")
        (param i32) (param i32) (param i32) (param i32) (result i32)
    (call $gdi_rgn_combine (local.get 0) (local.get 1) (local.get 2) (local.get 3)))
  (func (export "test_gdi_rgn_delete") (param i32) (result i32)
    (call $gdi_rgn_delete (local.get 0)))
  (func (export "test_gdi_rgn_equal") (param i32) (param i32) (result i32)
    (call $gdi_rgn_equal (local.get 0) (local.get 1)))
  (func (export "test_gdi_rgn_ext_create") (param i32) (param i32) (param i32) (result i32)
    (call $gdi_rgn_ext_create (local.get 0) (local.get 1) (local.get 2)))
  (func (export "test_gdi_bezier_leaf_count")
        (param f64) (param f64) (param f64) (param f64)
        (param f64) (param f64) (param f64) (param f64) (result i32)
    (call $gdi_bezier_leaf_count
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)
      (local.get 4) (local.get 5) (local.get 6) (local.get 7) (i32.const 0)))
  (func (export "get_gdi_region_table") (result i32) (global.get $GDI_REGION_TABLE))
  (func (export "test_gdi_bitmap_storage") (param i32) (result i32)
    (call $gdi_bitmap_storage (local.get 0)))
  (func (export "test_gdi_bitmap_palette") (param i32) (result i32)
    (local $record i32)
    (local.set $record (call $gdi_object_record (local.get 0)))
    (if (result i32) (local.get $record)
      (then (i32.load offset=32 (local.get $record))) (else (i32.const 0))))
  (func (export "test_gdi_bitmap_palette_count") (param i32) (result i32)
    (local $record i32)
    (local.set $record (call $gdi_object_record (local.get 0)))
    (if (result i32) (local.get $record)
      (then (i32.load offset=36 (local.get $record))) (else (i32.const 0))))
  (func (export "test_gdi_object_width") (param i32) (result i32)
    (call $gdi_native_get_object_w (local.get 0)))
  (func (export "test_gdi_object_style") (param i32) (result i32)
    (call $gdi_object_style (local.get 0)))
  (func (export "test_gdi_object_color") (param i32) (result i32)
    (call $gdi_object_color (local.get 0)))
  (func (export "test_gdi_object_param") (param i32) (result i32)
    (local $record i32)
    (local.set $record (call $gdi_object_record (local.get 0)))
    (if (result i32) (local.get $record)
      (then (i32.load offset=12 (local.get $record))) (else (i32.const 0))))
  (func (export "test_gdi_brush_sample")
        (param i32) (param i32) (param i32) (param i32) (result i32)
    (call $gdi_brush_sample
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)))
  ;; The row filler, exported beside the per-pixel sampler it is an
  ;; optimization of. $gdi_brush_fill_span samples one period of the brush and
  ;; repeats it, so it and $gdi_brush_sample are two statements of the same
  ;; function and can drift; test-wat-gdi-brush-period.js holds them together
  ;; by filling a row here and comparing it against the sampler pixel by pixel.
  (func (export "test_gdi_brush_fill_span")
        (param i32) (param i32) (param i32) (param i32) (param i32)
        (param i32) (param i32) (result i32)
    (call $gdi_brush_fill_span
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)
      (local.get 4) (local.get 5) (local.get 6)))
  ;; The status bar's sizing grip, drawn into any DC. Exported so its Win98
  ;; rib pattern can be asserted without rendering a whole application.
  (func (export "test_statusbar_draw_size_grip") (param i32) (param i32) (param i32)
    (call $statusbar_draw_size_grip
      (local.get 0) (local.get 1) (local.get 2)))
  (func (export "test_gdi_rop3_uses_pattern") (param i32) (result i32)
    (call $gdi_rop3_uses_pattern (local.get 0)))
  (func (export "test_gdi_object_height") (param i32) (result i32)
    (call $gdi_native_get_object_h (local.get 0)))
  (func (export "test_gdi_hdc_bitblt")
        (param i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32)
    (call $gdi_native_bitblt
      (local.get 0) (local.get 1) (local.get 2) (local.get 3) (local.get 4)
      (local.get 5) (local.get 6) (local.get 7) (local.get 8)))
  (func (export "test_gdi_hdc_transparent_blt")
        (param i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32)
    (call $gdi_native_transparent_blt
      (local.get 0) (local.get 1) (local.get 2) (local.get 3) (local.get 4)
      (local.get 5) (local.get 6) (local.get 7) (local.get 8)))
  (func (export "test_gdi_hdc_disabled_blt")
        (param i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32)
    (call $gdi_native_disabled_blt
      (local.get 0) (local.get 1) (local.get 2) (local.get 3) (local.get 4)
      (local.get 5) (local.get 6) (local.get 7) (local.get 8)))
  (func (export "test_gdi_hdc_fill_rgn") (param i32 i32 i32) (result i32)
    (call $gdi_native_fill_rgn (local.get 0) (local.get 1) (local.get 2)))
  (func (export "test_gdi_hdc_frame_rgn") (param i32 i32 i32 i32 i32) (result i32)
    (call $gdi_native_frame_rgn
      (local.get 0) (local.get 1) (local.get 2) (local.get 3) (local.get 4)))
  (func (export "test_gdi_mapping_adapters") (param i32) (result i32)
    (drop (call $gdi_native_set_window_org (local.get 0) (i32.const 3) (i32.const 4)))
    (drop (call $gdi_native_set_window_ext (local.get 0) (i32.const 5) (i32.const 6)))
    (drop (call $gdi_native_set_viewport_org (local.get 0) (i32.const 7) (i32.const 8)))
    (drop (call $gdi_native_set_viewport_ext (local.get 0) (i32.const 9) (i32.const 10)))
    (i32.and
      (i32.and
        (i32.and (i32.eq (call $gdi_native_get_window_org_x (local.get 0)) (i32.const 3))
          (i32.eq (call $gdi_native_get_window_org_y (local.get 0)) (i32.const 4)))
        (i32.and (i32.eq (call $gdi_native_get_window_ext_x (local.get 0)) (i32.const 5))
          (i32.eq (call $gdi_native_get_window_ext_y (local.get 0)) (i32.const 6))))
      (i32.and
        (i32.and (i32.eq (call $gdi_native_get_viewport_org_x (local.get 0)) (i32.const 7))
          (i32.eq (call $gdi_native_get_viewport_org_y (local.get 0)) (i32.const 8)))
        (i32.and (i32.eq (call $gdi_native_get_viewport_ext_x (local.get 0)) (i32.const 9))
          (i32.eq (call $gdi_native_get_viewport_ext_y (local.get 0)) (i32.const 10))))))
  (func (export "test_gdi_get_dibits")
        (param i32 i32 i32 i32 i32 i32 i32) (result i32)
    (call $gdi_get_dibits
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)
      (local.get 4) (local.get 5) (local.get 6)))
  (func (export "test_gdi_set_dibits")
        (param i32 i32 i32 i32 i32 i32 i32) (result i32)
    (call $gdi_set_dibits
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)
      (local.get 4) (local.get 5) (local.get 6)))
  (func (export "test_gdi_get_dib_color_table")
        (param i32 i32 i32 i32) (result i32)
    (call $gdi_get_dib_color_table
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)))
  (func (export "test_gdi_set_dib_color_table")
        (param i32 i32 i32 i32) (result i32)
    (call $gdi_set_dib_color_table
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)))
  (func (export "test_gdi_stretch_dibits")
        (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32)
    (call $gdi_stretch_dibits
      (local.get 0) (local.get 1) (local.get 2) (local.get 3) (local.get 4)
      (local.get 5) (local.get 6) (local.get 7) (local.get 8)
      (local.get 9) (local.get 10) (local.get 11) (local.get 12)))
  (func (export "test_gdi_ext_text_out_w_packed_ansi_len")
        (param i32 i32) (result i32)
    (call $gdi_ext_text_out_w_packed_ansi_len (call $g2w (local.get 0)) (local.get 1)))
  (func (export "test_start_LineDDA")
        (param i32 i32 i32 i32 i32 i32) (result i32)
    (local $start_esp i32)
    (local.set $start_esp (i32.load offset=16 (global.get $reg_base)))
    ;; Direct handler tests do not arrive through an API thunk, so provide the
    ;; return address and sixth stack argument at their ABI positions.
    (call $gs32 (local.get $start_esp) (i32.const 0))
    (call $gs32 (i32.add (local.get $start_esp) (i32.const 24)) (local.get 5))
    (call $handle_LineDDA
      (local.get 0) (local.get 1) (local.get 2) (local.get 3)
      (local.get 4) (i32.const 0))
    (global.get $eip))
  (func (export "test_gdi_client_rect_set")
        (param i32) (param i32) (param i32) (param i32) (param i32)
    (call $client_rect_set
      (local.get 0) (local.get 1) (local.get 2) (local.get 3) (local.get 4)))
  (func (export "gl_window_readback_version") (result i32) (i32.const 1))
  (func (export "gl_window_set_gpu_owned") (param $hwnd i32) (param $owned i32) (result i32)
    (local $p i32)
    (local.set $p (call $gdi_window_surface_record (local.get $hwnd) (i32.const 0)))
    (if (i32.eqz (local.get $p)) (then (return (i32.const 0))))
    (i32.atomic.store offset=28 (local.get $p) (local.get $owned))
    (i32.const 1))
  (func (export "test_gdi_window_surface_record") (param i32) (result i32)
    (call $gdi_window_surface_record (local.get 0) (i32.const 0)))
  (func (export "test_gdi_menu_overlay_dc") (result i32)
    (global.get $gdi_menu_overlay_dc))
  (func (export "test_gdi_menu_overlay_bitmap") (result i32)
    (global.get $gdi_menu_overlay_bitmap))
  (func (export "test_gdi_object_record") (param i32) (result i32)
    (call $gdi_object_record (local.get 0)))
  (func (export "test_dx_set_primary_palette_wa") (param i32)
    (call $dx_primary_pal_set (local.get 0)))
  ;; Seed/read the process-wide DirectDraw state from two WebAssembly instances
  ;; in the cross-thread SendMessage regression. These are deliberately helper
  ;; calls rather than raw memory accesses so the test covers the production
  ;; accessors used by DirectDraw handlers and GetSystemMetrics.
  (func (export "test_dx_set_process_state")
        (param $w i32) (param $h i32) (param $bpp i32) (param $mode i32)
        (param $hwnd i32) (param $exclusive i32) (param $palette i32)
    (call $dx_display_w_set (local.get $w))
    (call $dx_display_h_set (local.get $h))
    (call $dx_display_bpp_set (local.get $bpp))
    (call $dx_display_mode_set (local.get $mode))
    (call $dx_coop_hwnd_set (local.get $hwnd))
    (call $dx_exclusive_set (local.get $exclusive))
    (call $dx_primary_pal_set (local.get $palette)))
  (func (export "test_dx_get_process_state") (param $field i32) (result i32)
    (if (i32.eq (local.get $field) (i32.const 0))
      (then (return (call $dx_display_w_get))))
    (if (i32.eq (local.get $field) (i32.const 1))
      (then (return (call $dx_display_h_get))))
    (if (i32.eq (local.get $field) (i32.const 2))
      (then (return (call $dx_display_bpp_get))))
    (if (i32.eq (local.get $field) (i32.const 3))
      (then (return (call $dx_display_mode_get))))
    (if (i32.eq (local.get $field) (i32.const 4))
      (then (return (call $dx_coop_hwnd_get))))
    (if (i32.eq (local.get $field) (i32.const 5))
      (then (return (call $dx_exclusive_get))))
    (call $dx_primary_pal_get))
  (func (export "test_dx_set_primary_wa") (param i32)
    (global.set $dx_primary_wa (local.get 0)))
  (func (export "test_dx_primary_entry") (result i32)
    (call $dx_primary_entry))

  ;; ---- NC/message plumbing exports (JS host posts messages into WAT's queues) ----
  (func (export "nc_post_paint") (param $hwnd i32)
    (call $nc_flags_set (local.get $hwnd) (i32.const 1)))   ;; bit 0
  (func (export "nc_post_erase") (param $hwnd i32)
    (call $nc_flags_set (local.get $hwnd) (i32.const 2)))   ;; bit 1
  (func (export "nc_post_calcsize") (param $hwnd i32)
    (call $nc_flags_set (local.get $hwnd) (i32.const 4)))   ;; bit 2
  ;; Mark a visible window tree dirty without calling $host_invalidate for
  ;; every descendant. The host schedules one composite after this export;
  ;; generating per-child host invalidations here would create late synthetic
  ;; WM_NCPAINT work after a status bar has already repainted.
  (func $paint_mark_visible_tree (param $hwnd i32)
    (local $slot i32) (local $child i32)
    (if (i32.eqz (call $wnd_is_effectively_visible (local.get $hwnd)))
      (then (return)))
    (call $update_invalidate_full (local.get $hwnd))
    (call $paint_flag_set (local.get $hwnd))
    (local.set $slot (i32.const 0))
    (block $done (loop $scan
      (local.set $slot (call $wnd_next_child_slot (local.get $hwnd) (local.get $slot)))
      (br_if $done (i32.lt_s (local.get $slot) (i32.const 0)))
      (local.set $child (call $wnd_slot_hwnd (local.get $slot)))
      (call $paint_mark_visible_tree (local.get $child))
      (local.set $slot (i32.add (local.get $slot) (i32.const 1)))
      (br $scan)))
  )
  (func (export "test_cs_try_enter") (param $cs i32) (result i32)
    (i32.store offset=16 (global.get $reg_base) (i32.const 0x00700000))
    (call $handle_TryEnterCriticalSection (local.get $cs) (i32.const 0)
      (i32.const 0) (i32.const 0) (i32.const 0) (i32.const 0))
    (i32.load offset=0 (global.get $reg_base)))
  ;; Host-side child exposure happens while an app is still recalculating its
  ;; control-bar layout. Put the resulting repaint into USER's update-region
  ;; queue so pending non-client work drains before parent/child WM_PAINT.
  (func (export "paint_invalidate_visible_tree") (param $hwnd i32)
    (call $paint_mark_visible_tree (local.get $hwnd)))
  ;; The posted-message queue, for looking at rather than guessing about.
  ;; Production posts use the process-shared canonical FIFO; the private prefix
  ;; remains visible first for focused tests which seed raw queue bytes.
  ;; `field` is 0 hwnd, 1 message, 2 wParam, 3 lParam.
  (func (export "post_queue_depth") (result i32)
    (i32.add (call $post_queue_total_count)
      (call $shared_post_queue_total_count)))
  (func (export "get_post_queue_base") (result i32) (call $post_queue_base))
  (func (export "post_queue_peek") (param $i i32) (param $field i32) (result i32)
    (if (result i32)
        (i32.lt_u (local.get $i) (call $post_queue_total_count))
      (then (call $post_queue_peek_field (local.get $i) (local.get $field)))
      (else (call $shared_post_queue_peek_field_tid
        (global.get $current_thread_id)
        (i32.sub (local.get $i) (call $post_queue_total_count))
        (local.get $field)))))

  (func (export "nc_flags_test") (param $hwnd i32) (result i32)
    (call $nc_flags_test (local.get $hwnd)))
  ;; PAINT_WORK_COUNTS diagnostics: 0 when the shared paint/NC counts agree
  ;; with a full walk of PAINT_FLAGS/NC_FLAGS, else the mismatch mask
  ;; ($paint_work_audit). paint_work_count(k): k=0 dirty paint slots,
  ;; k=1..4 NC bit 0..3 holders.
  (func (export "paint_work_audit") (result i32)
    (call $paint_work_audit))
  (func (export "paint_work_count") (param $k i32) (result i32)
    (if (i32.gt_u (local.get $k) (i32.const 4)) (then (return (i32.const -1))))
    (i32.atomic.load (i32.add (global.get $PAINT_WORK_COUNTS)
      (i32.shl (local.get $k) (i32.const 2)))))
  ;; Is this window still owed a WM_PAINT? Pairs with nc_flags_test above: those
  ;; two flags are what decides whether a native child is allowed to draw yet,
  ;; and a control that never appears is nearly always one of them stuck.
  (func (export "paint_flag_test") (param $hwnd i32) (result i32)
    (local $slot i32)
    (local.set $slot (call $wnd_table_find (local.get $hwnd)))
    (if (i32.lt_s (local.get $slot) (i32.const 0)) (then (return (i32.const 0))))
    (i32.load8_u (i32.add (global.get $PAINT_FLAGS) (local.get $slot))))
  ;; The WAT-owned update rect, packed l,t,r,b into two i32s (0 when the
  ;; window has none). PAINT_FLAGS alone does not get a window painted: the
  ;; selector also demands a non-empty update rect, and $paint_seed_child_paints
  ;; propagates a parent's rect, not its flag. So "flag set, rect empty" and
  ;; "parent rect empty so children were never seeded" are distinct stalls that
  ;; look identical without this.
  (func (export "update_rect_lt") (param $hwnd i32) (result i32)
    (local $r i32)
    (local.set $r (call $paint_scratch_take))
    (if (i32.eqz (call $update_get_rect (local.get $hwnd) (local.get $r)))
      (then (return (i32.const 0))))
    (i32.or
      (i32.and (i32.load (local.get $r)) (i32.const 0xFFFF))
      (i32.shl (i32.load offset=4 (local.get $r)) (i32.const 16))))
  (func (export "update_rect_rb") (param $hwnd i32) (result i32)
    (local $r i32)
    (local.set $r (call $paint_scratch_take))
    (if (i32.eqz (call $update_get_rect (local.get $hwnd) (local.get $r)))
      (then (return (i32.const 0))))
    (i32.or
      (i32.and (i32.load offset=8 (local.get $r)) (i32.const 0xFFFF))
      (i32.shl (i32.load offset=12 (local.get $r)) (i32.const 16))))

  (func (export "post_message_q")
        (param $hwnd i32) (param $msg i32) (param $wP i32) (param $lP i32) (result i32)
    (call $post_queue_push (local.get $hwnd) (local.get $msg) (local.get $wP) (local.get $lP)))
  ;; Another app broadcast a registered message; see $regmsg_broadcast_in.
  (func (export "registered_broadcast_deliver")
        (param $hash i32) (param $wP i32) (param $lP i32) (result i32)
    (call $regmsg_broadcast_in (local.get $hash) (local.get $wP) (local.get $lP)))
  ;; Browser audio topology bridge.  lib/host-audio.js diffs
  ;; MediaDevices.enumerateDevices() snapshots and supplies only documented
  ;; arrival/removal event codes; WAT retains filter and HWND ownership.
  (func (export "device_notify_audio_change") (param $event i32) (result i32)
    (call $device_notify_broadcast_audio (local.get $event)))
  ;; Renderer-wide top-level lifecycle bridge. code uses the Win9x HSHELL_*
  ;; values (1=created, 2=destroyed, 4=activated); hwnd is lParam.
  (func (export "notify_shell_window")
        (param $code i32) (param $hwnd i32) (result i32)
    (if (result i32)
      (i32.and
        (i32.ne (global.get $shell_hook_hwnd) (i32.const 0))
        (i32.ne (global.get $shell_hook_message) (i32.const 0)))
      (then
        (call $post_queue_push
          (global.get $shell_hook_hwnd)
          (global.get $shell_hook_message)
          (local.get $code)
          (local.get $hwnd)))
      (else (i32.const 0))))
  ;; Post WM_MOVE + WM_SIZE for the current window rect (renderer-side state
  ;; already updated). Recomputes CLIENT_RECT first so the WM_SIZE lParam
  ;; reflects the new client area. $size_w is the WM_SIZE wParam:
  ;; 0=SIZE_RESTORED, 2=SIZE_MAXIMIZED. Reads x/y from JS via
  ;; $host_get_window_rect; same source nccalcsize uses.
  (func $post_resize_messages (export "post_resize_messages") (param $hwnd i32) (param $size_w i32)
    (local $rect i32) (local $x i32) (local $y i32)
    (local $cw i32) (local $ch i32)
    (local.set $rect (call $paint_scratch_take))
    (call $host_get_window_rect (local.get $hwnd) (local.get $rect))
    (local.set $x (load.field PaintRect left (local.get $rect)))
    (local.set $y (load.field.memarg PaintRect top (local.get $rect)))
    (call $defwndproc_do_nccalcsize (local.get $hwnd))
    (local.set $cw (i32.sub (call $client_rect_get_r (local.get $hwnd))
                             (call $client_rect_get_l (local.get $hwnd))))
    (local.set $ch (i32.sub (call $client_rect_get_b (local.get $hwnd))
                             (call $client_rect_get_t (local.get $hwnd))))
    (if (i32.lt_s (local.get $cw) (i32.const 0)) (then (local.set $cw (i32.const 0))))
    (if (i32.lt_s (local.get $ch) (i32.const 0)) (then (local.set $ch (i32.const 0))))
    ;; Show-state transitions change the outer frame after placement's normal
    ;; position transaction. Publish their recalculated client to the same
    ;; host mirror before delivering the corresponding resize notification.
    (call $host_sync_window_client (local.get $hwnd)
      (call $wnd_client_screen_x (local.get $hwnd))
      (call $wnd_client_screen_y (local.get $hwnd))
      (local.get $cw) (local.get $ch))
    (drop (call $post_queue_push (local.get $hwnd) (i32.const 0x0003) ;; WM_MOVE
      (i32.const 0)
      (i32.or (i32.and (local.get $x) (i32.const 0xFFFF))
              (i32.shl (local.get $y) (i32.const 16)))))
    (drop (call $post_queue_push (local.get $hwnd) (i32.const 0x0005) ;; WM_SIZE
      (local.get $size_w)
      (i32.or (i32.and (local.get $cw) (i32.const 0xFFFF))
              (i32.shl (local.get $ch) (i32.const 16)))))
    ;; Win98 invalidates the newly exposed client region when a window is
    ;; resized/maximized. Some apps repaint from WM_SIZE, but others (Spider)
    ;; wait for the subsequent WM_PAINT; without this the freshly reallocated
    ;; backing canvas remains the default grey fill.
    (call $paint_flag_set_inv (local.get $hwnd))
    ;; A resize exposes client area that has never been erased -- the reallocated
    ;; back-canvas is grey there. Invalidating alone only buys a WM_PAINT, and an
    ;; app that paints its own background from WM_ERASEBKGND (FreeCell's and
    ;; Solitaire's green baize is a PATCOPY over GetClientRect) draws its cards
    ;; onto grey and leaves the rest of the enlarged window grey forever. Queue
    ;; the erase alongside the paint, as USER does for the newly exposed region.
    (call $nc_flags_set (local.get $hwnd) (i32.const 2))
    ;; Resize reallocates the back-canvas (grey-filled), wiping the previous
    ;; chrome. The guest's WM_SIZE handler invalidates the client area but
    ;; not the NC region, so synchronously redraw chrome here — same pattern
    ;; as nc_repaint_now after a sysbutton release.
    (call $defwndproc_do_ncpaint (local.get $hwnd)))

  ;; User-initiated resize commit (host mousedrag on edge/corner).
  ;; Renderer has already updated win.{x,y,w,h}; we recompute CLIENT_RECT
  ;; and post WM_MOVE + WM_SIZE so the guest wndproc relays out.
  (func (export "host_resize_commit")
        (param $hwnd i32) (param $x i32) (param $y i32) (param $w i32) (param $h i32)
    (call $post_resize_messages
      (local.get $hwnd)
      (select (i32.const 2) (i32.const 0) (call $wnd_max_get (local.get $hwnd)))))
  (func (export "wnd_is_maximized") (param $hwnd i32) (result i32)
    (call $wnd_max_get (local.get $hwnd)))
  ;; The answer IsIconic gives the guest. The renderer keeps `_minimized` for
  ;; compositing; exporting this one lets a test see both and notice when they
  ;; disagree, which is the failure mode the show-state bits exist to close.
  (func (export "wnd_is_minimized") (param $hwnd i32) (result i32)
    (call $wnd_min_get (local.get $hwnd)))
  ;; User-initiated move commit (host title-bar drag). Moving a Win98 window
  ;; sends WM_MOVE but does not imply WM_SIZE/NCCALCSIZE; dialog controls keep
  ;; their layout and only the top-level screen origin changes.
  (func (export "host_move_commit")
        (param $hwnd i32) (param $x i32) (param $y i32)
    (drop (call $post_queue_push (local.get $hwnd) (i32.const 0x0003) ;; WM_MOVE
      (i32.const 0)
      (i32.or (i32.and (local.get $x) (i32.const 0xFFFF))
              (i32.shl (local.get $y) (i32.const 16)))))
    (call $defwndproc_do_ncpaint (local.get $hwnd)))
  ;; Cursor state readback — for tests / JS to verify SetCursor plumbing.
  (func (export "get_cursor") (result i32) (global.get $current_cursor))
  ;; ShowCursor's signed display count is also browser presentation state.
  ;; A negative count means the guest deliberately hid the system cursor and
  ;; is normally drawing/tracking its own (often through DirectInput).
  (func (export "get_cursor_display_count") (result i32)
    (global.get $cursor_count))
  ;; 1 when some DirectInput device that is a mouse (misc0 kind 2) is acquired
  ;; with DISCL_EXCLUSIVE (low bit of the DISCL_* the device flags keep): the
  ;; game reads mouse counts only and hides the system cursor, so the page
  ;; should capture the pointer (docs/mouse-model-audit.md). The DX table is in
  ;; shared memory, so this answers for a device any guest thread acquired.
  ;; A full table scan, which is why the page polls it at most every 250 ms.
  (func (export "get_mouse_capture_hint") (result i32)
    (local $i i32) (local $entry i32) (local $flags i32)
    (local.set $i (i32.const 1))
    (block $done (loop $lp
      (br_if $done (i32.ge_u (local.get $i) (global.get $DX_MAX)))
      (local.set $entry (i32.add (global.get $DX_OBJECTS) (i32.shl (local.get $i) (i32.const 5))))
      (if (i32.eq (load.field DxObject type (local.get $entry)) (i32.const 7)) (then
        (local.set $flags (load.field DxObject flags (local.get $entry)))
        (if (i32.and
              (i32.eq (load.field DxObject misc0 (local.get $entry)) (i32.const 2))
              (i32.and
                (i32.ne (i32.and (local.get $flags) (global.get $DIDEV_ACQUIRED)) (i32.const 0))
                (i32.ne (i32.and (local.get $flags) (i32.const 1)) (i32.const 0))))
          (then (return (i32.const 1))))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $lp)))
    (i32.const 0))
  ;; Synchronous NCHITTEST helper — JS calls before generating mouse
  ;; events so classification lives in WAT. Returns HT* code.
  (func (export "hittest_sync")
        (param $hwnd i32) (param $sx i32) (param $sy i32) (result i32)
    (call $defwndproc_do_nchittest (local.get $hwnd) (local.get $sx) (local.get $sy)))
  ;; Client rect (window-local) written by WM_NCCALCSIZE; read by JS drawWindow.
  (func (export "get_client_rect_l") (param $hwnd i32) (result i32) (call $client_rect_get_l (local.get $hwnd)))
  (func (export "get_client_rect_t") (param $hwnd i32) (result i32) (call $client_rect_get_t (local.get $hwnd)))
  (func (export "get_client_rect_r") (param $hwnd i32) (result i32) (call $client_rect_get_r (local.get $hwnd)))
  (func (export "get_client_rect_b") (param $hwnd i32) (result i32) (call $client_rect_get_b (local.get $hwnd)))
  ;; Packed client width|height (low 16 | high 16) — convenience for host_imports.
  ;; Same value $wnd_client_w/h_for_clip read directly -- shared so the export
  ;; and the WAT-internal fast path cannot disagree about what a client rect is.
  (func (export "get_client_rect_wh") (param $hwnd i32) (result i32)
    (call $client_rect_wh_packed (local.get $hwnd)))
  ;; Title storage — JS writes via set_window_title_wa; DefWindowProc reads during NCPAINT.
  (func (export "set_window_title_wa") (param $hwnd i32) (param $wa_ptr i32) (param $len i32)
    (call $title_table_set (local.get $hwnd) (local.get $wa_ptr) (local.get $len)))
  (func (export "get_window_title_ptr") (param $hwnd i32) (result i32)
    (call $title_table_get_ptr (local.get $hwnd)))
  (func (export "get_window_title_len") (param $hwnd i32) (result i32)
    (call $title_table_get_len (local.get $hwnd)))

  ;; Worker instances share the thunk table memory, but continuation thunk
  ;; globals are per-instance. Rebuild them from the shared marker entries.
  (func $sync_thread_thunk_globals
    (local $i i32) (local $marker i32) (local $guest i32)
    (local.set $i (i32.const 0))
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (global.get $num_thunks)))
      (local.set $marker
        (i32.load (call $thunk_metadata_addr (local.get $i))))
      (local.set $guest
        (i32.add (global.get $thunk_guest_base) (i32.mul (local.get $i) (i32.const 8))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0000))
        (then (global.set $catch_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA000E))
        (then (global.set $delphi_seh_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0037))
        (then (global.set $seh_raw_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0039))
        (then (global.set $rtl_unwind_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA003A))
        (then (global.set $seh_node_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA003C))
        (then (global.set $dialog_proc_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0001))
        (then (global.set $createwnd_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0002))
        (then (global.set $cbt_hook_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0003))
        (then (global.set $initterm_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA002C))
        (then (global.set $atexit_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0004))
        (then (global.set $dlg_loop_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0005))
        (then (global.set $sync_msg_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0006))
        (then (global.set $modal_loop_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0007))
        (then (global.set $ddenum_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0008))
        (then (global.set $enum_modes_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA000A))
        (then (global.set $mm_timer_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA000B))
        (then (global.set $d3d_enum_dev_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA000C))
        (then (global.set $bsearch_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA000F))
        (then (global.set $d3d_enum_tex_thunk (local.get $guest))))
      ;; These three were missing, so on a guest thread the callback returned
      ;; to address 0: Rayman 2's renderer calls EnumZBufferFormats from its
      ;; game thread (test-thread-thunk-sync checks the table is complete).
      (if (i32.eq (local.get $marker) (i32.const 0xCACA000D))
        (then (global.set $d3d_enum_zbuf_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA002D))
        (then (global.set $qsort_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0012))
        (then (global.set $line_dda_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0011))
        (then (global.set $font_enum_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0022))
        (then (global.set $createwnd_activate_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0023))
        (then (global.set $createwnd_setfocus_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0024))
        (then (global.set $createwnd_move_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0031))
        (then (global.set $createwnd_size_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA003D))
        (then (global.set $createwnd_size_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0026))
        (then (global.set $child_cbt_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0027))
        (then (global.set $child_create_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0028))
        (then (global.set $dialog_cbt_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0029))
        (then (global.set $createwnd_nccreate_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA002E))
        (then (global.set $child_create_nccreate_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA002A))
        (then (global.set $setfocus_ret_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA002B))
        (then (global.set $enum_child_thunk (local.get $guest))))
      (if (i32.eq (local.get $marker) (i32.const 0xCACA0030))
        (then (global.set $enum_rsrc_thunk (local.get $guest))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan))))

  ;; Focused CRT callback tests use these without routing through an imported
  ;; API thunk; callback execution itself still runs through the real x86
  ;; interpreter and CACA002C continuation path.
  (func (export "test_crt_atexit_register") (param $fn i32) (result i32)
    (call $crt_atexit_register (local.get $fn)))
  (func (export "test_crt_atexit_count") (result i32)
    (global.get $atexit_count))
  (func (export "test_crt_exit_begin") (param $code i32)
    ;; Historical probe starts after the API return word was consumed.
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (i32.const 0))
    (call $crt_callback_begin (i32.const 1) (i32.const 0) (i32.const 0) (local.get $code)))

  ;; Exercise the exact cooperative retry transition: the first call parks on
  ;; another owner, the owner releases while the import frame remains live,
  ;; and the second call completes on that same frame. Bits: 1=parked with
  ;; frame preserved, 2=retry no longer yielded, 4=stdcall frame consumed,
  ;; 8=thunk auto-pop suppression cleared for the completed call,
  ;; 16=the parked inline import resumes at its thunk instead of its caller.
  (func (export "test_cs_park_retry") (param $cs_gp i32) (result i32)
    (local $saved_esp i32) (local $saved_eip i32)
    (local $saved_thunk_eip i32) (local $cs i32) (local $bits i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (local.set $saved_eip (global.get $eip))
    (local.set $saved_thunk_eip (global.get $current_thunk_eip))
    (global.set $current_thunk_eip (i32.const 0x0BADF00D))
    (local.set $cs (call $g2w (local.get $cs_gp)))
    (i32.store offset=4 (local.get $cs) (i32.const 0))
    (i32.store offset=8 (local.get $cs) (i32.const 1))
    (i32.store offset=12 (local.get $cs)
      (i32.add (global.get $current_thread_id) (i32.const 1)))
    (call $handle_EnterCriticalSection
      (local.get $cs_gp) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (if (i32.and
          (i32.eq (global.get $yield_reason) (i32.const 9))
          (i32.and (global.get $handler_set_eip)
            (i32.eq (i32.load offset=16 (global.get $reg_base)) (local.get $saved_esp))))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 1)))))
    (if (i32.eq (global.get $eip) (global.get $current_thunk_eip))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 16)))))
    ;; Publish the owner's final LeaveCriticalSection, then let the parked
    ;; caller re-enter the same import handler just as ThreadManager does.
    (i32.store offset=4 (local.get $cs) (i32.const -1))
    (i32.store offset=8 (local.get $cs) (i32.const 0))
    (i32.store offset=12 (local.get $cs) (i32.const 0))
    (global.set $yield_reason (i32.const 0))
    (call $handle_EnterCriticalSection
      (local.get $cs_gp) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (if (i32.eqz (global.get $yield_reason))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 2)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (i32.add (local.get $saved_esp) (i32.const 8)))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 4)))))
    (if (i32.eqz (global.get $handler_set_eip))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 8)))))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (global.set $handler_set_eip (i32.const 0))
    (global.set $eip (local.get $saved_eip))
    (global.set $current_thunk_eip (local.get $saved_thunk_eip))
    (local.get $bits))

  ;; Page-index split, process-wide in $SHARED_COUNTERS +40 so every instance
  ;; created afterwards ($init_thread) agrees with the one that chose it.
  ;;   0  default: main 512 slots (0x480000), fifteen workers 16 (0x24000)
  ;;   1  worker-heavy: main 256 (0x240000), fifteen workers 32 (0x48000)
  ;;   2  preserve main 512 and worker arena 16, add 16 worker indexes in
  ;;      the last 0x24000 bytes of each worker's own code partition.
  ;; Modes 0/1 fit $PAGE_INDEX_ARENA (1: 0x240000 + 15*0x48000 = 0x678000).
  ;; Mode 2 retains mode 0's arena split and reduces worker code capacity from
  ;; 768KiB to 624KiB, including its existing 16KiB reserve. Index capacity
  ;; does not guarantee every indexed page's compiled chunks fit simultaneously.
  ;; Applies the stored mode to this instance's globals.
  (func $page_index_layout_apply
    ;; Reset on every application, including a Worker instance reused as main.
    (global.set $PAGE_INDEX_EXTRA (i32.const 0))
    (global.set $PAGE_INDEX_WORKER_EXTRA_BYTES (i32.const 0))
    (if (i32.eq (i32.atomic.load offset=40 (global.get $SHARED_COUNTERS)) (i32.const 1))
      (then
        (global.set $PAGE_INDEX_MAIN_BYTES (i32.const 0x00240000))
        (global.set $PAGE_INDEX_STRIDE (i32.const 0x00048000))
        (global.set $PAGE_INDEX_WORKER_SLOTS (i32.const 32)))
      (else
        (global.set $PAGE_INDEX_MAIN_BYTES (i32.const 0x00480000))
        (global.set $PAGE_INDEX_STRIDE (i32.const 0x00024000))
        (global.set $PAGE_INDEX_WORKER_SLOTS (i32.const 16))
        (if (i32.eq (i32.atomic.load offset=40 (global.get $SHARED_COUNTERS)) (i32.const 2))
          (then
            (global.set $PAGE_INDEX_WORKER_SLOTS (i32.const 32))
            (global.set $PAGE_INDEX_WORKER_EXTRA_BYTES (i32.const 0x24000)))))))

  ;; Host-side opt-in (lib/apps.js `workerHeavyCodeCache` or
  ;; `expandedWorkerCodeCache`). Call on the first
  ;; instance before anything is decoded and before any worker is spawned. The
  ;; calling instance is the main thread here (a CLI or page main never runs
  ;; $init_thread), so its own slot count is set too; workers and a Worker-
  ;; hosted main pick the mode up in $init_thread. Returns the mode in force.
  (func (export "set_page_index_layout") (param $mode i32) (result i32)
    (i32.atomic.store offset=40 (global.get $SHARED_COUNTERS)
      (select (local.get $mode) (i32.const 0)
        (i32.or (i32.eq (local.get $mode) (i32.const 1))
          (i32.eq (local.get $mode) (i32.const 2)))))
    (call $page_index_layout_apply)
    (global.set $PAGE_INDEX_SLOTS
      (i32.div_u (global.get $PAGE_INDEX_MAIN_BYTES) (global.get $PAGE_INDEX_BYTES)))
    (i32.atomic.load offset=40 (global.get $SHARED_COUNTERS)))

  ;; Thread init — called by host after creating worker instance
  (func (export "init_thread") (param $tid i32)
      (param $img_base i32) (param $code_s i32) (param $code_e i32)
      (param $thunk_gs i32) (param $thunk_ge i32) (param $num_th i32)
      (param $main_rsrc_rva i32)
    (local $pe_off i32)
    ;; A reused Worker instance must not retain heap-backed queue overflow from
    ;; its previous guest thread. Do this before replacing allocator cursors.
    (call $post_queue_reset)
    ;; Which page-index split this process chose (set_page_index_layout).
    (call $page_index_layout_apply)
    ;; The three per-thread arenas are split, not strided: the main thread
    ;; (tid 0) gets a large partition at offset 0 and every worker gets a small
    ;; one after it. A worker compiles the single routine it was spawned for,
    ;; so an equal share would have starved the thread that decodes the whole
    ;; program to feed fifteen that decode almost nothing. See the declarations
    ;; in 00-regions.wat. tid 0 keeps the globals' declared defaults, which are
    ;; the main thread's values, so only the worker arithmetic lives here.
    (if (local.get $tid)
      (then
        (global.set $THREAD_BASE (i32.add (region.addr $THREAD_CACHE_BASE 0)
          (i32.add (global.get $THREAD_CACHE_MAIN_BYTES)
            (i32.mul (i32.sub (local.get $tid) (i32.const 1))
                     (global.get $THREAD_CACHE_STRIDE)))))
        (global.set $THREAD_END (i32.sub
          (i32.add (global.get $THREAD_BASE) (global.get $THREAD_CACHE_STRIDE))
          (global.get $PAGE_INDEX_WORKER_EXTRA_BYTES)))
        (if (global.get $PAGE_INDEX_WORKER_EXTRA_BYTES)
          (then (global.set $PAGE_INDEX_EXTRA (global.get $THREAD_END))))
        ;; This worker's micro-op arena (07d), split the same way.
        (call $uop_set_arena
          (i32.add (global.get $UOP_THREAD_ARENAS)
            (i32.mul (i32.sub (local.get $tid) (i32.const 1))
                     (global.get $UOP_THREAD_ARENA_STRIDE)))
          (global.get $UOP_THREAD_ARENA_STRIDE))
        ;; Spill slot ($THREAD_SPILL): main 0x80000 at 0, worker N 0x10000
        ;; at 0x80000 + (N-1)*0x10000.
        (global.set $spill_base (i32.add (region.addr $THREAD_SPILL 0x80000)
          (i32.mul (i32.sub (local.get $tid) (i32.const 1)) (i32.const 0x10000))))
        (global.set $spill_end (i32.add (global.get $spill_base) (i32.const 0x10000))))
      (else
        (global.set $THREAD_BASE (region.addr $THREAD_CACHE_BASE 0))
        (global.set $THREAD_END (i32.add (global.get $THREAD_BASE)
          (global.get $THREAD_CACHE_MAIN_BYTES)))
        (call $uop_set_arena (global.get $UOP_ARENA) (global.get $UOP_ARENA_SIZE))
        (global.set $spill_base (region.addr $THREAD_SPILL 0))
        (global.set $spill_end (region.addr $THREAD_SPILL 0x80000))))
    (global.set $spill_active (i32.const 0))
    (global.set $spill_saved_end (global.get $THREAD_END))
    (global.set $thread_alloc (global.get $THREAD_BASE))
    ;; The register file IS strided, unlike the three arenas above: every
    ;; thread needs exactly eight slots, so tid*64 with no special case for the
    ;; main thread. Memory is shared between instances while globals are not,
    ;; so skipping this would give every worker the main thread's registers.
    (global.set $reg_base (i32.add (global.get $REGFILE)
      (i32.mul (local.get $tid) (global.get $REGFILE_STRIDE))))
    (global.set $fpu_base (i32.add (global.get $FPU_FILE)
      (i32.mul (local.get $tid) (global.get $FPU_FILE_STRIDE))))
    ;; A reused tid slot must not hand a new thread its predecessor's XMM.
    (global.set $xmm_base (i32.add (global.get $XMM_FILE)
      (i32.mul (local.get $tid) (global.get $XMM_FILE_STRIDE))))
    (memory.fill (global.get $xmm_base) (i32.const 0) (global.get $XMM_FILE_STRIDE))
    (global.set $mmx_base (i32.add (global.get $MMX_FILE)
      (i32.mul (local.get $tid) (global.get $MMX_FILE_STRIDE))))
    (memory.fill (global.get $mmx_base) (i32.const 0) (global.get $MMX_FILE_STRIDE))
    ;; Decode scratch too: worker instances decode in parallel, and a shared
    ;; op-start list lets one thread's fuser rewrite another's code.
    (global.set $OP_INDEX (i32.add (global.get $OP_INDEX_REGION)
      (i32.mul (i32.and (local.get $tid) (i32.const 15)) (global.get $OP_INDEX_SLICE))))
    ;; Page-compilation state is per-instance for the same reason THREAD_BASE
    ;; is: a worker is a separate instance over the same memory, and chunk
    ;; pointers name that thread's own arena partition.
    (if (local.get $tid)
      (then
        (global.set $PAGE_DIR (i32.add (global.get $PAGE_DIR_BASE)
          (i32.add (global.get $PAGE_DIR_MAIN_BYTES)
            (i32.mul (i32.sub (local.get $tid) (i32.const 1))
                     (global.get $PAGE_DIR_STRIDE)))))
        (global.set $PAGE_DIR_ENTRIES (global.get $PAGE_DIR_WORKER_ENTRIES))
        (global.set $PAGE_DIR_MASK
          (i32.sub (global.get $PAGE_DIR_WORKER_ENTRIES) (i32.const 1)))
        (global.set $PAGE_INDEX (i32.add (global.get $PAGE_INDEX_ARENA)
          (i32.add (global.get $PAGE_INDEX_MAIN_BYTES)
            (i32.mul (i32.sub (local.get $tid) (i32.const 1))
                     (global.get $PAGE_INDEX_STRIDE)))))
        (global.set $PAGE_INDEX_SLOTS (global.get $PAGE_INDEX_WORKER_SLOTS)))
      (else
        (global.set $PAGE_DIR (global.get $PAGE_DIR_BASE))
        (global.set $PAGE_DIR_ENTRIES
          (i32.div_u (global.get $PAGE_DIR_MAIN_BYTES)
                     (global.get $PAGE_DIR_SLOT_BYTES)))
        (global.set $PAGE_DIR_MASK
          (i32.sub (i32.div_u (global.get $PAGE_DIR_MAIN_BYTES)
                              (global.get $PAGE_DIR_SLOT_BYTES))
                   (i32.const 1)))
        (global.set $PAGE_INDEX (global.get $PAGE_INDEX_ARENA))
        (global.set $PAGE_INDEX_SLOTS
          (i32.div_u (global.get $PAGE_INDEX_MAIN_BYTES)
                     (global.get $PAGE_INDEX_BYTES)))))
    (global.set $page_index_next (i32.const 0))
    (call $page_dir_reset)
    (global.set $code_cache_generation_seen
      (i32.atomic.load offset=4 (global.get $SHARED_COUNTERS)))
    (global.set $image_base (local.get $img_base))
    ;; Separate instances share the name bytes but not their pointer/length
    ;; globals. Without this, a new thread reports a seven-character default
    ;; image path, so games resolve their config files against the wrong root.
    (if (i32.and (i32.load (global.get $PROCESS_IMAGE_STATE)) (i32.const 1))
      (then
        (global.set $exe_name_wa (i32.load offset=4 (global.get $PROCESS_IMAGE_STATE)))
        (global.set $exe_name_len (i32.load offset=8 (global.get $PROCESS_IMAGE_STATE)))))
    (if (i32.and (i32.load (global.get $PROCESS_IMAGE_STATE)) (i32.const 2))
      (then
        (global.set $exe_drive (i32.load offset=12 (global.get $PROCESS_IMAGE_STATE)))))
    ;; Resource lookup state is instance-local: the loading instance populates
    ;; $rsrc_rva, every other one starts at zero. A cooperative thread is handed
    ;; the value the main loader retained. The worker backend has none to hand
    ;; over — nothing loaded the PE on the main-thread instance — but there the
    ;; mapped DOS/PE headers do live in shared memory, so reread them.
    (if (local.get $main_rsrc_rva)
      (then (global.set $rsrc_rva (local.get $main_rsrc_rva)))
      (else
        (local.set $pe_off (i32.add (local.get $img_base)
          (i32.load (call $g2w (i32.add (local.get $img_base) (i32.const 0x3C))))))
        (global.set $rsrc_rva
          (i32.load (call $g2w (i32.add (local.get $pe_off) (i32.const 136)))))))
    ;; Allocator cursors are per-instance and describe one process-wide arena, so
    ;; a worker must NOT inherit main's: zero them and let the first allocation
    ;; reserve a private chunk from the shared cursors. heap_base is immutable
    ;; after load, so that one is read across directly.
    (global.set $heap_ptr (i32.const 0))
    (global.set $heap_end (i32.const 0))
    (global.set $heap_arena_record (i32.const 0))
    (global.set $heap_sparse_record (i32.const 0))
    (global.set $heap_base
      (i32.load (region.addr $HEAP_SHARED 4)))
    (global.set $heap_sparse_ptr (i32.const 0))
    (global.set $heap_sparse_end (i32.const 0))
    (global.set $virtual_alloc_top (global.get $VIRTUAL_ALLOC_TOP_INIT))
    (global.set $current_thread_id (i32.add (local.get $tid) (i32.const 1)))
    (call $invocation_thread_begin (local.get $tid))
    (call $getmessage_hook_reset (global.get $current_thread_id))
    (call $getmessage_hook_open_owner (global.get $current_thread_id))
    (call $shared_post_queue_reset_tid (global.get $current_thread_id))
    (global.set $post_queue_count (i32.const 0))
    (global.set $pq_read_off (i32.const 0))
    (global.set $sync_msg_depth (i32.const 0))
    (global.set $spill_pins (i32.const 0))
    (global.set $cross_thread_send_depth (i32.const 0))
    (global.set $code_start (local.get $code_s))
    (global.set $code_end (local.get $code_e))
    (global.set $thunk_guest_base (local.get $thunk_gs))
    (global.set $thunk_guest_end (local.get $thunk_ge))
    (global.set $num_thunks (local.get $num_th))
    (call $sync_thread_thunk_globals)
    ;; Worker code can call an existing COM object's vtable directly before
    ;; making another imported Win32 call. Restore every per-instance DirectX
    ;; vtable global eagerly so those calls never dispatch through address 0.
    (call $dx_sync_thread_vtables)
  )

  ;; Multimedia-timer state, for debugging a client that waits on a
  ;; timeSetEvent callback that never arrives. "The guest holds timer id N" and
  ;; "WAT is still running timer id N" can disagree; only this export can tell
  ;; them apart from the host side.
  ;; field: 0=id 1=interval 2=callback 3=dwUser 4=last_tick 5=oneshot
  ;;        6=next_id (slot ignored) 7=in_cb (slot ignored) 8=slot count
  (func (export "dbg_mm_timer") (param $slot i32) (param $field i32) (result i32)
    (local $p i32)
    (if (i32.eq (local.get $field) (i32.const 6))
      (then (return (i32.load (global.get $MM_TIMER_NEXT_ID)))))
    (if (i32.eq (local.get $field) (i32.const 7))
      (then (return (global.get $mm_timer_in_cb))))
    (if (i32.eq (local.get $field) (i32.const 8))
      (then (return (global.get $MM_TIMER_MAX))))
    (if (i32.ge_u (local.get $slot) (global.get $MM_TIMER_MAX))
      (then (return (i32.const -1))))
    (local.set $p (call $mm_timer_slot (local.get $slot)))
    (if (i32.eqz (local.get $field)) (then (return (i32.load (local.get $p)))))
    (if (i32.eq (local.get $field) (i32.const 1))
      (then (return (i32.load offset=4 (local.get $p)))))
    (if (i32.eq (local.get $field) (i32.const 2))
      (then (return (i32.load offset=8 (local.get $p)))))
    (if (i32.eq (local.get $field) (i32.const 3))
      (then (return (i32.load offset=12 (local.get $p)))))
    (if (i32.eq (local.get $field) (i32.const 4))
      (then (return (i32.load offset=16 (local.get $p)))))
    (if (i32.eq (local.get $field) (i32.const 5))
      (then (return (i32.load offset=20 (local.get $p)))))
    (i32.const -1))

  ;; Yield state exports
  (func (export "get_yield_reason") (result i32) (global.get $yield_reason))
  (func (export "get_wait_handle") (result i32) (global.get $wait_handle))
  (func (export "get_wait_handles_ptr") (result i32) (global.get $wait_handles_ptr))
  (func (export "get_wait_all") (result i32) (global.get $wait_all))
  (func (export "get_wait_timeout") (result i32) (global.get $wait_timeout))
  (func (export "get_wait_stack_bytes") (result i32) (global.get $wait_stack_bytes))
  (func (export "clear_yield")
    (global.set $yield_reason (i32.const 0))
    (global.set $wait_handles_ptr (i32.const 0))
    (global.set $wait_all (i32.const 0))
    (global.set $wait_timeout (i32.const 0xFFFFFFFF))
    (global.set $wait_stack_bytes (i32.const 12)))
  (func (export "resume_message_wait") (result i32)
    (local $msg_ptr i32)
    (if (i32.ne (global.get $yield_reason) (i32.const 7))
      (then (return (i32.const 0))))
    (local.set $msg_ptr (global.get $message_wait_msg_ptr))
    (global.set $message_wait_msg_ptr (i32.const 0))
    (global.set $yield_reason (i32.const 0))
    (if (local.get $msg_ptr)
      (then
        (call $handle_GetMessageA
          (local.get $msg_ptr)
          (i32.const 0)
          (i32.const 0)
          (i32.const 0)
          (i32.const 0)
          (i32.const 0)))
      (else
        ;; WaitMessage has no output buffer to fill and consumes no message.
        ;; Complete only its zero-argument stdcall frame.
        (i32.store offset=0 (global.get $reg_base) (i32.const 1))
        (i32.store offset=16 (global.get $reg_base) (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))))
    (i32.eqz (global.get $yield_reason)))
  (func (export "get_sync_table") (result i32) (global.get $SYNC_TABLE))
  (func (export "get_yield_flag") (result i32) (global.get $yield_flag))
  ;; Diagnostic state used by app-level print lifecycle tests.
  (func (export "get_quit_flag") (result i32) (global.get $quit_flag))
  (func (export "get_printer_doc_state") (result i32) (global.get $printer_doc_state))
  (func (export "get_printer_page_count") (result i32) (global.get $printer_page_count))
  (func (export "get_printer_bitmap") (result i32) (global.get $printer_bitmap))
  (func (export "get_sleep_yielded") (result i32)
    (local $v i32)
    (local.set $v (global.get $sleep_yielded))
    (global.set $sleep_yielded (i32.const 0))
    (local.get $v))
  (func (export "get_sleep_timeout") (result i32) (global.get $sleep_timeout))

  ;; ---- vertical blank (see $vblank_counter in src/01-header.wat) --------
  ;; The host says a refresh happened. In the browser that is a
  ;; requestAnimationFrame callback, already divided down to ~60 Hz; the CLI
  ;; never calls this, which is exactly what leaves it on the guest-clock
  ;; model. The first call latches $vblank_host_driven, so a page that turns
  ;; out to have a working rAF stops using the synthetic grid from then on.
  (func (export "vblank_tick")
    (global.set $vblank_host_driven (i32.const 1))
    (global.set $vblank_counter (i32.add (global.get $vblank_counter) (i32.const 1))))
  ;; The guest millisecond a parked vblank wait is due at. The CLI advances
  ;; its batch clock to this; the browser uses it only as a no-rAF backstop.
  (func (export "get_vblank_deadline_ms") (result i32) (global.get $vblank_deadline_ms))
  (func (export "get_vblank_wait_active") (result i32) (global.get $vblank_wait_active))
  (func (export "get_vblank_counter") (result i32) (global.get $vblank_counter))
  ;; Present pacing (src/09a8-handlers-directx.wat $present_pace): frames/s,
  ;; 0 = off. Per instance, so a host sets it on every thread instance.
  (func (export "set_present_cap") (param $cap i32) (call $present_set_cap (local.get $cap)))
  (func (export "get_present_paced_ms") (result i32) (global.get $present_paced_ms))
  (func (export "get_present_paced_count") (result i32) (global.get $present_paced_count))
  ;; 0 = deadline (sleep to a deadline one period on), 1 = smooth (one
  ;; per-frame delay nudged by at most 1.5 ms a frame). Resets pacing state.
  (func (export "set_present_pace_mode") (param $mode i32)
    (call $present_set_pace_mode (local.get $mode)))
  (func (export "get_present_smooth_delay_us") (result i32)
    (global.get $present_smooth_delay_us))
  (func (export "set_flip_vsync") (param $on i32)
    (global.set $dx_flip_vsync (i32.ne (local.get $on) (i32.const 0))))
  ;; Unit-test seams for the model itself: both are pure functions of a guest
  ;; millisecond, so they can be checked without running a guest at all.
  (func (export "test_vblank_next_boundary") (param $now i32) (result i32)
    (call $vblank_next_boundary (local.get $now)))
  (func (export "test_vblank_scanline") (param $now i32) (result i32)
    (call $vblank_scanline (local.get $now)))
  (func (export "test_vblank_in_blank") (param $now i32) (result i32)
    (call $vblank_in_blank (local.get $now)))
  (func (export "test_vblank_reset")
    (global.set $vblank_wait_active (i32.const 0))
    (global.set $vblank_host_driven (i32.const 0))
    (global.set $vblank_counter (i32.const 0))
    (global.set $vblank_deadline_ms (i32.const 0)))
  ;; Frame-end census ($present_frame_end / $present_pump in 09a8): detected
  ;; frame ends, and the message pumps that closed one or more of them. More
  ;; than one frame end per pump-bounded frame means a per-frame-end cap
  ;; would sleep several times per game frame (run.js --present-frames).
  (func (export "get_present_frame_ends") (result i32) (global.get $present_frame_ends))
  (func (export "get_present_pump_frames") (result i32) (global.get $present_pump_frames))
  (func (export "get_present_pump_bounded") (result i32) (global.get $present_pump_bounded))
  ;; Test seams: one frame end, and one pump (returns 1 when it parked the
  ;; pump on its thunk for the pace's sleep).
  (func (export "test_present_frame_end") (call $present_frame_end))
  (func (export "test_present_pump") (result i32) (call $present_pump))
  (func (export "test_present_frame_reset")
    (global.set $present_frame_pending (i32.const 0))
    (global.set $present_pump_bounded (i32.const 0))
    (global.set $present_frame_ends (i32.const 0))
    (global.set $present_pump_frames (i32.const 0)))
  ;; The app's game step (09a8 $th_logical_frame): the guest EIP the decoder
  ;; plants a marker at (0 = off; changing it recycles decoded code), and
  ;; whether a present cap paces there instead of at pumps/frame ends (1) or
  ;; the marker only counts (0). Per instance, so a host sets it on every
  ;; thread instance, before the first run() for a zero-cost switch-on.
  (func (export "set_logical_frame") (param $addr i32) (param $pace i32)
    (call $logical_frame_set (local.get $addr) (local.get $pace)))
  (func (export "get_logical_frame_addr") (result i32) (global.get $logical_frame_addr))
  (func (export "get_logical_frame_pace") (result i32) (global.get $logical_frame_pace))
  (func (export "get_logical_frame_count") (result i32) (global.get $logical_frame_count))
  (func (export "get_logical_frame_paced") (result i32) (global.get $logical_frame_paced))
  (func (export "get_logical_frame_owns") (result i32) (call $logical_frame_owns))
  ;; Drive WaitForVerticalBlank once and report what it did, the way
  ;; test_cs_enter does for EnterCriticalSection. Bits:
  ;;   1  parked with yield_reason 13
  ;;   2  left the stdcall frame alone (so the re-entry sees the same args)
  ;;   4  raised $handler_set_eip (opts out of $run's thunk-zone auto-pop --
  ;;      without it the parked call is spliced out and the guest resumes past
  ;;      its own WaitForVerticalBlank)
  ;;   8  returned DD_OK
  ;;  16  popped exactly the 3-arg stdcall frame
  (func (export "test_vblank_wait_once") (result i32)
    (local $saved_esp i32) (local $saved_eip i32) (local $bits i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (local.set $saved_eip (global.get $eip))
    (i32.store offset=0 (global.get $reg_base) (i32.const 0xDEADBEEF))
    (call $handle_IDirectDraw_WaitForVerticalBlank
      (i32.const 0) (i32.const 1) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (if (i32.eq (global.get $yield_reason) (i32.const 13))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 1)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (local.get $saved_esp))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 2)))))
    (if (global.get $handler_set_eip)
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 4)))))
    (if (i32.eqz (i32.load offset=0 (global.get $reg_base)))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 8)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (i32.add (local.get $saved_esp) (i32.const 16)))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 16)))))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp))
    (global.set $eip (local.get $saved_eip))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (global.set $handler_set_eip (i32.const 0))
    (local.get $bits))

  ;; ---- spin parking (see $spin_dispatch_seq in src/01-header.wat) -------
  ;; K, the number of consecutive indistinguishable reads that classifies a
  ;; thread as spinning. 0 disables both detectors outright, which is the A/B
  ;; arm (test/run.js --no-spin-park) and how a suspected false park is ruled
  ;; in or out in one run.
  (func (export "set_spin_park_k") (param $k i32)
    (global.set $spin_park_k (local.get $k)))
  (func (export "get_spin_park_k") (result i32) (global.get $spin_park_k))
  ;; The most blocks that may run between two clock reads of one context for
  ;; them to still count as a spin (see $spin_work_max in 01-header.wat).
  ;; 0 turns the work check off, restoring the four-condition detector.
  (func (export "set_spin_work_max") (param $n i32)
    (global.set $spin_work_max (local.get $n)))
  (func (export "get_spin_work_max") (result i32) (global.get $spin_work_max))
  ;; Mask of callee-saved registers that must match between two reads of one
  ;; context (see $spin_regs_check in 01-header.wat): bit0 EBX, bit1 EBP,
  ;; bit2 ESI, bit3 EDI; 15 is the default and 0 the A/B arm without it.
  (func (export "set_spin_regs_check") (param $on i32)
    (global.set $spin_regs_check (local.get $on)))
  (func (export "get_spin_regs_check") (result i32) (global.get $spin_regs_check))
  (func (export "get_blocks_now") (result i32) (call $blocks_now))
  ;; The guest millisecond a clock park is due at. The CLI compares it against
  ;; the batch clock; the browser turns it into a setTimeout.
  (func (export "get_spin_deadline_ms") (result i32) (global.get $spin_deadline_ms))
  ;; The last millisecond a clock API handed the guest. Paired with the
  ;; deadline above so a host can turn "due at T" into "sleep for N" without
  ;; having to agree with the guest about what time it is.
  (func (export "get_tick_count") (result i32) (global.get $tick_count))
  ;; Trip counters. These are the acceptance measurement: a game that must not
  ;; debounce is one that ends a run with both of these at zero.
  (func (export "get_clock_spin_parks") (result i32) (global.get $clock_spin_parks))
  (func (export "get_peek_spin_parks") (result i32) (global.get $peek_spin_parks))
  (func (export "get_clock_spin_count") (result i32) (global.get $clock_spin_count))
  (func (export "get_peek_spin_count") (result i32) (global.get $peek_spin_count))
  (func (export "get_spin_nonpoll_seq") (result i32) (global.get $spin_nonpoll_seq))
  (func (export "test_spin_reset")
    (global.set $spin_dispatch_seq (i32.const 0))
    (global.set $spin_nonpoll_seq (i32.const 0))
    (global.set $spin_deadline_ms (i32.const 0))
    (global.set $clock_spin_count (i32.const 0))
    (global.set $clock_spin_value (i32.const 0))
    (global.set $clock_spin_seq (i32.const 0))
    (global.set $clock_spin_ret (i32.const 0))
    (global.set $clock_spin_esp (i32.const 0))
    (global.set $clock_spin_key0 (i64.const 0))
    (global.set $clock_spin_key1 (i64.const 0))
    (global.set $clock_spin_key2 (i64.const 0))
    (global.set $clock_spin_history0 (i64.const 0))
    (global.set $clock_spin_history1 (i64.const 0))
    (global.set $clock_spin_history2 (i64.const 0))
    (global.set $clock_spin_count0 (i32.const 0))
    (global.set $clock_spin_count1 (i32.const 0))
    (global.set $clock_spin_count2 (i32.const 0))
    (global.set $clock_spin_blk (i32.const 0))
    (global.set $clock_spin_blk0 (i32.const 0))
    (global.set $clock_spin_blk1 (i32.const 0))
    (global.set $clock_spin_blk2 (i32.const 0))
    (global.set $clock_spin_regs (i32.const 0))
    (global.set $clock_spin_regs0 (i32.const 0))
    (global.set $clock_spin_regs1 (i32.const 0))
    (global.set $clock_spin_regs2 (i32.const 0))
    (global.set $clock_spin_raw_lo (i32.const 0))
    (global.set $clock_spin_raw_hi (i32.const 0))
    (global.set $clock_spin_parked_value (i32.const 0))
    (global.set $clock_spin_parked_valid (i32.const 0))
    (global.set $clock_spin_qualified_valid (i32.const 0))
    (global.set $clock_spin_qualified_ret (i32.const 0))
    (global.set $clock_spin_qualified_esp (i32.const 0))
    (global.set $spin_peek_activity_marked (i32.const 0))
    (global.set $clock_spin_parks (i32.const 0))
    (global.set $peek_spin_count (i32.const 0))
    (global.set $peek_spin_seq (i32.const 0))
    (global.set $peek_spin_ret (i32.const 0))
    (global.set $peek_spin_esp (i32.const 0))
    (global.set $peek_spin_parks (i32.const 0)))
  ;; Drive one timeGetTime the way $win32_dispatch would — the sequence bump
  ;; included, because "was anything else dispatched in between" is half of
  ;; what the detector tests and a seam that skipped it would test the other
  ;; half twice. Bits:
  ;;    1  parked with yield_reason 14
  ;;    2  left the stdcall frame alone (the re-entry sees the same args)
  ;;    4  raised $handler_set_eip (opts out of $run's thunk-zone auto-pop)
  ;;    8  completed instead: popped exactly the 0-arg stdcall frame
  ;;   16  completed instead: returned the clock in EAX
  ;; ESP and EIP are put back afterwards, so repeated calls look to the
  ;; detector like one call site spinning — which is the point.
  (func (export "test_clock_spin_once") (result i32)
    (local $saved_esp i32) (local $saved_eip i32) (local $bits i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (local.set $saved_eip (global.get $eip))
    (global.set $spin_dispatch_seq (i32.add (global.get $spin_dispatch_seq) (i32.const 1)))
    (call $handle_timeGetTime
      (i32.const 0) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (if (i32.eq (global.get $yield_reason) (i32.const 14))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 1)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (local.get $saved_esp))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 2)))))
    (if (global.get $handler_set_eip)
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 4)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (i32.add (local.get $saved_esp) (i32.const 4)))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 8)))))
    (if (i32.eq (i32.load offset=0 (global.get $reg_base)) (global.get $tick_count))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 16)))))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp))
    (global.set $eip (local.get $saved_eip))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (global.set $handler_set_eip (i32.const 0))
    (local.get $bits))
  ;; The same for QueryPerformanceCounter(lpCount), with the dispatcher's
  ;; activity classification applied through $spin_is_clock_read rather than
  ;; restated here. Bits 1/2/4 as above; 8 = popped the 1-arg frame; 16 = the
  ;; stored count is built on the millisecond the detector saw.
  (func (export "test_qpc_spin_once") (param $buf i32) (result i32)
    (local $saved_esp i32) (local $saved_eip i32) (local $bits i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (local.set $saved_eip (global.get $eip))
    (call $test_spin_mark_api (global.get $API_ID_QueryPerformanceCounter))
    (call $gs32 (local.get $buf) (i32.const 0))
    (call $gs32 (i32.add (local.get $buf) (i32.const 4)) (i32.const 0))
    (call $handle_QueryPerformanceCounter
      (local.get $buf) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (if (i32.eq (global.get $yield_reason) (i32.const 14))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 1)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (local.get $saved_esp))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 2)))))
    (if (global.get $handler_set_eip)
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 4)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (i32.add (local.get $saved_esp) (i32.const 8)))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 8)))))
    (if (i64.eq
          (i64.div_u (i64.load (call $g2w (local.get $buf))) (i64.const 1000))
          (i64.extend_i32_u (global.get $tick_count)))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 16)))))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp))
    (global.set $eip (local.get $saved_eip))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (global.set $handler_set_eip (i32.const 0))
    (local.get $bits))
  ;; Account one dispatched API the way $win32_dispatch does, without running
  ;; its handler: the two sequence numbers are all the detectors read.
  (func $test_spin_mark_api (param $api_id i32)
    (global.set $spin_dispatch_seq (i32.add (global.get $spin_dispatch_seq) (i32.const 1)))
    (if (i32.eqz (call $spin_is_clock_read (local.get $api_id)))
      (then (global.set $spin_nonpoll_seq
              (i32.add (global.get $spin_nonpoll_seq) (i32.const 1))))))
  ;; QueryPerformanceFrequency between two QPC reads, as the dispatcher counts it.
  (func (export "test_spin_qpf_call")
    (call $test_spin_mark_api (global.get $API_ID_QueryPerformanceFrequency)))
  ;; Guest work with no API call in it: retire N blocks as far as $blocks_now
  ;; can tell, which is what separates D2's per-object GetTickCount from a spin.
  (func (export "test_spin_retire_blocks") (param $n i32)
    (global.set $blocks_retired_base
      (i32.add (global.get $blocks_retired_base) (local.get $n))))
  ;; A Win32 call that is NOT the clock, to interleave between two reads. Any
  ;; API would do; GetDoubleClickTime is picked because it has no side effects
  ;; and no arguments. This is how the "no other call in between" reset is
  ;; tested without inventing a fake dispatch.
  (func (export "test_spin_other_call")
    (local $saved_esp i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (global.set $spin_dispatch_seq (i32.add (global.get $spin_dispatch_seq) (i32.const 1)))
    (global.set $spin_nonpoll_seq (i32.add (global.get $spin_nonpoll_seq) (i32.const 1)))
    (call $handle_GetDoubleClickTime
      (i32.const 0) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp)))
  ;; The PeekMessage twin. Same bits, with reason 15 and the 5-arg frame.
  (func (export "test_peek_spin_once") (param $msg i32) (result i32)
    (local $saved_esp i32) (local $saved_eip i32) (local $bits i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (local.set $saved_eip (global.get $eip))
    (global.set $spin_dispatch_seq (i32.add (global.get $spin_dispatch_seq) (i32.const 1)))
    (global.set $spin_nonpoll_seq (i32.add (global.get $spin_nonpoll_seq) (i32.const 1)))
    (global.set $spin_peek_activity_marked (i32.const 1))
    (call $handle_PeekMessageA
      (local.get $msg) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (if (i32.eq (global.get $yield_reason) (i32.const 15))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 1)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (local.get $saved_esp))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 2)))))
    (if (global.get $handler_set_eip)
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 4)))))
    (if (i32.eq (i32.load offset=16 (global.get $reg_base)) (i32.add (local.get $saved_esp) (i32.const 24)))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 8)))))
    (if (i32.eqz (i32.load offset=0 (global.get $reg_base)))
      (then (local.set $bits (i32.or (local.get $bits) (i32.const 16)))))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp))
    (global.set $eip (local.get $saved_eip))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (global.set $handler_set_eip (i32.const 0))
    (local.get $bits))
  ;; Model the Win16 USER bridge, which invokes the ANSI handler without first
  ;; passing through $win32_dispatch. Its empty result must not roll back some
  ;; earlier Win32 call's activity mark.
  (func (export "test_peek_spin_direct_empty") (param $msg i32)
    (local $saved_esp i32) (local $saved_eip i32)
    (local.set $saved_esp (i32.load offset=16 (global.get $reg_base)))
    (local.set $saved_eip (global.get $eip))
    (call $handle_PeekMessageA
      (local.get $msg) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (i32.store offset=16 (global.get $reg_base) (local.get $saved_esp))
    (global.set $eip (local.get $saved_eip))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (global.set $handler_set_eip (i32.const 0)))
  (func $has_pending_message (export "has_pending_message") (result i32)
    ;; Move the virtual wire first. A WSAAsyncSelect server parked in
    ;; GetMessage is resumed only when this says yes, and the only thing that
    ;; turns an inbound frame into its FD_ACCEPT/FD_READ message is the
    ;; $vsock_pump at the top of GetMessage -- which never runs while parked.
    ;; Two TetriNETs in one browser tab sat there for good: the client's SYN
    ;; in the server's inbox, the server parked with nothing "pending". The
    ;; CLI never saw it because run.js pumps the wire between batches. Same
    ;; drain the vlan_pump export does; a no-op when Winsock is unused.
    (call $vsock_pump)
    (if (global.get $quit_flag) (then (return (i32.const 1))))
    (if (global.get $pending_child_create) (then (return (i32.const 1))))
    (if (global.get $pending_child_size) (then (return (i32.const 1))))
    (if (global.get $pending_input_packed) (then (return (i32.const 1))))
    (if (call $post_queue_total_count) (then (return (i32.const 1))))
    (if (call $shared_post_queue_read (i32.const 0) (i32.const 0))
      (then (return (i32.const 1))))
    (if (global.get $pending_wm_size) (then (return (i32.const 1))))
    ;; Only NC calculation/paint (bits 2/0) are retrieved as messages.
    ;; Pending erase (bit 1) is paint lifecycle state, and bit 3 records
    ;; default erase ownership. Neither alone may spin the message waiter.
    (if (call $nc_flags_scan (i32.const 5))
      (then (return (i32.const 1))))
    ;; The selector mirrors the legacy main-window flag into PAINT_FLAGS
    ;; only when retrieval runs. Wake for it even before that mirror exists.
    (if (global.get $paint_pending) (then (return (i32.const 1))))
    (if (call $paint_flag_any) (then (return (i32.const 1))))
    (if (call $timer_check_due (call $paint_scratch_take) (i32.const 0))
      (then (return (i32.const 1))))
    (i32.const 0))

  ;; next_timer_due_ms() — milliseconds until the soonest timer this thread owns
  ;; becomes due, or -1 when it owns none. $has_pending_message answers "is
  ;; there work now"; a host that parks a guest waiting on GetMessage needs the
  ;; complementary "and when could there be", because a WM_TIMER is the one
  ;; wake source that arrives with nothing else touching the emulator: no
  ;; input event, no worker, no posted message. Without it the drive loop can
  ;; only poll. Same two tables $timer_check_due walks, same ownership rule
  ;; (a WM_TIMER is delivered to the thread that set it), and it consumes
  ;; nothing — a due timer reports 0 and is still there for the next
  ;; GetMessage/PeekMessage to take.
  (func (export "next_timer_due_ms") (result i32)
    (local $i i32) (local $addr i32) (local $elapsed i32)
    (local $interval i32) (local $remain i32) (local $best i32)
    (local.set $best (i32.const -1))
    (global.set $tick_count (call $host_get_ticks))
    (call $lock_wnd_acquire)
    (block $break
      (loop $loop
        (br_if $break (i32.ge_u (local.get $i) (global.get $TIMER_MAX)))
        (local.set $addr (i32.add (global.get $TIMER_TABLE)
          (i32.mul (local.get $i) (global.get $TIMER_ENTRY_SIZE))))
        ;; Both halves normalized to 0/1 before the i32.and: the raw hwnd/id are
        ;; arbitrary integers and an even one would clear the low bit.
        (if (i32.and
              (i32.or
                (i32.ne (i32.load (local.get $addr)) (i32.const 0))
                (i32.ne (i32.atomic.load offset=4 (local.get $addr)) (i32.const 0)))
              (i32.eq (i32.load (i32.add (global.get $TIMER_SHARED)
                (i32.add (i32.const 0x10) (i32.mul (local.get $i) (i32.const 4)))))
                (global.get $current_thread_id)))
          (then
            (local.set $interval (i32.load offset=8 (local.get $addr)))
            (local.set $elapsed (i32.sub (global.get $tick_count)
              (i32.load offset=12 (local.get $addr))))
            (local.set $remain
              (select (i32.const 0)
                (i32.sub (local.get $interval) (local.get $elapsed))
                (i32.ge_u (local.get $elapsed) (local.get $interval))))
            (if (i32.or
                  (i32.lt_s (local.get $best) (i32.const 0))
                  (i32.lt_u (local.get $remain) (local.get $best)))
              (then (local.set $best (local.get $remain))))))
        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $loop)))
    (call $lock_wnd_release)
    ;; Multimedia timers (timeSetEvent): id at +0, period at +4, last tick at +16.
    ;; Not a wake source for this thread once the winmm timer thread owns them.
    (local.set $i (if (result i32) (call $mm_timer_thread_owned)
      (then (global.get $MM_TIMER_MAX)) (else (i32.const 0))))
    (block $mm_break
      (loop $mm_loop
        (br_if $mm_break (i32.ge_u (local.get $i) (global.get $MM_TIMER_MAX)))
        (local.set $addr (call $mm_timer_slot (local.get $i)))
        (if (i32.load (local.get $addr))
          (then
            (local.set $interval (i32.load offset=4 (local.get $addr)))
            (local.set $elapsed (i32.sub (global.get $tick_count)
              (i32.load offset=16 (local.get $addr))))
            (local.set $remain
              (select (i32.const 0)
                (i32.sub (local.get $interval) (local.get $elapsed))
                (i32.ge_u (local.get $elapsed) (local.get $interval))))
            (if (i32.or
                  (i32.lt_s (local.get $best) (i32.const 0))
                  (i32.lt_u (local.get $remain) (local.get $best)))
              (then (local.set $best (local.get $remain))))))
        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $mm_loop)))
    ;; A playing MCI avivideo device wants its next frame.
    (call $mciavi_due_ms (local.get $best)))

  (func (export "get_com_dll_name") (result i32) (global.get $com_dll_name))
  (func (export "get_loadlib_name") (result i32) (global.get $loadlib_name_ptr))

  ;; PE metadata exports (needed to init worker threads)
  (func (export "get_code_start") (result i32) (global.get $code_start))
  (func (export "get_code_end") (result i32) (global.get $code_end))

  ;; Register setters for test harness
  (func (export "set_eip") (param i32) (global.set $eip (local.get 0)))
  (func (export "set_esp") (param i32) (i32.store offset=16 (global.get $reg_base) (local.get 0)))
  (func (export "set_ebp") (param i32) (i32.store offset=20 (global.get $reg_base) (local.get 0)))
  (func (export "set_eax") (param i32) (i32.store offset=0 (global.get $reg_base) (local.get 0)))
  (func (export "set_ecx") (param i32) (i32.store offset=4 (global.get $reg_base) (local.get 0)))
  (func (export "set_edx") (param i32) (i32.store offset=8 (global.get $reg_base) (local.get 0)))
  (func (export "set_ebx") (param i32) (i32.store offset=12 (global.get $reg_base) (local.get 0)))
  (func (export "set_esi") (param i32) (i32.store offset=24 (global.get $reg_base) (local.get 0)))
  (func (export "set_edi") (param i32) (i32.store offset=28 (global.get $reg_base) (local.get 0)))
  ;; Owner-thread SendMessage dispatcher support.  guest-worker.js snapshots
  ;; these few interpreter-control globals around a nested dispatch just as
  ;; $wnd_send_message_inner does for a local synchronous send.
  (func (export "get_handler_set_eip") (result i32) (global.get $handler_set_eip))
  (func (export "set_handler_set_eip") (param i32) (global.set $handler_set_eip (local.get 0)))
  (func (export "get_steps") (result i32) (global.get $steps))
  (func (export "set_steps") (param i32) (global.set $steps (local.get 0)))
  (func (export "set_yield_state") (param $reason i32) (param $flag i32)
    (global.set $yield_reason (local.get $reason))
    (global.set $yield_flag (local.get $flag)))
  (func (export "get_send_target_tid") (result i32) (global.get $send_target_tid))
  (func (export "get_send_hwnd") (result i32) (global.get $send_hwnd))
  (func (export "get_send_msg") (result i32) (global.get $send_msg))
  (func (export "get_send_wparam") (result i32) (global.get $send_wparam))
  (func (export "get_send_lparam") (result i32) (global.get $send_lparam))
  (func (export "get_send_post_kind") (result i32) (global.get $send_post_kind))
  ;; The scheduler raises this on a receiver that is not at a message call when
  ;; a send for it parks; the receiver's next message call yields reason 17.
  (func (export "set_incoming_send_pending") (param i32)
    (global.set $incoming_send_pending (local.get 0)))
  (func (export "get_incoming_send_pending") (result i32)
    (global.get $incoming_send_pending))

  ;; Finish message-specific compatibility work on the HWND owner's instance,
  ;; after its native WndProc has returned but before the LRESULT is delivered
  ;; to the parked sender.
  (func (export "thread_send_post")
    (param $hwnd i32) (param $msg i32) (param $wparam i32) (param $lparam i32)
    (param $post_kind i32) (param $result i32) (result i32)
    (if (i32.eq (local.get $post_kind) (i32.const 1))
      (then (return (call $richedit_formatrange_next (local.get $lparam)))))
    (if (i32.eq (local.get $post_kind) (i32.const 2))
      (then
        (call $richedit_patch_get_charformat_message
          (local.get $hwnd) (local.get $msg) (local.get $lparam))))
    (local.get $result))

  ;; Start a synchronous dispatch on this instance. Native USER procedures can
  ;; complete immediately; an x86 WndProc is entered with CACA0005 as its return
  ;; thunk and is driven by the worker until EIP becomes zero.
  (func (export "thread_send_begin")
    (param $hwnd i32) (param $msg i32) (param $wparam i32) (param $lparam i32)
    (result i32)
    (local $wp i32)
    (global.set $cross_thread_send_depth
      (i32.add (global.get $cross_thread_send_depth) (i32.const 1)))
    (if (call $win16_thread_send_begin (local.get $hwnd) (local.get $msg)
          (local.get $wparam) (local.get $lparam))
      (then
        (global.set $steps (i32.const 0))
        (global.set $yield_reason (i32.const 0))
        (global.set $yield_flag (i32.const 0))
        (call $sync_depth_enter)
        (return (i32.const 1))))
    (local.set $wp (call $wnd_table_get (local.get $hwnd)))
    (if (i32.or (i32.eqz (local.get $wp))
                (i32.ge_u (local.get $wp) (i32.const 0xFFFF0000)))
      (then
        (i32.store offset=0 (global.get $reg_base) (call $wnd_send_message
          (local.get $hwnd) (local.get $msg) (local.get $wparam) (local.get $lparam)))
        (global.set $cross_thread_send_depth
          (i32.sub (global.get $cross_thread_send_depth) (i32.const 1)))
        (return (i32.const 0))))
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 16)))
    (call $gs32 (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 12)) (local.get $lparam))
    (call $gs32 (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 8)) (local.get $wparam))
    (call $gs32 (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 4)) (local.get $msg))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $hwnd))
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (global.get $sync_msg_ret_thunk))
    (global.set $eip (local.get $wp))
    (global.set $steps (i32.const 0))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (call $sync_depth_enter)
    (i32.const 1))

  (func (export "thread_send_end") (result i32)
    (if (i32.and (i32.ne (global.get $send_reply_depth) (i32.const 0))
                 (i32.eq (global.get $send_reply_depth) (global.get $cross_thread_send_depth)))
      (then
        (i32.store offset=0 (global.get $reg_base) (global.get $send_reply_value))
        (global.set $send_reply_depth (i32.const 0))))
    (call $sync_depth_leave)
    (global.set $cross_thread_send_depth
      (i32.sub (global.get $cross_thread_send_depth) (i32.const 1)))
    (i32.load offset=0 (global.get $reg_base)))

  ;; Finish the original parked SendMessage stdcall on its owning instance.
  (func (export "complete_thread_send") (param $result i32)
    (local $ret i32)
    (if (i32.ne (global.get $yield_reason) (i32.const 10)) (then (return)))
    (if (global.get $is_win16)
      (then (call $win16_thread_send_complete (local.get $result)) (return)))
    (local.set $ret (call $gl32 (i32.load offset=16 (global.get $reg_base))))
    (i32.store offset=0 (global.get $reg_base) (local.get $result))
    (i32.store offset=16 (global.get $reg_base) (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 20)))
    (global.set $eip (local.get $ret))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0)))

  ;; Windows version
  (func (export "set_winver") (param i32) (global.set $winver (local.get 0)))
  (func (export "get_winver") (result i32) (global.get $winver))

  ;; Multi-app hwnd allocation — set base hwnd before PE load
  (func (export "set_hwnd_base") (param i32) (global.set $next_hwnd (local.get 0)))
  (func (export "get_hwnd_base") (result i32) (global.get $next_hwnd))

  ;; The run loop tests $dbg_any once instead of testing all six arming flags.
  ;; Every setter below that can arm or disarm one of them ends by calling this.
  ;; Missing a call here does not corrupt anything — it makes one debug flag
  ;; silently do nothing, which is why they are all in one place.
  ;; Benchmark-only mode: chains return to run at the breakpoint target;
  ;; every other debugging facility retains its ordinary no-chaining guard.
  (global $benchmark_chain_bp (mut i32) (i32.const 0))
  (global $dbg_chain_guard (mut i32) (i32.const 0))
  ;; Two guards, because the debug facilities want two different things.
  ;;
  ;; $dbg_chain_guard: every block ENTRY must pass $run's desk. The handler
  ;; histogram is in it because its per-block half, $hot_block_hist_record,
  ;; is recorded there; letting the transfer fast paths skip the desk would
  ;; silently drop block entries from the hot-block dump. It costs a desk trip
  ;; per transfer and changes no guest-visible result.
  ;;
  ;; $dbg_tier_guard: every x86 block must EXECUTE as its own threaded block,
  ;; so the micro-op tier ($th_uop_enter) may not run a loop inside one wasm
  ;; call. --break/--watch/--count/--trace-esp/--trace-eip test EIP or memory
  ;; at each block and would see nothing for the blocks a uop program retires,
  ;; so they keep it. The handler histogram does NOT: it measures the program
  ;; that runs, and with the tier on that program is "uop enters plus a
  ;; threaded remainder" -- the enter op is itself a dispatched handler and
  ;; $uop_blocks counts what the tier retired. Holding the tier off under the
  ;; histogram made every --handler-hist window describe a tier-off run
  ;; (docs/uop-tier-design.md 11.1).
  (global $dbg_tier_guard (mut i32) (i32.const 0))
  (func $dbg_recompute
    (global.set $dbg_any
      (i32.or (i32.ne (global.get $watch_addr) (i32.const 0))
        (i32.or (i32.ne (global.get $bp_addr) (i32.const 0))
          (i32.or (i32.ne (global.get $hit_count_n) (i32.const 0))
            (i32.or (i32.ne (global.get $trace_esp_flag) (i32.const 0))
              (i32.or (i32.ne (global.get $trace_eip_flag) (i32.const 0))
                      (i32.ne (global.get $handler_hist_enabled) (i32.const 0))))))))
    (global.set $dbg_chain_guard (global.get $dbg_any))
    (if (global.get $benchmark_chain_bp)
      (then (global.set $dbg_chain_guard
        (i32.or (i32.ne (global.get $watch_addr) (i32.const 0))
          (i32.or (i32.ne (global.get $hit_count_n) (i32.const 0))
            (i32.or (i32.ne (global.get $trace_esp_flag) (i32.const 0))
              (i32.or (i32.ne (global.get $trace_eip_flag) (i32.const 0))
                      (i32.ne (global.get $handler_hist_enabled) (i32.const 0)))))))))
    ;; Not a debug facility: a depth-0 frame owes the spill's full flush, which
    ;; only $run's desk takes (04-cache.wat $sync_depth_leave).
    (global.set $dbg_chain_guard
      (i32.or (global.get $dbg_chain_guard) (global.get $spill_desk_forced)))
    ;; The same set minus the histogram. Benchmark mode exempts the breakpoint
    ;; here exactly as it does above, so the tier's behaviour under
    ;; --benchmark-chain-bp is unchanged.
    ;; ...plus the shadow call stack: a uop program's CALL/RET (07e kinds 23,
    ;; 24) do not maintain it.
    (global.set $dbg_tier_guard
      (i32.or (i32.or (i32.ne (global.get $watch_addr) (i32.const 0)) (i32.ne (global.get $cs_enabled) (i32.const 0)))
        (i32.or (i32.and (i32.ne (global.get $bp_addr) (i32.const 0))
                         (i32.eqz (global.get $benchmark_chain_bp)))
          (i32.or (i32.ne (global.get $hit_count_n) (i32.const 0))
            (i32.or (i32.ne (global.get $trace_esp_flag) (i32.const 0))
                    (i32.ne (global.get $trace_eip_flag) (i32.const 0))))))))
  (func (export "get_dbg_tier_guard") (result i32) (global.get $dbg_tier_guard))
  (func (export "set_benchmark_chain_bp") (param $on i32)
    (global.set $benchmark_chain_bp (local.get $on)) (call $dbg_recompute))

  ;; Watchpoint exports
  (func (export "set_bp") (param $addr i32) (global.set $bp_addr (local.get $addr)) (global.set $bp_first_caller (i32.const 0)) (call $dbg_recompute))
  (func (export "clear_bp") (global.set $bp_addr (i32.const 0)) (call $dbg_recompute))
  (func (export "get_bp_addr") (result i32) (global.get $bp_addr))
  ;; --fault-null: 0=off, 1=log unmapped guest accesses, 2=log and trap,
  ;; 3=log and raise a guest EXCEPTION_ACCESS_VIOLATION at the faulting
  ;; instruction (--fault-null=raise), which is what real hardware does.
  ;; Per-instance like every mutable global, so a worker thread needs its own
  ;; call to see the same setting.
  ;; Arming this retires every decoded block, because the per-block executor
  ;; (H458) declines to install while it is set: a native micro-op that traps
  ;; inside $g2w under --fault-null=stop would do so with the register file
  ;; still in wasm locals, so the crash dump would name stale registers. The
  ;; decline is decode-time, so a block installed BEFORE the flag was armed
  ;; would keep running -- hence the flush. Costs nothing on an unarmed run.
  (func (export "set_fault_unmapped") (param $mode i32)
    (global.set $fault_unmapped (local.get $mode))
    (if (local.get $mode) (then (global.set $thread_flush_pending (i32.const 1)))))
  (func (export "get_guest_page_table_size") (result i32)
    (global.get $GUEST_PAGE_TABLE_SIZE))
  (func (export "get_bp_first_caller") (result i32) (global.get $bp_first_caller))

  ;; --trace-esp wiring (test harness uses this). Pass hi=0 to disable the
  ;; upper bound; pass flag=0 to turn off tracing.
  (func (export "set_trace_esp") (param $flag i32) (param $lo i32) (param $hi i32)
    (global.set $trace_esp_flag (local.get $flag))
    (global.set $trace_esp_lo (local.get $lo))
    (global.set $trace_esp_hi (local.get $hi))
    (call $dbg_recompute))

  ;; --trace-eip-range wiring. Pass hi=0 to leave upper bound open.
  (func (export "set_trace_eip_range") (param $flag i32) (param $lo i32) (param $hi i32)
    (global.set $trace_eip_flag (local.get $flag))
    (global.set $trace_eip_lo (local.get $lo))
    (global.set $trace_eip_hi (local.get $hi))
    (call $dbg_recompute))

  ;; Hit counters: set_count writes addr into slot N and zeros its count,
  ;; bumping $hit_count_n so the run loop includes this slot. Caller passes
  ;; slots 0..N-1 in order (contiguous); $hit_count_n = max(slot+1).
  (func (export "set_count") (param $slot i32) (param $addr i32)
    (local $base i32)
    (local.set $base (i32.add (global.get $HIT_COUNT_BASE)
                              (i32.shl (local.get $slot) (i32.const 3))))
    ;; Arming the same address twice must not throw the count away. The slots
    ;; live in linear memory, which worker instances share, and every spawn
    ;; re-arms all of them (lib/thread-manager.js) -- so an app that started a
    ;; thread mid-run reset every counter to zero and the flag reported 0 for
    ;; addresses it had already counted hundreds of thousands of times. Use
    ;; clear_counts to deliberately start over.
    (if (i32.ne (i32.load (local.get $base)) (local.get $addr))
      (then
        (i32.store          (local.get $base) (local.get $addr))
        (i32.store offset=4 (local.get $base) (i32.const 0))))
    (if (i32.gt_s (i32.add (local.get $slot) (i32.const 1)) (global.get $hit_count_n))
      (then (global.set $hit_count_n (i32.add (local.get $slot) (i32.const 1)))))
    (call $dbg_recompute))
  (func (export "get_count") (param $slot i32) (result i32)
    (i32.load offset=4 (i32.add (global.get $HIT_COUNT_BASE)
                                (i32.shl (local.get $slot) (i32.const 3)))))
  (func (export "clear_counts") (global.set $hit_count_n (i32.const 0)) (call $dbg_recompute))
  ;; Who reached slot 0's address (see $hit0_first_caller in 01-header.wat).
  (func (export "get_hit0_first_caller") (result i32) (global.get $hit0_first_caller))
  (func (export "get_hit0_last_caller")  (result i32) (global.get $hit0_last_caller))
  (func (export "get_hit0_last_ebp")     (result i32) (global.get $hit0_last_ebp))
  (func (export "get_hit0_reg") (param $i i32) (result i32)
    (block $d (block $7 (block $6 (block $5 (block $4 (block $3 (block $2 (block $1 (block $0
      (br_table $0 $1 $2 $3 $4 $5 $6 $7 $d (local.get $i)))
      (return (global.get $hit0_r0)))
      (return (global.get $hit0_r1)))
      (return (global.get $hit0_r2)))
      (return (global.get $hit0_r3)))
      (return (global.get $hit0_r4)))
      (return (global.get $hit0_r5)))
      (return (global.get $hit0_r6)))
      (return (global.get $hit0_r7)))
    (i32.const 0))
  (func (export "get_hit0_frame") (param $n i32) (result i32)
    (if (i32.eq (local.get $n) (i32.const 1)) (then (return (global.get $hit0_f1))))
    (if (i32.eq (local.get $n) (i32.const 2)) (then (return (global.get $hit0_f2))))
    (if (i32.eq (local.get $n) (i32.const 3)) (then (return (global.get $hit0_f3))))
    (global.get $hit0_f4))

  ;; Disabled-by-default stack-packet compiler prototype. Toggling clears the
  ;; decoded-block cache so already-decoded generic/packet blocks do not linger.
  ;; $variant selects which packet handler the armed address compiles to.
  ;; Passing 0 (or omitting the argument, which the JS API zero-fills) keeps the
  ;; historical address->variant mapping so existing callers behave the same;
  ;; the mapping lives here, in the prototype's own switch, rather than inside
  ;; $decode_block where every app pays to read it.
  (func (export "set_stack_packet_enabled") (param $flag i32) (param $addr i32) (param $variant i32)
    (global.set $stack_packet_enabled (local.get $flag))
    (if (local.get $addr)
      (then (global.set $stack_packet_addr (local.get $addr))))
    (if (local.get $variant)
      (then (global.set $stack_packet_variant (local.get $variant)))
      (else (global.set $stack_packet_variant
        (select (i32.const 2) (i32.const 1)
          (i32.eq (global.get $stack_packet_addr) (i32.const 0x0049DD20))))))
    (call $clear_cache))
  (func (export "set_stack_packet_count_enabled") (param $flag i32)
    (global.set $stack_packet_count_enabled (local.get $flag)))
  (func (export "reset_stack_packet_counters")
    (global.set $stack_packet_entries (i32.const 0))
    (global.set $stack_packet_0049d9d1_entries (i32.const 0))
    (global.set $stack_packet_0049dd20_entries (i32.const 0))
    (global.set $stack_packet_0049dd20_empty_inline_entries (i32.const 0))
    (global.set $stack_packet_0049dd20_to_dd8b_entries (i32.const 0))
    (global.set $stack_packet_0049dd20_to_ddc7_entries (i32.const 0))
    (global.set $stack_packet_0049dd20_to_e0ad_entries (i32.const 0)))
  (func (export "get_stack_packet_enabled") (result i32)
    (global.get $stack_packet_enabled))
  (func (export "get_stack_packet_addr") (result i32)
    (global.get $stack_packet_addr))
  (func (export "get_stack_packet_count_enabled") (result i32)
    (global.get $stack_packet_count_enabled))
  (func (export "get_stack_packet_entries") (result i32)
    (global.get $stack_packet_entries))
  (func (export "get_stack_packet_0049d9d1_entries") (result i32)
    (global.get $stack_packet_0049d9d1_entries))
  (func (export "get_stack_packet_0049dd20_entries") (result i32)
    (global.get $stack_packet_0049dd20_entries))
  (func (export "get_stack_packet_0049dd20_empty_inline_entries") (result i32)
    (global.get $stack_packet_0049dd20_empty_inline_entries))
  (func (export "get_stack_packet_0049dd20_to_dd8b_entries") (result i32)
    (global.get $stack_packet_0049dd20_to_dd8b_entries))
  (func (export "get_stack_packet_0049dd20_to_ddc7_entries") (result i32)
    (global.get $stack_packet_0049dd20_to_ddc7_entries))
  (func (export "get_stack_packet_0049dd20_to_e0ad_entries") (result i32)
    (global.get $stack_packet_0049dd20_to_e0ad_entries))

  ;; Loop-idiom matcher (src/07b-loop-match.wat). Decode-time only, so these
  ;; can be flipped at any point without disturbing a running block.
  (func (export "set_loop_trace") (param $flag i32) (param $eip i32)
    (global.set $loop_trace (local.get $flag))
    (global.set $loop_trace_eip (local.get $eip)))
  (func (export "get_loop_selfloop_blocks") (result i32)
    (global.get $loop_selfloop_blocks))
  (func (export "get_loop_matched_blocks") (result i32)
    (global.get $loop_matched_blocks))
  (func (export "get_loop_lut_bounded_matches") (result i32)
    (global.get $loop_lut_bounded_matches))
  (func (export "get_loop_lut_runs") (result i32)
    (global.get $loop_lut_runs))
  (func (export "get_loop_lut_bytes") (result i64)
    (global.get $loop_lut_bytes))
  (func (export "get_loop_xlat_stosb_matches") (result i32)
    (global.get $loop_xlat_stosb_matches))
  (func (export "get_loop_xlat_stosb_candidates") (result i32)
    (global.get $loop_xlat_stosb_candidates))
  (func (export "get_loop_xlat_stosb_runs") (result i32)
    (global.get $loop_xlat_stosb_runs))
  (func (export "get_loop_xlat_stosb_bytes") (result i64)
    (global.get $loop_xlat_stosb_bytes))
  ;; Compatibility switch: control both families together. Prefer the family
  ;; switches for an A/B because COPY_RUN remains disabled by default.
  (func (export "set_loop_emit") (param $flag i32)
    (global.set $loop_lut_emit_enabled (local.get $flag))
    (call $loop_copy_emit_set (local.get $flag))
    (call $loop_generic_copy_emit_set (local.get $flag)))
  (func (export "set_loop_lut_emit") (param $flag i32)
    (global.set $loop_lut_emit_enabled (local.get $flag)))
  (func (export "set_loop_copy_emit") (param $flag i32)
    (call $loop_copy_emit_set (local.get $flag)))
  ;; Unsafe generic COPY_RUN/AVG rollback switch. Production app policy uses
  ;; set_loop_copy_emit for exact byte-proved folds and never enables this.
  (func (export "set_loop_generic_copy_emit") (param $flag i32)
    (call $loop_generic_copy_emit_set (local.get $flag)))
  ;; UE1 SoftDrv MMX qword fill (07b $try_emit_mmx_fill64). On by default;
  ;; decode-time, so the cache is dropped and both A/B arms decode from scratch.
  (func (export "set_loop_mmx_fill_emit") (param $flag i32)
    (global.set $mmx_fill64_enabled (i32.ne (local.get $flag) (i32.const 0)))
    (call $clear_cache))
  (func (export "get_mmx_fill64_matches") (result i32) (global.get $mmx_fill64_matches))
  (func (export "get_mmx_fill64_runs") (result i32) (global.get $mmx_fill64_runs))
  (func (export "get_mmx_fill64_qwords") (result i64) (global.get $mmx_fill64_qwords))
  (func (export "get_mmx_fill64_bulk_qwords") (result i64) (global.get $mmx_fill64_bulk_qwords))
  (func (export "set_loop_aoe_fill_emit") (param $flag i32)
    (global.set $loop_aoe_fill_emit_enabled (local.get $flag))
    (call $clear_cache))
  (func (export "get_loop_aoe_fill_matches") (result i32)
    (global.get $loop_aoe_fill_matches))
  (func (export "get_loop_aoe_fill_runs") (result i32)
    (global.get $loop_aoe_fill_runs))
  (func (export "get_loop_aoe_fill_bytes") (result i64)
    (global.get $loop_aoe_fill_bytes))
  (func (export "set_loop_aoe_span_emit") (param $flag i32)
    (global.set $loop_aoe_span_emit_enabled (local.get $flag))
    (call $clear_cache))
  (func (export "get_loop_aoe_span_matches") (result i32)
    (global.get $loop_aoe_span_matches))
  (func (export "get_loop_aoe_span_runs") (result i32)
    (global.get $loop_aoe_span_runs))
  (func (export "get_loop_colorkey8_matches") (result i32)
    (global.get $loop_colorkey8_matches))
  (func (export "get_loop_colorkey8_runs") (result i32)
    (global.get $loop_colorkey8_runs))
  (func (export "get_loop_colorkey8_bytes") (result i64)
    (global.get $loop_colorkey8_bytes))

  ;; --no-sib-fusion: emit the unfused compute_ea_sib + consumer pair, so a
  ;; fused build and an unfused one differ in exactly one thing and need no
  ;; rebuild between them. Must be set before the first decode, and on every
  ;; per-thread instance — mut globals are per-instance.
  (func (export "set_sib_fusion") (param $flag i32)
    (global.set $sib_fusion_enabled (local.get $flag)))

  (func (export "set_store_span_fusion") (param $flag i32)
    (global.set $store_span_enabled (local.get $flag))
    (call $clear_cache))

  ;; --no-stack-fusion: decode PUSH/POP/CALL/RET one instruction per op again
  ;; (07-decoder.wat $try_emit_stack_run). Clears decoded code.
  (func (export "set_stack_fusion") (param $flag i32)
    (global.set $stack_fusion_enabled (local.get $flag))
    (call $clear_cache))

  (func (export "set_x87_pipeline4_fusion") (param $flag i32)
    (global.set $x87_pipeline4_emit_enabled (local.get $flag))
    (call $clear_cache))
  (func (export "get_x87_pipeline4_matches") (result i32)
    (global.get $x87_pipeline4_matches))
  (func (export "get_x87_pipeline4_runs") (result i32)
    (global.get $x87_pipeline4_runs))
  (func (export "get_x87_tree4_matches") (result i32)
    (global.get $x87_tree4_matches))
  (func (export "get_x87_tree4_runs") (result i32)
    (global.get $x87_tree4_runs))
  (func (export "get_x87_island_matches") (result i32)
    (global.get $x87_island_matches))
  (func (export "get_x87_island_runs") (result i32)
    (global.get $x87_island_runs))
  ;; --no-x87-island-predecode: run H451 islands through the original
  ;; per-op $fpu_exec_* walk. Run-time only, so no cache clear.
  (func (export "set_x87_island_predecode") (param $flag i32)
    (global.set $x87_island_predecode (local.get $flag)))
  (func (export "get_x87_island_predecode") (result i32)
    (global.get $x87_island_predecode))
  (func (export "set_x87_affine_fusion") (param $flag i32)
    (global.set $x87_affine_emit_enabled (local.get $flag))
    (call $clear_cache))
  (func (export "get_x87_affine_prepare_matches") (result i32)
    (global.get $x87_affine_prepare_matches))
  (func (export "get_x87_affine_prepare_runs") (result i32)
    (global.get $x87_affine_prepare_runs))
  (func (export "get_x87_affine_finish_matches") (result i32)
    (global.get $x87_affine_finish_matches))
  (func (export "get_x87_affine_finish_runs") (result i32)
    (global.get $x87_affine_finish_runs))

  ;; The run-length blit fold ($th_rle_run). Decode-time, so this only steers
  ;; blocks decoded after it is called -- set it before the first decode for a
  ;; clean A/B, and on every per-thread instance.
  (func (export "set_rle_run") (param $flag i32)
    (global.set $rle_run_enabled (local.get $flag)))
  (func (export "get_rle_run") (result i32) (global.get $rle_run_enabled))

  (func (export "set_alu8_sib") (param $flag i32)
    (global.set $alu8_sib_enabled (local.get $flag)))
  (func (export "get_alu8_sib") (result i32) (global.get $alu8_sib_enabled))
  (func (export "set_implode_cmp_run") (param $flag i32)
    (global.set $implode_cmp_run_enabled (local.get $flag)))
  (func (export "get_implode_cmp_run") (result i32) (global.get $implode_cmp_run_enabled))
  (func (export "get_implode_cmp_run_matches") (result i32) (global.get $implode_cmp_run_matches))
  (func (export "get_implode_cmp_run_runs") (result i32) (global.get $implode_cmp_run_runs))
  (func (export "get_implode_cmp_run_iters") (result i64) (global.get $implode_cmp_run_iters))

  ;; Off switches for the exact folds that had none (07-decoder.wat
  ;; $fold_off_mask; docs/uop-tier-design.md section 18). Decode-time, per
  ;; instance, inherited by guest threads (lib/worker-imports.js).
  (func (export "set_fold_off_mask") (param $mask i32)
    (global.set $fold_off_mask (local.get $mask)))
  (func (export "get_fold_off_mask") (result i32) (global.get $fold_off_mask))
  (func (export "set_mmx_copy64") (param $flag i32)
    (global.set $mmx_copy64_enabled (i32.ne (local.get $flag) (i32.const 0))))

  ;; TREE_FOLD ($th_tree_fold, src/07b-loop-match.wat). The general integer
  ;; expression fold; OFF by default. Decode-time, so the same rule as the
  ;; three above: set it before the first decode, and on every per-thread
  ;; instance. `matches` counts every block the predicate accepted whether or
  ;; not the gate let it emit, so a --tree-fold-off run still reports how much
  ;; of the corpus the family covers.
  (func (export "set_tree_fold") (param $flag i32)
    (global.set $tree_fold_enabled (local.get $flag)))
  (func (export "get_tree_fold") (result i32) (global.get $tree_fold_enabled))
  ;; --trace-tree-fold. Decode-time like the fold itself, so it has to reach
  ;; every per-thread instance or the census sees only the main thread's blocks.
  (func (export "set_tree_trace") (param $flag i32)
    (global.set $tree_trace (local.get $flag)))
  (func (export "set_tree_fold_min_ops") (param $n i32)
    (global.set $tree_fold_min_ops (local.get $n)))
  ;; The ceiling, clamped: a descriptor past $TREE_FOLD_UOPS_LIMIT overruns
  ;; either $decode_block's reserved slack or the classify scratch, and both
  ;; corrupt silently rather than declining, so the flag cannot be allowed to
  ;; ask for one. Lowering it is always safe, which is what an A/B wants.
  (func (export "set_tree_fold_max_ops") (param $n i32)
    (global.set $tree_fold_max_ops
      (select (global.get $TREE_FOLD_UOPS_LIMIT) (local.get $n)
              (i32.gt_u (local.get $n) (global.get $TREE_FOLD_UOPS_LIMIT)))))
  (func (export "get_tree_fold_max_ops") (result i32) (global.get $tree_fold_max_ops))
  (func (export "get_tree_fold_matches") (result i32) (global.get $tree_fold_matches))
  (func (export "get_tree_fold_runs") (result i32) (global.get $tree_fold_runs))
  (func (export "get_tree_fold_iters") (result i64) (global.get $tree_fold_iters))
  (func (export "get_tree_fold_ops") (result i64) (global.get $tree_fold_ops))
  (func (export "get_tree_fold_dead_flag_ops") (result i32)
    (global.get $tree_fold_dead_flag_ops))
  ;; What the most recent lowering put in the descriptor header. A fold that
  ;; runs the right number of iterations while publishing the wrong register
  ;; set is indistinguishable from one that never ran its body; these two say
  ;; which. Diagnostic only.
  (func (export "get_tree_fold_last_nuops") (result i32)
    (global.get $tree_fold_last_nuops))
  (func (export "get_tree_fold_last_live_out") (result i32)
    (global.get $tree_fold_last_live_out))
  ;; The decline split -- what a wider predicate would have to cover.
  (func (export "get_tree_decl_short") (result i32) (global.get $tree_decl_short))
  (func (export "get_tree_decl_long") (result i32) (global.get $tree_decl_long))
  (func (export "get_tree_decl_term") (result i32) (global.get $tree_decl_term))
  (func (export "get_tree_decl_uop") (result i32) (global.get $tree_decl_uop))
  (func (export "get_tree_decl_uop_fn") (result i32) (global.get $tree_decl_uop_fn))
  ;; The x87 sub-bucket of `unfoldable-op`: how many self-loops were declined
  ;; because an x87 op was outside the accepted set, and (group<<8)|(reg<<4)|rm
  ;; of the last one -- which names the instruction, where lastFn 188 cannot.
  (func (export "get_tree_decl_x87") (result i32) (global.get $tree_decl_x87))
  (func (export "get_tree_decl_x87_op") (result i32) (global.get $tree_decl_x87_op))

  ;; REGION descriptors. H454's descriptor is a graph; the shipped fold emits
  ;; the one-block case of it. These three exports install a hand-built
  ;; multi-block one at a chosen guest EIP, and exist for
  ;; tools/bench-loops.js --toggle=region and test/test-tree-fold.js only.
  ;; OFF by default and decode-time like every other fold gate, so the flag has
  ;; to be set before the block at that EIP is first decoded.
  ;;
  ;; There is deliberately no region MATCHER. Recognizing a graph in real code
  ;; is the app-scale work this measurement exists to decide about; building it
  ;; first would have been the thing the go/no-go was meant to gate. The
  ;; harness supplies the descriptor AND the x86 the other arm runs, and
  ;; checksum equality between the arms is what proves the two agree.
  ;; The per-block executor (H458, src/07c-block-exec.wat,
  ;; docs/block-executor-design.md). OFF by default and decode-time like every
  ;; other fold gate, so it has to be set before the first decode and on every
  ;; per-thread instance -- lib/worker-imports.js carries it for the second
  ;; half and test/test-worker-wasm-globals.js is the gate on that.
  ;; Block chaining (docs/block-chaining-design.md). Default OFF. Round 19
  ;; removed the mutual exclusion with the block executor: the slot no longer
  ;; holds a delta from the operand word's own address but a chunk selector
  ;; plus an offset inside one of the loaded page's two chunks, so a slot in a
  ;; descriptor's copied terminator names its target exactly as one in the
  ;; threaded stream does. Both flags on is a supported configuration and is
  ;; what section 8 of the design doc measures. The setter order no longer
  ;; decides anything, which is what the inherited-setter replay needed.
  (func (export "set_block_chain") (param $flag i32)
    (global.set $block_chain_on (i32.ne (local.get $flag) (i32.const 0)))
    (call $be_gate_refresh))
  (func (export "get_block_chain") (result i32) (global.get $block_chain_on))
  (func (export "set_jump_table") (param $flag i32)
    (global.set $jump_table_on (i32.ne (local.get $flag) (i32.const 0))))
  (func (export "get_jump_table") (result i32) (global.get $jump_table_on))
  (func (export "get_chain_hits") (result i64) (global.get $chain_hits))
  ;; Arms the $branch_end_calls / $branch_end_pool counters. Off, the block
  ;; transfer path pays no counter at all, so a reader that did not arm this
  ;; sees zeros, not a stale total.
  (func (export "set_branch_end_stats") (param $flag i32)
    (global.set $be_stats_on (i32.ne (local.get $flag) (i32.const 0)))
    (call $be_gate_refresh))
  (func (export "get_chain_slow") (result i64) (global.get $chain_slow))
  (func (export "get_chain_patches") (result i32) (global.get $chain_patches))
  (func (export "get_chain_bumps") (result i32) (global.get $chain_bumps))
  (func (export "get_chain_epoch") (result i32) (global.get $chain_epoch))
  (func (export "get_branch_end_calls") (result i64) (global.get $branch_end_calls))
  ;; ROUND 19 -- the anchor-location split. "pool" means the chain slot lives in
  ;; a page's block-executor DESCRIPTOR chunk, which can only be a copied
  ;; terminator, which can only be an executor tail exit.
  (func (export "get_chain_hits_pool") (result i64) (global.get $chain_hits_pool))
  (func (export "get_chain_slow_pool") (result i64) (global.get $chain_slow_pool))
  (func (export "get_chain_patches_pool") (result i32) (global.get $chain_patches_pool))
  (func (export "get_chain_refuse_target") (result i32) (global.get $chain_refuse_target))
  (func (export "get_chain_refuse_anchor") (result i32) (global.get $chain_refuse_anchor))
  (func (export "get_chain_stale_regs") (result i64) (global.get $chain_stale_regs))
  (func (export "get_branch_end_pool") (result i64) (global.get $branch_end_pool))
  (func (export "get_block_exec_tail_exit_count") (result i64)
    (global.get $block_exec_tail_exit_count))
  (func (export "get_block_exec_tail_chainable") (result i64)
    (global.get $block_exec_tail_chainable))
  ;; The epoch is 13 bits and the wrap has to be reachable from a test in under
  ;; a second. Every real invalidation path -- $page_retire_at, $page_chunk_put,
  ;; $page_dir_reset, $page_dir_drop_mode -- calls exactly this function, and
  ;; test-block-chain.js covers those paths separately through
  ;; invalidate_code_range and a guest SMC write. What this export exists for is
  ;; the arithmetic AT the wrap: that past $CHAIN_EPOCH_MAX the epoch parks on a
  ;; value no stored slot can hold, and that a later run restarts it at 1.
  ;; Driving 8192 real page drops takes hundreds of thousands of compile/run
  ;; cycles because a page dir slot that is already free costs nothing to drop.
  (func (export "test_chain_bump") (call $chain_bump))

  ;; ROUND 19: no longer clears $block_chain_on. The two features coexist --
  ;; see docs/block-chaining-design.md section 8 -- so this setter and
  ;; set_block_chain are independent and the replay order of the inherited
  ;; setters no longer decides which one a worker instance runs.
  (func (export "set_block_exec") (param $flag i32)
    (global.set $block_exec_enabled (local.get $flag))
    (call $bx_hot_gate_refresh))
  (func (export "get_block_exec") (result i32) (global.get $block_exec_enabled))
  (func (export "set_block_exec_min_uops") (param $n i32)
    (global.set $block_exec_min_uops (local.get $n)))
  (func (export "set_block_exec_max_uops") (param $n i32)
    (global.set $block_exec_max_uops (local.get $n)))
  (func (export "set_block_exec_trace") (param $n i32)
    (global.set $block_exec_trace (local.get $n)))
  ;; ---- round 11: the load/op split pass -------------------------------
  (func (export "set_block_exec_split") (param $flag i32)
    (global.set $block_exec_split (local.get $flag)))
  (func (export "get_block_exec_split") (result i32) (global.get $block_exec_split))
  (func (export "set_block_exec_x87") (param $flag i32)
    (global.set $block_exec_x87 (local.get $flag)))
  (func (export "get_block_exec_x87") (result i32) (global.get $block_exec_x87))
  (func (export "get_bx_pass_uops_before") (result i64)
    (global.get $bx_pass_uops_before))
  (func (export "get_bx_pass_uops_after") (result i64)
    (global.get $bx_pass_uops_after))
  (func (export "get_bx_pass_split") (result i64) (global.get $bx_pass_split))
  (func (export "get_bx_pass_rle") (result i64) (global.get $bx_pass_rle))
  (func (export "get_bx_pass_stlf") (result i64) (global.get $bx_pass_stlf))
  (func (export "get_bx_pass_movelim") (result i64) (global.get $bx_pass_movelim))
  (func (export "get_bx_pass_immfold") (result i64) (global.get $bx_pass_immfold))
  (func (export "get_bx_x87_uops") (result i64) (global.get $bx_x87_uops))
  (func (export "get_bx_x87run_uops") (result i64) (global.get $bx_x87run_uops))
  ;; Round 15 (section 24): the x87 machine state the executor deliberately
  ;; does NOT model, exported so a test can assert that directly instead of
  ;; inferring it from a stored float. Getters only -- nothing sets these from
  ;; the host, so they are not INHERITED_WASM_GLOBALS.
  (func (export "get_fpu_top") (result i32) (global.get $fpu_top))
  (func (export "get_fpu_sw") (result i32) (global.get $fpu_sw))
  (func (export "get_fpu_tags") (result i32) (global.get $fpu_tag))
  (func (export "get_bx_x87_native_uops") (result i64)
    (global.get $bx_x87_native_uops))
  (func (export "set_block_exec_carry") (param $flag i32)
    (global.set $block_exec_carry (local.get $flag)))
  (func (export "get_block_exec_carry") (result i32) (global.get $block_exec_carry))
  (func (export "get_bx_pass_carry_rle") (result i64)
    (global.get $bx_pass_carry_rle))
  (func (export "get_bx_carry_edges") (result i64) (global.get $bx_carry_edges))
  (func (export "get_bx_carry_refused") (result i64)
    (global.get $bx_carry_refused))
  (func (export "set_block_exec_rmw") (param $flag i32)
    (global.set $block_exec_rmw (local.get $flag)))
  (func (export "get_block_exec_rmw") (result i32) (global.get $block_exec_rmw))
  ;; Round 16: the one-block leaf entry point (H463). ON by default inside an
  ;; armed executor; zero sends every one-block install back through H458.
  (func (export "set_block_exec_leaf") (param $flag i32)
    (global.set $block_exec_leaf (local.get $flag)))
  (func (export "get_block_exec_leaf") (result i32) (global.get $block_exec_leaf))
  (func (export "get_block_exec_leaf_runs") (result i32)
    (global.get $block_exec_leaf_runs))
  ;; Round 17: the SECOND leaf (H464), the one that may fall back. Meaningless
  ;; with set_block_exec_leaf(0), which already sends every one-block install
  ;; back to H458; zero here narrows that to the fallback-carrying ones and
  ;; reproduces round 16 exactly.
  (func (export "set_block_exec_leaf_fb") (param $flag i32)
    (global.set $block_exec_leaf_fb (local.get $flag)))
  (func (export "get_block_exec_leaf_fb") (result i32) (global.get $block_exec_leaf_fb))
  (func (export "get_block_exec_leaf_fb_runs") (result i32)
    (global.get $block_exec_leaf_fb_runs))
  ;; Round 18 (section 28): the unmodelled-terminator side exit. Zero here
  ;; reproduces round 17 exactly on this build -- a block ending in a call, a
  ;; ret or an indirect branch goes back to being a classify refusal.
  (func (export "set_block_exec_tail_exits") (param $flag i32)
    (global.set $block_exec_tail_exits (local.get $flag)))
  (func (export "get_block_exec_tail_exits") (result i32)
    (global.get $block_exec_tail_exits))
  (func (export "get_block_exec_tail_exit_runs") (result i32)
    (global.get $block_exec_tail_exit_runs))
  ;; The census. `would_admit` / `would_grow` are the UPPER BOUND -- walks that
  ;; a term_kind 10 member could have turned into, or grown, a region --
  ;; counted whether or not the switch above is on, so the off arm measures the
  ;; opportunity and the on arm measures what was realised.
  (func (export "get_block_exec_tail_would_admit") (result i32)
    (global.get $bx_rg_tail_would_admit))
  (func (export "get_block_exec_tail_would_grow") (result i32)
    (global.get $bx_rg_tail_would_grow))
  (func (export "get_block_exec_tail_refusals") (result i64)
    (global.get $bx_rg_tail_refusals))
  (func (export "get_block_exec_tail_admitted") (result i64)
    (global.get $bx_rg_tail_admitted))
  (func (export "get_block_exec_tail_regions") (result i32)
    (global.get $bx_rg_tail_regions))
  (func (export "get_block_exec_tail_members") (result i32)
    (global.get $bx_rg_tail_members))
  (func (export "get_block_exec_tail_norm") (result i32)
    (global.get $bx_rg_tail_norm))
  (func (export "get_bx_pass_rmw") (result i64) (global.get $bx_pass_rmw))
  (func (export "get_block_exec_installs") (result i32)
    (global.get $block_exec_installs))
  (func (export "get_block_exec_declines") (result i32)
    (global.get $block_exec_declines))
  (func (export "get_block_exec_runs") (result i32) (global.get $block_exec_runs))
  ;; The migration meter. native/(native+fallback) is the share of retired ops
  ;; the executor served in-loop; the rest went out to a real handler through
  ;; the spill/call/reload path, and $..._last_fallback_fn names the family to
  ;; widen next.
  (func (export "get_block_exec_native_ops") (result i64)
    (global.get $block_exec_native_ops))
  (func (export "get_block_exec_fallback_ops") (result i64)
    (global.get $block_exec_fallback_ops))
  (func (export "get_block_exec_last_fallback_fn") (result i32)
    (global.get $block_exec_last_fallback_fn))
  (func (export "get_block_exec_decl_why") (result i32)
    (global.get $block_exec_decl_why))
  ;; Interior block edges the executor did not have to take. With the run count
  ;; and the two op totals this is everything a ns/entry-vs-ns/op fit needs, and
  ;; it is the one term nothing else records -- a folded edge is invisible to
  ;; the handler histogram and to $block_budget alike.
  (func (export "get_block_exec_transfers_saved") (result i64)
    (global.get $block_exec_transfers_saved))

  ;; The multi-block matcher (src/07c-block-exec.wat section "THE MULTI-BLOCK
  ;; MATCHER"). It rides on --block-exec; this setter exists so an A/B can
  ;; turn just the N-block half off and leave the one-block executor armed,
  ;; which is the only way to attribute a change to one of the two.
  (func (export "set_block_exec_regions") (param $flag i32)
    (global.set $bx_region_enabled (local.get $flag))
    (call $bx_hot_gate_refresh))
  (func (export "get_block_exec_regions") (result i32)
    (global.get $bx_region_enabled))
  ;; Discovery knobs (round 10). K entries before a head is walked, blocks one
  ;; walk may visit, declines before a head is memoised out. All three are
  ;; A/B levers, not tuning taste: the round-9 loss was decode-time discovery
  ;; cost, so the arm that prices it has to be able to move it.
  (func (export "set_block_exec_walk_k") (param $n i32)
    (global.set $bx_walk_hot_k (local.get $n)))
  (func (export "set_block_exec_walk_budget") (param $n i32)
    (global.set $bx_walk_budget (local.get $n)))
  (func (export "get_block_exec_walk_attempts") (result i32)
    (global.get $bx_walk_attempts))
  (func (export "get_block_exec_walk_installs") (result i32)
    (global.get $bx_walk_installs))
  ;; The discovery COST, in the two units the design doc reports it in: blocks
  ;; visited (each one a $decode_block) and micro-ops classified.
  (func (export "get_block_exec_walk_blocks") (result i64)
    (global.get $bx_walk_blocks))
  (func (export "get_block_exec_walk_uops") (result i64)
    (global.get $bx_walk_uops))
  (func (export "get_block_exec_walk_memo") (result i32)
    (global.get $bx_walk_memo_refusals))
  (func (export "get_block_exec_walk_probes") (result i32)
    (global.get $bx_walk_hot_probes))
  ;; Walks that failed and hinted a lower head to the gate instead. A high
  ;; number against few installs means discovery keeps arriving at loops from
  ;; the bottom.
  (func (export "get_block_exec_walk_reanchors") (result i32)
    (global.get $bx_walk_reanchors))
  (func (export "get_block_exec_region_installs") (result i32)
    (global.get $bx_region_installs))
  (func (export "get_block_exec_region_declines") (result i32)
    (global.get $bx_region_declines))
  ;; Sum of member blocks over every installed region; divided by the install
  ;; count it is the mean region size, and the histogram below is its shape.
  (func (export "get_block_exec_region_blocks") (result i32)
    (global.get $bx_region_blocks))
  (func (export "get_block_exec_region_why") (result i32)
    (global.get $bx_region_why))
  (func (export "get_block_exec_region_thrash") (result i32)
    (global.get $bx_region_thrash))
  ;; Classify refusals by reason, 1 <= $r <= 8. See $bx_rg_nofit.
  (func (export "get_block_exec_region_nofit") (param $r i32) (result i32)
    (if (i32.gt_u (local.get $r) (i32.const 8))
      (then (return (i32.const 0))))
    (i32.load (call $bx_rg_word
      (i32.add (global.get $BX_RG_NOFIT_OFF) (local.get $r)))))
  ;; Collect refusals: 0..3 = notContiguous/blockCap/poison/classify with an
  ;; empty chain, 4..7 = the same four with members already collected.
  (func (export "get_block_exec_region_cfail") (param $s i32) (result i32)
    (if (i32.gt_u (local.get $s) (i32.const 7))
      (then (return (i32.const 0))))
    (i32.load (call $bx_rg_word
      (i32.add (global.get $BX_RG_CFAIL_OFF) (local.get $s)))))
  ;; How many region candidates were declined for reason $w, 1 <= w <= 7.
  ;; See $bx_rg_decline for what each number means.
  (func (export "get_block_exec_region_why_n") (param $w i32) (result i32)
    (if (i32.gt_u (local.get $w) (i32.const 7))
      (then (return (i32.const 0))))
    (i32.load (call $bx_rg_word
      (i32.add (global.get $BX_RG_WHY_OFF) (local.get $w)))))
  ;; How many regions of exactly $n blocks were installed, 0 <= n <= 16.
  (func (export "get_block_exec_region_hist") (param $n i32) (result i32)
    (if (i32.gt_u (local.get $n) (global.get $REGION_MAX_BLOCKS))
      (then (return (i32.const 0))))
    (i32.load (call $bx_rg_word
      (i32.add (global.get $BX_RG_HIST_OFF) (local.get $n)))))
  ;; Coverage by size: micro-ops retired inside, and entries into, a descriptor
  ;; of exactly $n blocks. $n == 1 is the plain-block case, so the two together
  ;; are the "ops in 1-block vs N-block regions" split.
  (func (export "get_block_exec_ops_by_n") (param $n i32) (result i64)
    (if (i32.gt_u (local.get $n) (global.get $REGION_MAX_BLOCKS))
      (then (return (i64.const 0))))
    (i64.load (call $bx_rg_word
      (i32.add (global.get $BX_RG_OPSN_OFF) (i32.shl (local.get $n) (i32.const 1))))))
  (func (export "get_block_exec_entries_by_n") (param $n i32) (result i32)
    (if (i32.gt_u (local.get $n) (global.get $REGION_MAX_BLOCKS))
      (then (return (i32.const 0))))
    (i32.load (call $bx_rg_word
      (i32.add (global.get $BX_RG_ENTN_OFF) (local.get $n)))))

  (func (export "set_region_fold") (param $flag i32)
    (global.set $region_fold_enabled (local.get $flag)))
  (func (export "get_region_fold") (result i32) (global.get $region_fold_enabled))
  ;; $ptr is a GUEST address -- the descriptor words are read through $gl32, so
  ;; the harness writes them the same way it writes the guest code beside them.
  (func (export "set_region_spec") (param $eip i32) (param $ptr i32) (param $words i32)
    (global.set $region_spec_eip (local.get $eip))
    (global.set $region_spec_ptr (local.get $ptr))
    (global.set $region_spec_words (local.get $words)))
  (func (export "get_region_installs") (result i32) (global.get $region_installs))

  ;; Page compilation (docs/page-compile-design.md). There is deliberately no
  ;; switch: this replaces the storage layer rather than accelerating it, so the
  ;; thing to compare against is the commit before it, not a flag.
  (func (export "get_page_compiles") (result i32) (global.get $page_compiles))
  (func (export "get_page_chunk_samples") (result i32) (global.get $page_chunk_samples))
  (func (export "get_page_chunk_used_total") (result i64) (global.get $page_chunk_used_total))
  (func (export "get_page_chunk_used_max") (result i32) (global.get $page_chunk_used_max))
  (func (export "get_page_chunk_le_4k") (result i32) (global.get $page_chunk_le_4k))
  (func (export "get_page_chunk_le_8k") (result i32) (global.get $page_chunk_le_8k))
  (func (export "get_page_chunk_le_12k") (result i32) (global.get $page_chunk_le_12k))
  (func (export "get_page_chunk_le_16k") (result i32) (global.get $page_chunk_le_16k))
  (func (export "get_page_chunk_grows") (result i32) (global.get $page_chunk_grows))
  (func (export "get_page_chunk_reuses") (result i32) (global.get $page_chunk_reuses))
  (func (export "get_page_unpublished") (result i32) (global.get $page_unpublished))
  (func (export "get_page_hits")     (result i32) (global.get $page_hits))
  (func (export "get_page_misses")   (result i32) (global.get $page_misses))
  (func (export "get_page_fast")     (result i32) (global.get $page_fast))
  (func (export "get_page_ft")       (result i32) (global.get $page_ft))
  (func (export "get_page_ft_missed")(result i32) (global.get $page_ft_missed))
  (func (export "get_page_retires")  (result i32) (global.get $page_retires))
  (func (export "get_page_range_drops")(result i32) (global.get $page_range_drops))
  ;; Round 14 (docs/block-executor-design.md section 23): the SECOND per-page
  ;; chunk, the one executor descriptors live in. `full` is the count that
  ;; matters -- it is a publish that DECLINED because the descriptor chunk was
  ;; out of room, where round 13's equivalent dropped the whole page.
  (func (export "get_page_desc_chunk_allocs")(result i32) (global.get $page_desc_chunk_allocs))
  (func (export "get_page_desc_chunk_grows") (result i32) (global.get $page_desc_chunk_grows))
  (func (export "get_page_desc_chunk_full")  (result i32) (global.get $page_desc_chunk_full))
  ;; Round 17, section 27.2: the one-block family's headroom reserve inside the
  ;; per-page DESCRIPTOR chunk, and the count of one-block installs it declined
  ;; that the bare chunk would have taken. 0 is round 16's behaviour.
  (func (export "set_page_desc_rg_reserve") (param $n i32)
    (global.set $page_desc_rg_reserve (local.get $n)))
  (func (export "get_page_desc_rg_reserve") (result i32)
    (global.get $page_desc_rg_reserve))
  (func (export "get_page_desc_reserve_declines") (result i32)
    (global.get $page_desc_reserve_declines))
  (func (export "get_block_exec_no_room")    (result i32) (global.get $bx_no_room))
  ;; Round 16 (section 26). Discovery's view of the one-block family: how many
  ;; successors a walk could not read back, how many descriptors it had to take
  ;; back for want of a displaced-stream copy, and how many installs published
  ;; WITHOUT that copy in the first place -- which is what makes the previous
  ;; two happen.
  (func (export "get_block_exec_walk_uncached") (result i32)
    (global.get $bx_walk_uncached))
  (func (export "get_block_exec_raw_wants") (result i32) (global.get $bx_raw_wants))
  (func (export "get_block_exec_desc_nocopy") (result i32) (global.get $bx_desc_nocopy))
  (func (export "get_block_exec_rg_nocopy") (result i32) (global.get $bx_rg_nocopy))
  ;; Round 16: regions installed carrying at least one x87 member micro-op, and
  ;; the region classifier's own x87 split.
  (func (export "get_block_exec_rg_x87_regions") (result i32)
    (global.get $bx_rg_x87_regions))
  (func (export "get_block_exec_rg_x87run") (result i64) (global.get $bx_rg_x87run_uops))
  (func (export "get_block_exec_rg_x87_native") (result i64)
    (global.get $bx_rg_x87_native_uops))
  (func (export "get_block_exec_rg_x87_fb") (result i64) (global.get $bx_rg_x87_fb_uops))
  ;; Round 16: decline reason 3, split by site, plus the two measures of the
  ;; seam between the families -- walks that arrived at a head the one-block
  ;; installer already owned, and heads the memo permanently locked out.
  (func (export "set_block_exec_x87_regions") (param $f i32)
    (global.set $block_exec_x87_regions (local.get $f)))
  (func (export "get_block_exec_x87_regions") (result i32)
    (global.get $block_exec_x87_regions))
  (func (export "get_block_exec_rg_nr_bytes") (result i32) (global.get $bx_rg_nr_bytes))
  (func (export "get_block_exec_rg_nr_arena") (result i32) (global.get $bx_rg_nr_arena))
  (func (export "get_block_exec_rg_nr_fit")   (result i32) (global.get $bx_rg_nr_fit))
  (func (export "get_block_exec_rg_head_desc") (result i32) (global.get $bx_rg_head_desc))
  (func (export "get_block_exec_rg_head_desc_fail") (result i32)
    (global.get $bx_rg_head_desc_fail))
  (func (export "get_block_exec_memo_locked") (result i32) (global.get $bx_memo_locked))
  (func (export "get_page_ft_chains")(result i32) (global.get $page_ft_chains))
  (func (export "get_page_ft_blocks")(result i32) (global.get $page_ft_blocks))

  ;; Threaded-handler histogram. Profiling tools enable this only around a
  ;; measured window. Counts are stored in WAT-private memory and read by JS.
  (func (export "set_handler_hist_enabled") (param $flag i32)
    (global.set $handler_hist_enabled (local.get $flag))
    (global.set $branch_hist_kind (i32.const 0))
    (if (local.get $flag)
      (then (global.set $handler_hist_last (i32.const -1))))
    (call $dbg_recompute))
  ;; Seven whole-region zero fills. Each region is page-sized, so the dword
  ;; loops these replace covered exactly the same bytes.
  (func (export "reset_handler_hist")
    (memory.fill (global.get $HANDLER_HIST_COUNTS) (i32.const 0)
      (global.get $HANDLER_HIST_COUNTS_SIZE))
    (memory.fill (global.get $HANDLER_PAIR_HIST_COUNTS) (i32.const 0)
      (global.get $HANDLER_PAIR_HIST_COUNTS_SIZE))
    (memory.fill (global.get $BRANCH_CMP_JCC_HIST) (i32.const 0)
      (global.get $BRANCH_CMP_JCC_HIST_SIZE))
    (memory.fill (global.get $BRANCH_TEST_JCC_HIST) (i32.const 0)
      (global.get $BRANCH_TEST_JCC_HIST_SIZE))
    (memory.fill (global.get $BRANCH_ALU_M32_RO_JCC_HIST) (i32.const 0)
      (global.get $BRANCH_ALU_M32_RO_JCC_HIST_SIZE))
    (memory.fill (global.get $HOT_BLOCK_HIST) (i32.const 0)
      (global.get $HOT_BLOCK_HIST_SIZE))
    (memory.fill (global.get $SIB_CONSUMER_HIST) (i32.const 0)
      (global.get $SIB_CONSUMER_HIST_SIZE))
    (global.set $branch_hist_kind (i32.const 0))
    (global.set $hot_block_hist_collisions (i32.const 0))
    ;; (the edge records live in the pair matrix, zeroed above)
    (global.set $edge_hist_prev (i32.const 0))
    (global.set $edge_hist_collisions (i32.const 0))
    (global.set $sib_consumer_hist_collisions (i32.const 0))
    (global.set $sib_consumer_hist_total (i32.const 0))
    (global.set $handler_hist_last (i32.const -1)))
  (func (export "get_handler_hist_base") (result i32) (global.get $HANDLER_HIST_COUNTS))
  (func (export "get_handler_pair_hist_base") (result i32) (global.get $HANDLER_PAIR_HIST_COUNTS))
  (func (export "get_handler_hist_count") (result i32) (global.get $HANDLER_HIST_COUNT))
  ;; How many per-handler counters HANDLER_HIST_COUNTS actually holds. This is
  ;; NOT get_handler_hist_count: that one is the side of the dense pair matrix,
  ;; frozen at 361 because the matrix is 361x361. Every handler above it is
  ;; still counted individually, so a reader that sizes its per-handler loop
  ;; with the pair bound silently omits the fused superinstructions -- and
  ;; reports a total that shrinks by construction every time one lands.
  (func (export "get_handler_hist_slots") (result i32)
    (i32.shr_u (global.get $HANDLER_HIST_COUNTS_SIZE) (i32.const 2)))
  (func (export "get_branch_cmp_jcc_hist_base") (result i32) (global.get $BRANCH_CMP_JCC_HIST))
  (func (export "get_branch_test_jcc_hist_base") (result i32) (global.get $BRANCH_TEST_JCC_HIST))
  (func (export "get_branch_alu_m32_ro_jcc_hist_base") (result i32) (global.get $BRANCH_ALU_M32_RO_JCC_HIST))
  (func (export "get_hot_block_hist_base") (result i32) (global.get $HOT_BLOCK_HIST))
  (func (export "get_hot_block_hist_count") (result i32) (global.get $HOT_BLOCK_HIST_COUNT))
  (func (export "get_hot_block_hist_collisions") (result i32) (global.get $hot_block_hist_collisions))
  ;; --edge-hist: 65536 {from,to,count,pad} records in the borrowed pair
  ;; matrix (see $edge_hist_record). Arm it before reset_handler_hist.
  (func (export "set_edge_hist") (param $on i32) (global.set $edge_hist_enabled (local.get $on)))
  (func (export "get_edge_hist_base") (result i32) (global.get $HANDLER_PAIR_HIST_COUNTS))
  (func (export "get_edge_hist_count") (result i32)
    (i32.shr_u (global.get $HANDLER_PAIR_HIST_COUNTS_SIZE) (i32.const 4)))
  (func (export "get_edge_hist_collisions") (result i32) (global.get $edge_hist_collisions))
  (func (export "get_sib_consumer_hist_base") (result i32) (global.get $SIB_CONSUMER_HIST))
  (func (export "get_sib_consumer_hist_count") (result i32) (global.get $SIB_CONSUMER_HIST_COUNT))
  (func (export "get_sib_consumer_hist_collisions") (result i32) (global.get $sib_consumer_hist_collisions))
  (func (export "get_sib_consumer_hist_total") (result i32) (global.get $sib_consumer_hist_total))

  ;; Size-aware load for watchpoint. $watch_size: 1=byte, 2=word, anything else=dword.
  (func $watch_load (param $addr i32) (result i32)
    (if (result i32) (i32.eq (global.get $watch_size) (i32.const 1))
      (then (call $gl8 (local.get $addr)))
      (else (if (result i32) (i32.eq (global.get $watch_size) (i32.const 2))
        (then (call $gl16 (local.get $addr)))
        (else (call $gl32 (local.get $addr)))))))
  (func (export "set_watchpoint") (param $addr i32)
    (global.set $watch_addr (local.get $addr))
    (if (local.get $addr)
      (then (global.set $watch_val (call $watch_load (local.get $addr))))
      (else (global.set $watch_val (i32.const 0))))
    (call $dbg_recompute))
  (func (export "set_watchpoint_size") (param $size i32)
    (global.set $watch_size (local.get $size))
    ;; re-read current value with new size so caller sees consistent baseline
    (if (global.get $watch_addr)
      (then (global.set $watch_val (call $watch_load (global.get $watch_addr))))))
  (func (export "get_watch_val") (result i32) (global.get $watch_val))
  (func (export "get_watch_addr") (result i32) (global.get $watch_addr))
  (func (export "get_watch_size") (result i32) (global.get $watch_size))

  ;; --- Shadow call-stack (--trace-callstack) ---
  (func (export "set_callstack_enabled") (param $on i32) (global.set $cs_enabled (local.get $on)) (call $dbg_recompute))
  (func (export "get_callstack_depth") (result i32) (global.get $cs_depth))
  ;; entry i=0 → most recent ret_addr, i=1 → caller's, etc. up to 64 entries.
  (func (export "get_callstack_entry") (param $i i32) (result i32)
    (local $idx i32)
    (if (i32.ge_u (local.get $i) (i32.const 64)) (then (return (i32.const 0))))
    (if (i32.ge_u (local.get $i) (global.get $cs_depth)) (then (return (i32.const 0))))
    (local.set $idx (i32.and (i32.sub (i32.sub (global.get $cs_depth) (i32.const 1)) (local.get $i)) (global.get $CS_MASK)))
    (i32.load (i32.add (global.get $CS_RING) (i32.shl (local.get $idx) (i32.const 2)))))

  ;; call_func(addr, arg0, arg1, arg2, arg3): push args right-to-left + halt
  ;; return addr, set EIP, then caller uses run() to execute. Result in EAX.
  (func (export "call_func") (param $addr i32) (param $a0 i32) (param $a1 i32) (param $a2 i32) (param $a3 i32)
    ;; Push args right-to-left (stdcall/cdecl convention)
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $a3))
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $a2))
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $a1))
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $a0))
    ;; Push return address = 0 (will halt when RET tries to jump to 0)
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (i32.const 0))
    ;; Set EIP to function address
    (global.set $eip (local.get $addr))
  )

  ;; fire_mm_timer: check if multimedia timer is due, inject callback if so.
  ;; Saves current EIP as return address so execution resumes after callback returns.
  ;; Returns 1 if timer was fired, 0 if not due or no timer active.
  (func (export "is_mm_timer_callback_active") (result i32)
    (global.get $mm_timer_in_cb))

  ;; Milliseconds until the next multimedia timer is due (0 = due now, -1 =
  ;; none, or the winmm timer thread serves them so the host need not).
  (func (export "mm_timer_ms_until_due") (result i32)
    (if (call $mm_timer_thread_owned) (then (return (i32.const -1))))
    (call $mm_timer_ms_until_due))
  ;; 1 = run timeSetEvent callbacks on a winmm timer guest thread, started by
  ;; the first timeSetEvent. Process-wide; set before the guest runs.
  (func (export "set_mm_timer_thread_mode") (param $mode i32)
    (i32.store (global.get $MM_TIMER_THREAD) (local.get $mode)))
  (func (export "get_mm_timer_thread") (result i32)
    (i32.atomic.load offset=4 (global.get $MM_TIMER_THREAD)))
  ;; 1 = guest threads run concurrently (Worker backend): decode LOCK-prefixed
  ;; RMW and memory XCHG as atomic compare-and-swap (handler 499). 0 keeps the
  ;; cooperative encoding. Process-wide; set before the guest runs, since a
  ;; block decoded earlier keeps the encoding it was decoded with.
  (func (export "set_lock_atomic_mode") (param $mode i32)
    (i32.atomic.store (global.get $LOCK_MODE) (local.get $mode)))
  (func (export "get_lock_atomic_mode") (result i32)
    (i32.atomic.load (global.get $LOCK_MODE)))

  (func $fire_mm_timer (export "fire_mm_timer") (result i32)
    (local $slot i32) (local $id i32) (local $dwuser i32) (local $cb i32)
    ;; Most yielded APIs cannot be interrupted. A plain object wait is the one
    ;; exception: timeSetEvent runs on a system thread on Win32 and is commonly
    ;; used specifically to signal the object the application is waiting on.
    (if (i32.and (global.get $yield_reason)
          (i32.ne (global.get $yield_reason) (i32.const 1)))
      (then (return (i32.const 0))))
    ;; The CACA000A callback-return continuation clears this flag exactly when
    ;; the guest callback returns. Do not infer that event from later ESP: the
    ;; interrupted code may already have entered a deeper call by this poll.
    (if (global.get $mm_timer_in_cb)
      (then (return (i32.const 0))))
    ;; The winmm timer thread runs the callbacks itself.
    (if (call $mm_timer_thread_owned) (then (return (i32.const 0))))
    (call $mm_callback_begin
      (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 40)) (i32.const 0))
    (local.set $slot (call $mm_timer_due_slot))
    (if (i32.eqz (local.get $slot)) (then (call $mm_callback_cancel) (return (i32.const 0))))
    (local.set $id (i32.load (local.get $slot)))
    (local.set $dwuser (i32.load offset=12 (local.get $slot)))
    (local.set $cb (i32.load offset=8 (local.get $slot)))
    ;; Timer is due — consume through the latest interval boundary without
    ;; turning host scheduling lateness into permanent periodic-timer drift,
    ;; retiring the slot first if it was a one-shot.
    (call $mm_timer_consume_slot (local.get $slot))
    (global.set $mm_timer_resume_yield (global.get $yield_reason))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (global.set $mm_timer_in_cb (i32.const 1))
    ;; Save caller-saved regs + flags (40 bytes, includes EIP and saved_cf for restore)
    (call $save_caller_regs)
    ;; Push 5 args: dw2=0, dw1=0, dwUser, uMsg=0, uTimerID
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (i32.const 0))                   ;; dw2
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (i32.const 0))                   ;; dw1
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $dwuser))             ;; dwUser
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (i32.const 0))                   ;; uMsg
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $id))                 ;; uTimerID
    ;; Push return address = CACA000A thunk (restores regs when callback returns)
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (global.get $mm_timer_ret_thunk))
    ;; Redirect EIP to callback
    (global.set $eip (local.get $cb))
    (i32.const 1))

  ;; Deliver one completed waveOut buffer to a CALLBACK_FUNCTION client.
  ;; The host queues WOM_DONE notifications until a slice boundary, then calls
  ;; this export. Reuse the multimedia-timer continuation because it already
  ;; saves/restores the interrupted x86 caller state and rejects nested async
  ;; callbacks. waveOutProc(hwo, WOM_DONE, instance, waveHdr, 0) is stdcall.
  ;; Owner-authenticated host delivery supplies the immutable registration.
  ;; It must never resolve a queued old completion through WAVE_OUT_SHARED.
  (func $fire_wave_out_callback_bound (export "fire_wave_out_callback_bound")
      (param $handle i32) (param $wave_hdr i32)
      (param $cb i32) (param $instance i32) (result i32)
    (call $fire_audio_callback_bound (local.get $handle) (local.get $wave_hdr)
      (local.get $cb) (local.get $instance) (i32.const 0x03BD)))

  ;; Cooperative MIDI delivery uses the same guarded continuation and
  ;; invocation-owned save_caller_regs frame, with an explicit MIDI message.
  (func $fire_midi_out_callback_bound (export "fire_midi_out_callback_bound")
      (param $handle i32) (param $hdr i32) (param $cb i32)
      (param $instance i32) (param $message i32) (result i32)
    (call $fire_audio_callback_bound (local.get $handle) (local.get $hdr)
      (local.get $cb) (local.get $instance) (local.get $message)))

  (func $fire_audio_callback_bound
      (param $handle i32) (param $wave_hdr i32)
      (param $cb i32) (param $instance i32) (param $message i32) (result i32)
    (if (i32.or (i32.eqz (local.get $cb))
          (i32.or (i32.eqz (global.get $eip))
            (i32.eqz (i32.load offset=16 (global.get $reg_base)))))
      (then (return (i32.const 0))))
    (if (i32.and (i32.ne (global.get $yield_reason) (i32.const 0))
          (i32.ne (global.get $yield_reason) (i32.const 1)))
      (then (return (i32.const 0))))
    (if (i32.or (global.get $mm_timer_in_cb) (global.get $wave_callback_saved))
      (then (return (i32.const 0))))
    (call $mm_callback_begin
      (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 40)) (i32.const 1))
    (global.set $wave_callback_saved_wait_handle (global.get $wait_handle))
    (global.set $wave_callback_saved_wait_handles_ptr (global.get $wait_handles_ptr))
    (global.set $wave_callback_saved_wait_all (global.get $wait_all))
    (global.set $wave_callback_saved_wait_timeout (global.get $wait_timeout))
    (global.set $wave_callback_saved_wait_stack_bytes (global.get $wait_stack_bytes))
    (global.set $wave_callback_saved_yield_reason (global.get $yield_reason))
    (global.set $wave_callback_saved_yield_flag (global.get $yield_flag))
    (global.set $wave_callback_saved (i32.const 1))
    (global.set $yield_reason (i32.const 0))
    (global.set $yield_flag (i32.const 0))
    (global.set $mm_timer_in_cb (i32.const 1))
    (call $save_caller_regs)
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (i32.const 0))                    ;; dwParam2
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $wave_hdr))            ;; dwParam1
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $instance))            ;; dwInstance
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $message))
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (local.get $handle))              ;; hwo
    (i32.store offset=16 (global.get $reg_base) (i32.sub (i32.load offset=16 (global.get $reg_base)) (i32.const 4)))
    (call $gs32 (i32.load offset=16 (global.get $reg_base)) (global.get $mm_timer_ret_thunk))
    (global.set $eip (local.get $cb))
    (i32.const 1))

  ;; Existing cooperative entry retains its public signature.
  (func (export "fire_wave_out_callback")
      (param $handle i32) (param $wave_hdr i32) (result i32)
    (if (i32.ne (i32.load (region.addr $WAVE_OUT_SHARED 12)) (i32.const 3))
      (then (return (i32.const 0))))
    (call $fire_wave_out_callback_bound (local.get $handle) (local.get $wave_hdr)
      (i32.load (region.addr $WAVE_OUT_SHARED 4))
      (i32.load (region.addr $WAVE_OUT_SHARED 8))))

  (func $wave_callback_restore_wait
    (if (i32.eqz (global.get $wave_callback_saved)) (then (return)))
    (global.set $wait_handle (global.get $wave_callback_saved_wait_handle))
    (global.set $wait_handles_ptr (global.get $wave_callback_saved_wait_handles_ptr))
    (global.set $wait_all (global.get $wave_callback_saved_wait_all))
    (global.set $wait_timeout (global.get $wave_callback_saved_wait_timeout))
    (global.set $wait_stack_bytes (global.get $wave_callback_saved_wait_stack_bytes))
    (global.set $yield_reason (global.get $wave_callback_saved_yield_reason))
    (global.set $yield_flag (global.get $wave_callback_saved_yield_flag))
    (global.set $wave_callback_saved (i32.const 0))
    ;; This continuation belongs to waveOut, not a multimedia timer. A stale
    ;; timer resume value must not overwrite the exact restored wave wait.
    (global.set $mm_timer_resume_yield (i32.const 0))
    (if (global.get $yield_reason) (then (global.set $steps (i32.const 0)))))

  ;; A host-side writer that fills guest memory directly (ReadFile into the
  ;; guest's buffer, a mapped view, a decompressed resource) bypasses every
  ;; store handler, so nothing retires the decoded blocks it just overwrote.
  ;; Storm keeps its generated code and its file buffers in the same heap
  ;; region, so that is a real collision, not a theoretical one.
  ;; The host calls this AFTER it wrote guest bytes (a ReadFile served for a
  ;; guest Worker). Translating here must not materialize a lazily synced
  ;; D3DIM surface: the page's shadow instance has no executor (it trapped
  ;; in $d3dim_lazy_materialize -- Drakan, Threads on), and a readback now
  ;; would overwrite the bytes just written anyway.
  (func (export "invalidate_code_range") (param $ga i32) (param $len i32)
    (local $bypass i32)
    (local.set $bypass (global.get $d3dim_lazy_bypass))
    (global.set $d3dim_lazy_bypass (i32.const 1))
    (call $page_watch_write_guest (local.get $ga) (local.get $len))
    (call $invalidate_code_range (local.get $ga) (local.get $len))
    (global.set $d3dim_lazy_bypass (local.get $bypass)))

  ;; Write guest memory (guest addr)
  (func (export "guest_write32") (param $ga i32) (param $val i32)
    (call $gs32 (local.get $ga) (local.get $val)))
  (func (export "guest_read32") (param $ga i32) (result i32)
    (call $gl32 (local.get $ga)))

  (func (export "guest_write8") (param $ga i32) (param $val i32)
    (call $gs8 (local.get $ga) (local.get $val)))
  (func (export "guest_read8") (param $ga i32) (result i32)
    (call $gl8 (local.get $ga)))

  ;; Decoded-code arena bounds and the spill slot, exercised by
  ;; test/test-thread-arena-spill.js. $k: 0 thread_alloc, 1 THREAD_END,
  ;; 2 THREAD_BASE, 3 spill_active, 4 spill_base, 5 spill_end,
  ;; 6 thread_flush_pending, 7 spill_enters, 8 spill_recycles, 9 spill_pins,
  ;; 10 sync_msg_depth, 11 dbg_chain_guard.
  (func (export "test_arena_get") (param $k i32) (result i32)
    (if (i32.eq (local.get $k) (i32.const 11)) (then (return (global.get $dbg_chain_guard))))
    (if (i32.eq (local.get $k) (i32.const 8)) (then (return (global.get $spill_recycles))))
    (if (i32.eq (local.get $k) (i32.const 9)) (then (return (global.get $spill_pins))))
    (if (i32.eq (local.get $k) (i32.const 10)) (then (return (global.get $sync_msg_depth))))
    (if (i32.eqz (local.get $k)) (then (return (global.get $thread_alloc))))
    (if (i32.eq (local.get $k) (i32.const 1)) (then (return (global.get $THREAD_END))))
    (if (i32.eq (local.get $k) (i32.const 2)) (then (return (global.get $THREAD_BASE))))
    (if (i32.eq (local.get $k) (i32.const 3)) (then (return (global.get $spill_active))))
    (if (i32.eq (local.get $k) (i32.const 4)) (then (return (global.get $spill_base))))
    (if (i32.eq (local.get $k) (i32.const 5)) (then (return (global.get $spill_end))))
    (if (i32.eq (local.get $k) (i32.const 6)) (then (return (global.get $thread_flush_pending))))
    (global.get $spill_enters))
  (func (export "test_arena_set_alloc") (param $v i32) (global.set $thread_alloc (local.get $v)))
  (func (export "test_arena_set_depth") (param $v i32) (global.set $sync_msg_depth (local.get $v)))
  (func (export "test_arena_set_ip") (param $v i32) (global.set $ip (local.get $v)))
  (func (export "test_arena_depth_enter") (call $sync_depth_enter))
  (func (export "test_arena_depth_leave") (call $sync_depth_leave))
  (func (export "test_arena_reserve") (call $decode_reserve_headroom))
  (func (export "test_arena_emit") (param $v i32) (call $te_raw (local.get $v)))
  (func (export "test_arena_flush") (result i32) (call $thread_arena_flush_if_safe))

  ;; FormatMessage insert expansion, exercised by
  ;; test/test-format-message-inserts.js. All three addresses are guest
  ;; addresses; $dst_g == 0 is the measure-only mode the real handler uses to
  ;; size an ALLOCATE_BUFFER allocation before writing into it.
  (func (export "test_format_message_ansi")
      (param $flags i32) (param $fmt_g i32) (param $source i32) (param $msg_id i32)
      (param $args_g i32) (param $dst_g i32) (param $max i32) (result i32)
    (call $format_message_ansi
      (local.get $flags)
      (select (i32.const 0) (call $g2w (local.get $fmt_g)) (i32.eqz (local.get $fmt_g)))
      (local.get $source) (local.get $msg_id) (local.get $args_g)
      (select (i32.const 0) (call $g2w (local.get $dst_g)) (i32.eqz (local.get $dst_g)))
      (local.get $max)))

  ;; FormatMessage's Arguments resolution (va_list* vs ARGUMENT_ARRAY).
  (func (export "test_format_message_args") (param $flags i32) (param $arguments i32) (result i32)
    (call $format_message_args (local.get $flags) (local.get $arguments)))

  (func (export "test_format_message_expand")
      (param $src_g i32) (param $dst_g i32) (param $max i32) (param $args_g i32) (result i32)
    (call $format_message_expand
      (call $g2w (local.get $src_g))
      (select (i32.const 0) (call $g2w (local.get $dst_g)) (i32.eqz (local.get $dst_g)))
      (local.get $max) (local.get $args_g)))

  ;; A section owns one stable reservation; views commit subranges without
  ;; allocating backing for the whole file. Only the main host uses these
  ;; exports. Keep reservation publication atomic against guest VirtualAlloc.
  (func (export "guest_section_reserve") (param $requested i32) (result i32)
    (local $size i32) (local $guest i32)
    (if (i32.or (i32.eqz (local.get $requested))
          (i32.gt_u (local.get $requested) (i32.const 0xFFFFF000)))
      (then (return (i32.const 0))))
    (local.set $size (i32.and (i32.add (local.get $requested) (i32.const 4095))
      (i32.const -4096)))
    (call $lock_acquire (global.get $LOCK_VIRTUAL_MAP))
    (if (i32.or
          (i32.ge_u (i32.load (global.get $MAPPED_VIEW_TABLE)) (global.get $MAX_MAPPED_VIEWS))
          (i32.ge_u (i32.load offset=16 (global.get $VIRTUAL_MAP_STATE))
            (global.get $MAX_VIRTUAL_RESERVES)))
      (then
        (call $lock_release (global.get $LOCK_VIRTUAL_MAP))
        (return (i32.const 0))))
    (local.set $guest (call $virtual_reserve_down (local.get $size)))
    (if (local.get $guest)
      (then
        ;; Native Win98 section reservations report PAGE_NOACCESS even after
        ;; individual pages acquire READONLY/READWRITE view protection.
        (call $virtual_reserve_record (local.get $guest) (local.get $size) (i32.const 1))
        (call $mapped_view_register (local.get $guest) (local.get $size))))
    (call $lock_release (global.get $LOCK_VIRTUAL_MAP))
    (local.get $guest))

  (func $host_mapped_range_size (param $guest i32) (result i32)
    (local $i i32) (local $slot i32)
    (local.set $i (i32.const 1))
    (block $done (loop $scan
      (br_if $done (i32.gt_u (local.get $i) (i32.load (global.get $MAPPED_VIEW_TABLE))))
      (local.set $slot (call $mapped_view_slot (local.get $i)))
      (if (i32.eq (i32.load (local.get $slot)) (local.get $guest))
        (then (return (i32.load offset=4 (local.get $slot)))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (i32.const 0))

  ;; Commit holes only. The general commit helper handles forward extension,
  ;; but a request enclosing an already committed island would otherwise
  ;; publish overlapping records and shadow bytes written through an older view.
  (func $host_section_commit_range
      (param $guest i32) (param $size i32) (param $protect i32) (result i32)
    (local $cursor i32) (local $end i32) (local $next i32)
    (local $i i32) (local $rec i32) (local $base i32) (local $limit i32)
    (local $covered i32)
    (if (call $virtual_map_lease_mutation_busy (local.get $guest) (local.get $size))
      (then (return (i32.const 0))))
    (local.set $cursor (local.get $guest))
    (local.set $end (i32.add (local.get $guest) (local.get $size)))
    (block $done (loop $ranges
      (br_if $done (i32.ge_u (local.get $cursor) (local.get $end)))
      (local.set $next (local.get $end))
      (local.set $covered (i32.const 0))
      (local.set $i (i32.const 0))
      (block $scanned (loop $scan
        (br_if $scanned (i32.ge_u (local.get $i) (i32.load (global.get $VIRTUAL_MAP_STATE))))
        (local.set $rec (i32.add (global.get $VIRTUAL_MAP_TABLE)
          (i32.shl (local.get $i) (i32.const 4))))
        (local.set $base (i32.load (local.get $rec)))
        (local.set $limit (i32.add (local.get $base) (i32.load offset=4 (local.get $rec))))
        (if (i32.and (i32.le_u (local.get $base) (local.get $cursor))
              (i32.gt_u (local.get $limit) (local.get $cursor)))
          (then
            (local.set $covered (i32.const 1))
            (local.set $next (local.get $limit))
            (br $scanned)))
        (if (i32.and (i32.gt_u (local.get $base) (local.get $cursor))
              (i32.lt_u (local.get $base) (local.get $next)))
          (then (local.set $next (local.get $base))))
        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $scan)))
      (if (i32.eqz (local.get $covered))
        (then (if (i32.eqz (call $virtual_map_commit_locked
                    (local.get $cursor) (i32.sub (local.get $next) (local.get $cursor))
                    (local.get $protect) (i32.const 0)))
          (then (return (i32.const 0))))))
      (local.set $cursor (local.get $next))
      (br $ranges)))
    (local.get $guest))

  (func (export "guest_section_commit")
      (param $base i32) (param $offset i32) (param $requested i32)
      (param $protect i32) (result i32)
    (local $size i32) (local $extent i32) (local $result i32)
    (if (i32.and (i32.ne (local.get $protect) (i32.const 2))
          (i32.ne (local.get $protect) (i32.const 4)))
      (then (return (i32.const 0))))
    (if (i32.or (i32.eqz (local.get $requested))
          (i32.or (i32.gt_u (local.get $requested) (i32.const 0xFFFFF000))
            (i32.ne (i32.and (local.get $offset) (i32.const 4095)) (i32.const 0))))
      (then (return (i32.const 0))))
    (local.set $size (i32.and (i32.add (local.get $requested) (i32.const 4095))
      (i32.const -4096)))
    (call $lock_acquire (global.get $LOCK_VIRTUAL_MAP))
    (local.set $extent (call $host_mapped_range_size (local.get $base)))
    (if (i32.le_u (local.get $offset) (local.get $extent))
      (then (if (i32.le_u (local.get $size) (i32.sub (local.get $extent) (local.get $offset)))
        (then
          ;; Do not coalesce with another section's adjacent record. Recommit
          ;; preserves existing bytes; only missing backing is zero-initialized.
          (local.set $result (call $host_section_commit_range
            (i32.add (local.get $base) (local.get $offset)) (local.get $size)
            (local.get $protect)))))))
    ;; READ maps never downgrade existing writable pages. WRITE/COPY maps
    ;; upgrade the whole requested run, even when some pages were already
    ;; committed. Win98 keeps that protection after those views are unmapped.
    (if (i32.and (i32.ne (local.get $result) (i32.const 0))
          (i32.eq (local.get $protect) (i32.const 4)))
      (then (drop (call $guest_page_protect_range
        (local.get $result) (local.get $size) (local.get $protect)))))
    (call $lock_release (global.get $LOCK_VIRTUAL_MAP))
    (local.get $result))

  (func (export "guest_section_free") (param $base i32) (result i32)
    (local $size i32) (local $i i32) (local $guest i32)
    (call $lock_acquire (global.get $LOCK_VIRTUAL_MAP))
    (local.set $size (call $host_mapped_range_size (local.get $base)))
    (if (i32.or (i32.eqz (local.get $size))
      (call $virtual_map_lease_mutation_busy (local.get $base) (local.get $size)))
      (then
        (call $lock_release (global.get $LOCK_VIRTUAL_MAP))
        (return (i32.const 0))))
    ;; Disjoint commits need not form a continuation chain. Each release
    ;; compacts the table, so revisit that index before advancing.
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (i32.load (global.get $VIRTUAL_MAP_STATE))))
      (local.set $guest (i32.load (i32.add (global.get $VIRTUAL_MAP_TABLE)
        (i32.shl (local.get $i) (i32.const 4)))))
      (if (i32.and (i32.ge_u (local.get $guest) (local.get $base))
            (i32.lt_u (i32.sub (local.get $guest) (local.get $base)) (local.get $size)))
        (then (drop (call $virtual_map_release_one (local.get $guest))))
        (else (local.set $i (i32.add (local.get $i) (i32.const 1)))))
      (br $scan)))
    (call $mapped_view_unregister (local.get $base))
    (call $virtual_reserve_forget_locked (local.get $base))
    (call $virtual_reserve_reclaim_locked)
    (call $lock_release (global.get $LOCK_VIRTUAL_MAP))
    (i32.const 1))

  ;; Allocate guest heap memory (returns guest address)
  (func (export "guest_alloc") (param $size i32) (result i32)
    (call $heap_alloc (local.get $size)))
  ;; Reserve and commit a page-aligned sparse guest range for file mappings.
  ;; Unlike HeapAlloc, this can hold a large view without crossing the fixed
  ;; low-memory stack/thunk arenas on its way upward.
  (func (export "guest_map_alloc") (param $requested i32) (result i32)
    (local $size i32) (local $guest i32)
    ;; Host mapping operations are serialized on the main host. Refuse a view
    ;; before allocation if its VirtualFree exclusion cannot be recorded;
    ;; otherwise the guest can decommit mapped file bytes as ordinary memory.
    (if (i32.ge_u (i32.load (global.get $MAPPED_VIEW_TABLE))
          (global.get $MAX_MAPPED_VIEWS))
      (then (return (i32.const 0))))
    (local.set $size
      (i32.and (i32.add (local.get $requested) (i32.const 0xFFF))
        (i32.const 0xFFFFF000)))
    (if (i32.eqz (local.get $size)) (then (return (i32.const 0))))
    (local.set $guest (call $virtual_alloc_committed (local.get $size)))
    (if (i32.eqz (local.get $guest)) (then (return (i32.const 0))))
    ;; Remember the range as a view, so VirtualFree can refuse it the way
    ;; Windows does instead of treating it as VirtualAlloc'd memory.
    (call $mapped_view_register (local.get $guest) (local.get $size))
    (local.get $guest))
  ;; A guest thread's stack. Win9x CreateThread reserves it with VirtualAlloc,
  ;; so every thread stack lies ABOVE the main thread's, which the loader made
  ;; first. Single-threaded Watcom programs depend on that: their __CHK keeps
  ;; one stack floor (the main thread's) and judges every thread's ESP against
  ;; it, so a callback on a timer thread whose stack came from the low guest
  ;; heap, below $GUEST_STACK, reported "Stack Overflow!" and ExitProcess'd
  ;; (Atlantis demo's MSS timer). 0 means no range was free; the caller falls
  ;; back to guest_alloc.
  (func (export "guest_stack_alloc") (param $requested i32) (result i32)
    (local $size i32) (local $guest i32)
    (local.set $size
      (i32.and (i32.add (local.get $requested) (i32.const 0xFFF))
        (i32.const 0xFFFFF000)))
    (if (i32.eqz (local.get $size)) (then (return (i32.const 0))))
    (call $virtual_alloc_committed (local.get $size)))
  (func (export "guest_free") (param $g i32)
    (call $heap_free (local.get $g)))
  ;; Paired with guest_map_alloc; heap_free cannot release a sparse mapping.
  (func (export "guest_map_free") (param $g i32) (result i32)
    (local $result i32)
    (call $lock_acquire (global.get $LOCK_VIRTUAL_MAP))
    (local.set $result (call $virtual_map_release_locked (local.get $g)))
    (if (local.get $result) (then (call $mapped_view_unregister (local.get $g))))
    (call $lock_release (global.get $LOCK_VIRTUAL_MAP))
    (local.get $result))

  ;; Host launchers call this before guest entry. Queue entries in fixed low
  ;; memory so launch compatibility settings do not eagerly allocate the
  ;; environment heap and perturb an executable's startup layout.
  (func (export "set_process_environment_a")
      (param $name_g i32) (param $value_g i32) (result i32)
    (local $name_len i32) (local $value_len i32) (local $p i32)
    (if (i32.or (i32.eqz (local.get $name_g)) (i32.eqz (local.get $value_g)))
      (then (return (i32.const 0))))
    ;; These pointers are WASM offsets supplied by the host, just like the PE
    ;; staging-buffer arguments to set_exe_name/set_extra_cmdline. Do not run
    ;; them through guest virtual-address translation.
    (block $name_len_done (loop $name_len_loop
      (br_if $name_len_done
        (i32.eqz (i32.load8_u (i32.add (local.get $name_g) (local.get $name_len)))))
      (local.set $name_len (i32.add (local.get $name_len) (i32.const 1)))
      (br $name_len_loop)))
    (block $value_len_done (loop $value_len_loop
      (br_if $value_len_done
        (i32.eqz (i32.load8_u (i32.add (local.get $value_g) (local.get $value_len)))))
      (local.set $value_len (i32.add (local.get $value_len) (i32.const 1)))
      (br $value_len_loop)))
    ;; Entry bytes are NAME, '=', VALUE, NUL; retain one more byte for the
    ;; environment block's second NUL.
    (if (i32.gt_u
          (i32.add (global.get $launch_env_len)
            (i32.add (local.get $name_len) (i32.add (local.get $value_len) (i32.const 3))))
          (global.get $LAUNCH_ENV_OVERRIDES_SIZE))
      (then (return (i32.const 0))))
    (local.set $p (i32.add (region.addr $LAUNCH_ENV_OVERRIDES 0) (global.get $launch_env_len)))
    (memory.copy (local.get $p) (local.get $name_g) (local.get $name_len))
    (i32.store8 (i32.add (local.get $p) (local.get $name_len)) (i32.const 0x3d))
    (local.set $p (i32.add (local.get $p) (i32.add (local.get $name_len) (i32.const 1))))
    (memory.copy (local.get $p) (local.get $value_g) (local.get $value_len))
    (local.set $p (i32.add (local.get $p) (local.get $value_len)))
    (i32.store8 (local.get $p) (i32.const 0))
    (global.set $launch_env_len
      (i32.add (global.get $launch_env_len)
        (i32.add (local.get $name_len) (i32.add (local.get $value_len) (i32.const 2)))))
    (i32.store8 (i32.add (region.addr $LAUNCH_ENV_OVERRIDES 0) (global.get $launch_env_len)) (i32.const 0))
    (i32.const 1))

  ;; sscanf — exercised by test/test-sscanf.js. Varargs are a guest array of
  ;; pointers here rather than a live stack frame, which is exactly what
  ;; $sscanf_impl walks.
  (func (export "test_sscanf") (param $src i32) (param $fmt i32) (param $va i32) (result i32)
    (call $sscanf_impl (local.get $src) (local.get $fmt) (local.get $va)))

  ;; Dynamic menus — exercised by test/test-menu-insert.js. The read-backs
  ;; expose the MNUD item records so a test can assert insertion *order*,
  ;; which is the part InsertMenuItem exists to get right.
  ;; -1 when the handle is not a WAT dynamic menu.
  (func (export "test_menu_item_count") (param $hmenu i32) (result i32)
    (local $sw i32)
    (local.set $sw (call $dynamic_menu_state_w (local.get $hmenu)))
    (if (i32.eqz (local.get $sw)) (then (return (i32.const -1))))
    (i32.load offset=4 (local.get $sw)))
  ;; $field: 0 = flags, 1 = id, 2 = legacy payload (text when present,
  ;; otherwise dwItemData), 3 = submenu, 4 = raw text.
  (func (export "test_menu_item_field") (param $hmenu i32) (param $index i32) (param $field i32) (result i32)
    (local $sw i32) (local $rec i32)
    (local.set $sw (call $dynamic_menu_state_w (local.get $hmenu)))
    (if (i32.eqz (local.get $sw)) (then (return (i32.const -1))))
    (if (i32.ge_u (local.get $index) (i32.load offset=4 (local.get $sw)))
      (then (return (i32.const -1))))
    (local.set $rec
      (i32.add (local.get $sw)
        (i32.add (i32.const 16)
          (i32.mul (local.get $index) (global.get $DYNAMIC_MENU_ITEM_BYTES)))))
    (if (i32.eq (local.get $field) (i32.const 2))
      (then
        (return
          (select
            (i32.load offset=16 (local.get $rec))
            (i32.load offset=8 (local.get $rec))
            (i32.ne (i32.load offset=16 (local.get $rec)) (i32.const 0))))))
    (i32.load
      (i32.add (local.get $rec) (i32.mul (local.get $field) (i32.const 4)))))

  ;; Atom tables — exercised by test/test-atom-table.js. The A/W and
  ;; local/global split is the part worth pinning: the same name in different
  ;; namespaces must yield independent atoms and independent reference counts.
  ;; Non-OLE clipboard inspection/helpers for renderer shortcuts and tests.
  (func (export "clipboard_rtf_format_id") (result i32)
    (global.get $clipboard_rtf_format_id))
  (func (export "clipboard_get_rtf_format_id") (result i32)
    (call $clipboard_get_rtf_format_id))
  (func (export "clipboard_register_format_a") (param $name_g i32) (result i32)
    (call $clipboard_register_format_a (local.get $name_g)))
  (func (export "clipboard_register_format_w") (param $name_g i32) (result i32)
    (call $clipboard_register_format_w (local.get $name_g)))
  (func (export "clipboard_clear_all_data")
    (call $clipboard_clear_all_data))
  (func (export "clipboard_store_rtf_data") (param $src_g i32) (result i32)
    (call $clipboard_store_rtf_data (local.get $src_g)))
  (func (export "clipboard_store_binary_data") (param $fmt i32) (param $src_g i32) (result i32)
    (call $clipboard_store_binary_data (local.get $fmt) (local.get $src_g)))
  (func (export "clipboard_text_len") (result i32)
    (global.get $clipboard_len))
  (func (export "clipboard_rtf_len") (result i32)
    (global.get $clipboard_rtf_len))
  (func (export "clipboard_rtf_ptr") (result i32)
    (global.get $clipboard_rtf_ptr))
  (func (export "clipboard_ole_data_object") (result i32)
    (global.get $clipboard_ole_data_object))
  (func (export "clipboard_count_formats") (result i32)
    (call $clipboard_count_formats))
  (func (export "clipboard_is_format_available") (param $fmt i32) (result i32)
    (call $clipboard_is_format_available (local.get $fmt)))
  (func (export "clipboard_get_data_handle") (param $fmt i32) (result i32)
    (call $clipboard_get_data_handle (local.get $fmt)))
  (func (export "native_richedit_clipboard_copy") (param $hwnd i32) (result i32)
    (call $native_text_copy_selection_to_clipboard (local.get $hwnd)))
  (func (export "native_richedit_clipboard_cut") (param $hwnd i32) (result i32)
    (drop (call $native_text_copy_selection_to_clipboard (local.get $hwnd)))
    (call $wordpad_richedit_replace_empty (local.get $hwnd)))
  (func (export "native_richedit_clipboard_paste") (param $hwnd i32) (result i32)
    (call $wordpad_richedit_paste_clipboard (local.get $hwnd)))

  ;; Write 16-bit value to guest memory
  (func (export "guest_write16") (param $ga i32) (param $val i32)
    (call $gs16 (local.get $ga) (local.get $val)))

  ;; Focused DIB arena hooks used by allocator tests.
  (func (export "test_dib_alloc") (param $size i32) (result i32)
    (call $dib_alloc (local.get $size)))
  (func (export "test_dib_free") (param $ga i32)
    (call $dib_free_wasm (call $g2w (local.get $ga))))
  (func (export "test_dib_is_allocated") (param $ga i32) (result i32)
    (if (result i32)
      (i32.lt_u
        (i32.sub (local.get $ga) (global.get $DIB_GUEST_BASE))
        (global.get $DIB_GUEST_CAPACITY))
      (then
        (i32.ne
          (i32.load8_u
            (i32.add (global.get $DIB_PAGE_USED)
              (i32.shr_u
                (i32.sub (local.get $ga) (global.get $DIB_GUEST_BASE))
                (i32.const 12))))
          (i32.const 0)))
      (else (i32.const 0))))

  ;; Flags, name WASM pointer, name length, drive, then 128 name bytes.
  ;; No active data initializer:
  ;; instantiating another guest thread must not reset the process identity.
  (global $PROCESS_IMAGE_STATE i32 (region.addr $PROCESS_IMAGE_STATE 0))
  (global $PROCESS_IMAGE_STATE_SIZE i32 (region.size $PROCESS_IMAGE_STATE))

  ;; Publish launch identity before guest entry. The old 0x120 buffer overlaps
  ;; static data and was overwritten when another module instance was created.
  ;; Keep both bytes and metadata in uninitialized process-owned storage.
  (func (export "set_exe_name") (param $wa i32) (param $len i32)
    (local $n i32)
    (local.set $n (if (result i32) (i32.gt_u (local.get $len) (i32.const 127))
      (then (i32.const 127)) (else (local.get $len))))
    (memory.copy (region.addr $PROCESS_IMAGE_STATE 16) (local.get $wa) (local.get $n))
    (i32.store8 (i32.add (region.addr $PROCESS_IMAGE_STATE 16) (local.get $n)) (i32.const 0))
    (global.set $exe_name_wa (region.addr $PROCESS_IMAGE_STATE 16))
    (global.set $exe_name_len (local.get $n))
    (i32.store offset=4 (global.get $PROCESS_IMAGE_STATE) (global.get $exe_name_wa))
    (i32.store offset=8 (global.get $PROCESS_IMAGE_STATE) (local.get $n))
    (i32.store (global.get $PROCESS_IMAGE_STATE)
      (i32.or (i32.load (global.get $PROCESS_IMAGE_STATE)) (i32.const 1))))

  ;; The browser and CLI know the guest launch path. Keep GetModuleFileName and
  ;; argv on that drive instead of pretending every mounted executable is C:.
  (func (export "set_exe_drive") (param $drive i32)
    (local.set $drive (i32.and (local.get $drive) (i32.const 0xDF)))
    (if (i32.and
          (i32.ge_u (local.get $drive) (i32.const 0x41))
          (i32.le_u (local.get $drive) (i32.const 0x5A)))
      (then (global.set $exe_drive (local.get $drive)))
      (else (global.set $exe_drive (i32.const 0x43))))
    (i32.store offset=12 (global.get $PROCESS_IMAGE_STATE) (global.get $exe_drive))
    (i32.store (global.get $PROCESS_IMAGE_STATE)
      (i32.or (i32.load (global.get $PROCESS_IMAGE_STATE)) (i32.const 2))))

  ;; Get GUEST_BASE for direct WASM memory access
  (func (export "get_guest_base") (result i32) (global.get $GUEST_BASE))
  (func (export "get_dll_table") (result i32) (global.get $DLL_TABLE))
  (func (export "set_dll_path") (param $idx i32) (param $path_g i32)
    (if (i32.lt_u (local.get $idx) (global.get $DLL_TABLE_CAPACITY))
      (then
        (i32.store
          (i32.add (global.get $DLL_PATH_TABLE)
            (i32.shl (local.get $idx) (i32.const 2)))
          (local.get $path_g)))))
  (func (export "set_dll_count") (param $count i32) (i32.atomic.store (global.get $DLL_SHARED) (local.get $count)))
  (func (export "test_set_dll_count") (param $count i32) (i32.atomic.store (global.get $DLL_SHARED) (local.get $count)))
  (func (export "get_ansi_code_page") (result i32) (global.get $ansi_code_page))
  ;; --- Virtual LAN Winsock (docs/virtual-lan-party.md, Slice 1) ---
  ;; Each wrapper restores ESP because the handlers pop their stdcall frame,
  ;; and these exports are called without a guest frame underneath.
  (func (export "test_vsock_reset")
    (local $i i32)
    (local.set $i (i32.const 0))
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (global.get $VSOCK_MAX)))
      (call $vsock_destroy (local.get $i) (i32.const 0))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (global.set $wsa_last_error (i32.const 0))
    (i32.atomic.store (global.get $WSA_STARTED_SHARED) (i32.const 0))
    (global.set $vsock_sel_waiting (i32.const 0))
    (global.set $vsock_local_ip (i32.const 0x0A000001))  ;; 10.0.0.1
    ;; The cursor moved into shared memory (one per process, not one per
    ;; instance), so the reset has to clear it there or a fresh test inherits the
    ;; previous one's port.
    (i32.store (global.get $VSOCK_NEXT_PORT_SHARED) (i32.const 49152)))

  ;; Room address of this process. The host of the room keeps 10.0.0.1;
  ;; every other member takes the next free seat before the guest runs.
  (func (export "set_vlan_local_ip") (param $ip i32) (global.set $vsock_local_ip (local.get $ip)))
  (func (export "get_vlan_local_ip") (result i32) (global.get $vsock_local_ip))
  ;; Per-app Nagle-style pacing of small wire sends, in ms (0 = off); see
  ;; $vsock_nagle_ms in 09d-winsock.wat. Per instance, like the room address.
  (func (export "set_vlan_nagle_ms") (param $ms i32) (global.set $vsock_nagle_ms (local.get $ms)))
  (func (export "get_vlan_nagle_ms") (result i32) (global.get $vsock_nagle_ms))
  ;; Drain the wire without going through a guest API call, so a host that
  ;; has just delivered frames can settle them before resuming the guest.
  (func (export "vlan_pump") (call $vsock_pump))

  ;; ---- DDEML conversations, for test/test-win16-dde-room.js ----
  ;;
  ;; A DDE conversation needs two instances with separate memories on one
  ;; wire, which is exactly what test/vlan-node.js already builds for Winsock.
  ;; These reach the tables directly rather than through a 16-bit stack frame,
  ;; so a test can register a service on one node and connect from the other
  ;; without driving a guest binary to the point where it would.
  (func (export "test_dde_intern") (param $ga i32) (result i32)
    (call $win16_dde_hsz_intern (local.get $ga)))
  (func (export "test_dde_instance") (param $i i32) (param $used i32)
    (local $slot i32) (local $was_used i32)
    (local.set $slot (call $win16_dde_inst (local.get $i)))
    (local.set $was_used (i32.ne (i32.load (local.get $slot)) (i32.const 0)))
    (local.set $used (i32.ne (local.get $used) (i32.const 0)))
    (if (i32.ne (local.get $was_used) (local.get $used))
      (then
        (global.set $win16_dde_users
          (i32.add (global.get $win16_dde_users)
            (select (i32.const 1) (i32.const -1) (local.get $used))))))
    (i32.store (local.get $slot) (local.get $used)))
  ;; Point an instance's DDE callback at a far proc. A real task sets this
  ;; through DdeInitialize; a test needs it to aim the callback at a stub it
  ;; can predict the answer of, which is the only way to exercise the
  ;; XTYP_CONNECT path without driving an app all the way to a live server.
  (func (export "test_dde_set_callback") (param $inst i32) (param $proc i32)
    (i32.store offset=4 (call $win16_dde_inst
      (i32.sub (local.get $inst) (i32.const 1))) (local.get $proc)))
  (func (export "test_dde_ask_pending") (result i32)
    (i32.ge_s (call $win16_dde_ask_next) (i32.const 0)))
  ;; The text behind a DDE string handle. Every DDE trace line names its topic
  ;; and item by handle, and a handle is a per-instance number: the two sides
  ;; of one conversation call the same string different things, so comparing
  ;; the numbers across a pair of transcripts says nothing at all. This is what
  ;; lets the trace print the name.
  (func (export "win16_dde_hsz_text") (param $hsz i32) (result i32)
    (if (i32.or (i32.eqz (local.get $hsz)) (i32.gt_u (local.get $hsz) (i32.const 64)))
      (then (return (i32.const 0))))
    (i32.add (call $win16_dde_hsz_slot (i32.sub (local.get $hsz) (i32.const 1)))
             (i32.const 4)))
  ;; 0 free, 1 established, 2 offered to the application and not yet answered.
  (func (export "test_dde_conv_state") (param $conv i32) (result i32)
    (i32.load (call $win16_dde_conv_slot (i32.sub (local.get $conv) (i32.const 1)))))

  ;; A data handle holding known bytes, so a server's callback has something
  ;; real to answer a request with and the test can check what crossed.
  (func (export "test_dde_make_data") (param $ga i32) (param $len i32) (result i32)
    (call $win16_dde_data_take (call $g2w (local.get $ga)) (local.get $len)))
  (func (export "test_dde_data_len") (param $h i32) (result i32)
    (if (i32.ge_u (i32.sub (local.get $h) (i32.const 0x100)) (i32.const 16))
      (then (return (i32.const -1))))
    (i32.load offset=4 (call $win16_dde_data_slot
      (i32.sub (local.get $h) (i32.const 0x100)))))
  (func (export "test_dde_data_byte") (param $h i32) (param $i i32) (result i32)
    (i32.load8_u (i32.add (i32.add (call $win16_dde_data_slot
      (i32.sub (local.get $h) (i32.const 0x100))) (i32.const 8)) (local.get $i))))

  ;; The client half of DdeClientTransaction(XTYP_REQUEST) without the park,
  ;; so a test can drive both machines by hand. The parking itself is the same
  ;; $win16_dde_park the connect test already covers.
  (func (export "test_dde_xact_begin") (param $conv i32) (param $item i32) (result i32)
    (local $pend i32) (local $wa i32) (local $len i32)
    (if (i32.ne (i32.load (call $win16_dde_conv_slot
          (i32.sub (local.get $conv) (i32.const 1)))) (i32.const 1))
      (then (return (i32.const 0))))
    (local.set $pend (call $win16_dde_pending_slot))
    (i32.store (local.get $pend) (i32.const 1))
    (i32.store offset=4  (local.get $pend) (i32.const 0))
    (i32.store offset=8  (local.get $pend) (local.get $conv))
    (i32.store offset=12 (local.get $pend) (i32.const 0))
    (i32.store offset=16 (local.get $pend) (global.get $DDE_WAIT_XACT))
    (i32.store offset=20 (local.get $pend) (i32.const 0))
    (i32.store offset=24 (local.get $pend) (global.get $DDE_CONNECT_TIMEOUT_MS))
    (i32.store offset=28 (local.get $pend) (i32.const 0))
    (local.set $wa (call $win16_dde_frame_wa))
    (if (i32.eqz (local.get $wa)) (then (return (i32.const 0))))
    (local.set $len (call $win16_dde_put_hsz
      (local.get $wa) (global.get $DDE_HDR) (local.get $item)))
    (call $win16_dde_emit (i32.const 4) (local.get $conv)
      (i32.load offset=12 (call $win16_dde_conv_slot
        (i32.sub (local.get $conv) (i32.const 1))))
      (i32.sub (local.get $len) (global.get $DDE_HDR))))
  ;; 0 while still waiting, else the handle the far application answered with.
  (func (export "test_dde_xact_done") (result i32)
    (local $pend i32)
    (local.set $pend (call $win16_dde_pending_slot))
    (if (i32.eqz (i32.load offset=12 (local.get $pend))) (then (return (i32.const 0))))
    (i32.load offset=20 (local.get $pend)))

  ;; Start an advise loop from the client, and count the loops a server holds.
  (func (export "test_dde_advstart") (param $conv i32) (param $item i32) (result i32)
    (local $pend i32) (local $wa i32) (local $len i32)
    (if (i32.ne (i32.load (call $win16_dde_conv_slot
          (i32.sub (local.get $conv) (i32.const 1)))) (i32.const 1))
      (then (return (i32.const 0))))
    (local.set $pend (call $win16_dde_pending_slot))
    (i32.store (local.get $pend) (i32.const 1))
    (i32.store offset=4  (local.get $pend) (i32.const 0))
    (i32.store offset=8  (local.get $pend) (local.get $conv))
    (i32.store offset=12 (local.get $pend) (i32.const 0))
    (i32.store offset=16 (local.get $pend) (global.get $DDE_WAIT_XACT))
    (i32.store offset=20 (local.get $pend) (i32.const 0))
    (i32.store offset=24 (local.get $pend) (global.get $DDE_CONNECT_TIMEOUT_MS))
    (i32.store offset=28 (local.get $pend) (i32.const 0))
    (local.set $wa (call $win16_dde_frame_wa))
    (if (i32.eqz (local.get $wa)) (then (return (i32.const 0))))
    (local.set $len (call $win16_dde_put_hsz
      (local.get $wa) (global.get $DDE_HDR) (local.get $item)))
    (call $win16_dde_emit (i32.const 8) (local.get $conv)
      (i32.load offset=12 (call $win16_dde_conv_slot
        (i32.sub (local.get $conv) (i32.const 1))))
      (i32.sub (local.get $len) (global.get $DDE_HDR))))
  (func (export "test_dde_advise_count") (result i32)
    (local $i i32) (local $n i32)
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (i32.const 8)))
      (if (i32.load (call $win16_dde_advise_slot (local.get $i)))
        (then (local.set $n (i32.add (local.get $n) (i32.const 1)))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (local.get $n))
  ;; The application announcing that an item changed, as DdePostAdvise does.
  (func (export "test_dde_post_advise") (param $inst i32) (param $topic i32)
        (param $item i32)
    (local $i i32) (local $slot i32) (local $conv i32)
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (i32.const 8)))
      (local.set $slot (call $win16_dde_advise_slot (local.get $i)))
      (if (i32.load (local.get $slot))
        (then
          (local.set $conv (i32.load offset=4 (local.get $slot)))
          (if (i32.or (i32.eqz (local.get $item))
                      (i32.eq (i32.load offset=8 (local.get $slot)) (local.get $item)))
            (then (drop (call $win16_dde_ask_push (global.get $XTYP_ADVREQ)
                    (local.get $inst) (local.get $conv) (local.get $topic)
                    (i32.load offset=8 (local.get $slot))))))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan))))
  ;; What the client's own callback was last handed, so a push can be checked
  ;; from the receiving end rather than only from the sender's.
  (func (export "test_dde_last_advdata") (result i32)
    (global.get $win16_dde_last_advdata))

  (func (export "test_dde_register") (param $inst i32) (param $hsz i32)
    (i32.store (call $win16_dde_service_slot
                 (i32.sub (local.get $inst) (i32.const 1))) (local.get $hsz)))
  (func (export "test_dde_connect_begin") (param $inst i32)
        (param $svc i32) (param $topic i32) (result i32)
    (local $pend i32) (local $conv i32) (local $wa i32) (local $len i32)
    (local.set $pend (call $win16_dde_pending_slot))
    (local.set $conv (call $win16_dde_conv_alloc (local.get $inst) (i32.const 0)))
    (if (i32.eqz (local.get $conv)) (then (return (i32.const 0))))
    (i32.store (local.get $pend) (i32.const 1))
    (i32.store offset=4  (local.get $pend) (i32.const 0))
    (i32.store offset=8  (local.get $pend) (local.get $conv))
    (i32.store offset=12 (local.get $pend) (i32.const 0))
    (local.set $wa (call $win16_dde_frame_wa))
    (if (i32.eqz (local.get $wa)) (then (return (i32.const 0))))
    (local.set $len (call $win16_dde_put_hsz
      (local.get $wa) (global.get $DDE_HDR) (local.get $svc)))
    (local.set $len (call $win16_dde_put_hsz
      (local.get $wa) (local.get $len) (local.get $topic)))
    (drop (call $win16_dde_emit (i32.const 1) (local.get $conv) (i32.const 0)
      (i32.sub (local.get $len) (global.get $DDE_HDR))))
    (local.get $conv))
  ;; 0 while still waiting, else the established conversation handle.
  (func (export "test_dde_connect_done") (result i32)
    (local $pend i32)
    (local.set $pend (call $win16_dde_pending_slot))
    (if (i32.eqz (i32.load offset=12 (local.get $pend))) (then (return (i32.const 0))))
    (i32.load offset=8 (local.get $pend)))
  ;; How many conversations this instance is holding open.
  (func (export "test_dde_conv_count") (result i32)
    (local $i i32) (local $n i32)
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (i32.const 8)))
      (if (i32.load (call $win16_dde_conv_slot (local.get $i)))
        (then (local.set $n (i32.add (local.get $n) (i32.const 1)))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (local.get $n))
  (func (export "test_dde_conv_peer") (param $conv i32) (result i32)
    (i32.load offset=8 (call $win16_dde_conv_slot
      (i32.sub (local.get $conv) (i32.const 1)))))
  (func (export "test_dde_disconnect") (param $conv i32)
    (local $slot i32)
    (local.set $slot (call $win16_dde_conv_slot
      (i32.sub (local.get $conv) (i32.const 1))))
    (if (i32.load (local.get $slot))
      (then
        (drop (call $win16_dde_emit (i32.const 3) (local.get $conv)
          (i32.load offset=12 (local.get $slot)) (i32.const 0)))
        (i32.store (local.get $slot) (i32.const 0)))))

  (func (export "set_ansi_code_page") (param $cp i32)
    (if (call $is_supported_code_page (local.get $cp))
      (then (global.set $ansi_code_page (call $resolve_code_page (local.get $cp))))))
  (func (export "test_is_dbcs_lead_byte") (param $ch i32) (result i32)
    (call $is_dbcs_lead_byte (local.get $ch)))
  (func (export "test_mbsinc") (param $gp i32) (result i32)
    (call $mbsinc_ptr (local.get $gp)))

  ;; Direct test surface for the memory-backed OLE storage foundation. These
  ;; helpers intentionally bypass stdcall ESP bookkeeping while exercising the
  ;; same object/state helpers used by the public OLE32 and COM handlers.
  (func (export "test_ole_create_lockbytes") (param $hglobal i32) (param $delete_on_release i32) (result i32)
    (call $ole_create_lockbytes (local.get $hglobal) (local.get $delete_on_release)))
  (func (export "test_ole_create_storage") (param $lockbytes i32) (result i32)
    (call $ole_create_storage (local.get $lockbytes)))
  (func (export "test_ole_create_child_storage") (param $storage i32) (param $name i32) (result i32)
    (if (result i32) (i32.or
          (call $ole_storage_find_stream (local.get $storage) (local.get $name))
          (call $ole_storage_find_storage (local.get $storage) (local.get $name)))
      (then (i32.const 0))
      (else (call $ole_create_child_storage (local.get $storage) (local.get $name)))))
  (func (export "test_ole_find_storage") (param $storage i32) (param $name i32) (result i32)
    (local $child i32)
    (local.set $child (call $ole_storage_find_storage (local.get $storage) (local.get $name)))
    (if (local.get $child) (then (drop (call $ole_obj_addref (local.get $child)))))
    (local.get $child))
  (func (export "test_ole_storage_parent") (param $storage i32) (result i32)
    (call $gl32 (i32.add (local.get $storage) (i32.const 44))))
  (func (export "test_ole_destroy_element") (param $storage i32) (param $name i32) (result i32)
    (call $ole_storage_destroy_element (local.get $storage) (local.get $name)))
  (func (export "test_ole_rename_element") (param $storage i32) (param $old_name i32) (param $new_name i32) (result i32)
    (call $ole_storage_rename_element (local.get $storage) (local.get $old_name) (local.get $new_name)))
  (func (export "test_ole_copy_storage") (param $source i32) (param $dest i32) (result i32)
    (call $ole_storage_copy_contents (local.get $source) (local.get $dest)))
  (func (export "test_ole_move_element") (param $source i32) (param $name i32) (param $dest i32) (param $new_name i32) (param $flags i32) (result i32)
    (call $ole_storage_move_element
      (local.get $source) (local.get $name) (local.get $dest) (local.get $new_name) (local.get $flags)))
  (func (export "test_ole_create_stat_enum") (param $storage i32) (result i32)
    (call $ole_create_stat_enum (local.get $storage)))
  (func (export "test_ole_stat_enum_next") (param $obj i32) (param $requested i32) (param $stats i32) (param $fetched i32) (result i32)
    (call $ole_stat_enum_next (local.get $obj) (local.get $requested) (local.get $stats) (local.get $fetched)))
  (func (export "test_ole_stat_enum_skip") (param $obj i32) (param $requested i32) (result i32)
    (call $ole_stat_enum_skip (local.get $obj) (local.get $requested)))
  (func (export "test_ole_stat_enum_reset") (param $obj i32) (result i32)
    (call $ole_stat_enum_reset (local.get $obj)))
  (func (export "test_ole_clone_stat_enum") (param $obj i32) (result i32)
    (call $ole_clone_stat_enum (local.get $obj)))
  (func (export "test_ole_storage_commit") (param $storage i32) (result i32)
    (call $ole_storage_commit (local.get $storage)))
  (func (export "test_ole_storage_revert") (param $storage i32) (result i32)
    (call $ole_storage_revert (local.get $storage)))
  (func (export "test_ole_fill_stat") (param $obj i32) (param $stat i32) (param $flags i32) (result i32)
    (call $ole_fill_statstg (local.get $obj) (local.get $stat) (local.get $flags)))
  (func (export "test_ole_storage_set_state_bits") (param $storage i32) (param $bits i32) (param $mask i32) (result i32)
    (call $ole_storage_set_state_bits (local.get $storage) (local.get $bits) (local.get $mask)))
  (func (export "test_ole_cfb_serialize") (param $storage i32) (param $lockbytes i32) (result i32)
    (call $ole_cfb_serialize (local.get $storage) (local.get $lockbytes)))
  (func (export "test_ole_cfb_deserialize") (param $lockbytes i32) (param $out i32) (result i32)
    (call $ole_cfb_deserialize (local.get $lockbytes) (local.get $out)))
  (func (export "test_ole_lockbytes_data") (param $lockbytes i32) (result i32)
    (call $gl32 (i32.add (local.get $lockbytes) (i32.const 12))))
  (func (export "test_ole_lockbytes_size") (param $lockbytes i32) (result i32)
    (call $gl32 (i32.add (local.get $lockbytes) (i32.const 16))))
  (func (export "test_ole_lockbytes_set_size") (param $lockbytes i32) (param $size i32) (result i32)
    (call $ole_resize_buffer (local.get $lockbytes) (local.get $size)))
  (func (export "test_ole_create_stream") (param $storage i32) (param $name i32) (result i32)
    (local $stream i32)
    (if (i32.or
          (call $ole_storage_find_stream (local.get $storage) (local.get $name))
          (call $ole_storage_find_storage (local.get $storage) (local.get $name)))
      (then (return (i32.const 0))))
    (local.set $stream (call $ole_create_stream (local.get $storage) (local.get $name)))
    (if (i32.and
          (i32.ne (local.get $stream) (i32.const 0))
          (i32.ne (local.get $storage) (i32.const 0)))
      (then
        (call $gs32 (i32.add (local.get $stream) (i32.const 40)) (call $gl32 (i32.add (local.get $storage) (i32.const 16))))
        (call $gs32 (i32.add (local.get $storage) (i32.const 16)) (local.get $stream))
        (drop (call $ole_obj_addref (local.get $stream)))))
    (local.get $stream))
  (func (export "test_ole_create_hglobal_stream") (param $hglobal i32) (param $delete_on_release i32) (result i32)
    (call $ole_create_hglobal_stream (local.get $hglobal) (local.get $delete_on_release)))
  (func (export "test_ole_get_hglobal") (param $obj i32) (result i32)
    (call $gl32 (i32.add (call $ole_stream_root (local.get $obj)) (i32.const 12))))
  (func (export "test_ole_create_static_handler") (param $clsid i32) (result i32)
    (call $ole_create_static_handler (local.get $clsid)))
  (func (export "test_ole_static_query") (param $obj i32) (param $iid i32) (param $out i32) (result i32)
    (call $ole_static_query_interface (local.get $obj) (local.get $iid) (local.get $out)))
  (func (export "test_ole_static_set_storage") (param $obj i32) (param $storage i32)
    (call $ole_persist_replace_storage (local.get $obj) (local.get $storage)))
  (func (export "test_ole_persist_initialize") (param $obj i32) (param $storage i32) (param $loaded i32) (result i32)
    (call $ole_persist_initialize (local.get $obj) (local.get $storage) (local.get $loaded)))
  (func (export "test_ole_persist_save") (param $obj i32) (param $storage i32) (param $same_as_load i32) (result i32)
    (call $ole_persist_save (local.get $obj) (local.get $storage) (local.get $same_as_load)))
  (func (export "test_ole_persist_save_completed") (param $obj i32) (param $storage i32) (result i32)
    (call $ole_persist_save_completed (local.get $obj) (local.get $storage)))
  (func (export "test_ole_persist_hands_off") (param $obj i32) (result i32)
    (call $ole_persist_hands_off (local.get $obj)))
  (func (export "test_ole_persist_state") (param $obj i32) (result i32)
    (call $gl32 (i32.add (local.get $obj) (i32.const 96))))
  (func (export "test_ole_persist_storage") (param $obj i32) (result i32)
    (call $gl32 (i32.add (local.get $obj) (i32.const 20))))
  (func (export "test_ole_persist_dirty") (param $obj i32) (result i32)
    (call $gl32 (i32.add (local.get $obj) (i32.const 48))))
  (func (export "test_ole_cache_add") (param $obj i32) (param $formatetc i32) (param $advf i32) (param $out i32) (result i32)
    (call $ole_cache_add (local.get $obj) (local.get $formatetc) (local.get $advf) (local.get $out)))
  (func (export "test_ole_cache_set_data") (param $obj i32) (param $formatetc i32) (param $medium i32) (param $take i32) (result i32)
    (call $ole_cache_set_data (local.get $obj) (local.get $formatetc) (local.get $medium) (local.get $take)))
  (func (export "test_ole_cache_uncache") (param $obj i32) (param $connection i32) (result i32)
    (call $ole_cache_uncache (local.get $obj) (local.get $connection)))
  (func (export "test_ole_cache_count") (param $obj i32) (result i32)
    (call $gl32 (i32.add (local.get $obj) (i32.const 104))))
  (func (export "test_ole_cache_get") (param $obj i32) (param $formatetc i32) (param $medium i32) (result i32)
    (local $entry i32)
    (local.set $entry (call $ole_cache_find_format (local.get $obj) (local.get $formatetc)))
    (if (i32.eqz (local.get $entry)) (then (return (i32.const 0x80040064))))
    (call $ole_copy_medium (local.get $medium) (i32.add (local.get $entry) (i32.const 28))))
  (func (export "test_ole_cache_render_valid") (param $obj i32) (result i32)
    (call $gl32 (i32.add (local.get $obj) (i32.const 92))))
  (func (export "test_ole_create_cache_enum") (param $obj i32) (result i32)
    (call $ole_create_cache_enum (local.get $obj)))
  (func (export "test_ole_cache_enum_next") (param $obj i32) (param $requested i32) (param $items i32) (param $fetched i32) (result i32)
    (call $ole_statdata_enum_next (local.get $obj) (local.get $requested) (local.get $items) (local.get $fetched)))
  (func (export "test_ole_clone_cache_enum") (param $obj i32) (result i32)
    (call $ole_clone_cache_enum (local.get $obj)))
  (func (export "test_ole_static_init_from_data") (param $obj i32) (param $data i32) (result i32)
    (call $ole_static_init_from_data (local.get $obj) (local.get $data)))
  (func (export "test_ole_static_get_clipboard_data") (param $obj i32) (result i32)
    (call $ole_static_get_clipboard_data (local.get $obj)))
  (func (export "test_ole_static_set_host_names") (param $obj i32) (param $app i32) (param $name i32) (result i32)
    (call $ole_static_set_host_names (local.get $obj) (local.get $app) (local.get $name)))
  (func (export "test_ole_create_test_site") (result i32)
    (call $ole_create_test_site))
  (func (export "test_ole_static_set_client_site") (param $obj i32) (param $site i32) (result i32)
    (call $ole_static_set_client_site (local.get $obj) (local.get $site)))
  (func (export "test_ole_static_get_client_site") (param $obj i32) (param $out i32) (result i32)
    (call $ole_static_get_client_site (local.get $obj) (local.get $out)))
  (func (export "test_ole_static_advise") (param $obj i32) (param $sink i32) (param $out i32) (result i32)
    (call $ole_static_advise (local.get $obj) (local.get $sink) (local.get $out)))
  (func (export "test_ole_static_unadvise") (param $obj i32) (param $connection i32) (result i32)
    (call $ole_static_unadvise (local.get $obj) (local.get $connection)))
  (func (export "test_ole_create_advise_enum") (param $obj i32) (result i32)
    (call $ole_create_advise_enum (local.get $obj)))
  (func (export "test_ole_static_close") (param $obj i32) (param $option i32) (result i32)
    (call $ole_static_close (local.get $obj) (local.get $option)))
  (func (export "test_ole_static_run") (param $obj i32)
    (call $ole_static_run (local.get $obj)))
  (func (export "test_ole_static_lock_running") (param $obj i32) (param $lock i32) (param $last_unlock_closes i32)
    (call $ole_static_lock_running (local.get $obj) (local.get $lock) (local.get $last_unlock_closes)))
  (func (export "test_ole_static_set_contained") (param $obj i32) (param $contained i32)
    (call $ole_static_set_contained (local.get $obj) (local.get $contained)))
  (func (export "test_ole_static_set_extent") (param $obj i32) (param $aspect i32) (param $size i32) (result i32)
    (call $ole_static_set_extent (local.get $obj) (local.get $aspect) (local.get $size)))
  (func (export "test_ole_static_get_extent") (param $obj i32) (param $aspect i32) (param $size i32) (result i32)
    (call $ole_static_get_extent (local.get $obj) (local.get $aspect) (local.get $size)))
  (func (export "test_ole_static_get_user_type") (param $form i32) (param $out i32) (result i32)
    (call $ole_static_get_user_type (local.get $form) (local.get $out)))
  (func (export "test_ole_find_stream") (param $storage i32) (param $name i32) (result i32)
    (local $stream i32)
    (local.set $stream (call $ole_storage_find_stream (local.get $storage) (local.get $name)))
    (if (local.get $stream) (then (drop (call $ole_obj_addref (local.get $stream)))))
    (local.get $stream))
  (func (export "test_ole_stream_write") (param $stream i32) (param $buf i32) (param $count i32) (param $written i32) (result i32)
    (call $ole_stream_write (local.get $stream) (local.get $buf) (local.get $count) (local.get $written)))
  (func (export "test_ole_stream_read") (param $stream i32) (param $buf i32) (param $count i32) (param $read i32) (result i32)
    (call $ole_stream_read (local.get $stream) (local.get $buf) (local.get $count) (local.get $read)))
  (func (export "test_ole_stream_seek") (param $stream i32) (param $position i32)
    (call $gs32 (i32.add (local.get $stream) (i32.const 24)) (local.get $position)))
  (func (export "test_ole_stream_position") (param $stream i32) (result i32)
    (call $ole_data_position (local.get $stream)))
  (func (export "test_ole_stream_size") (param $stream i32) (result i32)
    (call $gl32 (i32.add (call $ole_stream_root (local.get $stream)) (i32.const 16))))
  (func (export "test_ole_stream_set_size") (param $stream i32) (param $size i32) (result i32)
    (call $ole_stream_set_size (local.get $stream) (local.get $size)))
  (func (export "test_ole_stream_clone") (param $stream i32) (result i32)
    (call $ole_clone_stream (local.get $stream)))
  (func (export "test_ole_stream_commit") (param $stream i32) (result i32)
    (call $ole_stream_commit (local.get $stream)))
  (func (export "test_ole_stream_revert") (param $stream i32) (result i32)
    (call $ole_stream_revert (local.get $stream)))
  (func (export "test_ole_stream_lock") (param $stream i32) (param $offset i32) (param $length i32) (param $flags i32) (result i32)
    (call $ole_stream_lock_region (local.get $stream) (local.get $offset) (local.get $length) (local.get $flags)))
  (func (export "test_ole_stream_unlock") (param $stream i32) (param $offset i32) (param $length i32) (param $flags i32) (result i32)
    (call $ole_stream_unlock_region (local.get $stream) (local.get $offset) (local.get $length) (local.get $flags)))
  (func (export "test_ole_stream_copy_to") (param $source i32) (param $dest i32) (param $count_low i32) (param $count_high i32) (param $read i32) (param $written i32) (result i32)
    (call $ole_stream_copy_to
      (local.get $source) (local.get $dest) (local.get $count_low) (local.get $count_high)
      (local.get $read) (local.get $written)))
  (func (export "test_ole_set_class") (param $storage i32) (param $clsid i32)
    (memory.copy (call $g2w (i32.add (local.get $storage) (i32.const 20))) (call $g2w (local.get $clsid)) (i32.const 16)))
  (func (export "test_ole_get_class") (param $storage i32) (param $clsid i32)
    (memory.copy (call $g2w (local.get $clsid)) (call $g2w (i32.add (local.get $storage) (i32.const 20))) (i32.const 16)))
  (func (export "test_ole_addref") (param $obj i32) (result i32)
    (call $ole_obj_addref (local.get $obj)))
  (func (export "test_ole_release") (param $obj i32) (result i32)
    (call $ole_obj_release (local.get $obj)))
  (func (export "test_ole_create_data_object") (param $formatetc i32) (param $medium i32) (result i32)
    (call $ole_create_data_object (local.get $formatetc) (local.get $medium)))

  (func (export "test_ole_clipboard_wrap_win32") (result i32)
    (call $ole_clipboard_wrap_win32))

  (func (export "test_create_insert_object_dialog") (param $params i32) (result i32)
    (local $dlg i32)
    (local.set $dlg (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $create_insert_object_dialog (local.get $dlg) (i32.const 0) (local.get $params))
    (local.get $dlg))

  ;; What OK would report, and what it would have written into the struct.
  (func (export "test_insert_object_commit") (param $hwnd i32) (result i32)
    (call $insertobj_commit (local.get $hwnd)))

  ;; How many insertable classes the registry walk found for this dialog.
  (func (export "test_insert_object_type_count") (param $hwnd i32) (result i32)
    (local $ctx i32)
    (local.set $ctx (call $wnd_get_userdata (local.get $hwnd)))
    (if (i32.eqz (local.get $ctx)) (then (return (i32.const -1))))
    (call $gl32 (i32.add (local.get $ctx) (i32.const 8))))

  (func (export "test_clsid_from_string") (param $src i32) (param $dest i32) (result i32)
    (call $clsid_from_string (local.get $src) (local.get $dest)))

  ;; The static-object side of OleCreateFromData, minus the guest stack frame:
  ;; pick a presentation format off a source, build the handler, load its cache.
  ;; Returns the handler, or 0. The two accessors below report what a container
  ;; would find on it — the render slot OleDraw uses, and the HIMETRIC extent.
  (func (export "test_ole_static_from_data") (param $source i32) (result i32)
    (local $picture i32) (local $obj i32)
    (local.set $picture (call $ole_data_first_static_format (local.get $source)))
    (if (i32.eqz (local.get $picture)) (then (return (i32.const 0))))
    (local.set $obj (call $ole_create_static_handler (i32.const 0)))
    (if (i32.eqz (local.get $obj))
      (then (call $heap_free (local.get $picture)) (return (i32.const 0))))
    (drop (call $ole_static_cache_from_data
      (local.get $obj) (local.get $source) (local.get $picture)))
    (call $heap_free (local.get $picture))
    (local.get $obj))

  ;; The HRESULT of the cache load alone, so a failure names itself instead of
  ;; showing up as an object that silently draws nothing.
  (func (export "test_ole_static_load_cache") (param $root i32) (param $source i32) (result i32)
    (local $picture i32) (local $hr i32)
    (local.set $picture (call $ole_data_first_static_format (local.get $source)))
    (if (i32.eqz (local.get $picture)) (then (return (i32.const -1))))
    (local.set $hr (call $ole_static_cache_from_data
      (local.get $root) (local.get $source) (local.get $picture)))
    (call $heap_free (local.get $picture))
    (local.get $hr))

  (func (export "test_ole_static_render_dib") (param $root i32) (result i32)
    (if (i32.eqz (call $gl32 (i32.add (local.get $root) (i32.const 92))))
      (then (return (i32.const 0))))
    (call $gl32 (i32.add (local.get $root) (i32.const 64))))

  (func (export "test_ole_static_extent") (param $root i32) (param $axis i32) (result i32)
    (call $gl32 (i32.add (local.get $root)
      (select (i32.const 44) (i32.const 40) (local.get $axis)))))
  (func (export "test_ole_data_query") (param $obj i32) (param $formatetc i32) (result i32)
    (call $ole_data_query_error (local.get $obj) (local.get $formatetc)))
  (func (export "test_ole_data_get") (param $obj i32) (param $formatetc i32) (param $medium i32) (result i32)
    (local $entry i32) (local $hr i32)
    (if (i32.eqz (local.get $medium)) (then (return (i32.const 0x80004003))))
    (call $zero_memory (call $g2w (local.get $medium)) (i32.const 12))
    (local.set $hr (call $ole_data_query_error (local.get $obj) (local.get $formatetc)))
    (if (local.get $hr) (then (return (local.get $hr))))
    (local.set $entry (call $ole_data_find_entry (local.get $obj) (local.get $formatetc)))
    (call $ole_copy_medium (local.get $medium) (i32.add (local.get $entry) (i32.const 20))))
  (func (export "test_ole_data_get_here") (param $obj i32) (param $formatetc i32) (param $medium i32) (result i32)
    (call $ole_data_get_here (local.get $obj) (local.get $formatetc) (local.get $medium)))
  (func (export "test_ole_data_set") (param $obj i32) (param $formatetc i32) (param $medium i32) (param $take i32) (result i32)
    (call $ole_data_set_entry (local.get $obj) (local.get $formatetc) (local.get $medium) (local.get $take)))
  (func (export "test_ole_data_set_with_text_conversions") (param $obj i32) (param $formatetc i32) (param $medium i32) (param $take i32) (result i32)
    (call $ole_data_set_with_text_conversions (local.get $obj) (local.get $formatetc) (local.get $medium) (local.get $take)))
  (func (export "test_ole_data_count") (param $obj i32) (result i32)
    (call $gl32 (i32.add (local.get $obj) (i32.const 16))))
  (func (export "test_ole_create_format_enum") (param $obj i32) (result i32)
    (call $ole_create_format_enum (local.get $obj)))
  (func (export "test_ole_format_enum_next") (param $obj i32) (param $requested i32) (param $formats i32) (param $fetched i32) (result i32)
    (call $ole_format_enum_next (local.get $obj) (local.get $requested) (local.get $formats) (local.get $fetched)))
  (func (export "test_ole_format_enum_skip") (param $obj i32) (param $requested i32) (result i32)
    (call $ole_enum_skip (local.get $obj) (local.get $requested)))
  (func (export "test_ole_format_enum_reset") (param $obj i32)
    (call $gs32 (i32.add (local.get $obj) (i32.const 20)) (i32.const 0)))
  (func (export "test_ole_clone_format_enum") (param $obj i32) (result i32)
    (call $ole_clone_format_enum (local.get $obj)))
  (func (export "test_ole_format_free") (param $formatetc i32)
    (call $ole_format_free (local.get $formatetc)))
  (func (export "test_ole_release_medium") (param $medium i32)
    (call $ole_release_medium (local.get $medium)))
  (func (export "test_start_ReleaseStgMedium") (param $medium i32) (result i32)
    (local $start_esp i32)
    (local.set $start_esp (i32.load offset=16 (global.get $reg_base)))
    ;; Direct handler tests provide the return address normally installed by
    ;; the stdcall API thunk. Guest interface releases then resume at EIP 0.
    (call $gs32 (local.get $start_esp) (i32.const 0))
    (call $handle_ReleaseStgMedium
      (local.get $medium) (i32.const 0) (i32.const 0) (i32.const 0)
      (i32.const 0) (i32.const 0))
    (global.get $eip))
  ;; Native OpenGL encoder controls and parity-test surface. stackWa is a
  ;; linear-memory address whose first dword is the x86 return address.
  (func (export "gl_wat_encoder_call") (param $opcode i32) (param $stackWa i32)
      (param $aux i32) (result i32)
    (call $gl_wat_encode_call (local.get $opcode) (local.get $stackWa) (local.get $aux)))
  (export "gl_wat_stream_flush" (func $gl_wat_stream_flush))
  (export "gl_wat_encoder_reset" (func $gl_wat_encoder_reset))
  (func (export "gl_wat_stream_base") (result i32) (global.get $gl_stream_wa))
  (func (export "gl_wat_stream_pool_version") (result i32) (i32.const 1))
  (export "gl_wat_stream_pool_enable" (func $gl_wat_stream_pool_enable))
  (export "gl_wat_stream_pool_base" (func $gl_wat_stream_pool_base))
  (func (export "gl_wat_stream_capacity") (result i32) (i32.const 0x00200000))
  (func (export "gl_wat_stream_used") (result i32) (global.get $gl_stream_used_bytes))
  (func (export "gl_wat_stream_commands") (result i32) (global.get $gl_stream_command_count))
  (func (export "gl_wat_stat_calls") (result i64) (global.get $gl_wat_stat_calls))
  (func (export "gl_wat_stat_spans") (result i64) (global.get $gl_wat_stat_spans))
  (func (export "gl_wat_stat_vertices") (result i64) (global.get $gl_wat_stat_vertices))
  (func (export "gl_wat_stat_flushes") (result i64) (global.get $gl_wat_stat_flushes))

  (func (export "test_ole_flush_clipboard") (result i32)
    (call $ole_flush_clipboard_value))

  ;; Direct formatter hook for Unicode/Win32-format regression tests.
  (func (export "test_wsprintf_w")
    (param $out i32) (param $fmt i32) (param $args i32) (result i32)
    (call $wsprintf_impl_w (local.get $out) (local.get $fmt) (local.get $args)))

  ;; ============================================================
  ;; STEP 6 — WAT-side find/replace + edit-state inspection exports
  ;; ============================================================
  ;; The test bridge in test/run.js uses these to drive the parallel
  ;; WAT-side find dialog state created by $create_findreplace_dialog.
  (func (export "get_findreplace_dlg")  (result i32) (global.get $findreplace_dlg_hwnd))
  (func (export "get_findreplace_edit") (result i32) (global.get $findreplace_edit_hwnd))
  (func (export "get_findreplace_replace_edit") (result i32) (global.get $findreplace_replace_hwnd))
  (func (export "get_findreplace_last_flags") (result i32) (global.get $findreplace_last_flags))
  (func (export "wnd_get_userdata_export") (param $hwnd i32) (result i32)
    (call $wnd_get_userdata (local.get $hwnd)))

  ;; (No create_about_dialog export — $handle_ShellAboutA calls
  ;; $create_about_dialog directly from inside the WAT-side handler.
  ;; JS does not need to drive dialog construction.)
  (func (export "get_focus_hwnd")       (result i32) (global.get $focus_hwnd))
  (func (export "get_capture_hwnd")     (result i32) (global.get $capture_hwnd))
  (func (export "release_capture")
    (drop (call $capture_replace (i32.const 0))))
  (func (export "clip_cursor_active")   (result i32) (global.get $clip_cursor_active))
  (func (export "clip_cursor_left")     (result i32) (global.get $clip_cursor_l))
  (func (export "clip_cursor_top")      (result i32) (global.get $clip_cursor_t))
  (func (export "clip_cursor_right")    (result i32) (global.get $clip_cursor_r))
  (func (export "clip_cursor_bottom")   (result i32) (global.get $clip_cursor_b))
  (func (export "set_focus_hwnd")       (param i32)  (global.set $focus_hwnd (local.get 0)))
  ;; Set focus via the proper SETFOCUS/KILLFOCUS message round-trip so
  ;; per-class focus bits + default-button flip + invalidates fire.
  (func (export "set_focus") (param $hwnd i32) (call $set_focus (local.get $hwnd)))

  ;; Find the current default button under $dlg (any child with bit2 of
  ;; ButtonState+8 set). Returns 0 if none.
  (func (export "dlg_get_default_btn") (param $dlg i32) (result i32)
    (local $i i32) (local $rec i32) (local $h i32) (local $st i32) (local $stw i32)
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (global.get $MAX_WINDOWS)))
      (local.set $rec (call $wnd_record_addr (local.get $i)))
      (local.set $h (i32.load (local.get $rec)))
      (if (i32.and
            (i32.and (i32.ne (local.get $h) (i32.const 0))
                     (i32.eq (i32.load offset=8 (local.get $rec)) (local.get $dlg)))
            (i32.eq (call $ctrl_table_get_class (local.get $h)) (i32.const 1)))
        (then
          (local.set $st (i32.load offset=20 (local.get $rec)))
          (if (local.get $st)
            (then
              (local.set $stw (call $g2w (local.get $st)))
              (if (i32.and (call $btn_flags (local.get $stw)) (i32.const 0x04))
                (then (return (local.get $h))))))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (i32.const 0))

  ;; Move focus within a radio group. $hwnd is the currently-focused
  ;; BS_AUTORADIOBUTTON; $dir is +1 (next) or -1 (prev). Walks contiguous
  ;; sibling slots looking for another autoradio under the same parent.
  ;; Returns the new focus hwnd, or 0 if no peer found.
  (func (export "radio_group_step") (param $hwnd i32) (param $dir i32) (result i32)
    (local $parent i32) (local $idx i32) (local $start i32) (local $i i32)
    (local $rec i32) (local $h i32) (local $count i32)
    (local.set $parent (call $wnd_get_parent (local.get $hwnd)))
    (if (i32.eqz (local.get $parent)) (then (return (i32.const 0))))
    (local.set $idx (call $wnd_table_find (local.get $hwnd)))
    (if (i32.lt_s (local.get $idx) (i32.const 0)) (then (return (i32.const 0))))
    (local.set $i (local.get $idx))
    (local.set $count (i32.const 0))
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $count) (global.get $MAX_WINDOWS)))
      (local.set $i (i32.add (local.get $i) (local.get $dir)))
      (if (i32.lt_s (local.get $i) (i32.const 0))
        (then (local.set $i (i32.sub (global.get $MAX_WINDOWS) (i32.const 1)))))
      (if (i32.ge_u (local.get $i) (global.get $MAX_WINDOWS))
        (then (local.set $i (i32.const 0))))
      (local.set $rec (call $wnd_record_addr (local.get $i)))
      (local.set $h (i32.load (local.get $rec)))
      (if (i32.and
            (i32.and (i32.ne (local.get $h) (i32.const 0))
                     (i32.eq (i32.load offset=8 (local.get $rec)) (local.get $parent)))
            (i32.eq (i32.and (call $wnd_get_style (local.get $h)) (i32.const 0x0F))
                    (i32.const 9)))
        (then (return (local.get $h))))
      (local.set $count (i32.add (local.get $count) (i32.const 1)))
      (br $scan)))
    (i32.const 0))

  ;; Count occupied WND_RECORDS slots (hwnd != 0). Used by the find dialog
  ;; cancel/leak regression test to verify $wnd_destroy_tree actually
  ;; releases child slots rather than letting them accumulate.
  (func (export "wnd_count_used") (result i32)
    (local $i i32) (local $n i32)
    (local.set $i (i32.const 0))
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (global.get $MAX_WINDOWS)))
      (if (i32.load (call $wnd_record_addr (local.get $i)))
        (then (local.set $n (i32.add (local.get $n) (i32.const 1)))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (local.get $n))

  ;; Generic SendMessage entry point. Routes through $wnd_send_message:
  ;; WAT-native targets dispatch synchronously via $wat_wndproc_dispatch;
  ;; x86 targets queue via post_queue (PostMessage semantics, return 0).
  (func (export "send_message")
    (param $hwnd i32) (param $msg i32) (param $wParam i32) (param $lParam i32)
    (result i32)
    (local $ret i32)
    (call $richedit_note_text_reset_message
      (local.get $hwnd) (local.get $msg))
    (call $richedit_note_charformat_message
      (local.get $hwnd) (local.get $msg) (local.get $wParam) (local.get $lParam))
    (call $richedit_note_paraformat_message
      (local.get $hwnd) (local.get $msg) (local.get $lParam))
    (local.set $ret
      (call $wnd_send_message (local.get $hwnd) (local.get $msg)
                              (local.get $wParam) (local.get $lParam)))
    (call $richedit_patch_get_charformat_message
      (local.get $hwnd) (local.get $msg) (local.get $lParam))
    (call $richedit_patch_get_paraformat_message
      (local.get $hwnd) (local.get $msg) (local.get $lParam))
    (local.get $ret))

  ;; Browser startup automation occasionally needs the semantics of a real
  ;; BUTTON click, not merely its parent WM_COMMAND notification. In
  ;; particular, automatic radio buttons update their checked state before
  ;; notifying the dialog procedure. Keep control lookup and input dispatch
  ;; inside USER so the host does not duplicate either table's layout.
  (func (export "click_dialog_control")
    (param $parent i32) (param $ctrl_id i32) (result i32)
    (local $child i32)
    (local.set $child (call $ctrl_find_by_id (local.get $parent) (local.get $ctrl_id)))
    (if (i32.eqz (local.get $child)) (then (return (i32.const 0))))
    (drop (call $wnd_send_message
      (local.get $child) (i32.const 0x0201) (i32.const 0) (i32.const 0)))
    (drop (call $wnd_send_message
      (local.get $child) (i32.const 0x0202) (i32.const 0) (i32.const 0)))
    (i32.const 1))

  (func (export "richedit_formatrange_next") (param $fr i32) (result i32)
    (call $richedit_formatrange_next (local.get $fr)))

  ;; Send WM_CHAR to the currently-focused hwnd. Returns 1 if dispatched.
  (func (export "send_char_to_focus") (param $code i32) (result i32)
    (if (i32.eqz (global.get $focus_hwnd)) (then (return (i32.const 0))))
    (drop (call $wnd_send_message
            (global.get $focus_hwnd)
            (i32.const 0x0102)  ;; WM_CHAR
            (local.get $code)
            (i32.const 0)))
    (i32.const 1))

  ;; Read the EditState text for an EDIT-class hwnd into a guest buffer.
  ;; Returns chars copied (excluding NUL); 0 if no state or empty buffer.
  ;; Caller is responsible for the destination buffer; we NUL-terminate.
  (func (export "get_edit_text")
    (param $hwnd i32) (param $dest_guest i32) (param $max i32) (result i32)
    (local $state i32) (local $state_w ptr<EditState>) (local $len i32) (local $src i32)
    (local.set $state (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $state)) (then (return (i32.const 0))))
    (local.set $state_w (cast ptr<EditState> (call $g2w (local.get $state))))
    (local.set $len (load.field EditState text_len (local.get $state_w)))
    (local.set $src (load.field EditState text_buf_ptr (local.get $state_w)))
    (if (i32.le_u (local.get $max) (i32.const 0)) (then (return (i32.const 0))))
    (if (i32.ge_u (local.get $len) (local.get $max))
      (then (local.set $len (i32.sub (local.get $max) (i32.const 1)))))
    (if (local.get $src)
      (then (if (local.get $len)
              (then (call $memcpy (call $g2w (local.get $dest_guest))
                                  (call $g2w (local.get $src))
                                  (local.get $len))))))
    (i32.store8 (i32.add (call $g2w (local.get $dest_guest)) (local.get $len)) (i32.const 0))
    (local.get $len))

  ;; EditState cursor position (offset+12).
  (func (export "get_edit_cursor") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<EditState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<EditState> (call $g2w (local.get $s))))
    (load.field EditState cursor (local.get $sw)))

  ;; EditState selection anchor (offset+16).
  (func (export "get_edit_sel_start") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<EditState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<EditState> (call $g2w (local.get $s))))
    (load.field EditState sel_anchor (local.get $sw)))

  ;; EditState flags (offset+24), used by tests/debugging to verify focus.
  (func (export "get_edit_flags") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<EditState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<EditState> (call $g2w (local.get $s))))
    (load.field EditState flags (local.get $sw)))

  ;; EditState text length (offset+4).
  (func (export "get_edit_text_len") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<EditState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<EditState> (call $g2w (local.get $s))))
    (load.field EditState text_len (local.get $sw)))

  ;; Test helper: create a parent + EDIT child, return EDIT hwnd. The caller
  ;; passes the full EDIT/WS_* style and optional initial text guest pointer.
  (func (export "test_create_edit")
    (param $x i32) (param $y i32) (param $w i32) (param $h i32)
    (param $style i32) (param $text_g i32) (result i32)
    (local $parent i32) (local $edit i32)
    (local.set $parent (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $wnd_table_set (local.get $parent) (global.get $WNDPROC_CTRL_NATIVE))
    (drop (call $wnd_set_style (local.get $parent) (i32.const 0x80000000)))
    (local.set $edit (call $ctrl_create_child
      (local.get $parent) (i32.const 2) (i32.const 100)
      (local.get $x) (local.get $y) (local.get $w) (local.get $h)
      (local.get $style) (local.get $text_g)))
    (local.get $edit))

  (func $test_edit_visual_line_count (export "test_edit_visual_line_count")
    (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<EditState>) (local $sz i32) (local $w i32) (local $style i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<EditState> (call $g2w (local.get $s))))
    (local.set $style (call $wnd_get_style (local.get $hwnd)))
    (local.set $sz (call $ctrl_get_wh_packed (local.get $hwnd)))
    (local.set $w (i32.and (local.get $sz) (i32.const 0xFFFF)))
    (if (i32.and (local.get $style) (i32.const 0x00200000))
      (then
        (if (i32.gt_u (local.get $w) (i32.const 16))
          (then (local.set $w (i32.sub (local.get $w) (i32.const 16)))))))
    (if (i32.and
          (i32.ne (i32.and (local.get $style) (i32.const 0x00200000)) (i32.const 0))
          (i32.eqz (i32.and (local.get $style) (i32.const 0x00000080))))
      (then
        (return (call $edit_layout_build
          (local.get $sw) (i32.add (local.get $hwnd) (i32.const 0x40000))
          (local.get $w)))))
    (i32.add
      (call $edit_line_from_char (local.get $sw) (load.field EditState text_len (local.get $sw)))
      (i32.const 1)))

  (func (export "test_edit_max_scroll")
    (param $hwnd i32) (result i32)
    (local $lines i32) (local $visible i32) (local $sz i32) (local $h i32) (local $max i32)
    (local.set $lines (call $test_edit_visual_line_count (local.get $hwnd)))
    (local.set $sz (call $ctrl_get_wh_packed (local.get $hwnd)))
    (local.set $h (i32.shr_u (local.get $sz) (i32.const 16)))
    (local.set $visible (i32.div_u
      (select (i32.sub (local.get $h) (i32.const 8)) (i32.const 1)
              (i32.gt_u (local.get $h) (i32.const 8)))
      (i32.const 16)))
    (if (i32.eqz (local.get $visible))
      (then (local.set $visible (i32.const 1))))
    (local.set $max (i32.sub (local.get $lines) (local.get $visible)))
    (if (i32.lt_s (local.get $max) (i32.const 0))
      (then (return (i32.const 0))))
    (local.get $max))

  ;; USER caret state, used by the renderer to composite native-control carets
  ;; after normal window back-canvas painting.
  (func (export "get_caret_hwnd") (result i32)
    (global.get $caret_hwnd))
  (func (export "get_caret_x") (result i32)
    (global.get $caret_x))
  (func (export "get_caret_y") (result i32)
    (global.get $caret_y))
  (func (export "get_caret_w") (result i32)
    (global.get $caret_w))
  (func (export "get_caret_h") (result i32)
    (global.get $caret_h))
  (func (export "get_caret_visible") (result i32)
    (global.get $caret_visible))

  ;; ============================================================
  ;; Child-window enumeration + control read-back exports
  ;; ============================================================
  ;; Used by the renderer to draw WAT-managed children without needing
  ;; a parallel JS-side `controls[]` array.

  ;; Find next child slot of $parent at or after $start. Returns -1 when
  ;; no more children exist. Caller iterates: slot=0; while ((slot=next(p,slot))!=-1) { ... slot++; }
  (func (export "wnd_next_child_slot") (param $parent i32) (param $start i32) (result i32)
    (call $wnd_next_child_slot (local.get $parent) (local.get $start)))

  (func (export "wnd_slot_hwnd") (param $slot i32) (result i32)
    (call $wnd_slot_hwnd (local.get $slot)))

  ;; Get the geometry parent hwnd of a window (0 if none). Owned top-level
  ;; windows expose their owner via wnd_get_owner instead.
  (func (export "wnd_get_parent") (param $hwnd i32) (result i32)
    (call $wnd_get_parent (local.get $hwnd)))
  (func (export "test_wnd_set_parent") (param $hwnd i32) (param $parent i32)
    (call $wnd_set_parent (local.get $hwnd) (local.get $parent)))
  (func (export "wnd_get_owner") (param $hwnd i32) (result i32)
    (call $wnd_get_owner (local.get $hwnd)))
  (func (export "wnd_get_parent_api") (param $hwnd i32) (result i32)
    (call $wnd_get_parent_api (local.get $hwnd)))

  ;; Absolute HWND geometry in screen coordinates. Top-level placement is
  ;; backed by the host canvas; child placement is fully WAT-owned.
  (func (export "wnd_top_level") (param $hwnd i32) (result i32)
    (call $wnd_top_level (local.get $hwnd)))
  (func (export "wnd_window_screen_x") (param $hwnd i32) (result i32)
    (call $wnd_window_screen_x (local.get $hwnd)))
  (func (export "wnd_window_screen_y") (param $hwnd i32) (result i32)
    (call $wnd_window_screen_y (local.get $hwnd)))
  (func (export "wnd_client_screen_x") (param $hwnd i32) (result i32)
    (call $wnd_client_screen_x (local.get $hwnd)))
  (func (export "wnd_client_screen_y") (param $hwnd i32) (result i32)
    (call $wnd_client_screen_y (local.get $hwnd)))
  (func (export "wnd_screen_w") (param $hwnd i32) (result i32)
    (call $wnd_screen_w (local.get $hwnd)))
  (func (export "wnd_screen_h") (param $hwnd i32) (result i32)
    (call $wnd_screen_h (local.get $hwnd)))
  (func (export "scrollbar_hit_part") (param $long_dim i32) (param $coord i32) (param $pos i32) (param $smin i32) (param $smax i32) (result i32)
    (call $scrollbar_hit_part
      (local.get $long_dim)
      (local.get $coord)
      (local.get $pos)
      (local.get $smin)
      (local.get $smax)))
  (func (export "scrollbar_drag_pos") (param $long_dim i32) (param $coord i32) (param $anchor_coord i32) (param $anchor_pos i32) (param $smin i32) (param $smax i32) (result i32)
    (call $scrollbar_drag_pos
      (local.get $long_dim)
      (local.get $coord)
      (local.get $anchor_coord)
      (local.get $anchor_pos)
      (local.get $smin)
      (local.get $smax)))
  (func (export "modal_dialog_hwnd") (result i32)
    (i32.atomic.load (global.get $SHARED_MODAL_DLG_HWND)))
  ;; Guest DialogBoxParam has a different pump from WAT common dialogs.
  ;; Keep the existing export's input-routing semantics unchanged.
  (func (export "dialogbox_hwnd") (result i32)
    (i32.atomic.load (global.get $SHARED_DLG_PUMP_HWND)))
  (func (export "modal_cancel_if_hwnd") (param $hwnd i32)
    (if (i32.eq (i32.atomic.load (global.get $SHARED_MODAL_DLG_HWND)) (local.get $hwnd))
      (then
        (i32.atomic.store (global.get $SHARED_MODAL_RESULT) (i32.const 0))
        (i32.atomic.store (global.get $SHARED_MODAL_DONE) (i32.const 1)))))
  (func (export "wnd_mouse_msg_origin_x") (param $hwnd i32) (result i32)
    (call $wnd_mouse_msg_origin_x (local.get $hwnd)))
  (func (export "wnd_mouse_msg_origin_y") (param $hwnd i32) (result i32)
    (call $wnd_mouse_msg_origin_y (local.get $hwnd)))
  (func (export "wnd_child_from_point_deep") (param $parent i32) (param $sx i32) (param $sy i32) (result i32)
    (call $wnd_child_from_point_deep (local.get $parent) (local.get $sx) (local.get $sy)))
  ;; Browser Shell file-drop bridge. Start at the deepest child under the
  ;; pointer and walk toward the supplied top-level until the first window
  ;; registered by DragAcceptFiles (WS_EX_ACCEPTFILES) is found.
  (func (export "drop_target_at") (param $top i32) (param $sx i32) (param $sy i32) (result i32)
    (local $hwnd i32)
    (local.set $hwnd (call $wnd_child_from_point_deep
      (local.get $top) (local.get $sx) (local.get $sy)))
    (if (i32.eqz (local.get $hwnd)) (then (local.set $hwnd (local.get $top))))
    (block $none (loop $parents
      (br_if $none (i32.eqz (local.get $hwnd)))
      (if (i32.and (call $ctrl_get_ex_style (local.get $hwnd)) (i32.const 0x10))
        (then (return (local.get $hwnd))))
      (br_if $none (i32.eq (local.get $hwnd) (local.get $top)))
      (local.set $hwnd (call $wnd_get_parent (local.get $hwnd)))
      (br $parents)))
    (i32.const 0))
  (func (export "dialog_route_mouse_screen")
    (param $parent i32) (param $msg i32) (param $wParam i32) (param $sx i32) (param $sy i32) (result i32)
    (call $dialog_route_mouse_screen
      (local.get $parent) (local.get $msg) (local.get $wParam)
      (local.get $sx) (local.get $sy)))
  (func (export "dialog_ancestor") (param $hwnd i32) (result i32)
    (call $dialog_ancestor (local.get $hwnd)))
  (func (export "dialog_handle_key") (param $dlg i32) (param $vk i32) (param $shift i32) (result i32)
    (call $dialog_handle_key (local.get $dlg) (local.get $vk) (local.get $shift)))
  (func (export "wnd_first_visible_control_class") (param $cls i32) (result i32)
    (call $wnd_first_visible_control_class (local.get $cls)))
  (func (export "edit_command_target") (result i32)
    (call $edit_command_target))
  (func (export "menu_try_edit_command") (param $id i32) (result i32)
    (call $menu_try_edit_command (local.get $id)))

  ;; Geometry getters: each returns x|y<<16 or w|h<<16 (i16 each).
  (func (export "ctrl_get_xy") (param $hwnd i32) (result i32)
    (call $ctrl_get_xy_packed (local.get $hwnd)))
  (func (export "ctrl_get_wh") (param $hwnd i32) (result i32)
    (call $ctrl_get_wh_packed (local.get $hwnd)))
  (func (export "wnd_z_get") (param $hwnd i32) (result i32)
    (call $wnd_z_get (local.get $hwnd)))
  (func (export "wnd_z_set_after") (param $hwnd i32) (param $after i32)
    (call $wnd_z_set_after (local.get $hwnd) (local.get $after)))
  (func (export "wnd_z_is_above_sibling") (param $hwnd i32) (param $sibling i32) (result i32)
    (call $wnd_z_is_above_sibling (local.get $hwnd) (local.get $sibling)))

  ;; Standard window scrollbar state for renderer non-client hit-testing.
  ;; $bar is SB_HORZ=0 or SB_VERT=1.
  (func $standard_scroll_pos (export "standard_scroll_pos") (param $hwnd i32) (param $bar i32) (result i32)
    (local $slot i32) (local $base i32)
    (local.set $slot (call $wnd_table_find (local.get $hwnd)))
    (if (i32.lt_s (local.get $slot) (i32.const 0)) (then (return (i32.const 0))))
    (local.set $base (call $scroll_bar_addr (local.get $slot)
      (i32.ne (local.get $bar) (i32.const 0))))
    (i32.load (local.get $base)))
  (func $standard_scroll_min (export "standard_scroll_min") (param $hwnd i32) (param $bar i32) (result i32)
    (local $slot i32) (local $base i32)
    (local.set $slot (call $wnd_table_find (local.get $hwnd)))
    (if (i32.lt_s (local.get $slot) (i32.const 0)) (then (return (i32.const 0))))
    (local.set $base (call $scroll_bar_addr (local.get $slot)
      (i32.ne (local.get $bar) (i32.const 0))))
    (i32.load offset=4 (local.get $base)))
  (func $standard_scroll_max (export "standard_scroll_max") (param $hwnd i32) (param $bar i32) (result i32)
    (local $slot i32) (local $base i32)
    (local.set $slot (call $wnd_table_find (local.get $hwnd)))
    (if (i32.lt_s (local.get $slot) (i32.const 0)) (then (return (i32.const 0))))
    (local.set $base (call $scroll_bar_addr (local.get $slot)
      (i32.ne (local.get $bar) (i32.const 0))))
    (i32.load offset=8 (local.get $base)))
  (func $standard_scroll_page (export "standard_scroll_page") (param $hwnd i32) (param $bar i32) (result i32)
    (local $slot i32) (local $aux i32)
    (local.set $slot (call $wnd_table_find (local.get $hwnd)))
    (if (i32.lt_s (local.get $slot) (i32.const 0)) (then (return (i32.const 0))))
    (local.set $aux (call $scroll_aux_bar_addr (local.get $slot)
      (i32.ne (local.get $bar) (i32.const 0))))
    (i32.load (local.get $aux)))
  (func $standard_scroll_arrows (export "standard_scroll_arrows")
      (param $hwnd i32) (param $bar i32) (result i32)
    (call $scroll_arrow_mask
      (local.get $hwnd) (i32.ne (local.get $bar) (i32.const 0))))

  (func (export "dc_apply_client_clip") (param $hdc i32) (param $hwnd i32)
    (call $dc_apply_client_clip (local.get $hdc) (local.get $hwnd)))

  (func (export "dc_apply_client_erase_clip") (param $hdc i32) (param $hwnd i32)
    (call $dc_apply_client_erase_clip (local.get $hdc) (local.get $hwnd)))

  ;; Update geometry for a control (used by renderer to sync JS dimensions → WAT).
  (func (export "ctrl_set_geom") (param $hwnd i32) (param $x i32) (param $y i32) (param $w i32) (param $h i32)
    (local $idx i32)
    (local.set $idx (call $wnd_table_find (local.get $hwnd)))
    (if (i32.ne (local.get $idx) (i32.const -1))
      (then (call $ctrl_geom_set (local.get $idx)
              (local.get $x) (local.get $y) (local.get $w) (local.get $h)))))

  ;; Control class (1=Button, 2=Edit, 3=Static; 0 if not a control).
  (func (export "ctrl_get_class") (param $hwnd i32) (result i32)
    (call $ctrl_table_get_class (local.get $hwnd)))

  ;; --- Dialog record readers ---
  ;; The JS renderer reads dialog header fields from WND_DLG_RECORDS
  ;; after WAT populates them in $dlg_load. Everything is keyed by the
  ;; dialog HWND. x/y/cx/cy are raw dialog units (DLUs) from the template —
  ;; the renderer multiplies by dluX/dluY to convert to pixels.
  (func (export "dlg_get_key") (param $hwnd i32) (result i32)
    (local $rec i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (i32.load (local.get $rec)))
  (func (export "dlg_get_style") (param $hwnd i32) (result i32)
    (local $rec i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (i32.load offset=4 (local.get $rec)))
  (func (export "dlg_get_ex_style") (param $hwnd i32) (result i32)
    (local $rec i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (i32.load offset=8 (local.get $rec)))
  (func (export "dlg_get_x") (param $hwnd i32) (result i32)
    (local $rec i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (i32.load16_s offset=12 (local.get $rec)))
  (func (export "dlg_get_y") (param $hwnd i32) (result i32)
    (local $rec i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (i32.load16_s offset=14 (local.get $rec)))
  (func (export "dlg_get_cx") (param $hwnd i32) (result i32)
    (local $rec i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (i32.load16_s offset=16 (local.get $rec)))
  (func (export "dlg_get_cy") (param $hwnd i32) (result i32)
    (local $rec i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (i32.load16_s offset=18 (local.get $rec)))
  ;; Returns the WASM linear address of the dialog's ASCII title string,
  ;; or 0 if the template has no title. The guest heap is in linear
  ;; memory so $g2w is the JS-facing form.
  (func (export "dlg_get_title_wa") (param $hwnd i32) (result i32)
    (local $rec i32) (local $gptr i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (local.set $gptr (i32.load offset=20 (local.get $rec)))
    (if (i32.eqz (local.get $gptr)) (then (return (i32.const 0))))
    (call $g2w (local.get $gptr)))
  ;; Menu field from the template: integer ordinal, or guest ptr to an
  ;; ASCII string if the template named the menu. 0 = no menu. The
  ;; WNDCLASS.lpszMenuName path already handles both encodings.
  (func (export "dlg_get_menu") (param $hwnd i32) (result i32)
    (local $rec i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (i32.load offset=24 (local.get $rec)))
  ;; This dialog's base units, x | y<<16: measured from its DS_SETFONT
  ;; template font, else the stock 6x13 (Win16 8x16).
  (func (export "dlg_get_base_units") (param $hwnd i32) (result i32)
    (call $dialog_base_units (local.get $hwnd)))
  ;; Generic resource data accessor. Finds (type, name_id_or_str) and
  ;; returns the WASM linear address of the data payload; the size
  ;; sits in a WAT global readable via rsrc_last_size. Used by
  ;; gdi_load_bitmap to pull RT_BITMAP bytes without a JS pre-parse.
  (func (export "rsrc_find_data_wa") (param $type_id i32) (param $name_id i32) (result i32)
    (call $rsrc_find_data_wa (local.get $type_id) (local.get $name_id)))
  (func (export "rsrc_last_size") (result i32)
    (global.get $rsrc_last_size))
  ;; Existence check for a resource by (type, int id or guest str ptr).
  ;; Used by the renderer to decide whether a window has a menu resource
  ;; without a JS-side presence map.
  ;; "Does this module carry that resource?" — asked by the renderer before it
  ;; hangs a menu on a window. A 16-bit task keeps its resources in the NE
  ;; table, which the PE walker cannot see at all, so answering from
  ;; $find_resource alone told the renderer every Win16 app was menu-less.
  ;; The NAMEINFO id word the last NE resource scan matched. FindResource
  ;; keeps it so a resource named by string can be found again after the
  ;; caller's string is gone; a test needs it to check that round trip.
  (func (export "win16_res_found_id") (result i32)
    (global.get $win16_res_found_id))

  (func (export "rsrc_exists") (param $type_id i32) (param $name_id i32) (result i32)
    (if (global.get $code16)
      (then (return (i32.ne
        (call $win16_find_resource (local.get $type_id) (local.get $name_id))
        (i32.const 0)))))
    (i32.ne (call $find_resource (local.get $type_id) (local.get $name_id)) (i32.const 0)))

  (func (export "dlg_get_ctrl_count") (param $hwnd i32) (result i32)
    (local $rec i32)
    (local.set $rec (call $dlg_record_for_hwnd (local.get $hwnd)))
    (if (i32.eqz (local.get $rec)) (then (return (i32.const 0))))
    (i32.load offset=28 (local.get $rec)))

  ;; Control id from CONTROL_TABLE.
  (func (export "ctrl_get_id") (param $hwnd i32) (result i32)
    (call $ctrl_table_get_id (local.get $hwnd)))

  ;; Window style (also exposed for renderer drawing decisions).
  (func (export "wnd_get_style_export") (param $hwnd i32) (result i32)
    (call $wnd_get_style (local.get $hwnd)))

  (func (export "test_show_scroll_bar")
      (param $hwnd i32) (param $bar i32) (param $show i32) (result i32)
    (call $show_scroll_bar_core
      (local.get $hwnd) (local.get $bar) (local.get $show)))

  (func (export "test_enable_scroll_bar")
      (param $hwnd i32) (param $bar i32) (param $arrows i32) (result i32)
    (call $enable_scroll_bar_core
      (local.get $hwnd) (local.get $bar) (local.get $arrows)))

  ;; ButtonState text reader (parallel to get_edit_text).
  (func (export "button_get_text")
    (param $hwnd i32) (param $dest_guest i32) (param $max i32) (result i32)
    (local $state i32) (local $sw i32) (local $len i32) (local $src i32)
    (local.set $state (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $state)) (then (return (i32.const 0))))
    (local.set $sw (call $g2w (local.get $state)))
    (local.set $src (call $btn_text_ptr (local.get $sw)))
    (local.set $len (call $btn_text_len (local.get $sw)))
    (if (i32.le_u (local.get $max) (i32.const 0)) (then (return (i32.const 0))))
    (if (i32.ge_u (local.get $len) (local.get $max))
      (then (local.set $len (i32.sub (local.get $max) (i32.const 1)))))
    (if (local.get $src)
      (then (if (local.get $len)
              (then (call $memcpy (call $g2w (local.get $dest_guest))
                                  (call $g2w (local.get $src))
                                  (local.get $len))))))
    (i32.store8 (i32.add (call $g2w (local.get $dest_guest)) (local.get $len)) (i32.const 0))
    (local.get $len))

  ;; ButtonState flags: bit0=pressed bit1=checked bit2=default bit3=focused
  ;; bits 4..7 = button kind (0=push 1=checkbox 2=radio 3=groupbox).
  (func (export "button_get_flags") (param $hwnd i32) (result i32)
    (local $state i32)
    (local.set $state (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $state)) (then (return (i32.const 0))))
    (call $btn_flags (call $g2w (local.get $state))))

  ;; Wrapper around $wnd_destroy_tree for tests that need to tear down a
  ;; standalone dialog/control without going through find/about teardown.
  (func (export "wnd_destroy_tree") (param $hwnd i32)
    (call $wnd_destroy_tree (local.get $hwnd)))

  ;; Windows owned by a terminating thread do not survive that thread. Scan
  ;; the shared USER table and restart after each recursive teardown because
  ;; descendants can occupy any later slot.
  (func (export "wnd_destroy_thread_windows") (param $tid i32) (result i32)
    (local $slot i32) (local $ptr i32) (local $hwnd i32) (local $count i32)
    (block $done
      (loop $scan
        (br_if $done (i32.ge_u (local.get $slot) (global.get $MAX_WINDOWS)))
        (local.set $ptr (call $wnd_record_addr (local.get $slot)))
        (local.set $hwnd (load.field WndRecord hwnd (local.get $ptr)))
        (if (i32.and
              (i32.ne (local.get $hwnd) (i32.const 0))
              (i32.eq (i32.load (call $wnd_thread_addr (local.get $slot)))
                      (local.get $tid)))
          (then
            (call $wnd_destroy_recursive (local.get $hwnd))
            (local.set $count (i32.add (local.get $count) (i32.const 1)))
            (local.set $slot (i32.const 0))
            (br $scan)))
        (local.set $slot (i32.add (local.get $slot) (i32.const 1)))
        (br $scan)))
    (local.get $count))

  ;; Tear down a dialog frame without sending WM_DESTROY to the dialog proc.
  ;; DialogBoxParamA uses the same shape after EndDialog; modeless dialog
  ;; titlebar-close fallback uses this when the guest closes its children but
  ;; leaves the frame alive.
  (func (export "destroy_dialog_frame") (param $hwnd i32)
    (call $wnd_destroy_children (local.get $hwnd))
    (call $wnd_table_remove (local.get $hwnd))
    (call $host_destroy_window (local.get $hwnd)))

  ;; Open dialog: re-populate the listbox after a file upload completes.
  ;; JS calls this from the <input type="file"> change handler once the
  ;; new file has been written into the VFS, so the listbox shows it.
  (func (export "opendlg_refresh_listbox") (param $dlg i32)
    (local $dir_g i32) (local $copy_g i32)
    (local.set $dir_g (global.get $opendlg_current_dir))
    (if (i32.eqz (local.get $dir_g)) (then (return)))
    (local.set $copy_g (call $guest_strdup (local.get $dir_g)))
    (call $opendlg_set_dir (local.get $dlg) (local.get $copy_g))
    (call $heap_free (local.get $copy_g)))

  ;; Lookup the Nth basic color in the ChooseColor swatch grid. Used by
  ;; the renderer's class-6 draw branch so the grid can be painted
  ;; without duplicating the color table in JS.
  (func (export "colorgrid_color") (param $idx i32) (result i32)
    (call $colorgrid_color_for_idx (local.get $idx)))

  ;; Resolve a swatch through its control so tests can cover caller-owned
  ;; custom colors as well as the predefined table.
  (func (export "colorgrid_control_color") (param $hwnd i32) (param $idx i32) (result i32)
    (call $colorgrid_color_for_hwnd (local.get $hwnd) (local.get $idx)))

  ;; Current selection for a colorgrid hwnd (reads ColorGridState[0]).
  (func (export "colorgrid_get_sel") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<ColorGridState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const -1))))
    (local.set $sw (cast ptr<ColorGridState> (call $g2w (local.get $s))))
    (load.field ColorGridState sel_idx (local.get $sw)))

  ;; Test helper: build a Color dialog standalone (no x86 caller).
  (func (export "test_create_color_dialog") (result i32)
    (local $dlg i32) (local $cc i32) (local $custom i32)
    (local.set $cc (call $heap_alloc (i32.const 36)))
    (local.set $custom (call $heap_alloc (i32.const 64)))
    (i32.store offset=16 (call $g2w (local.get $cc)) (local.get $custom))
    ;; Give one custom box a distinctive value for interaction coverage.
    (i32.store offset=20 (call $g2w (local.get $custom)) (i32.const 0x00123456))
    (local.set $dlg (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $create_color_dialog (local.get $dlg) (i32.const 0) (local.get $cc))
    (local.get $dlg))

  (func (export "test_color_dialog_result") (param $dlg i32) (result i32)
    (local $cc i32)
    (local.set $cc (call $wnd_get_userdata (local.get $dlg)))
    (if (i32.eqz (local.get $cc)) (then (return (i32.const -1))))
    (i32.load offset=12 (call $g2w (local.get $cc))))

  ;; Test helper: build a Font dialog standalone (no x86 caller). Needs
  ;; a fake CHOOSEFONT guest ptr with at minimum lpLogFont at +0x0C so
  ;; the IDOK handler doesn't NPE on write-back.
  (func (export "test_create_font_dialog") (result i32)
    (local $dlg i32) (local $cf i32) (local $lf i32)
    (local.set $cf (call $heap_alloc (i32.const 64)))
    (local.set $lf (call $heap_alloc (i32.const 60)))
    (i32.store offset=12 (call $g2w (local.get $cf)) (local.get $lf))
    (local.set $dlg (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $create_font_dialog (local.get $dlg) (i32.const 0) (local.get $cf))
    (local.get $dlg))

  ;; Test helper: build an Open/Save dialog standalone (no x86 caller).
  ;; kind 0 = Open, 1 = Save As. Returns the dialog hwnd. Used by
  ;; scratch/render-open-dlg.js to render the dialog visually with
  ;; has_dom=1 so the upload/download button is included.
  (func (export "test_create_open_dialog") (param $kind i32) (result i32)
    (local $dlg i32)
    (local.set $dlg (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $create_open_dialog (local.get $dlg) (i32.const 0) (local.get $kind) (i32.const 0))
    (local.get $dlg))

  ;; Test helper: build a Find/Replace dialog standalone (no x86 caller).
  ;; FR struct guest ptr is allocated but unused by the dialog beyond
  ;; SetWindowLongPtr stash.
  (func (export "test_create_find_dialog") (result i32)
    (local $dlg i32) (local $fr i32)
    (local.set $fr (call $heap_alloc (i32.const 40)))
    (memory.fill (call $g2w (local.get $fr)) (i32.const 0) (i32.const 40))
    (i32.store (call $g2w (local.get $fr)) (i32.const 40))
    (local.set $dlg (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $create_findreplace_dialog (local.get $dlg) (i32.const 0) (local.get $fr) (i32.const 0))
    (local.get $dlg))

  ;; Test helper: build the Replace variant and expose its FINDREPLACE flags.
  ;; A standalone owner is unnecessary for validating WM_COMMAND flag assembly.
  (func (export "test_create_replace_dialog") (result i32)
    (local $dlg i32) (local $fr i32)
    (local.set $fr (call $heap_alloc (i32.const 40)))
    (memory.fill (call $g2w (local.get $fr)) (i32.const 0) (i32.const 40))
    (i32.store (call $g2w (local.get $fr)) (i32.const 40))
    (local.set $dlg (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $create_findreplace_dialog (local.get $dlg) (i32.const 0) (local.get $fr) (i32.const 1))
    (local.get $dlg))

  (func (export "test_findreplace_flags") (result i32)
    (local $fr i32)
    (local.set $fr (call $wnd_get_userdata (global.get $findreplace_dlg_hwnd)))
    (if (i32.eqz (local.get $fr)) (then (return (i32.const 0))))
    (i32.load offset=12 (call $g2w (local.get $fr))))

  ;; Test helper: create a parent + SysTreeView32 child, return tree hwnd.
  ;; This exercises the WAT-native TreeView wndproc without booting a guest EXE.
  (func (export "test_create_treeview")
    (param $x i32) (param $y i32) (param $w i32) (param $h i32) (param $style i32) (result i32)
    (local $parent i32) (local $tv i32)
    (global.set $tv_drag_anchor_y (i32.const 0))
    (global.set $tv_drag_anchor_row (i32.const 0))
    (global.set $tv_debug_expand_notify_count (i32.const 0))
    (global.set $tv_debug_expand_notify_code (i32.const 0))
    (global.set $tv_debug_expand_notify_action (i32.const 0))
    (global.set $tv_debug_expand_notify_item (i32.const 0))
    (global.set $tv_debug_expand_notify_children (i32.const 0))
    (local.set $parent (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $wnd_table_set (local.get $parent) (global.get $WNDPROC_CTRL_NATIVE))
    (drop (call $wnd_set_style (local.get $parent) (i32.const 0x80000000)))
    (local.set $tv (call $ctrl_create_child (local.get $parent) (i32.const 8) (i32.const 100)
                     (local.get $x) (local.get $y) (local.get $w) (local.get $h)
                     (i32.or (i32.const 0x50000000) (local.get $style)) (i32.const 0)))
    ;; The view state a bare export reads is the one belonging to the control
    ;; the test just made, so point the active owner at it.
    (global.set $tv_active_owner (local.get $tv))
    (call $tv_view_set_row (i32.const 0))
    (local.get $tv))

  ;; Where the item table lives and how far the walks go. Debug readers used to
  ;; hardcode both; the table has since moved and grown, and a hardcoded base
  ;; silently dumps an empty tree instead of failing.
  (func (export "treeview_get_table_base") (result i32)
    (global.get $TV_TABLE))
  (func (export "treeview_get_slot_limit") (result i32)
    (call $tv_slot_limit))

  (func (export "treeview_get_first_visible_row") (result i32)
    (call $tv_view_row))
  (func (export "treeview_get_visible_count") (result i32)
    (call $tv_visible_count))

  (func (export "treeview_has_selected_descendant") (param $hItem i32) (result i32)
    (local $slot i32)
    (local.set $slot (call $tv_find_slot (local.get $hItem)))
    (if (i32.eq (local.get $slot) (i32.const -1)) (then (return (i32.const 0))))
    (call $tv_has_selected_descendant
      (i32.add (global.get $TV_TABLE) (i32.mul (local.get $slot) (i32.const 32)))))
  (func (export "treeview_get_max_scroll") (param $hwnd i32) (result i32)
    (local $sz i32)
    (local.set $sz (call $ctrl_get_wh_packed (local.get $hwnd)))
    (call $tv_max_scroll_for_h (i32.shr_u (local.get $sz) (i32.const 16))))
  (func (export "treeview_get_debug_paint_visible") (result i32)
    (global.get $tv_debug_paint_visible))
  (func (export "treeview_get_debug_paint_text") (result i32)
    (global.get $tv_debug_paint_text))
  (func (export "treeview_get_debug_paint_iterations") (result i32)
    (global.get $tv_debug_paint_iterations))
  (func (export "treeview_get_debug_paint_last_y") (result i32)
    (global.get $tv_debug_paint_last_y))
  (func (export "treeview_get_debug_paint_rows") (result i32)
    (global.get $tv_debug_paint_rows))
  (func (export "treeview_get_debug_expand_notify_count") (result i32)
    (global.get $tv_debug_expand_notify_count))
  (func (export "treeview_get_debug_expand_notify_code") (result i32)
    (global.get $tv_debug_expand_notify_code))
  (func (export "treeview_get_debug_expand_notify_action") (result i32)
    (global.get $tv_debug_expand_notify_action))
  (func (export "treeview_get_debug_expand_notify_item") (result i32)
    (global.get $tv_debug_expand_notify_item))
  (func (export "treeview_get_debug_expand_notify_children") (result i32)
    (global.get $tv_debug_expand_notify_children))

  ;; Test helper: create a parent + SysListView32 child, return listview hwnd.
  ;; This exercises the WAT-native ListView wndproc without booting a guest EXE.
  (func (export "test_create_listview")
    (param $x i32) (param $y i32) (param $w i32) (param $h i32) (param $style i32) (param $ex_style i32) (result i32)
    (local $parent i32) (local $lv i32)
    (local.set $parent (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $wnd_table_set (local.get $parent) (global.get $WNDPROC_CTRL_NATIVE))
    (drop (call $wnd_set_style (local.get $parent) (i32.const 0x80000000)))
    (local.set $lv (call $ctrl_create_child (local.get $parent) (i32.const 18) (i32.const 100)
                     (local.get $x) (local.get $y) (local.get $w) (local.get $h)
                     (i32.or (i32.const 0x50000000) (local.get $style)) (i32.const 0)))
    (call $ctrl_set_ex_style (local.get $lv) (local.get $ex_style))
    (local.get $lv))

  ;; Test helper: create the same bounded ImageList struct used by the
  ;; COMCTL32 handlers, optionally backed by a bitmap strip.
  (func (export "test_create_imagelist")
    (param $cx i32) (param $cy i32) (param $bmp i32) (param $count i32) (param $mask i32) (result i32)
    (local $himl i32) (local $sw i32)
    (if (i32.le_s (local.get $cx) (i32.const 0))
      (then (local.set $cx (i32.const 16))))
    (if (i32.le_s (local.get $cy) (i32.const 0))
      (then (local.set $cy (local.get $cx))))
    (if (i32.lt_s (local.get $count) (i32.const 0))
      (then (local.set $count (i32.const 0))))
    (local.set $himl (call $heap_alloc (i32.const 24)))
    (local.set $sw (call $g2w (local.get $himl)))
    (call $zero_memory (local.get $sw) (i32.const 24))
    (i32.store        (local.get $sw) (local.get $cx))
    (i32.store offset=4  (local.get $sw) (local.get $cy))
    (i32.store offset=8  (local.get $sw) (i32.const -1)) ;; CLR_NONE
    (i32.store offset=12 (local.get $sw) (local.get $count))
    (i32.store offset=16 (local.get $sw) (local.get $bmp))
    (i32.store offset=20 (local.get $sw) (local.get $mask))
    (local.get $himl))

  ;; Test helper: create a parent + ToolbarWindow32 child, return toolbar hwnd.
  ;; This exercises the WAT-native ToolbarWindow32 wndproc without booting MFC.
  (func (export "test_create_toolbar")
    (param $x i32) (param $y i32) (param $w i32) (param $h i32) (param $style i32) (result i32)
    (local $parent i32) (local $tb i32)
    (local.set $parent (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $wnd_table_set (local.get $parent) (global.get $WNDPROC_CTRL_NATIVE))
    (drop (call $wnd_set_style (local.get $parent) (i32.const 0x80000000)))
    (local.set $tb (call $ctrl_create_child (local.get $parent) (i32.const 21) (i32.const 100)
                     (local.get $x) (local.get $y) (local.get $w) (local.get $h)
                     (i32.or (i32.const 0x50000000) (local.get $style)) (i32.const 0)))
    (local.get $tb))

  (func (export "test_class_name_to_ctrl_id") (param $class_name i32) (result i32)
    (call $class_name_to_ctrl_id (local.get $class_name)))

  (func (export "test_richedit_class_version") (param $class_name i32) (result i32)
    (call $richedit_class_version (local.get $class_name)))

  ;; Create the bounded WAT RichEdit fallback used when a guest requests a
  ;; RichEdit class without a usable native class proc. version=1 models
  ;; RICHEDIT/Riched32; all other values model RichEdit20A/W.
  (func (export "test_create_richedit")
    (param $version i32) (param $style i32) (param $text_g i32) (result i32)
    (local $parent i32)
    (local.set $parent (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $wnd_table_set (local.get $parent) (global.get $WNDPROC_CTRL_NATIVE))
    (drop (call $wnd_set_style (local.get $parent) (i32.const 0x80000000)))
    (call $ctrl_create_child
      (local.get $parent)
      (select (i32.const 24) (i32.const 25) (i32.eq (local.get $version) (i32.const 1)))
      (i32.const 100) (i32.const 0) (i32.const 0) (i32.const 320) (i32.const 200)
      (local.get $style) (local.get $text_g)))

  (func (export "listview_get_count") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<ListViewState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<ListViewState> (call $g2w (local.get $s))))
    (load.field ListViewState item_count (local.get $sw)))

  (func (export "listview_get_column_count") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<ListViewState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<ListViewState> (call $g2w (local.get $s))))
    (load.field ListViewState col_count (local.get $sw)))

  (func (export "listview_get_top_index") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<ListViewState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<ListViewState> (call $g2w (local.get $s))))
    (load.field ListViewState top_index (local.get $sw)))

  (func (export "listview_get_selected_index") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw ptr<ListViewState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const -1))))
    (local.set $sw (cast ptr<ListViewState> (call $g2w (local.get $s))))
    (load.field ListViewState selected_index (local.get $sw)))

  (func (export "listview_get_debug_notify_count") (result i32)
    (global.get $lv_debug_notify_count))
  (func (export "listview_get_debug_notify_code") (result i32)
    (global.get $lv_debug_notify_code))
  (func (export "listview_get_debug_notify_item") (result i32)
    (global.get $lv_debug_notify_item))
  (func (export "listview_get_debug_notify_old_state") (result i32)
    (global.get $lv_debug_notify_old_state))
  (func (export "listview_get_debug_notify_new_state") (result i32)
    (global.get $lv_debug_notify_new_state))

  (func (export "listview_get_visible_rows") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw i32) (local $sz i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (call $g2w (local.get $s)))
    (local.set $sz (call $ctrl_get_wh_packed (local.get $hwnd)))
    (call $lv_visible_rows_for_h (local.get $sw) (i32.shr_u (local.get $sz) (i32.const 16))))

  (func (export "listview_get_max_scroll") (param $hwnd i32) (result i32)
    (local $s i32) (local $sw i32) (local $sz i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (call $g2w (local.get $s)))
    (local.set $sz (call $ctrl_get_wh_packed (local.get $hwnd)))
    (call $lv_max_scroll_for_h (local.get $sw) (i32.shr_u (local.get $sz) (i32.const 16))))

  (func (export "listview_get_column_width") (param $hwnd i32) (param $idx i32) (result i32)
    (local $s i32) (local $sw ptr<ListViewState>)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<ListViewState> (call $g2w (local.get $s))))
    (if (i32.or (i32.lt_s (local.get $idx) (i32.const 0))
                (i32.ge_s (local.get $idx) (load.field ListViewState col_count (local.get $sw))))
      (then (return (i32.const 0))))
    (i32.load (i32.add (call $g2w (load.field ListViewState col_widths_ptr (local.get $sw))) (i32.mul (local.get $idx) (i32.const 4)))))

  (func (export "listview_get_item_text")
    (param $hwnd i32) (param $idx i32) (param $sub i32) (param $dest_guest i32) (param $max i32) (result i32)
    (local $s i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (call $lv_copy_cell_text (call $g2w (local.get $s))
      (local.get $idx) (local.get $sub) (local.get $dest_guest) (local.get $max)))

  ;; Test helper: create a parent dlg + listbox child, return listbox hwnd.
  ;; The parent is registered as WNDPROC_CTRL_NATIVE with no class tag (so
  ;; control_wndproc_dispatch returns 0 = DefWindowProc) and exists only so
  ;; the listbox child has a real parent. Used by test/test-listbox.js.
  (func (export "test_create_listbox")
    (param $x i32) (param $y i32) (param $w i32) (param $h i32) (result i32)
    (local $parent i32) (local $lb i32)
    (local.set $parent (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $wnd_table_set (local.get $parent) (global.get $WNDPROC_CTRL_NATIVE))
    (drop (call $wnd_set_style (local.get $parent) (i32.const 0x80000000)))
    (local.set $lb (call $ctrl_create_child (local.get $parent) (i32.const 4) (i32.const 100)
                     (local.get $x) (local.get $y) (local.get $w) (local.get $h)
                     (i32.const 0x50000000) (i32.const 0)))
    (local.get $lb))

  ;; ListBoxState readers — used by lib/renderer.js to draw the visible
  ;; rows + selection highlight without round-tripping LB_GETTEXT for every
  ;; row. State layout in $listbox_wndproc.
  (func (export "listbox_get_count") (param $hwnd i32) (result i32)
    (local $s i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (call $lb_count (call $g2w (local.get $s))))
  (func (export "listbox_get_cur_sel") (param $hwnd i32) (result i32)
    (local $s i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const -1))))
    (call $lb_cur_sel (call $g2w (local.get $s))))
  (func (export "listbox_get_sel") (param $hwnd i32) (param $idx i32) (result i32)
    (local $s i32) (local $sw i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (call $g2w (local.get $s)))
    (if (i32.or (i32.lt_s (local.get $idx) (i32.const 0))
                (i32.ge_s (local.get $idx) (call $lb_count (local.get $sw))))
      (then (return (i32.const 0))))
    (if (i32.eqz (call $lb_sel_ptr (local.get $sw)))
      (then (return (i32.eq (local.get $idx) (call $lb_cur_sel (local.get $sw))))))
    (i32.load8_u
      (i32.add (call $g2w (call $lb_sel_ptr (local.get $sw))) (local.get $idx))))
  (func (export "listbox_get_top_index") (param $hwnd i32) (result i32)
    (local $s i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (call $lb_top_index (call $g2w (local.get $s))))
  ;; Copy item $idx text into $dest_guest (NUL-terminated). Returns chars
  ;; copied (excluding NUL), or 0 if out of range. Same shape as
  ;; get_edit_text / button_get_text so the renderer can use the same
  ;; readText helper.
  (func (export "listbox_get_item_text")
    (param $hwnd i32) (param $idx i32) (param $dest_guest i32) (param $max i32) (result i32)
    (local $s i32) (local $sw i32) (local $count i32) (local $items_w i32)
    (local $p i32) (local $i i32) (local $slen i32) (local $dest_w i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (call $g2w (local.get $s)))
    (local.set $count (call $lb_count (local.get $sw)))
    (if (i32.or (i32.lt_s (local.get $idx) (i32.const 0))
                (i32.ge_s (local.get $idx) (local.get $count)))
      (then (return (i32.const 0))))
    (local.set $items_w (call $g2w (call $lb_items_ptr (local.get $sw))))
    (local.set $p (local.get $items_w))
    (local.set $i (i32.const 0))
    (block $found (loop $skip
      (br_if $found (i32.eq (local.get $i) (local.get $idx)))
      (local.set $p (i32.add (local.get $p)
                      (i32.add (call $strlen (local.get $p)) (i32.const 1))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $skip)))
    (local.set $slen (call $strlen (local.get $p)))
    (if (i32.le_u (local.get $max) (i32.const 0)) (then (return (i32.const 0))))
    (if (i32.ge_u (local.get $slen) (local.get $max))
      (then (local.set $slen (i32.sub (local.get $max) (i32.const 1)))))
    (local.set $dest_w (call $g2w (local.get $dest_guest)))
    (call $memcpy (local.get $dest_w) (local.get $p) (local.get $slen))
    (i32.store8 (i32.add (local.get $dest_w) (local.get $slen)) (i32.const 0))
    (local.get $slen))

  ;; Test helper: create a parent dlg + combobox child. Class index 5 is
  ;; ComboBox. $cbs_style ORs CBS_* (1=SIMPLE, 2=DROPDOWN, 3=DROPDOWNLIST)
  ;; into the window style. 0 → defaults to DROPDOWNLIST (matches WM_CREATE
  ;; fallback in $combobox_wndproc).
  (func (export "test_create_combobox")
    (param $x i32) (param $y i32) (param $w i32) (param $h i32) (param $cbs_style i32) (result i32)
    (local $parent i32) (local $cb i32)
    (local.set $parent (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    ;; Register parent dialog frame with renderer so back-canvas + paint
    ;; queue exist. (Title=0 means renderer uses an empty caption.) Same
    ;; pattern as $create_findreplace_dialog. nc kind=0.
    (call $host_register_dialog_frame
      (local.get $parent) (i32.const 0)
      (i32.const 0)
      (i32.const 320) (i32.const 200)
      (i32.const 0))
    (call $wnd_table_set (local.get $parent) (global.get $WNDPROC_CTRL_NATIVE))
    (drop (call $wnd_set_style (local.get $parent) (i32.const 0x80000000)))
    (local.set $cb (call $ctrl_create_child (local.get $parent) (i32.const 5) (i32.const 100)
                     (local.get $x) (local.get $y) (local.get $w) (local.get $h)
                     (i32.or (i32.const 0x50000000) (local.get $cbs_style)) (i32.const 0)))
    (local.get $cb))

  ;; Test helper: create a parent + tooltip window. Tooltips are usually
  ;; popup-style owned windows, but routing through a WAT-native control class
  ;; is enough for exercising TTM_* message behavior.
  (func (export "test_create_tooltip") (result i32)
    (local $parent i32) (local $tt i32)
    (local.set $parent (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (global.get $next_hwnd) (i32.const 1)))
    (call $wnd_table_set (local.get $parent) (global.get $WNDPROC_CTRL_NATIVE))
    (drop (call $wnd_set_style (local.get $parent) (i32.const 0x80000000)))
    (local.set $tt (call $ctrl_create_child (local.get $parent) (i32.const 20) (i32.const 0)
                     (i32.const 0) (i32.const 0) (i32.const 0) (i32.const 0)
                     (i32.const 0x80000000) (i32.const 0)))
    (local.get $tt))

  ;; ComboBoxState readers for tests.
  (func (export "combobox_get_cur_sel") (param $hwnd i32) (result i32)
    (local $s i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const -1))))
    (call $cb_cur_sel (call $g2w (local.get $s))))

  (func (export "combobox_is_dropped") (param $hwnd i32) (result i32)
    (local $s i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (call $cb_is_dropped (call $g2w (local.get $s))))

  (func (export "combobox_get_lb_hwnd") (param $hwnd i32) (result i32)
    (local $s i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (call $cb_lb_hwnd (call $g2w (local.get $s))))

  (func (export "combobox_get_popup_hwnd") (param $hwnd i32) (result i32)
    (local $s i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (call $cb_popup_hwnd (call $g2w (local.get $s))))

  (func (export "combobox_get_edit_hwnd") (param $hwnd i32) (result i32)
    (local $s i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (call $cb_edit_hwnd (call $g2w (local.get $s))))

  (func (export "combobox_get_text")
    (param $hwnd i32) (param $dest_guest i32) (param $max i32) (result i32)
    (local $s i32) (local $sw i32) (local $len i32) (local $src i32)
    (local.set $s (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $s)) (then (return (i32.const 0))))
    (local.set $sw (call $g2w (local.get $s)))
    (local.set $src (call $cb_text_ptr (local.get $sw)))
    (local.set $len (call $cb_text_len (local.get $sw)))
    (if (i32.le_u (local.get $max) (i32.const 0)) (then (return (i32.const 0))))
    (if (i32.ge_u (local.get $len) (local.get $max))
      (then (local.set $len (i32.sub (local.get $max) (i32.const 1)))))
    (if (local.get $src)
      (then (if (local.get $len)
              (then (call $memcpy (call $g2w (local.get $dest_guest))
                                  (call $g2w (local.get $src))
                                  (local.get $len))))))
    (i32.store8 (i32.add (call $g2w (local.get $dest_guest)) (local.get $len)) (i32.const 0))
    (local.get $len))

  ;; StaticState text reader (StaticState layout matches ButtonState for the
  ;; first two fields: text_buf_ptr / text_len).
  (func (export "static_get_text")
    (param $hwnd i32) (param $dest_guest i32) (param $max i32) (result i32)
    (local $state i32) (local $sw i32) (local $len i32) (local $src i32)
    (local.set $state (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $state)) (then (return (i32.const 0))))
    (local.set $sw (call $g2w (local.get $state)))
    (local.set $src (call $static_text_ptr (local.get $sw)))
    (local.set $len (call $static_text_len (local.get $sw)))
    (if (i32.le_u (local.get $max) (i32.const 0)) (then (return (i32.const 0))))
    (if (i32.ge_u (local.get $len) (local.get $max))
      (then (local.set $len (i32.sub (local.get $max) (i32.const 1)))))
    (if (local.get $src)
      (then (if (local.get $len)
              (then (call $memcpy (call $g2w (local.get $dest_guest))
                                  (call $g2w (local.get $src))
                                  (local.get $len))))))
    (i32.store8 (i32.add (call $g2w (local.get $dest_guest)) (local.get $len)) (i32.const 0))
    (local.get $len))

  ;; GDI table occupancy. The DC-state and object tables are fixed-size arrays,
  ;; and running one dry does not announce itself: GetDC starts
  ;; returning NULL and the app converts that into whatever its own error path
  ;; is (MFC throws CResourceException, which lands as an unhandled C++ throw
  ;; several thousand instructions away from the leak). These are pure reads of
  ;; the same words the allocators scan, so a census costs nothing but a walk.
  (func (export "gdi_dc_state_used") (result i32)
    (local $i i32) (local $n i32)
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (global.get $GDI_DC_STATE_COUNT)))
      (if (i32.load (i32.add (global.get $GDI_DC_STATE_TABLE)
            (i32.mul (local.get $i) (global.get $GDI_DC_STATE_STRIDE))))
        (then (local.set $n (i32.add (local.get $n) (i32.const 1)))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (local.get $n))

  (func (export "gdi_dc_state_capacity") (result i32)
    (global.get $GDI_DC_STATE_COUNT))

  (func (export "gdi_object_used") (result i32)
    (local $i i32) (local $n i32)
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (global.get $GDI_OBJECT_COUNT)))
      (if (i32.load (i32.add (global.get $GDI_OBJECT_TABLE)
            (i32.mul (local.get $i) (global.get $GDI_OBJECT_STRIDE))))
        (then (local.set $n (i32.add (local.get $n) (i32.const 1)))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (local.get $n))

  (func (export "gdi_object_capacity") (result i32)
    (global.get $GDI_OBJECT_COUNT))

  ;; DIB backing arena occupancy. $kind: 0 = used pages, 1 = free pages,
  ;; 2 = largest free contiguous run, 3 = total pages. A screen-sized overlay
  ;; needs one contiguous run, so kind 1 >> kind 2 means fragmentation, not
  ;; exhaustion.
  (func (export "gdi_dib_arena_stat") (param $kind i32) (result i32)
    (local $i i32) (local $used i32) (local $run i32) (local $best i32)
    (if (i32.eq (local.get $kind) (i32.const 3))
      (then (return (global.get $DIB_PAGE_COUNT))))
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $i) (global.get $DIB_PAGE_COUNT)))
      (if (i32.load8_u (i32.add (global.get $DIB_PAGE_USED) (local.get $i)))
        (then
          (local.set $used (i32.add (local.get $used) (i32.const 1)))
          (local.set $run (i32.const 0)))
        (else
          (local.set $run (i32.add (local.get $run) (i32.const 1)))
          (if (i32.gt_u (local.get $run) (local.get $best))
            (then (local.set $best (local.get $run))))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $scan)))
    (if (i32.eqz (local.get $kind)) (then (return (local.get $used))))
    (if (i32.eq (local.get $kind) (i32.const 1))
      (then (return (i32.sub (global.get $DIB_PAGE_COUNT) (local.get $used)))))
    (local.get $best))

  ;; slot 0 = clip table, 1 = system clip table, 2 = DC state table.
  (func (export "gdi_table_mark") (param $slot i32) (result i32)
    (if (i32.ge_u (local.get $slot) (i32.const 4)) (then (return (i32.const -1))))
    (i32.load (i32.add (global.get $GDI_TABLE_MARKS)
      (i32.shl (local.get $slot) (i32.const 2)))))

  ;; The shutting-down (0), safe-to-turn-off (1) and its footered form (2), painted by GDI
  ;; into a 320x400 32bpp DIB; returns the linear address of the pixels or 0.
  (func (export "paint_power_screen") (param $kind i32) (result i32)
    (call $paint_power_screen (local.get $kind)))

  (func (export "static_get_image_ordinal") (param $hwnd i32) (result i32)
    (local $state i32) (local $sw ptr<StaticState>)
    (local.set $state (call $wnd_get_state_ptr (local.get $hwnd)))
    (if (i32.eqz (local.get $state)) (then (return (i32.const 0))))
    (local.set $sw (cast ptr<StaticState> (call $g2w (local.get $state))))
    (load.field StaticState image_ord (local.get $sw)))

  ;; NO closing paren for `(module` here — this fragment is self-balanced.
  ;; See the banner at the top of src/01-header.wat.

  (func (export "get_dx_display_palette_wa") (result i32) (call $dx_present_pal_get))
