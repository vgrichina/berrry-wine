from work import *
assert (O/'guest-attempt.json').exists()
inventory=py('''import pathlib,json,hashlib
h=pathlib.Path(ROOT);files=[p for p in (h/'guest').rglob('*') if p.is_file()]+[h/n for n in ['preflight.json','tree-validation.json.gz','immediate-locked-gate.json'] if (h/n).exists()]
print(json.dumps([dict(path=str(p.relative_to(h)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]))'''.replace('ROOT',repr(R)))
save('guest-artifact-inventory-api.json',inventory);rows=json.loads(inventory['stdout']);save('guest-artifact-inventory.json',rows)
for row in rows:
 assert row['bytes']<=(2097152 if row['path'].endswith('.png') else 262144),row
 target=REPO/E/'startup.png' if row['path'].endswith('.png') else O/'retained'/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('wb') as f:
  for off in range(0,row['bytes'],18000):
   reply=py('import base64;f=open('+repr(R+'/'+row['path'])+',"rb");f.seek('+str(off)+');print(base64.b64encode(f.read(18000)).decode())')
   f.write(base64.b64decode(reply['stdout'].strip()))
  f.flush();os.fsync(f.fileno())
 assert target.stat().st_size==row['bytes'] and sha(target.read_bytes())==row['sha256']
png=next((x for x in rows if x['path'].endswith('.png')),None)
if png:
 save('png-remote-retirement.json',py('import pathlib,hashlib,json;p=pathlib.Path('+repr(R+'/'+png['path'])+');assert hashlib.sha256(p.read_bytes()).hexdigest()=='+repr(png['sha256'])+';p.unlink();print(json.dumps(dict(retiredAfterDurableLocal=True,sha256='+repr(png['sha256'])+')))'))
save('cleanup-api.json',py('''import pathlib,json,subprocess,fcntl
h=pathlib.Path(ROOT);ps=subprocess.check_output(['ps','-eo','pid,comm,args'],text=True);native=[l for l in ps.splitlines() if any(n in l.split()[1:2] for n in ['node','d8','js','wasmtime','wine'])]
f=open('/tmp/wine-qualification-heavy.lock','a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
print(json.dumps(dict(nativeProcesses=native,heavyLockReleased=True,guestDirectory=str(h/'guest'),terminalExists=(h/'guest/terminal.json').exists())))'''.replace('ROOT',repr(R))))
assert not json.loads(jread('cleanup-api.json')['stdout'])['nativeProcesses']
box=subprocess.run(['boat','--no-update','--json','info',BOX],capture_output=True,text=True,check=True);save('box-handback.json',json.loads(box.stdout))
save('checkpoint-collected.json',dict(phase='COLLECTED',guestAttempts=1,png=png,remaining=['inspect evidence','publish report on exact task branch','handback running box']))
print(json.dumps(rows))
