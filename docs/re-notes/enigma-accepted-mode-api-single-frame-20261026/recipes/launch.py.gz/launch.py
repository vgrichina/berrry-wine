from work import *
import datetime
assert (O/'checkpoint-validated.json').exists()
assert not (O/'guest-attempt.json').exists(),'one guest only'
schedule=json.loads(pathlib.Path(str(L)+'.task.runtime.json').read_text());cutoff=datetime.datetime.fromisoformat(schedule['guestCutoff'].replace('Z','+00:00')).timestamp()
assert time.time()<cutoff
info=py('''import pathlib,json,os,shutil,importlib.util,subprocess
h=pathlib.Path(ROOT);spec=importlib.util.spec_from_file_location('s',h/'bounded-staging.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
ps=subprocess.check_output(['ps','-eo','pid,comm,args'],text=True)
native=[l for l in ps.splitlines() if any(n in l.split()[1:2] for n in ['node','d8','js','wasmtime','wine'])]
print(json.dumps(dict(uid=os.getuid(),free=shutil.disk_usage('/tmp').free,memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024,materialized=s.inventory(h)['physicalOwnedBytes'],nativeProcesses=native,largest=max(p.stat().st_size for p in h.rglob('*') if p.is_file()))))'''.replace('ROOT',repr(R)))
save('resource-immediate-api.json',info);save('remote-admission.json',info);ri=json.loads(info['stdout'])
assert ri['uid']==1000 and ri['memAvailable']>=2684354560 and ri['largest']<=25165824 and not ri['nativeProcesses'],ri
a=admission('immediate-before-guest',ri['materialized']+2293760+16384)
env=jread('next-env.json');assert env['ENIGMA_CAPTURE_PROFILE']=='single-frame' and env['ENIGMA_LOSSLESS_CAPTURE']=='1'
locked='''import pathlib,os,json,time,shutil,hashlib,sys,resource,subprocess
h=pathlib.Path(ROOT)
mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;free=shutil.disk_usage('/tmp').free
ps=subprocess.check_output(['ps','-eo','pid,comm,args'],text=True);native=[l for l in ps.splitlines() if any(n in l.split()[1:2] for n in ['node','d8','js','wasmtime','wine'])]
j=dict(at=time.time(),host=BOX,memAvailable=mem,threshold=2684354560,free=free,projectedPeak=PEAK,lock='/tmp/wine-qualification-heavy.lock',uid=os.getuid(),kernelArtifactLimit=2097152,combinedOutputLimit=131072,inheritedFileLimit=resource.getrlimit(resource.RLIMIT_FSIZE),inheritedDataLimit=resource.getrlimit(resource.RLIMIT_DATA),nativeProcesses=native)
(h/'immediate-locked-gate.json').write_text(json.dumps(j))
assert mem>=2684354560 and free-PEAK>=2982150144 and os.getuid()==1000 and not native
assert resource.getrlimit(resource.RLIMIT_FSIZE)[1] in (-1,resource.RLIM_INFINITY) or resource.getrlimit(resource.RLIMIT_FSIZE)[1]>=2097152
assert resource.getrlimit(resource.RLIMIT_DATA)[1] in (-1,resource.RLIM_INFINITY),'Git-only DATA limit must not reach Node'
assert time.time()<CUTOFF
assert hashlib.sha256((h/'supervise.py').read_bytes()).hexdigest()==PIN
assert not (h/'guest').exists()
os.execv(sys.executable,[sys.executable,str(h/'supervise.py'),'guest'])
'''.replace('ROOT',repr(R)).replace('BOX',repr(BOX)).replace('PEAK',str(a['peak'])).replace('CUTOFF',str(cutoff)).replace('PIN',repr(jread('supervisor-identity.json')['deployed']))
encoded=base64.b64encode(locked.encode()).decode();py('import base64,pathlib;pathlib.Path('+repr(R+'/launch-locked.py')+').write_bytes(base64.b64decode('+repr(encoded)+'))')
cmd='flock -n -E 73 /tmp/wine-qualification-heavy.lock env '+' '.join(shlex.quote(k+'='+v) for k,v in env.items())+' python3 '+shlex.quote(R+'/launch-locked.py')
save('guest-attempt.json',dict(at=time.time(),guestAttempts=1,command=cmd,box=BOX,configuration='actual FTQ/TFQ then unchanged original capture; accepted single-frame',limits='original max10000000/55s; first/only PNG30000 fixed640x480',localGate=a,remoteGate=ri))
save('guest-supervisor-api.json',remote(cmd,75,allow_exit=True))
print('ONE ATTEMPT FINISHED')
