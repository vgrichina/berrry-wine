from work import *
assert (O/'checkpoint-staged.json').exists()
verify='''import pathlib,json,gzip,hashlib,stat,os,importlib.util
h=pathlib.Path(ROOT);m=json.loads(gzip.decompress((h/'manifest.json.gz').read_bytes()));modes=json.loads((h/'modes.json').read_text())
spec=importlib.util.spec_from_file_location('s',h/'bounded-staging.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
fontkeys={};ordinary=set();fontinodes=set();fonts=0
for x,mode in zip(m,modes):
 p=h/x['target'];st=p.lstat();assert stat.S_ISREG(st.st_mode),x['target'];assert p.stat().st_size==x['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],x['target']
 inode=st.st_dev,st.st_ino
 if s.font(x['target']):
  fonts+=1;assert stat.S_IMODE(st.st_mode)==0o444 and not os.access(p,os.W_OK),x['target'];key=x['bytes'],x['sha256']
  assert key not in fontkeys or fontkeys[key]==inode; fontkeys[key]=inode;fontinodes.add(inode)
 else:
  assert stat.S_IMODE(st.st_mode)==mode and inode not in ordinary and inode not in fontinodes,x['target'];ordinary.add(inode)
assert not ordinary.intersection(fontinodes)
probe=h/'ordinary-write-probe';probe.write_bytes(b'ordinary-user');assert probe.read_bytes()==b'ordinary-user';probe.unlink()
print(json.dumps(dict(passHash=True,files=len(m),bytes=sum(x['bytes'] for x in m),ordinaryUnique=len(ordinary),immutableFontPaths=fonts,immutableFontBlobs=len(fontkeys),allModesMatch=True,specialBitsAbsent=True,noMutableAliases=True,ordinaryUserWrite=True,inventory=s.inventory(h))))
'''.replace('ROOT',repr(R))
save('remote-rehash-mode-api.json',py(verify,60))
save('preflight-api.json',remote('cd '+shlex.quote(R)+' && python3 preflight.py',70))
save('tree-validation-api.json',remote('cd '+shlex.quote(R)+' && node --max-old-space-size=256 validate-tree.cjs',60))
# Reuse the accepted real-recipe dependency/sibling/supervisor check verbatim,
# adapting only owned configuration paths and receipt access.
text=(REC/'stage-and-validate.py').read_text();start=text.index("code='''const fs=");end=text.index("info=json.loads",start)
code=text[start:end].replace("json.load(open(H/'standing-identities.json'))","jread('standing-identities.json')").replace("json.load(open(H/'supervisor-identity.json'))","jread('supervisor-identity.json')")
exec(compile(code,str(O/'validate.py'),'exec'))
save('checkpoint-validated.json',dict(phase='DESTINATION_VALIDATED',remaining=['consolidated preguest gate under lock','ONE guest','collect inspect publish'],guestAttempts=0))
print('DESTINATION VERIFIED hash/mode/alias/providers/dependencies/canonical parser/supervisor')
