from work import *
import gzip
dest=REPO/E;dest.mkdir(parents=True,exist_ok=True)
excluded={'messageboard-watch.log','messageboard-watch.pid','messageboard-watch-closeout.log','messageboard-watch-closeout.pid'}
for p in O.iterdir():
 if p.is_file() and p.name not in excluded and p.suffix in ['.json','.jsonl','.log']:
  data=p.read_bytes()
  if len(data)>32768:(dest/(p.name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
  else:(dest/p.name).write_bytes(data)
for p in (O/'retained').rglob('*'):
 if p.is_file():
  target=dest/'runtime'/p.relative_to(O/'retained');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
recipes=dest/'recipes';recipes.mkdir(exist_ok=True)
for p in O.iterdir():
 if p.suffix in ['.py','.cjs']:(recipes/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for name in ['root-ref-digest.json']:(dest/name).write_bytes((L/name).read_bytes())
(dest/'runtime-schedule.json').write_bytes(pathlib.Path(str(L)+'.task.runtime.json').read_bytes())
# Preserve the earlier actual resource rejection without relabeling it as a run.
prior=pathlib.Path('/tmp/enigma-api-single-frame-startup-oct26/repo/docs/re-notes/enigma-api-single-frame-startup-20261026')
for name in ['first-failure.json','resource-ready.json']:
 if (prior/name).exists():(dest/('historical-'+name)).write_bytes((prior/name).read_bytes())
report='''# Enigma diagnostic startup: one accepted frame

One authentic-unpacked diagnostic startup produced an accepted lossless 640×480 PNG. Visual inspection shows the Enigma v1.01 title bar, logo, marble background and **Loading Enigma levels**. No menu or gameplay is visible. This is neither packed-original nor gameplay acceptance.

`startup.png`: 413407 bytes, SHA-256 `b876992c5035e22563a9a2c9ed87bda8d3ab381bc7b55974050d6205b8933be9`. `visual-inspection.json` binds decoded RGBA identity and observations. The unchanged original batch30000 capture was the only PNG; the original bounded run continued to max-seconds55, batch97160, 4185821 API calls. Supervisor exited0 naturally after55.3866s, retained60868 combined output bytes, and reported no remaining process group. Cleanup independently found no native processes and reacquired the heavy lock. No second guest, build, acquisition, semantic repair or accepted-test replay occurred.

The output records eight native provider loads and dependency patches, accesses to compat.lua/startup.lua/enigma_conf.lua/models Lua files and assets. No crash, unimplemented-handler or Lua-error diagnostic was observed. The four original count addresses all remained zero. Absence of a diagnostic does not establish Lua correctness or menu completion. Read `runtime/guest/output.log` for exact observations.

The accepted helper `d3b2a9c152de0a7cfbe61facf1d847d6192e4bd399e1638091417070ffdb1f3b` staged all2659 manifest entries/37476538 logical bytes through bounded API segments and one FIFO, with no full tar or local asset copy. Accepted-helper staging measured42942464 physical bytes; projected target42893312 plus131072 slack covered the49152 difference. All source bytes/modes were revalidated. Full destination hash checks passed; 2587 ordinary files have separate inodes, and72 immutable font paths share43 blobs with0444 modes and ordinary-user writes rejected. Special bits are absent. Every ordinary source mode matches independently of umask. Actual canonical parser/tree enumeration validates2460 VFS files including commas, eight provider arguments,512MiB arena and --no-build. Destination preflight, provider dependencies, font/capture sibling resolution and complete accepted supervisor composition passed. Retained accepted staging/capture test receipts were reused.

This resumes predecessor session01a1774a-c888-7d40-a854-272d790541ac at PREPARED after its provider-capacity exit1 before staging/guest. Its branch and artifacts remain. Preparation was not rerun. `predecessor-provider-interruption.json` preserves the original provider errors. One ordinary internal CLI error (--timeout incompatible with --detach) was retained and corrected before streaming; it was not an API access/resource rejection. No model switch or provider retry occurred in this continuation. Actual current gpt-6.1-sol medium/200000 total runtime argv and session are in launch-closeout.json; predecessor argv remains in launch.json.

The fresh preguest combined incremental projection was66473984/67108864 (margin634880), including all retained local task bytes, both launcher/session charges, positive SQLite/WAL highwater once, future growth once, remote payload/metadata/PNG/output, bounded transport and8MiB reserve. Both hosts satisfied disk-floor2982150144 after projected growth. Local MemAvailable3698089984 left3144441856 after aggregate512MiB client+16MiB helper allowance. Under the heavy lock remote MemAvailable7358595072 exceeded2684354560; fixed512MiB arena+512MiB Node heap, CPU90 and wall60 remained. Node inherited unlimited DATA, preserving its V8 CodeRange; Git alone uses DATA512MiB, one thread and its separately admitted client allowance. The locked gate and all component charges are retained. PNG transfer was hashed/fsynced locally before remote PNG retirement; its peak remains charged. Publication admission separately includes future Git PNG/compression and evidence allowance. Historical67547136/67108864 rejection remains historical, not fresh admission or runtime evidence.

Exact source manifest SHA-256:4ccbdd4e9bab80a88bf9565f813681c5369e4b16ef5dcd34291b87c361a793fe. Standing module SHA-256:8fac39936b6df2418ad86cab118cef19a65a727f649fbc14c412b37818904686,1879746 bytes; historical source b41a7c5f4b752d1f0bdab1141a11d4fed4dc6f9a,ABI291,layout9a3bc9149d58209c. This is explicitly a historical closure, not a current-main binary claim. Canonical run.js revisiond8cd8c54c8d63c107696f1e4ef7a1e229dcadc1e, SHA-2564d7b9587676db38fcf3314807acb2b2a42b5f09d2c98fcf3dccb8a6cde9e1809. Accepted helper/source identities and all recipes are retained. Standing readonly donor/executables were executed in place; no main publication or root/donor edits occurred beyond append-only messageboard entries.

Publication branch: `task/enigma-retained-api-single-frame-closeout-oct26`, based on accepted source ef10196a82eaad6d374617fc4a08f108487d264a. Publish only this evidence branch using the supplied trusted SSH configuration, force-add and verify the PNG as a real Git blob, and verify exact remote ref. The coordinator owns integration and lifecycle.

Handback box `bx_h44cmz3t` remains running/idle, healthy; expiry2026-10-26T09:48:43.654Z. Worker did not stop/delete/resume it. Coordinator shutdown09:20UTC; guest cutoff09:00UTC and handback09:10UTC. Heavy ownership is released after cleanup; no further guest is authorized by this task. Result: accepted diagnostic loading-screen frame; menu/gameplay/Lua correctness remain unqualified.
'''
(dest/'REPORT.md').write_text(report)
manifest={str(p.relative_to(dest)):dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in dest.rglob('*') if p.is_file() and p.name!='evidence-manifest.json'}
(dest/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PACKAGED',len(manifest))
