from work import *
import math,stat,gzip
if not (O/'sqlite-baseline.json').exists():save('sqlite-baseline.json',{str(p):allocated(p) for p in pathlib.Path('/home/user/.codex').glob('*sqlite*')})
argv=[x.decode() for x in pathlib.Path('/proc/2325534/cmdline').read_bytes().split(b'\0') if x]
for value in ['gpt-6.1-sol','model_reasoning_effort="medium"','model_auto_compact_token_limit=200000','model_auto_compact_token_limit_scope="total"']:assert value in argv
save('launch.json',dict(pid=2325534,session=json.loads((L/'events.jsonl').open().readline())['thread_id'],actual=True,argv=argv))
manifest=(P/'manifest.json').read_bytes();assert sha(manifest)=='4ccbdd4e9bab80a88bf9565f813681c5369e4b16ef5dcd34291b87c361a793fe'
m=json.loads(manifest);assert len(m)==2659 and sum(x['bytes'] for x in m)==37476538
spec=importlib.util.spec_from_file_location('staging',D/'tools/enigma-bounded-staging.py');staging=importlib.util.module_from_spec(spec);spec.loader.exec_module(staging)
assert sha(pathlib.Path(spec.origin).read_bytes())=='d3b2a9c152de0a7cfbe61facf1d847d6192e4bd399e1638091417070ffdb1f3b'
modes=[None if staging.font(x['target']) else staging.regular_mode(x) for x in m]
save('source-modes.json',dict(manifestSHA256=sha(manifest),modes=modes,queryHelperSHA256=sha(pathlib.Path(spec.origin).read_bytes()),ordinarySourceMetadataReadOnly=True,specialBitsStripped=True))
seen=set();dirs={''};files=0;path_files=0
for x in m:
 dirs.update(str(p) for p in pathlib.PurePosixPath(x['target']).parents if str(p)!='.')
 n=math.ceil(x['bytes']/4096)*4096;path_files+=n;key=x['bytes'],x['sha256']
 if not staging.font(x['target']) or key not in seen:files+=n
 if staging.font(x['target']):seen.add(key)
target=files+len(dirs)*4096
# Separate maxima: staging metadata/pipe versus the later single PNG/output.
# All staged payloads, including immutable aliases, are physically charged.
save('projection.json',dict(manifestSHA256=sha(manifest),entries=len(m),logicalBytes=sum(x['bytes'] for x in m),uniqueFontBlobs=len(seen),pathFileAllocation=path_files,uniqueFileAllocation=files,directories=len(dirs),targetAllocation=target,directorySlack=131072,remoteMetadataAndHelpers=524288,remoteGuestPNGAndOutput=2097152+131072+65536,remotePeak=target+131072+524288+2097152+131072+65536,transport='bounded in-memory API segments -> FIFO -> accepted helper; zero full transport tree; actual source bytes all verified',standingSourcesReadOnly=True))
save('remote-admission.json',py('import os,json,pathlib,shutil;print(json.dumps(dict(uid=os.getuid(),free=shutil.disk_usage("/tmp").free,memAvailable=int(pathlib.Path("/proc/meminfo").read_text().split("MemAvailable:")[1].split()[0])*1024)))'))
admission('precheckout')
accepted=pathlib.Path('/tmp/enigma-accepted-lossless-startup-oct24')
args=[x.replace(str(P),R) for x in json.loads((accepted/'guest-args.json').read_text())]
if '--quiet-fs' not in args:args.append('--quiet-fs')
assert args.count('--no-build')==1 and len([x for x in args if x.startswith('--input=')])==1
assert '--input=30000:png:'+R+'/guest/startup.png' in args
source=payload(m[0]);assert sha(source)=='4d7b9587676db38fcf3314807acb2b2a42b5f09d2c98fcf3dccb8a6cde9e1809'
text=source.decode();parser=text[text.index('const getArg ='):text.index('// Was `--name=...`')]
code='const assert=require("assert"),args='+json.dumps(args[7:])+';'+parser+';assert.deepEqual(getArgs("vfs-tree"),['+json.dumps(R+'/vfs')+']);assert.equal(getArgs("vfs-mount").length,0);assert.equal(getArgs("dlls").length,8);assert(hasFlag("no-build"));assert(hasFlag("quiet-fs"));console.log("PASS exact argv canonical parser")'
pr=subprocess.run(['node','--max-old-space-size=256','-e',code],capture_output=True,text=True,timeout=60)
save('precheckout-parser.json',dict(status=pr.returncode,stdout=pr.stdout,stderr=pr.stderr,argv=args,parserSHA256=sha(parser.encode()),enumeration=[x['target'] for x in m if x['target'].startswith('vfs/')],commaFilenames=[x['target'] for x in m if ',' in x['target']]))
assert pr.returncode==0
refs=git('ls-remote',URL,'refs/heads/main','refs/heads/'+BRANCH,repo=D);save('trusted-donor.json',dict(ssh=SSH,remote=refs,donor=str(D),revision=C));assert refs.splitlines()==[C+'\trefs/heads/main']
pins=json.loads((accepted/'standing-identities.json').read_text())['acceptedPaths']
pins.update({'tools/enigma-bounded-staging.py':'d3b2a9c152de0a7cfbe61facf1d847d6192e4bd399e1638091417070ffdb1f3b','tools/lossless-capture-png.cjs':'9dae92170fbf4ef5acf0a2b0be43b93d3b3a7c8ec86f227df708d3b65d67cb4b','tools/enigma-terminal-capture-guard.cjs':'56399047e54417b7968944639831b2a5268ebb87ea57a64833d8dd1f0fb4384c','tools/enigma-supervisor-output.py':'2d8e66d5e0c42513a6b21b62e897fccaa152c54b93d4e68e5e5595b8b3350d9a'})
roots=[];seen=set()
def add(p):
 p=p.resolve()
 if str(p) in seen:return
 seen.add(str(p));roots.append(str(p));f=p/'info/alternates'
 if f.exists():
  for line in f.read_text().splitlines():q=pathlib.Path(line);add(q if q.is_absolute() else p/q)
add(D/'.git/objects');git('init','-q',str(REPO),repo=H)
(REPO/'.git/objects/info/alternates').write_text('\n'.join(roots)+'\n')
for k,v in [('core.sparseCheckout','true'),('core.sparseCheckoutCone','false'),('user.name','Wine Ops'),('user.email','wine-ops@local'),('core.sshCommand',SSH),('gc.auto','0')]:git('config',k,v)
(REPO/'.git/info/sparse-checkout').write_text('\n'.join('/'+p for p in pins)+'\n/'+E+'/\n')
git('checkout','-qb',BRANCH,C);git('remote','add','origin',URL)
for p,pin in pins.items():assert sha((REPO/p).read_bytes())==pin,(p,pin)
save('standing-identities.json',dict(revision=C,donor=str(D),pins=pins,alternates=roots,standingManifest=str(P/'manifest.json'),standingManifestBytes=37476538,standingModule='/home/user/wine-assembly-shadow-man-span-static-canonical-oct23/build/wine-assembly.wasm',moduleSHA256='8fac39936b6df2418ad86cab118cef19a65a727f649fbc14c412b37818904686',historicalSource='b41a7c5f4b752d1f0bdab1141a11d4fed4dc6f9a',ABI=291,layout='9a3bc9149d58209c',currentMainBinaryClaim=False,acceptedReuse='/tmp/enigma-mode-independent-publication-oct26/repo/docs/reviews/enigma-mode-independent-publication-oct26/evidence-manifest.json',historicalFailuresRetained=True))
for name in ['capture.cjs','supervise-original.py']:(O/name).write_bytes((pathlib.Path('/tmp/enigma-recovered-lossless-startup-oct24')/name).read_bytes())
assert sha((O/'capture.cjs').read_bytes())=='6d64a146f2daf8b598dbf13e3c13f890dbc783d8f5286aacba6d343758d22079'
assert sha((O/'supervise-original.py').read_bytes())=='73be15954cedc19340779ff6bda2397cb94927ca702d2baebdccd5e763cf7b73'
code='const fs=require("fs"),t=require('+json.dumps(str(REPO/'tools/enigma-terminal-capture-guard.cjs'))+');fs.writeFileSync('+json.dumps(str(O/'supervise-transformed.py'))+',t.transformSupervisor(fs.readFileSync('+json.dumps(str(O/'supervise-original.py'))+',"utf8")));'
subprocess.run(['node','--max-old-space-size=256','-e',code],check=True,timeout=60)
import datetime
schedule=json.loads(pathlib.Path(str(L)+'.task.runtime.json').read_text());cutoff=int(datetime.datetime.fromisoformat(schedule['guestCutoff'].replace('Z','+00:00')).timestamp())
s=(O/'supervise-transformed.py').read_text();assert "1792835520,'latest start09:52UTC'" in s
s=s.replace("1792835520,'latest start09:52UTC'",str(cutoff)+",'latest start09:00UTC'").replace('bx_fvkjwxap',BOX).replace('shutdown09:57UTC','shutdown09:20UTC').replace('2026-10-24T10:02:44.741Z',schedule['expiry'])
(O/'supervise.py').write_text(s)
env={k:v.replace(str(P),R) for k,v in json.loads((accepted/'next-env.json').read_text()).items()};env['ENIGMA_CAPTURE_PROFILE']='single-frame'
save('next-env.json',env);save('guest-args.json',args)
save('supervisor-identity.json',dict(original=sha((O/'supervise-original.py').read_bytes()),acceptedTransformed=sha((O/'supervise-transformed.py').read_bytes()),deployed=sha(s.encode()),configurationOnly=['cutoff','box','shutdown','expiry'],schedule=schedule,environment=env,selectedKernelArtifactLimit=2097152,combinedOutputLimit=131072))
# Keep retained real recipe behavior; compact manifest is read from its lossless
# gzip representation to avoid a redundant remote transport/evidence copy.
for name in ['preflight.py','validate-tree.cjs']:
 s=(REC/name).read_text().replace(str(P),R).replace('/home/user/enigma-api-single-frame-startup-oct26',R)
 if name.endswith('.py'):s=s.replace('m=json.load(open(H/\'manifest.json\'))','import gzip\nm=json.loads(gzip.decompress((H/"manifest.json.gz").read_bytes()))')
 else:s=s.replace("JSON.parse(fs.readFileSync(H+'/manifest.json'))","JSON.parse(require('zlib').gunzipSync(fs.readFileSync(H+'/manifest.json.gz')))")
 (O/name).write_text(s)
save('checkpoint.json',dict(phase='PREPARED',sourceManifestSHA256=sha(manifest),moduleSHA256='8fac39936b6df2418ad86cab118cef19a65a727f649fbc14c412b37818904686',remaining=['actual bounded helper staging','destination hash/mode/alias verification','preguest memory/disk/lock admission','one startup','PNG inspect or first blocker','commit and exact remote task verification']))
admission('prepared');print('PREPARED canonical parser / trusted donor / exact helpers / accepted full supervisor PASS')
