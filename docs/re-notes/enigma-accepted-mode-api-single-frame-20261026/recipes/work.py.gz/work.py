import os,sys,json,pathlib,subprocess,hashlib,time,shutil,resource,importlib.util,shlex,base64,zlib
H=pathlib.Path(__file__).resolve().parent.parent; O=H/'ops'; REPO=H/'repo'
ROOT=pathlib.Path('/home/user/wine-assembly'); P=pathlib.Path('/tmp/enigma-provider-complete-startup-oct24')
D=pathlib.Path('/tmp/enigma-accepted-retained-publication-oct26/repo')
REC=pathlib.Path('/tmp/enigma-api-single-frame-startup-oct26/repo/docs/re-notes/enigma-api-single-frame-startup-20261026/recipes')
R='/home/user/enigma-accepted-mode-api-single-frame-oct26'; BOX='bx_h44cmz3t'
C='ef10196a82eaad6d374617fc4a08f108487d264a'; BRANCH='task/enigma-retained-api-single-frame-closeout-oct26'
E='docs/re-notes/enigma-accepted-mode-api-single-frame-20261026'
L=ROOT/'scratch/usage-watch/enigma-retained-api-single-frame-closeout-oct26'
PREVIOUS_L=ROOT/'scratch/usage-watch/enigma-accepted-mode-api-single-frame-oct26'
SSH='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
URL='git@github.com:vgrichina/wine-assembly.git'
spec=importlib.util.spec_from_file_location('account',ROOT/'scratch/usage-watch/owned-storage-accounting-oct24.py');account=importlib.util.module_from_spec(spec);spec.loader.exec_module(account)
assert hashlib.sha256(pathlib.Path(spec.origin).read_bytes()).hexdigest()=='c683aa3aef60cb92f7907a4779cbf2c2c58d36d675d3025be047b59056942651'
allocated=account.allocated
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,j):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.new');t.write_text(json.dumps(j,indent=2)+'\n');os.replace(t,p)
def jread(n):return json.loads((O/n).read_text())
def remote(cmd,timeout=30,allow_exit=False,detach=False):
 assert len(cmd.encode())<=65536
 argv=['boat','--no-update','--json','exec']+(['--detach'] if detach else ['--timeout',str(timeout)])+[BOX,cmd]
 p=subprocess.run(argv,capture_output=True,text=True,timeout=timeout+15)
 with (O/'api-history.jsonl').open('a') as f:f.write(json.dumps(dict(at=time.time(),command=cmd if len(cmd)<1800 else None,commandSHA256=sha(cmd.encode()),requestBytes=len(cmd.encode()),responseBytes=len(p.stdout.encode())+len(p.stderr.encode())))+'\n')
 try:j=json.loads(p.stdout)
 except Exception:save('first-rejection.json',dict(status=p.returncode,stdout=p.stdout,stderr=p.stderr));raise
 if (p.returncode or (not detach and j.get('exitCode')!=0)) and not allow_exit or j.get('stdoutTruncated') or j.get('stderrTruncated'):
  save('first-rejection.json',j);raise RuntimeError('FIRST remote rejection retained; no retry')
 return j
def py(code,timeout=30,**kw):return remote('python3 -c '+shlex.quote(code),timeout,**kw)
def git(*args,repo=REPO):
 def limits():
  resource.setrlimit(resource.RLIMIT_DATA,(536870912,536870912));resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
 argv=['git','-c','pack.threads=1','-c','pack.window=0','-c','pack.windowMemory=16m','-c','core.preloadIndex=false','-c','index.threads=1','-C',str(repo),*args]
 p=subprocess.run(argv,capture_output=True,text=True,timeout=120,preexec_fn=limits,env=dict(os.environ,GIT_SSH_COMMAND=SSH,TMPDIR=str(O)))
 assert len(p.stdout.encode())+len(p.stderr.encode())<=131072
 with (O/'git-commands.jsonl').open('a') as f:f.write(json.dumps(dict(argv=argv,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
 if p.returncode:save('git-first-failure.json',dict(argv=argv,status=p.returncode,stdout=p.stdout,stderr=p.stderr));raise RuntimeError(p.stderr[:8192])
 return p.stdout.strip()
def payload(x):
 return subprocess.check_output(['git','-C',x['donor'],'show',x['revision']+':'+x['path']],stderr=subprocess.DEVNULL) if x['kind']=='git' else pathlib.Path(x['path']).read_bytes()
def admission(stage,remote_bytes=None,publication=False):
 baseline=jread('sqlite-baseline.json');db=sum(max(0,allocated(pathlib.Path(p))-v) for p,v in baseline.items())
 db=max(db,jread('sqlite-highwater.json') if (O/'sqlite-highwater.json').exists() else 0);save('sqlite-highwater.json',db)
 external=0; sessions=[]
 for launcher in [PREVIOUS_L,L]:
  sid=json.loads((launcher/'events.jsonl').open().readline())['thread_id'];session=next(pathlib.Path('/home/user/.codex/sessions/2026/10/26').glob('*'+sid+'.jsonl'))
  charge=allocated(launcher)+allocated(session)+sum(allocated(pathlib.Path(str(launcher)+s)) for s in ['.task.txt','.task.runtime.json','-dispatch.json'])
  external+=charge;sessions.append(dict(launcher=str(launcher),session=str(session),allocated=charge))
 save('both-session-accounting.json',sessions)
 projection=jread('projection.json')
 png=REPO/E/'startup.png'
 charges=dict(localOwned=allocated(H),remoteOwned=remote_bytes if remote_bytes is not None else projection['remotePeak'],launcherSessionFull=external,positiveDBWALHighwaterOnce=db,futureSessionDBOnce=2097152,futureCheckoutGitHelpers=max(0,1048576-allocated(REPO)),captureAndPublicationFuture=524288+allocated(png) if publication else 4194304,transportBuffer=131072,reserve=8388608)
 mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;free=shutil.disk_usage(H).free
 rf=json.loads(jread('remote-admission.json')['stdout'])['free']
 extra=536870912+16777216+(536870912 if publication or stage=='precheckout' else 0)
 j=dict(stage=stage,at=time.time(),charges=charges,peak=sum(charges.values()),cap=67108864,localMemAvailable=mem,aggregateClientOverhead=536870912,helper=16777216,gitData=536870912 if extra>553648128 else 0,remainingLocalMemory=mem-extra,localMemoryFloor=805306368,localFree=free,remoteFree=rf,projectedLocalAfter=free-sum(charges.values()),projectedRemoteAfter=rf-sum(charges.values()),diskFloor=2982150144)
 j['pass']=j['peak']<=67108864 and j['remainingLocalMemory']>=805306368 and min(j['projectedLocalAfter'],j['projectedRemoteAfter'])>=2982150144
 save('resource-'+stage+'.json',j)
 if not j['pass']:save('first-resource-rejection.json',j);raise RuntimeError('FIRST resource rejection; no staging/guest retry')
 return j
