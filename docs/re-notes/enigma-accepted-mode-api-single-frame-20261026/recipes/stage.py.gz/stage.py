from work import *
import gzip,contextlib,stat
m=json.loads((P/'manifest.json').read_bytes())
admission('stream-stage')
# Reuse the accepted helper without changing its staging algorithm. The source
# adapter supplies pinned bytes and source modes over one bounded FIFO stream.
spec=importlib.util.spec_from_file_location('staging',D/'tools/enigma-bounded-staging.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
modes=jread('source-modes.json')['modes']
for x,mode in zip(m,modes):
 if mode is not None:assert s.regular_mode(x)==mode,x['target']
def send(b,target):
 for off in range(0,len(b),30000):
  enc=base64.b64encode(zlib.compress(b[off:off+30000])).decode()
  py('import pathlib,base64,zlib;p=pathlib.Path('+repr(R+'/'+target)+');p.parent.mkdir(parents=True,exist_ok=True);p.open('+repr('wb' if off==0 else 'ab')+').write(zlib.decompress(base64.b64decode('+repr(enc)+')))')
save('stream-stage-detach.json',remote('python3 '+shlex.quote(R+'/stream-stage.py'),300,detach=True))
receipts=[];buf=bytearray();verified=0
def flush():
 if not buf:return
 raw=bytes(buf);enc=base64.b64encode(zlib.compress(raw)).decode()
 j=py('import os,base64,zlib;data=zlib.decompress(base64.b64decode('+repr(enc)+'));f=os.open('+repr(R+'/stream.fifo')+',os.O_WRONLY);v=memoryview(data)\nwhile v:\n n=os.write(f,v);v=v[n:]\nos.close(f);print(len(data))',30)
 assert int(j['stdout'])==len(raw)
 receipts.append(dict(commandId=j.get('commandId'),bytes=len(raw),sha256=sha(raw)));buf.clear()
for i,x in enumerate(m):
 with s.source(x) as source:
  digest=hashlib.sha256();size=0
  while True:
   b=source.read(min(30000-len(buf),8192))
   if not b:break
   size+=len(b);digest.update(b);buf.extend(b)
   if len(buf)==30000:flush()
  assert size==x['bytes'] and digest.hexdigest()==x['sha256'],x['target']
 verified+=1
 if i%500==0:print('verified and streamed',verified,flush=True)
flush();save('stream-transfer-receipts.json',receipts)
check=py('import pathlib,json,time;h=pathlib.Path('+repr(R)+')\nfor i in range(100):\n if (h/"stage-receipt.json").exists():break\n time.sleep(.05)\nprint((h/"stage-receipt.json").read_text())')
save('accepted-stage-receipt-api.json',check)
# Move the fresh completed payload into the same root expected by real recipes.
py('import pathlib;h=pathlib.Path('+repr(R)+');[(p.rename(h/p.name)) for p in (h/"payload").iterdir()];(h/"payload").rmdir();(h/"stream.fifo").unlink()')
for name in ['capture.cjs','supervise.py','supervise-original.py','preflight.py','validate-tree.cjs','guest-args.json','next-env.json']:
 send((O/name).read_bytes(),name)
for name in jread('standing-identities.json')['pins']:send((REPO/name).read_bytes(),'accepted/'+name)
save('checkpoint-staged.json',dict(phase='STAGED',files=verified,oneGuestAttempts=0,acceptedHelperSHA256=sha((D/'tools/enigma-bounded-staging.py').read_bytes())))
print('STAGED',verified,flush=True)
