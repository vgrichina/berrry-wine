from work import *
import tarfile
archive=H/'operations.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as t:
 for p in sorted(O.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and not p.name.startswith('board-watch'):t.add(p,arcname=str(p.relative_to(O)),recursive=False)
# Retain recovery archive, minimal publication helpers, and terminal admission receipts.
for p in list(O.iterdir()):
 if p.name in ['work.py','package.py','first-allocation-blocker.json','handback-api.json','launch.json','sqlite-baseline.json','input-verification.json','module.json','incidents.json','compile-result-api.json','node-startup-api.json','guest-preflight-api.json','local-stage-monitor.json']:continue
 if p.is_dir():shutil.rmtree(p)
 else:p.unlink()
print(dict(archiveBytes=archive.stat().st_size,localAllocated=allocated(H)))
