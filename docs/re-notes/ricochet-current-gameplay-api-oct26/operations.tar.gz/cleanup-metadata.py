from work import *
# Retain exact metadata in compressed local evidence, remove only reproducible staging metadata remotely.
save('metadata-cleanup-api.json',py('import pathlib,json;h=pathlib.Path('+repr(R)+');removed=[]\nfor p in h.glob("*-manifest.json"):\n removed.append(dict(name=p.name,bytes=p.stat().st_size));p.unlink()\nfor name in ["stage-driver.py","remove-compiler-inputs.json"]:\n p=h/name\n if p.exists():p.unlink()\nprint(json.dumps(dict(removed=removed,allocated=sum(p.lstat().st_blocks*512 for p in [h,*h.rglob("*")]))))'))
for p in O.glob('*-transfer.json'):
 p.with_suffix('.json.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
p=O/'api-history.jsonl'
if p.exists():
 dest=O/'asset-api-history.jsonl.gz';dest.write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
print('staging metadata preserved compressed')
