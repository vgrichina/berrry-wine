import pathlib,os,time,sys,json,signal
h=pathlib.Path('/tmp/ricochet-current-gameplay-api-oct26/ops');pid=int(sys.argv[1]);known={};peak=0;stop=None
while True:
 rows={}
 for p in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   s=(p/'stat').read_text();a=s[s.rfind(')')+2:].split();rows[int(p.name)]=(int(a[1]),a[19],int(a[21])*os.sysconf('SC_PAGE_SIZE'))
  except (OSError,ValueError,IndexError):pass
 if pid not in rows:break
 owners={pid}
 for _ in range(5):owners|={p for p,v in rows.items() if v[0] in owners}
 known.update({p:rows[p][1] for p in owners if p in rows});rss=sum(rows[p][2] for p in owners if p in rows);peak=max(peak,rss)
 if rss>67108864:
  stop='64MiB local helper tree RSS gate'
  for p in owners:
   if p in rows and known[p]==rows[p][1]:
    try:os.kill(p,signal.SIGKILL)
    except ProcessLookupError:pass
  break
 time.sleep(.08)
(h/'local-stage-monitor.json').write_text(json.dumps(dict(peakHelperTreeRSS=peak,limit=67108864,reason=stop,identities=known,qualification='monitor attached during asset staging; preceding source/helper samples about19MiB, not full-history peak')))
