from work import *
import re
m=jread('source.json');by={x['path']:x for x in m};S=pathlib.Path('/tmp/civ2-win16-ordinary-gameplay-oct26/source');pending=['test/run.js'];seen=set();missing=[]
while pending:
 p=pending.pop()
 if p in seen:continue
 seen.add(p)
 if p not in by:missing.append(p);continue
 for req in re.findall(r'''require\(['"]([^'"]+)['"]\)''',(S/p).read_text()):
  if not req.startswith('.'):continue
  q=os.path.normpath(str(pathlib.Path(p).parent/req));q=next((v for v in [q,q+'.js',q+'/index.js'] if v in by),q)
  if q.startswith('tools/') and q not in ['tools/disasm.js','tools/simd-ops.js','tools/region-layout-hash.js']:continue
  pending.append(q)
unused=[x for x in jread('runner.json') if x['path'] not in seen];save('closure-review.json',dict(seen=sorted(seen),missing=missing,unused=unused,unusedBytes=sum(x['bytes'] for x in unused)))
print('unused',sum(x['bytes'] for x in unused),[(x['path'],x['bytes']) for x in unused]);print('missing',missing)
