from work import *
phase=sys.argv[1];m=jread('source.json') if phase=='compile' else jread('assets.json')
# Source already retained runner subset stays in place after compile.
# Reuse verified completed destination files; partial owned file is replaced.
j=py('import pathlib,json,hashlib;h=pathlib.Path('+repr(R)+');m=json.loads((h/'+repr(phase+'-manifest.json')+').read_text()) if (h/'+repr(phase+'-manifest.json')+').exists() else [];print(json.dumps([x["target"] for x in m if (h/x["target"]).is_file() and (h/x["target"]).stat().st_size==x["bytes"] and hashlib.file_digest((h/x["target"]).open("rb"),"sha256").hexdigest()==x["sha256"]]));p=h/"stream.fifo";p.unlink(missing_ok=True)')
done=set(json.loads(j['stdout']));m=[x for x in m if x['target'] not in done]
groups=[];group=[];size=0
for x in m:
 if size+x['bytes']>3500000 and group:groups.append(group);group=[];size=0
 group.append(x);size+=x['bytes']
if group:groups.append(group)
for groupindex,m in enumerate(groups):
 phasekey=phase+'-'+str(groupindex)
 send(json.dumps(m).encode(),phasekey+'-manifest.json')
 driver='''
 import pathlib,json,os,hashlib
 h=pathlib.Path(ROOT);m=json.loads((h/PHASEMANIFEST).read_text());fd=os.open(h/'stream.fifo',os.O_RDWR);stream=os.fdopen(fd,'rb',buffering=0)
 for x in m:
  p=h/x['target'];p.parent.mkdir(parents=True,exist_ok=True);left=x['bytes'];digest=hashlib.sha256()
  with p.open('wb') as out:
   while left:
    b=stream.read(min(8192,left));assert b;out.write(b);digest.update(b);left-=len(b)
  assert digest.hexdigest()==x['sha256'];p.chmod(x['mode'])
 (h/PHASERECEIPT).write_text(json.dumps(dict(files=len(m),bytes=sum(x['bytes'] for x in m),verified=True)))
 '''.replace('ROOT',repr(R)).replace('PHASEMANIFEST',repr(phasekey+'-manifest.json')).replace('PHASERECEIPT',repr(phasekey+'-stage.json'))
 driver=__import__('textwrap').dedent(driver);compile(driver,'stage-driver.py','exec');send(driver.encode(),'stage-driver.py');remote('mkfifo '+shlex.quote(R+'/stream.fifo'));save(phasekey+'-detach.json',remote('python3 '+shlex.quote(R+'/stage-driver.py'),detach=True))
 buf=bytearray();receipts=[]
 def flush():
  if not buf:return
  raw=bytes(buf);enc=base64.b64encode(zlib.compress(raw)).decode();r=py('import os,base64,zlib,hashlib;b=zlib.decompress(base64.b64decode('+repr(enc)+'));f=os.open('+repr(R+'/stream.fifo')+',os.O_WRONLY);v=memoryview(b)\nwhile v:\n n=os.write(f,v);v=v[n:]\nos.close(f);print(hashlib.sha256(b).hexdigest())');assert r['stdout'].strip()==sha(raw);receipts.append(dict(bytes=len(raw),sha256=sha(raw),commandId=r.get('commandId')));buf.clear()
 for i,x in enumerate(m):
  h=hashlib.sha256()
  with open(x['source'],'rb') as f:
   while b:=f.read(min(8192,30000-len(buf))):
    h.update(b);buf.extend(b)
    if len(buf)==30000:flush()
  assert h.hexdigest()==x['sha256']
  if i%60==0:print(phase,i,flush=True)
 flush();save(phasekey+'-transfer.json',receipts);save(phasekey+'-stage-api.json',py('import pathlib;h=pathlib.Path('+repr(R)+');print((h/'+repr(phasekey+'-stage.json')+').read_text());(h/"stream.fifo").unlink()'))
 print('COMPLETE',phase,flush=True)
