from work import *
save('first-allocation-blocker.json',dict(kind='preguest-full-allocation-gate',gate=jread('admission-preguest.json'),deficit=70623232-67108864,guestLaunches=0,guestSeconds=0,pngs=0,inputTransitions=0,gameplayObserved=False,reason='Exact full projection plus positive WAL growth exceeds64MiB; no invented15MiB duplicate cache charge. All358manifest data assets charged once; required EXE/manifest, exact runtime closure, fonts/pngjs and compiled module included.',closureReview=jread('closure-review.json'),resumeCondition='Coordinator must supply a materially fitting task allocation/owned footprint and fresh admission; unchanged retry is not authorized.',safePublicationCleanup='Remove only task-owned reproducible1880280B wasm after retaining exact hash and compileSrcWasm recipe; standing source and supplied cache unchanged.'))
# No Node/guest was launched. Retain compact remote inventory and cleanup only module for publication headroom.
code='''import pathlib,json,hashlib,os
h=pathlib.Path(ROOT);p=h/'canonical.wasm';actual=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();assert actual=='f3f3cd439c50a2bc441de67c5f138e32cc060186d84d37d85de2b200ca806d75';n=p.stat().st_size;p.unlink()
rows=[]
for q in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  c=(q/'cmdline').read_bytes()
  if b'node' in c.split(b'\\0')[0] and ROOT.encode() in c:rows.append(dict(pid=int(q.name),starttime=(q/'stat').read_text().split(') ')[1].split()[19]))
 except (OSError,ValueError,IndexError):pass
assert not rows
print(json.dumps(dict(removedReproducibleModule=dict(bytes=n,sha256=actual),remainingOwnedGuestProcesses=rows,guestEverLaunched=False,remoteAllocated=sum(p.lstat().st_blocks*512 for p in [h,*h.rglob('*')]),box='bx_ex22dvm8',state='RUNNING API exec succeeded',expiry='2026-10-26T22:31:02.949Z',shutdownOwner='coordinator',cachePreserved=True)))
'''.replace('ROOT',repr(R))
save('handback-api.json',py(code));v=json.loads(jread('handback-api.json')['stdout']);print(json.dumps(v));admission('postblocker-publication',v['remoteAllocated'])
