from work import *
phase=sys.argv[1];m=jread('source.json') if phase=='compile' else jread('assets.json')
# Source already retained runner subset stays in place after compile.
if phase=='compile':
 projection=sum(((x['bytes']+4095)//4096)*4096 for x in jread('assets.json')+jread('runner.json'))+2000000+262144
 admission('prestage',projection)
 r=py('import os,pathlib,json,shutil,resource;print(json.dumps(dict(uid=os.getuid(),memAvailable=int(pathlib.Path("/proc/meminfo").read_text().split("MemAvailable:")[1].split()[0])*1024,diskFree=shutil.disk_usage("/tmp").free,limits={k:resource.getrlimit(getattr(resource,k)) for k in ["RLIMIT_DATA","RLIMIT_AS","RLIMIT_CPU","RLIMIT_FSIZE"]})))');save('remote-prestage.json',r);v=json.loads(r['stdout']);assert v['uid']==1000 and v['memAvailable']>=3758096384 and v['diskFree']-67108864>=2982150144
 remote('test ! -e '+shlex.quote(R)+' && mkdir '+shlex.quote(R))
send(json.dumps(m).encode(),phase+'-manifest.json')
driver='''import pathlib,json,os,hashlib
h=pathlib.Path(ROOT);m=json.loads((h/PHASEMANIFEST).read_text());fd=os.open(h/'stream.fifo',os.O_RDWR);stream=os.fdopen(fd,'rb',buffering=0)
for x in m:
 p=h/x['target'];p.parent.mkdir(parents=True,exist_ok=True);left=x['bytes'];digest=hashlib.sha256()
 with p.open('wb') as out:
  while left:
   b=stream.read(min(8192,left));assert b;out.write(b);digest.update(b);left-=len(b)
 assert digest.hexdigest()==x['sha256'];p.chmod(x['mode'])
(h/PHASERECEIPT).write_text(json.dumps(dict(files=len(m),bytes=sum(x['bytes'] for x in m),verified=True)))
'''.replace('ROOT',repr(R)).replace('PHASEMANIFEST',repr(phase+'-manifest.json')).replace('PHASERECEIPT',repr(phase+'-stage.json'))
send(driver.encode(),'stage-driver.py');remote('mkfifo '+shlex.quote(R+'/stream.fifo'));save(phase+'-detach.json',remote('python3 '+shlex.quote(R+'/stage-driver.py'),detach=True))
buf=bytearray();receipts=[]
def flush():
 if not buf:return
 raw=bytes(buf);enc=base64.b64encode(zlib.compress(raw)).decode();r=py('import os,base64,zlib,hashlib;b=zlib.decompress(base64.b64decode('+repr(enc)+'));f=os.open('+repr(R+'/stream.fifo')+',os.O_WRONLY);v=memoryview(b)\nwhile v:\n n=os.write(f,v);v=v[n:]\nos.close(f);print(hashlib.sha256(b).hexdigest())');assert r['stdout'].strip()==sha(raw);receipts.append(dict(bytes=len(raw),sha256=sha(raw),commandId=r.get('commandId')));buf.clear()
for i,x in enumerate(m):
 h=hashlib.sha256()
 with open(x['source'],'rb') as f:
  while b:=f.read(min(8192,30000-len(buf))):
   h.update(b);buf.extend(b)
   if len(buf)==30000:flush()
 assert h.hexdigest()==x['sha256']
 if i%60==0:print(phase,i,flush=True)
flush();save(phase+'-transfer.json',receipts);save(phase+'-stage-api.json',py('import pathlib;h=pathlib.Path('+repr(R)+');print((h/'+repr(phase+'-stage.json')+').read_text());(h/"stream.fifo").unlink()'))
print('COMPLETE',phase,flush=True)
