from work import *
import collections
save('sqlite-baseline.json',{str(p):allocated(p) for p in pathlib.Path('/home/user/.codex').glob('*sqlite*')})
save('trusted-ssh.json',dict(command=SSH,rootRef=json.loads((L/'root-ref-digest.json').read_text())))
session=json.loads((L/'events.jsonl').open().readline())['thread_id'];save('launch.json',dict(session=session))
sourceReceipt=json.loads((ROOT/'scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json').read_text());fixture=json.loads((ROOT/'scratch/usage-watch/ricochet-current-gameplay-api-oct26-inputs.json').read_text());S=pathlib.Path(sourceReceipt['source'])
rows=[]
for x in sourceReceipt['files']:
 p=S/x['path'];assert p.stat().st_size==x['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==x['sha256'];rows.append(dict(x,source=str(p),target='runner/'+x['path'],mode=p.stat().st_mode&0o777))
assets=[]
for x in fixture['files']:
 p=ROOT/x['path'];assert p.stat().st_size==x['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==x['sha256'];assets.append(dict(x,source=str(p),target='runner/'+x['path'],mode=p.stat().st_mode&0o777))
# The manifest also declares exe independently of its data-file list.
froot=pathlib.Path(fixture['fixtureRoot']);manifest=froot/'.wine-assembly-browser.json';assert sha(manifest.read_bytes())==fixture['manifestSHA256']
for p in [manifest,froot/'game/Ricochet.exe']:
 if str(p) not in [x['source'] for x in assets]:assets.append(dict(source=str(p),target='runner/'+str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),mode=p.stat().st_mode&0o777))
for p in pathlib.Path('/tmp/wa-local-runtime-deps/node_modules/pngjs').rglob('*'):
 if p.is_file():assets.append(dict(source=str(p),target='runner/node_modules/pngjs/'+str(p.relative_to('/tmp/wa-local-runtime-deps/node_modules/pngjs')),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),mode=p.stat().st_mode&0o777))
runner=[x for x in rows if not x['path'].startswith(('src/','tools/')) and x['path']!='test/compile-src.js']
save('source.json',rows);save('assets.json',assets);save('runner.json',runner)
save('input-verification.json',dict(sourceFiles=len(rows),sourceRevision=C,sourceReceiptSHA256=sha((ROOT/'scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json').read_bytes()),fixtureFiles=len(fixture['files']),fixtureLogical=fixture['logical'],manifestSHA256=fixture['manifestSHA256'],cacheIncludedOnce=True,extraAssets=len(assets)-358))
print(json.dumps(dict(source=sum(x['bytes'] for x in rows),runner=sum(x['bytes'] for x in runner),assets=sum(x['bytes'] for x in assets))))
