from work import *
rows=[x for x in jread('source.json') if x['path'] in ['tools/disasm.js','tools/simd-ops.js','tools/region-layout-hash.js']]
for x in rows:
 p=pathlib.Path(x['source']);b=p.read_bytes();assert sha(b)==x['sha256'];send(b,x['target']);py('import pathlib;pathlib.Path('+repr(R+'/'+x['target'])+').chmod('+str(x['mode'])+')')
save('runner.json',jread('runner.json')+rows);save('runner-required-tools-correction.json',dict(paths=[x['path'] for x in rows],reason='Static final closure inspection found unconditional no-build runner requires for region section validation and failure diagnostics; restored exact pinned files before guest. No failed guest run.'))
