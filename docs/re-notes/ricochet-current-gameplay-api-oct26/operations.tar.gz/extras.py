from work import *
a=json.loads(subprocess.check_output(['node','--max-old-space-size=32',str(O/'extras.cjs')],timeout=10));m=jread('assets.json');checks=[]
for p in a:
 q=ROOT/p;b=q.read_bytes();blob=sha(b)
 if p.startswith('fonts/'):
  expected=git('rev-parse',C+':'+p,repo=pathlib.Path('/tmp/enigma-tracked-pin-independent-publication-oct26/repo'));actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert expected==actual
 else:expected=None
 m.append(dict(source=str(q),target='runner/'+p,bytes=len(b),sha256=blob,mode=q.stat().st_mode&0o777));checks.append(dict(path=p,sha256=blob,gitBlob=expected))
save('assets.json',m);save('mandatory-runtime-extras.json',checks);admission('extras-projection',sum(((x['bytes']+4095)//4096)*4096 for x in m+jread('runner.json'))+2262144)
print(len(a),sum(x['bytes'] for x in m))
