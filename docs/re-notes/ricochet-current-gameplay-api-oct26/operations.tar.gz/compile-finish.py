from work import *
r=py('import pathlib,json,hashlib,shutil;h=pathlib.Path('+repr(R)+');print((h/"compile/terminal.json").read_text());print((h/"compile/output.log").read_text())');save('compile-result-api.json',r);lines=[x for x in r['stdout'].splitlines() if x.strip()];t=json.loads(lines[0]);assert t['returncode']==0 and t['reason']=='natural' and not t['remainingOwnedLive'];module=json.loads(lines[-1]);save('module.json',module)
# Preserve compile recipe/hashes and retained runner; delete only reproducible owned compiler source.
keep={x['target'] for x in jread('runner.json')}
remove=[x['target'] for x in jread('source.json') if x['target'] not in keep];send(json.dumps(remove).encode(),'remove-compiler-inputs.json')
save('postcompile-removal.json',py('import pathlib,json;h=pathlib.Path('+repr(R)+');m=json.loads((h/"remove-compiler-inputs.json").read_text())\nfor x in m:(h/x).unlink()\nprint(json.dumps(dict(removed=len(m),retainedModule=(h/"canonical.wasm").stat().st_size)))'))
# Compress completed transport records in place; all chunk receipts remain recoverable.
for p in O.glob('compile-*-transfer.json'):
 p.with_suffix('.json.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
p=O/'api-history.jsonl';p.with_suffix('.jsonl.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
print('PASS canonical source compile and phased removal')
