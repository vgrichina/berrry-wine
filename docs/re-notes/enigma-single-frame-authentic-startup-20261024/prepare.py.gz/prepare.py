from work import *
old=pathlib.Path('/tmp/enigma-recovered-lossless-startup-oct24')
args=[s.replace(str(P),R) for s in json.load(open(old/'guest-args.json'))];args.insert(-1,'--quiet-fs');save('guest-args.json',args)
m=json.load(open(H/'manifest.json'));s=payload(m[0]).decode();assert sha(s.encode())=='4d7b9587676db38fcf3314807acb2b2a42b5f09d2c98fcf3dccb8a6cde9e1809'
parser=s[s.index('const getArg ='):s.index('// Was `--name=...`')]
code='const assert=require("assert"),args='+json.dumps(args[7:])+';'+parser+';assert.deepEqual(getArgs("vfs-tree"),['+json.dumps(R+'/vfs')+']);assert.equal(getArgs("vfs-mount").length,0);assert.equal(getArgs("dlls").length,8);assert(hasFlag("no-build"));assert(hasFlag("quiet-fs"));console.log("PASS canonical parser eight providers/tree")'
r=subprocess.run(['node','--max-old-space-size=256','-e',code],capture_output=True,text=True,timeout=60,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_CPU,(60,60)))
save('precheckout-parser.json',dict(status=r.returncode,stdout=r.stdout,stderr=r.stderr,argv=args,parserSHA256=sha(parser.encode()),enumeratedFiles=len([x for x in m if x['target'].startswith('vfs/')]),commaFilenames=[x['target'] for x in m if ',' in x['target']],standingFullEnumeration=str(P/'manifest.json')));assert r.returncode==0
r=subprocess.run(['git','ls-remote','git@github.com:vgrichina/wine-assembly.git','refs/heads/main'],env=dict(os.environ,GIT_SSH_COMMAND=SSH),capture_output=True,text=True,timeout=30)
save('trusted-donor.json',dict(ssh=SSH,status=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0 and r.stdout.split()[0]==REV
save('remote-admission.json',py('import os,json,pathlib,shutil;print(json.dumps(dict(uid=os.getuid(),free=shutil.disk_usage("/tmp").free,memAvailable=int(pathlib.Path("/proc/meminfo").read_text().split("MemAvailable:")[1].split()[0])*1024)))'))
assert int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024>=805306368
measure('precheckout')
repo=H/'repo';repo.mkdir()
def git(*args):
 r=subprocess.run(['git','-C',str(repo),*args],capture_output=True,text=True);assert r.returncode==0,r.stderr;return r.stdout
pins=json.load(open(old/'standing-identities.json'))['acceptedPaths'];pins['tools/lossless-capture-png.cjs']='9dae92170fbf4ef5acf0a2b0be43b93d3b3a7c8ec86f227df708d3b65d67cb4b';pins['tools/enigma-terminal-capture-guard.cjs']='ee2e5424485ab14f57a12454a2e839a008de3158ac76f2fdf55e8efe17117386'
git('init');seen=set();ordered=[]
def alt(p):
 p=p.resolve()
 if str(p) in seen:return
 seen.add(str(p));ordered.append(str(p));a=p/'info/alternates'
 if a.exists():
  for x in a.read_text().splitlines():alt(pathlib.Path(x) if pathlib.Path(x).is_absolute() else p/x)
alt(D/'.git/objects');(repo/'.git/objects/info/alternates').write_text('\n'.join(ordered)+'\n')
git('config','core.sparseCheckout','true');git('config','core.sparseCheckoutCone','false');(repo/'.git/info/sparse-checkout').write_text('\n'.join('/'+p for p in pins)+'\n/docs/re-notes/enigma-single-frame-authentic-startup-20261024.md\n/docs/re-notes/enigma-single-frame-authentic-startup-20261024/\n')
git('checkout','-b','task/enigma-single-frame-authentic-startup-oct24',REV);git('config','user.name','Wine Ops');git('config','user.email','wine-ops@local');git('remote','add','origin','git@github.com:vgrichina/wine-assembly.git')
for p,pin in pins.items():assert sha((repo/p).read_bytes())==pin
save('standing-identities.json',dict(acceptedPaths=pins,donor=str(D),revision=REV,manifest=str(P/'manifest.json'),manifestSHA256=sha((H/'manifest.json').read_bytes()),standingInputs='Original/overlays/native providers/installed pngjs and retained wasm all reused unchanged via pinned manifest',flattenedAlternates=ordered))
for name in ['capture.cjs','supervise-original.py']:(H/name).write_bytes((old/name).read_bytes())
assert sha((H/'capture.cjs').read_bytes())=='6d64a146f2daf8b598dbf13e3c13f890dbc783d8f5286aacba6d343758d22079'
assert sha((H/'supervise-original.py').read_bytes())=='73be15954cedc19340779ff6bda2397cb94927ca702d2baebdccd5e763cf7b73'
code='const fs=require("fs"),t=require('+json.dumps(str(repo/'tools/enigma-terminal-capture-guard.cjs'))+');fs.writeFileSync('+json.dumps(str(H/'supervise-transformed.py'))+',t.transformSupervisor(fs.readFileSync('+json.dumps(str(H/'supervise-original.py'))+',"utf8")));'
subprocess.run(['node','--max-old-space-size=256','-e',code],check=True,timeout=60)
s=(H/'supervise-transformed.py').read_text();assert "1792835520,'latest start09:52UTC'" in s
s=s.replace("1792835520,'latest start09:52UTC'","1792851480,'latest start14:18UTC'").replace('bx_fvkjwxap',BOX).replace('shutdown09:57UTC','shutdown14:25UTC').replace('2026-10-24T10:02:44.741Z','2026-10-24T14:29:00Z');(H/'supervise.py').write_text(s)
save('supervisor-identity.json',dict(original=sha((H/'supervise-original.py').read_bytes()),acceptedTransformed=sha((H/'supervise-transformed.py').read_bytes()),deployed=sha(s.encode()),configurationOnly=['lateststart14:18UTC','box','watchdog14:25UTC','expiry~14:29UTC'],ordinaryRun55s=True))
env={k:v.replace(str(P),R) for k,v in json.load(open(old/'next-env.json')).items()};env['ENIGMA_CAPTURE_PROFILE']='single-frame';save('next-env.json',env)
save('schedule-correction.json',dict(latestGuestStart='2026-10-24T14:18:00Z',guestFinish='2026-10-24T14:19:00Z',handback='2026-10-24T14:21:00Z',watchdog='2026-10-24T14:25:00Z',box=BOX))
measure('prepared');print('PREPARED parser, trusted donor, sparse pins, supervisor PASS')
