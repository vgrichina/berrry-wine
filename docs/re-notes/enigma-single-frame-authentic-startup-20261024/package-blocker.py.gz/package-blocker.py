from work import *
import gzip,difflib
E=H/'repo/docs/re-notes/enigma-single-frame-authentic-startup-20261024';E.mkdir(parents=True,exist_ok=True)
# Retain bounded evidence, including unchanged history and exact recipes, without originals/assets.
for p in H.iterdir():
 if p.is_file() and p.suffix in ['.py','.json','.jsonl','.log','.cjs']:
  (E/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in (H/'ops').iterdir():
 if p.is_file():shutil.copyfile(p,E/p.name)
(E/'supervisor-config.diff').write_text(''.join(difflib.unified_diff((H/'supervise-transformed.py').read_text().splitlines(True),(H/'supervise.py').read_text().splitlines(True),fromfile='accepted',tofile='deployed')))
obs=dict(guestAttempts=0,acceptedPNG=None,scene='UNKNOWN: no guest launched',menu='UNKNOWN',Lua='UNKNOWN',gameplayAccepted=False,packedOriginalAccepted=False,blocker='Mandatory unchanged supervisor file-size ceiling131072 is incompatible with accepted single-frame PNG2097152',test='Non-guest exact-RLIMIT kernel probe returned EFBIG at131072',acceptedFiveSuites='Reused exact main010bb7c evidence, not rerun',historicalFailuresRemainFailed=True)
(E/'observations.json').write_text(json.dumps(obs,indent=2)+'\n')
report='''# Enigma authentic single-frame startup: blocked before guest

No guest was launched and no PNG exists. The first launch-compatibility failure is the unchanged accepted supervisor's `RLIMIT_FSIZE=(131072,131072)`. It applies to all Node-created regular files, including the actual intercepted `fs.writeFileSync` PNG, rather than just output.log. The accepted named single-frame encoder permits2097152bytes, cumulative2097152/max1. The previous authentic batch30000 frame exhausted both strategies3 then0 at131072; its exact larger size and pixels remain unknown. A different deterministic startup is not presumed to have the same pixels, but the launch cannot support its full accepted capture contract.

A bounded generic-byte, non-guest kernel probe with that exact hard/soft limit wrote only131072 of131073 requested bytes; the next write returned errno27 EFBIG. Fixture removed after measurement and child waited/reaped. The actual guest was stopped at compatibility admission, rather than knowingly invoking a writer whose accepted profile exceeds its inherited hard file limit. No supervisor/guard semantics were repaired or weakened. The accepted supervisor's terminal validator also requires ERR_ASSERTION, whereas a writer EFBIG preserves its native error identity; no claim is made about a guest failure path that was never executed.

Planned source main010bb7c2176d0f783b56657cff1b2848ebd102d2 from immutable closeout donor; sparse exact paths and flattened deduplicated alternates only. Planned retained module8fac39936b6df2418ad86cab118cef19a65a727f649fbc14c412b37818904686,1879746bytes, sourceb41a7c5f4b752d1f0bdab1141a11d4fed4dc6f9a, ABI291/layout9a3bc9149d58209c. It was NOT instantiated in this task. Canonical runner4d7b9587676db38fcf3314807acb2b2a42b5f09d2c98fcf3dccb8a6cde9e1809 retained with --no-build. Pinned original capture6d64a146f2daf8b598dbf13e3c13f890dbc783d8f5286aacba6d343758d22079 and supervisor73be15954cedc19340779ff6bda2397cb94927ca702d2baebdccd5e763cf7b73 are unchanged. Accepted terminal adapteree2e5424485ab14f57a12454a2e839a008de3158ac76f2fdf55e8efe17117386 and encod er9dae92170fbf4ef5acf0a2b0be43b93d3b3a7c8ec86f227df708d3b65d67cb4b matched donor pins.

Planned environment explicitly ENIGMA_CAPTURE_PROFILE=single-frame, ENIGMA_LOSSLESS_CAPTURE=1, ENIGMA_TERMINAL_CAPTURE_INSTALL=1 and actual ROOT/CAPTURE_PATH/TERMINAL_RECEIPT retained in next-env.json.gz; FTQ then original capture, --quiet-fs, first and only PNG30000 at640x480, max10000000/55s. No capture-directed early termination change. The actual filename-bearing mount argv passed the unchanged canonical parser before checkout: supported vfs-tree, zero vfs-mount, eight dependency-ordered providers,2460 intended files including comma-bearing names in the standing full2659-entry manifest. Remote full closure rehash, ordinary-user probe and real-dependency preflight were NOT reached because staging was halted at the compatibility discovery. No claim of runtime readiness.

Five exact-candidate/merged acceptance suites are reused from the coordinator's accepted-single-frame-and-native-review-oct24 receipt; no redundant tests/build/acquisition/semantic repair/second guest/workers/main merge. Historical broad-checkout440418438byte breach and earlier capture failures remain FAILED, preserved by complete carried history and immutable references. Before staging, prospective peak65011712/67108864 included full external session/launcher, positive SQLite growth/future, both possible2MiB PNG copies, publication copies and8MiB reserve. Post-blocker conservative peak65662976 remained below64MiB, sourceafter3487592448 above2982150144; remoteafter49197879296. Later publication admission is retained externally. No accounting history reset.

Streaming partial staging stopped with local processgroup3977026 exit143; allocated box contains10051584 materialized bytes, no guest directory and no task guest nodes. Coordinator owns shutdown. bx_hc2kmvbs remains RUNNING (API idle, healthok), expiry2026-10-24T14:29:05.931Z; watchdog14:25UTC. No stop/create/resume/snapshot operation was issued by this worker. Box handed back; no retry or replacement task. Resume requires coordinator acceptance of a bounded supervisor that retains output131072 while supporting PNG2097152, then a new assigned guest attempt.

All artifacts/recipes are adjacent, sealed by artifact-seals.json. Originals/providers/assets remain standing read-only inputs identified in manifest.json.gz; no copied full local assets. Scene, menu, Lua and gameplay remain UNKNOWN; this is neither packed-original nor gameplay acceptance. ops/result.json is published last outside Git after push verification.
'''.replace('encod er','encoder')
(H/'repo/docs/re-notes/enigma-single-frame-authentic-startup-20261024.md').write_text(report)
seals=[dict(path=str(p.relative_to(E)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(E.iterdir()) if p.is_file()]
(E/'artifact-seals.json').write_text(json.dumps(seals,indent=2)+'\n')
assert not list(E.glob('*.png'));assert not (H/'guest-attempt.json').exists()
for x in seals:assert sha((E/x['path']).read_bytes())==x['sha256']
save('ops/bundle-check.json',dict(passed=True,files=len(seals)+1,bytes=sum(x['bytes'] for x in seals),guestAttempts=0,PNGs=0,checks='all copied seals, unchanged source pins, no guest claim, actual kernel EFBIG, captured raw failure'))
measure('prepublication');print('BUNDLE PASS')
