import pathlib,json,shutil,os
H=pathlib.Path(__file__).parent;old=pathlib.Path('/tmp/enigma-recovered-lossless-startup-oct24');root=pathlib.Path('/home/user/wine-assembly')
def save(n,j):(H/n).write_text(json.dumps(j,indent=2)+'\n')
# Capture the complete prior historical receipt unchanged, not a new baseline for it.
save('capture-history.json',dict(previousHistory=json.load(open(old/'capture-history.json')),previousFinal=json.load(open(old/'capture-current.json')),previousResult=json.load(open(old/'ops/result.json')),historicalBroadCheckoutFailure='/tmp/enigma-bounded-single-frame-profile-oct24/ops/resource-first-rejection.json',historicalFailuresRemainFailed=True))
save('admission.json',dict(session='/home/user/.codex/sessions/2026/10/24/rollout-2026-10-24T14-00-35-01a16e36-9b81-7781-a7a3-edd498c5139e.jsonl',launcher=str(root/'scratch/usage-watch/enigma-single-frame-authentic-startup-oct24')))
save('sqlite-baseline.json',{str(p):max(p.stat().st_size,p.stat().st_blocks*512) for p in pathlib.Path('/home/user/.codex').glob('*.sqlite*') if p.is_file()})
s=(old/'work.py').read_text().replace("D=pathlib.Path('/tmp/enigma-lossless-independent-integrate-oct24/repo')","D=pathlib.Path('/tmp/enigma-single-frame-independent-closeout-oct24/repo')").replace("R=str(P); BOX='bx_7wpw3hf6'","R=str(H); BOX='bx_hc2kmvbs'").replace("REV='2545fba6c8234031bc8fbdcb5273491cbc4461ca'","REV='010bb7c2176d0f783b56657cff1b2848ebd102d2'")
s=s.replace("launcherFull=sum(allocated(pathlib.Path(a['launcher']+s)) for s in ['', '-dispatch.json','.task.txt'])","launcherFull=allocated(pathlib.Path(a['launcher']))+allocated(pathlib.Path(a['launcher']+'.task.txt'))")
s=s.replace('remoteHelpersEvidence=2097152','remoteHelpersEvidence=262144,remotePNGFuture=2097152,localPNGFuture=2097152').replace('gitPublicationFuture=1048576','gitPublicationFuture=2359296').replace('externalFuture=1048576','externalFuture=524288')
s=s.replace("(H/'api-history.jsonl').read_text().splitlines()","((H/'api-history.jsonl').read_text() if (H/'api-history.jsonl').exists() else '').splitlines()")
(H/'work.py').write_text(s)
for n in ['stage.py','preflight.py','validate-tree.cjs','launch.py','collect.py']:
 s=(old/n).read_text().replace('/tmp/enigma-provider-complete-startup-oct24',str(H)).replace('1792848720','1792851480').replace('13:32UTC','14:18UTC')
 if n=='collect.py':s=s.replace("assert row['bytes']<=131072,row","assert row['bytes']<=(2097152 if row['path'].endswith('.png') else 131072),row")
 (H/n).write_text(s)
shutil.copyfile(old/'manifest.json',H/'manifest.json')
save('accepted-evidence-reuse.json',dict(revision='010bb7c2176d0f783b56657cff1b2848ebd102d2',receipt=str(root/'scratch/usage-watch/accepted-single-frame-and-native-review-oct24.json'),fiveSuites='PASS exact candidate and merged; reused no rerun',dispatch=str(root/'scratch/usage-watch/enigma-single-frame-runtime-dispatch-oct24.json')))
