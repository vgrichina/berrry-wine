import pathlib
H=pathlib.Path(__file__).parent;old=pathlib.Path('/tmp/enigma-recovered-lossless-startup-oct24')
s=(old/'stage-and-validate.py').read_text();a=s.index('code=(old/');b=s.index("for name in ['capture.cjs'",a)
s=s[:a]+"code=(H/'stage.py').read_text();ns={'__name__':'stage','__file__':str(H/'stage.py')};exec(compile(code,str(H/'stage.py'),'exec'),ns)\n"+s[b:]
s=s.replace('537acd267b07490bca0694116b0fbc20a81d553487dac2606be27ec20811f03e','9dae92170fbf4ef5acf0a2b0be43b93d3b3a7c8ec86f227df708d3b65d67cb4b').replace('458677a467a9bb2abc67244fb7319423166e4c7185339e02fc579b2145702851','ee2e5424485ab14f57a12454a2e839a008de3158ac76f2fdf55e8efe17117386')
(H/'stage-and-validate.py').write_text(s)
# Payload manifest source remains standing P; stage writes only remote task R.
s=(H/'launch.py').read_text().replace('acceptedSuitesReused=4','acceptedSuitesReused=5');s=s.replace("assert env['ENIGMA_LOSSLESS_CAPTURE']=='1'","assert env['ENIGMA_LOSSLESS_CAPTURE']=='1' and env['ENIGMA_CAPTURE_PROFILE']=='single-frame'")
(H/'launch.py').write_text(s)
