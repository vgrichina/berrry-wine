from prepare import *
assert time.time()+100<1793051400
# inspect control and capture preload identity in addition to standing509 manifest.
j=py('import pathlib,hashlib,json;h=pathlib.Path('+repr(str(OLD))+');print(json.dumps({x:dict(bytes=(h/x).stat().st_size,sha256=hashlib.file_digest((h/x).open("rb"),"sha256").hexdigest()) for x in ["capture-bounds.cjs","runner/test/run.js","canonical.wasm","runner/src/api_table.json"]}))');save('runtime-identities.json',j)
send((O/'serial.py').read_bytes(),'serial.py')
v=measure();assert v['memAvailable']>=3758096384;gate('before-execution',v['allocated'])
# fresh one exactNode startup receipt under identical childlimits/environment.
code='''import subprocess,resource,json
A=ARGS
E={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/home/user','LANG':'C.UTF-8','TZ':'UTC','NODE_PATH':'/tmp/ricochet-current-gameplay-api-oct26/runner/node_modules'}
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
p=subprocess.run(A[:3]+['-e',"console.log(JSON.stringify({exec:process.execPath,flags:process.execArgv,limits:require('fs').readFileSync('/proc/self/limits','utf8'),memory:process.memoryUsage(),environment:process.env}))"],env=E,capture_output=True,text=True,preexec_fn=limits,timeout=10)
print(json.dumps(dict(exit=p.returncode,stdout=p.stdout,stderr=p.stderr)))
assert p.returncode==0
'''.replace('ARGS',repr(jread('guest-args.json')))
save('node-startup.json',py(code))
save('production-launch.json',remote('python3 '+R+'/supervisor.py guest',detach=True))
save('serial-launch.json',remote('python3 '+R+'/serial.py',detach=True))
print('GUEST AND SERIAL CONTROLLER LAUNCHED ONCE')
