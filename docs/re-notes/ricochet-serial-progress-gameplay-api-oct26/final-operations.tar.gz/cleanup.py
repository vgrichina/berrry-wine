from prepare import *
j=py('''import pathlib,json,hashlib,time
h=pathlib.Path(OWNROOT);t=json.loads((h/'guest/terminal.json').read_text());live=[]
for pid,s in t['identities'].items():
 p=pathlib.Path('/proc')/pid/'stat'
 if p.exists():
  q=p.read_text();a=q[q.rfind(')')+2:].split()
  if a[19]==s['start'] and a[0]!='Z':live.append(pid)
assert not live
print(json.dumps(dict(ownedLive=live,box='bx_ex22dvm8',state='RUNNING APIexec',expiry='2026-10-26T22:31:02.949Z',shutdownOwner='coordinator',cleanup='none; keep retained runner/assets/module and task evidence',moduleSHA256=hashlib.file_digest(pathlib.Path('/tmp/ricochet-current-gameplay-api-oct26/canonical.wasm').open('rb'),'sha256').hexdigest(),at=time.time())))
'''.replace('OWNROOT',repr(R)))
save('handback.json',j);gate('after-collection',measure()['allocated']);print(json.dumps(jread('durable-checkpoint.json')))
