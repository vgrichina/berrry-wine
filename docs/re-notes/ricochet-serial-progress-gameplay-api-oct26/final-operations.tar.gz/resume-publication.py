from prepare import *
import signal
E="docs/re-notes/ricochet-serial-progress-gameplay-api-oct26";e=REPO/E;run=ROOT/"scratch/runs/ricochet-serial-progress-gameplay-api-oct26";check=H/"check"
import tarfile
remoteExtra=sum(x["allocated"] for x in json.loads(jread("remote-capture-footprint.json")["stdout"]).values())
node=shutil.which('node');env=dict(os.environ)
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
def checked(argv):
 p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,preexec_fn=limits);peak=0;beg=time.monotonic()
 while p.poll() is None:
  try:
   s=pathlib.Path('/proc/'+str(p.pid)+'/status').read_text();peak=max(peak,int(s.split('VmRSS:')[1].split()[0])*1024)
  except (OSError,IndexError):pass
  parentStatus=pathlib.Path('/proc/self/status').read_text();parentRSS=int(parentStatus.split('VmRSS:')[1].split()[0])*1024
  if peak+parentRSS>268435456 or time.monotonic()-beg>120:
   p.kill();p.wait();save('checker-first-resource-failure.json',dict(childPeak=peak,parentRSS=parentRSS,parentHistoricalHighwater=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,wall=time.monotonic()-beg));raise RuntimeError('physicaltesttree or wall guard')
  time.sleep(.01)
 out,err=p.communicate();assert len(out)+len(err)<=2097152
 return dict(exit=p.returncode,stdout=out.decode(),stderr=err.decode(),childPeakRSS=peak,parentPeakRSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
save('checker-parent-preflight.json',dict(status=pathlib.Path('/proc/self/status').read_text(),rusage=tuple(resource.getrusage(resource.RUSAGE_SELF))))
startup=checked([node,'--max-old-space-size=32','-e',"console.log(JSON.stringify({exec:process.execPath,flags:process.execArgv,limits:require('fs').readFileSync('/proc/self/limits','utf8')}))"]);save('checker-startup.json',startup);assert startup['exit']==0
r=checked([node,'--max-old-space-size=32',str(ROOT/'ops/check-run-evidence.js'),str(check)]);save('evidence-check.json',r);assert r['exit']==0 and '"invalid": []' in r['stdout'];shutil.rmtree(check)
# include all operational evidence after acceptance and before committing.
with tarfile.open(e/'operations.tar.gz','w:gz') as t:
 for p in sorted(O.iterdir()):
  if p.is_file() and p.suffix!='.png' and p.name!='board-watch.log':t.add(p,arcname=p.name)
manifest=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(e.iterdir())];(e/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for x in manifest:assert sha((e/x['path']).read_bytes())==x['sha256']
v=measure();gate('before-commit',v['allocated']+remoteExtra);git('add',E);assert all(x.startswith(E+'/') for x in git('diff','--cached','--name-only').splitlines());git('diff','--cached','--check');git('commit','-m','docs: preserve Ricochet actual menu and serial progress evidence');commit=git('rev-parse','HEAD')
gate('before-push',v['allocated']+remoteExtra);git('push','origin','refs/heads/'+BRANCH+':refs/heads/'+BRANCH);ref=git('ls-remote','origin','refs/heads/'+BRANCH);assert ref.split()[0]==commit
save('publication.json',dict(commit=commit,branch=BRANCH,exactRemoteRef=ref,evidence=str(e),dashboard=str(run),trustedSSH=SSH,gitDATAChildOnly=536870912));print(json.dumps(jread('publication.json')))
