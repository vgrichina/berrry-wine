from prepare import *
import tarfile,datetime,signal
E='docs/re-notes/ricochet-serial-progress-gameplay-api-oct26';run=ROOT/'scratch/runs/ricochet-serial-progress-gameplay-api-oct26'
# supplemental process capture log footprints and final fresh child identity check.
j=py('import pathlib,json;ps='+repr([jread(n)[k] for n in ['production-launch.json','serial-launch.json'] for k in ['logPath','errLogPath']])+';print(json.dumps({x:dict(bytes=pathlib.Path(x).stat().st_size,allocated=pathlib.Path(x).stat().st_blocks*512) for x in ps}))');save('remote-capture-footprint.json',j)
watch=3176727;watchPath=pathlib.Path('/proc/'+str(watch)+'/cmdline');watchLive=watchPath.exists() and b'ricochet-current-gameplay-api-oct26-shutdown-watch.py' in watchPath.read_bytes()
save('lifecycle.json',dict(box=BOX,state='RUNNING APIexec confirmed',guestCutoff='2026-10-26T21:50:00Z',handback='2026-10-26T21:55:00Z',shutdown='2026-10-26T22:00:00Z',expiry='2026-10-26T22:31:02.949Z',shutdownOwner='coordinator',watchPID=watch,live=watchLive,untouched=True,qualification="Previously live initial and21:44:53; absent final. Coordinator must verify coverage."))
# Admission counts dashboard copy as it appears, plus remote exec capture logs.
remoteExtra=sum(x['allocated'] for x in json.loads(j['stdout']).values())
v=measure();gate('before-publication',v['allocated']+remoteExtra)
REPO.mkdir(exist_ok=True);git('init','-b',BRANCH);git('remote','add','origin',URL);git('config','user.name','Wine Ops');git('config','user.email','wine-ops@local')
e=REPO/E;e.mkdir(parents=True,exist_ok=True)
receipt=jread('durable-checkpoint.json');receipt.update(dict(status='ACTUAL_MAIN_MENU_GAMEPLAY_UNVERIFIED',APIcalls=827031,sourceManifest=str(ROOT/'scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json'),sourceManifestSHA256=sha((ROOT/'scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json').read_bytes()),runtimeVerified=509,configuration=jread('configuration-reuse.json'),pins=jread('runtime-identities.json'),admission=jread('admission-before-execution.json'),incident=jread('controller-planning-incident.json'),helperRepair=jread('decision-check.json'),cleanup=jread('handback.json'),lifecycle=jread('lifecycle.json'),capture=dict(path='later.png',width=640,height=480,bytes=(O/'later.png').stat().st_size,sha256=sha((O/'later.png').read_bytes()),inspected=True,scene='Actual main menu with Play Game, Statistics, Options, Exit Game'),historicalFailures='Original500-batch10sec timeout completedunreplayed in predecessor; older64MiB/allocation/startup incidents retained, not reclassified'))
(e/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(e/'README.md').write_text('''Ricochet Xtreme: actual Play Game menu reached; gameplay unverified

One exact production invocation reached the actual main menu at1537 acknowledged batches and827031 API calls. Personally inspected lossless640x480 later.png shows Play Game, Statistics, Options and Exit Game. This is progress beyond the predecessor's loading700/900 captures; it does not establish a Play Game click, Anonymous Guest, a round, or paddle/ball movement.

Prepared box-local serial controller ran7 acknowledged steps (1 then six256), with9 frozen snapshots all showing zero credits, no overlapping request or timeout. All acknowledgements match requested counts. IFC22 DllMain executed. Exact pinned runner87ab63d768eb59a09a8b69df2ccb3843270dd867a67405abd82f02c25c1628e7, source754c97d3, retained1880280B modulef3f3cd439c50a2bc441de67c5f138e32cc060186d84d37d85de2b200ca806d75 and723350B API table562acd9c5870750d29cc88ed1ec12112c9da7164b8d9c3fe470a109842d39486 unchanged.509 runtimefiles/modes reverified; canonical mount parser358files and exact argv receipt reused after source/parser/argv validation. Fresh Node24.22.1 startup succeeded under exact flags/environment with DATA/ASunlimited, heap2048MiB separate from RSS2560MiB. No compile/retransfer/fullrestage.

Controller captured at59.46s then froze for inspection. Collecting401056B PNG through90 serial4500B bounded API readbacks consumed the remaining window. Controller quit normally at82.05s; guest supervisor82.267946537s wall,60.04sampledCPU,320278528B sampled peakRSS, exit0. Local input decision was queued after controller completion and remained unconsumed; no guest input occurred. That decision also used input instead of the production cmd key: latent schema error, not an executed guest failure. Original decision and executed helper preserved. Corrected continuation helper rejects finished/late windows, wrong input keys and oversized steps; proper mousemove/down/up cmd fixture and rejecting controls pass offline. No second guest; remaining nominal7.73s cannot fund a meaningful fresh attempt. No observed trap; earlier loading was not a proven hang.

A cleanup helper initially replaced H inside moduleSHA256 and produced SyntaxError before executing its read-only check; original API rejection retained. Fixed only the placeholder and resumed cleanup without recollecting or replaying completed groups. Earlier500-batch10s timeout and historical allocation/startup failures preserved unchanged as predecessor/historical receipts.

Fresh256MiB full allocation admission included retained local/remote trees, ownGit/evidence, session/events, positiveWALgrowth once,32MiB future publication/client growth (including remoteGit) and8MiB reserve. Host free projection>=2982150144B and MemAvailable>=3489660928B beforeguest; remote MemAvailable>=3758096384B. Standing readonly donor sources excluded, no duplicated cache charge. Detailed admission/pins/commands/environment/control/logs/checkpoints in receipt and operations archive. Taskbranch only, no main publication.

Reproduction: use archived work.py/prepare.py/launch.py and exact guest-args.json, retained bx_ex22dvm8 paths and canonical parser/startup receipt paths. This documents the performed attempt, not authorization to repeat it. Future coordinator assignment should reserve more time after menu capture, use validated cmd syntax and wait for observed ACK+zero-credit before next input. Do not replay an in-flight timed-out request.

Cleanup: owned guest processes none. bx_ex22dvm8 left RUNNING; retained assets/module/cache/evidence kept. Coordinator owns22:00UTC snapshot-stop, expiry2026-10-26T22:31:02.949Z. Shutdownwatch3176727 was initially live and live at21:44:53, then absent during final publication. Worker never signaled or replaced it; coordinator must verify shutdown coverage. Worker stops here; no worker spawn, refill, SSH/runtime permission changes, services or public deployment.
''')
for n in ['later.png','output.log','control.jsonl','command.json','terminal.json','durable-checkpoint.json','controller-planning-incident.json','decision-check.json','unconsumed-decision.json']:
 shutil.copy2(O/n,e/n)
run.mkdir(exist_ok=False)
for n in ['later.png','output.log','control.jsonl','command.json','terminal.json','durable-checkpoint.json']:shutil.copy2(O/n,run/n)
start=jread('production-launch.json')['startedAt'];finish=datetime.datetime.fromtimestamp(jread('command.json')['at']+jread('terminal.json')['elapsed'],datetime.timezone.utc).isoformat()
result=dict(candidateId='reflexive-ricochet-xtreme',agentId='codex:'+SESSION,startedAt=start,finishedAt=finish,outcome='unknown',route='production startup to actual main menu',appId='ricochet_xtreme',command=jread('guest-args.json'),build=dict(commit=C,wasmSha256=receipt['moduleSHA256']),environment=dict(box=BOX,node='24.22.1',renderer='headless pure-JS canvas',viewport='640x480'),summary='Actual Play Game main menu verified at1537ACKbatches827031APIcalls. No gameplay or delivered input. Serial7steps9zero-credit snapshots no timeout; normalquit82.27s. PNG collection exhausted decision window; late invalid-key decision unconsumed, helper repaired offline.',verification='reviewed',screenshots=['later.png'],artifacts=['output.log','control.jsonl','command.json','terminal.json','durable-checkpoint.json'])
(run/'result.json.tmp').write_text(json.dumps(result,indent=2)+'\n');(run/'result.json.tmp').rename(run/'result.json')
save('dashboard.json',dict(runId=run.name,path=str(run)))
# Bounded exact local Node startup then evidence containment check; no broad suite.
check=H/'check';(check/'scratch/runs').mkdir(parents=True);shutil.copytree(run,check/'scratch/runs'/run.name)
node=shutil.which('node');env=dict(os.environ)
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
def checked(argv):
 p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,preexec_fn=limits);peak=0;beg=time.monotonic()
 while p.poll() is None:
  try:
   s=pathlib.Path('/proc/'+str(p.pid)+'/status').read_text();peak=max(peak,int(s.split('VmRSS:')[1].split()[0])*1024)
  except (OSError,IndexError):pass
  parentStatus=pathlib.Path('/proc/self/status').read_text();parentRSS=int(parentStatus.split('VmRSS:')[1].split()[0])*1024
  if peak+parentRSS>268435456 or time.monotonic()-beg>120:
   p.kill();p.wait();save('checker-first-resource-failure.json',dict(childPeak=peak,parentRSS=parentRSS,parentHistoricalHighwater=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,wall=time.monotonic()-beg));raise RuntimeError('physicaltesttree or wall guard')
  time.sleep(.01)
 out,err=p.communicate();assert len(out)+len(err)<=2097152
 return dict(exit=p.returncode,stdout=out.decode(),stderr=err.decode(),childPeakRSS=peak,parentPeakRSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
save('checker-parent-preflight.json',dict(status=pathlib.Path('/proc/self/status').read_text(),rusage=tuple(resource.getrusage(resource.RUSAGE_SELF))))
startup=checked([node,'--max-old-space-size=32','-e',"console.log(JSON.stringify({exec:process.execPath,flags:process.execArgv,limits:require('fs').readFileSync('/proc/self/limits','utf8')}))"]);save('checker-startup.json',startup);assert startup['exit']==0
r=checked([node,'--max-old-space-size=32',str(ROOT/'ops/check-run-evidence.js'),str(check)]);save('evidence-check.json',r);assert r['exit']==0 and '"invalid": []' in r['stdout'];shutil.rmtree(check)
# include all operational evidence after acceptance and before committing.
with tarfile.open(e/'operations.tar.gz','w:gz') as t:
 for p in sorted(O.iterdir()):
  if p.is_file() and p.suffix!='.png' and p.name!='board-watch.log':t.add(p,arcname=p.name)
manifest=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(e.iterdir())];(e/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for x in manifest:assert sha((e/x['path']).read_bytes())==x['sha256']
v=measure();gate('before-commit',v['allocated']+remoteExtra);git('add',E);assert all(x.startswith(E+'/') for x in git('diff','--cached','--name-only').splitlines());git('diff','--cached','--check');git('commit','-m','docs: preserve Ricochet actual menu and serial progress evidence');commit=git('rev-parse','HEAD')
gate('before-push',v['allocated']+remoteExtra);git('push','origin','refs/heads/'+BRANCH+':refs/heads/'+BRANCH);ref=git('ls-remote','origin','refs/heads/'+BRANCH);assert ref.split()[0]==commit
save('publication.json',dict(commit=commit,branch=BRANCH,exactRemoteRef=ref,evidence=str(e),dashboard=str(run),trustedSSH=SSH,gitDATAChildOnly=536870912));print(json.dumps(jread('publication.json')))
