from work import *
c=json.loads(sys.argv[1]);raw=json.dumps(c).encode();print(py('import pathlib;p=pathlib.Path('+repr(R+'/serial/continue.json')+');assert not p.exists();p.write_bytes('+repr(raw)+');print("decision queued")')['stdout'])
