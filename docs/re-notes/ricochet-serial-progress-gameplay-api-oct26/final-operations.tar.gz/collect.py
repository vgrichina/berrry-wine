from prepare import *
from read import readfile
for source,target in [('guest/terminal.json','terminal.json'),('guest/command.json','command.json'),('guest/output.log','output.log'),('serial/control.jsonl','control.jsonl'),('serial/checkpoint.json','checkpoint.json'),('serial/paused.json','paused.json'),('serial/done.json','done.json'),('serial/continue.json','unconsumed-decision.json')]:
 readfile(source,O/target)
# preserve same-task incident and predecessor's original failures; never overwrite prior artifacts.
save('controller-planning-incident.json',dict(menuVerified=True,menuBatch=1537,captureBytes=401056,serialDeadline=jread('paused.json')['deadline'],decisionWasConsumed=False,decisionQueuedAfterDone=True,inputCommandsUsedWrongKey='input should be cmd in production protocol; never delivered to guest',reason='401056B lossless capture required90 bounded4500B API readbacks; frozen inspection used remaining controller window',noReplay=True,productionInvocations=1,remainingNominalGuestSeconds=90-jread('terminal.json')['elapsed'],noSecondGuest=True))
for n in ['first-controller-failure.json','first-historical-startup-failure.json']:
 shutil.copy2(PRE/'ops'/n,O/('predecessor-'+n))
for n in ['first-allocation-blocker.json','incidents.json']:
 shutil.copy2(OLD/'ops'/n,O/('historical-'+n))
# Checkpoint accepts only exact acknowledged steps and coherent frozen snapshots.
a=[json.loads(x) for x in (O/'control.jsonl').read_text().splitlines()]
steps=[x for x in a if x['request'].get('action')=='step'];snaps=[x for x in a if x['request'].get('action')=='snapshot'];last=0
for x in steps:
 n=x['request']['n'];v=x['response']['value'];assert x['response']['ok'] and n<=256 and v['ran']==n and v['steps']==n and v['batch']==last+n;last=v['batch']
assert last==1537 and all(x['response']['value']['frozen']['credits']==0 and x['response']['value']['frozen']['frozen'] for x in snaps)
assert a[-1]['request']['action']=='quit' and not any('input' in x['request'] or 'cmd' in x['request'] for x in a)
term=jread('terminal.json');assert term['returncode']==0 and not term['remainingOwnedLive'] and term['peakTreeCPU']<90 and term['elapsed']<90
save('durable-checkpoint.json',dict(source=C,runnerSHA256='87ab63d768eb59a09a8b69df2ccb3843270dd867a67405abd82f02c25c1628e7',moduleSHA256='f3f3cd439c50a2bc441de67c5f138e32cc060186d84d37d85de2b200ca806d75',productionInvocations=1,stepCount=len(steps),snapshotCount=len(snaps),ACKbatches=last,zeroCreditsAll=True,noTimeout=True,inspectedMenu=True,PlayGameLabelObserved=True,PlayGameClickAcknowledged=False,AnonymousGuest=False,round=False,paddleBallGameplay=False,remaining='Coordinator may assign new bounded guest with earlier menu capture, more efficient readback, production cmd input syntax; no worker refill',predecessorCommit='1c18ba58b998ba1ee569dc267dae5d4c36afadb6',terminal=term))
j=py('''import pathlib,json,hashlib,time
h=pathlib.Path(OWNROOT);t=json.loads((h/'guest/terminal.json').read_text());live=[]
for pid,s in t['identities'].items():
 p=pathlib.Path('/proc')/pid/'stat'
 if p.exists():
  q=p.read_text();a=q[q.rfind(')')+2:].split()
  if a[19]==s['start'] and a[0]!='Z':live.append(pid)
assert not live
print(json.dumps(dict(ownedLive=live,box='bx_ex22dvm8',state='RUNNING APIexec',expiry='2026-10-26T22:31:02.949Z',shutdownOwner='coordinator',cleanup='none; keep retained runner/assets/module and task evidence',moduleSHA256=hashlib.file_digest(pathlib.Path('/tmp/ricochet-current-gameplay-api-oct26/canonical.wasm').open('rb'),'sha256').hexdigest(),at=time.time())))
'''.replace('OWNROOT',repr(R)))
save('handback.json',j);gate('after-collection',measure()['allocated']);print(json.dumps(jread('durable-checkpoint.json')))
