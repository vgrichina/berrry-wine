from work import *
from decision import validate
c=json.loads(sys.argv[1])
j=py('import pathlib,json,time;h=pathlib.Path('+repr(R+'/serial')+');s=json.loads((h/"paused.json").read_text());print(json.dumps(dict(deadline=s["deadline"],done=(h/"done.json").exists(),now=time.time())))');state=json.loads(j['stdout']);validate(c,state,state['now'])
raw=json.dumps(c).encode()
print(py('import pathlib,json,time;h=pathlib.Path('+repr(R+'/serial')+');s=json.loads((h/"paused.json").read_text());assert not (h/"done.json").exists() and time.time()<s["deadline"]-3;p=h/"continue.json";assert not p.exists();p.write_bytes('+repr(raw)+');print("decision queued")')['stdout'])
