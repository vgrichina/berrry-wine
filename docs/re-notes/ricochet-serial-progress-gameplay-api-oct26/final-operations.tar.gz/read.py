from work import *
def readfile(target,local):
 j=py('import pathlib,hashlib,json;p=pathlib.Path('+repr(R+'/'+target)+');print(json.dumps(dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open("rb"),"sha256").hexdigest())))');meta=json.loads(j['stdout']);assert meta['bytes']<=2097152
 p=pathlib.Path(local);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('wb') as f:
  for off in range(0,meta['bytes'],4500):
   j=py('import pathlib,base64;p=pathlib.Path('+repr(R+'/'+target)+');f=p.open("rb");f.seek('+str(off)+');print(base64.b64encode(f.read(4500)).decode())');f.write(base64.b64decode(j['stdout']))
 assert sha(p.read_bytes())==meta['sha256'];return meta
if __name__=='__main__':print(json.dumps(readfile(sys.argv[1],O/(sys.argv[2] if len(sys.argv)>2 else pathlib.Path(sys.argv[1]).name))))
