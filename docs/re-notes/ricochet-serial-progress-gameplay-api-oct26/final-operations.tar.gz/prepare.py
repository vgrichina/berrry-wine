from work import *
OLD=pathlib.Path('/tmp/ricochet-current-gameplay-api-oct26');PRE=pathlib.Path('/tmp/ricochet-pinned-startup-gameplay-api-oct26');PRIOR=pathlib.Path('/tmp/ricochet-retained-module-gameplay-api-oct26');SOURCE=pathlib.Path('/tmp/civ2-win16-ordinary-gameplay-oct26/source')
SESSION=os.environ['CODEX_SESSION_ID'];L=ROOT/'scratch/usage-watch/ricochet-serial-progress-gameplay-api-oct26'
def measure():
 roots=[str(x) for x in [OLD,PRE,PRIOR,H]]
 j=py('import pathlib,json,hashlib,shutil;roots=[pathlib.Path(x) for x in '+repr(roots)+'];print(json.dumps(dict(allocated=sum(p.lstat().st_blocks*512 for r in roots if r.exists() for p in [r,*r.rglob("*")]),memAvailable=int(pathlib.Path("/proc/meminfo").read_text().split("MemAvailable:")[1].split()[0])*1024,free=shutil.disk_usage("/tmp").free,module=hashlib.file_digest((roots[0]/"canonical.wasm").open("rb"),"sha256").hexdigest())))')
 v=json.loads(j['stdout']);assert v['module']=='f3f3cd439c50a2bc441de67c5f138e32cc060186d84d37d85de2b200ca806d75';save('remote-measure.json',v);return v

def gate(stage,rm):
 base=json.loads((OLD/'ops/sqlite-baseline.json').read_text());wal=sum(max(0,allocated(pathlib.Path(p))-v) for p,v in base.items() if p.endswith('-wal'))
 sessions=list(pathlib.Path('/home/user/.codex/sessions/2026/10/26').glob('*'+SESSION+'.jsonl'));assert len(sessions)==1
 clients=[]
 for p in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');st=(p/'status').read_text();rss=int(st.split('VmRSS:')[1].split()[0])*1024 if 'VmRSS:' in st else 0
   if 'codex' in cmd or 'boat --no-update' in cmd:clients.append(dict(pid=int(p.name),rss=rss,command=cmd[:200]))
  except OSError:pass
 mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;free=shutil.disk_usage(H).free
 charges=dict(dashboard=allocated(ROOT/'scratch/runs/ricochet-serial-progress-gameplay-api-oct26'),remote=rm,localRetained=sum(allocated(x) for x in [OLD,PRE,PRIOR]),ownLocalGit=allocated(H),session=allocated(sessions[0]),events=allocated(L)+sum(allocated(pathlib.Path(str(L)+s)) for s in ['.task.txt','.task.runtime.json','-dispatch.json']),WALpositiveOnce=wal,futurePublicationAndSessions=33554432,reserve=8388608)
 # MemAvailable already deducts actual resident clients. Reserve host768,Civ768,GL512,own256, four remotehelpers64MiB; fresh stricter floor applies.
 minimum=max(3489660928,(768+768+512+256+4*64)*1048576)
 v=dict(at=time.time(),charges=charges,total=sum(charges.values()),cap=268435456,memAvailable=mem,minimum=minimum,clients=clients,actualClientRSS=sum(x['rss'] for x in clients),hostFree=free,projectedFree=free-33554432,hostFloor=2982150144)
 v['pass']=v['total']<=268435456 and mem>=minimum and v['projectedFree']>=2982150144
 save('admission-'+stage+'.json',v);assert v['pass'],str({k:v[k] for k in ['total','cap','memAvailable','minimum','projectedFree']});return v
if __name__=='__main__':
 # canonical parser receipt reused only after actual source/parser/argv identity comparison.
 args=json.loads((PRE/'ops/guest-args.json').read_text());parser=json.loads((PRIOR/'ops/canonical-parser.json').read_text());assert args[3:]==parser['argv']
 src=(SOURCE/'test/run.js').read_text();part=src[src.index('const getArg ='):src.index('// Was `--name=...`')];assert sha(part.encode())==parser['parserSHA256']
 save('configuration-reuse.json',dict(argv=args,canonicalParserReceipt=str(PRIOR/'ops/canonical-parser.json'),parserSHA256=sha(part.encode()),enumeratedFiles=len(parser['enumerated']),commaFiles=parser['commaFilenames'],startupReceipt=str(OLD/'ops/guest-preflight-api.json'),unchanged=True,trustedSSH=SSH))
 save('guest-args.json',args)
 v=measure();gate('preparation',v['allocated'])
 send(json.dumps(args).encode(),'guest-args.json');send((O/'supervisor.py').read_bytes(),'supervisor.py');send((O/'serial.py').read_bytes(),'serial.py')
 j=py('import pathlib,hashlib,json;old=pathlib.Path('+repr(str(OLD))+');a=json.loads(pathlib.Path('+repr(str(PRE/'validation.json'))+').read_text())\nfor x in a:\n p=old/x["target"];assert p.stat().st_size==x["bytes"] and hashlib.file_digest(p.open("rb"),"sha256").hexdigest()==x["sha256"] and p.stat().st_mode&511==x["mode"],x["target"]\nprint(json.dumps(dict(verified=len(a),runner=hashlib.file_digest((old/"runner/test/run.js").open("rb"),"sha256").hexdigest())))')
 save('pin-verification.json',j)
 print(json.dumps(dict(prepared=True,remote=v)))
