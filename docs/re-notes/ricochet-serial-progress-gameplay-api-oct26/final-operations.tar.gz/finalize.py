from prepare import *
import signal,tarfile
E='docs/re-notes/ricochet-serial-progress-gameplay-api-oct26';e=REPO/E
# Preserve raw original mislabeled receipt; add truthful qualification without rerunning passedgroups.
pf=jread('checker-parent-preflight.json');status=pf['status'];actualHWM=int(status.split('VmHWM:')[1].split()[0])*1024;actualRSS=int(status.split('VmRSS:')[1].split()[0])*1024
r=dict(firstFailure='Initial checker-startup wrapper killed before receipt because parentRUSAGE_SELF highwater exceeded256MiB; test itself was not shown to exceed physical allowance.',rawInheritedParentRusagePeak=pf['rusage'][2]*1024,actualParentVmHWM=actualHWM,actualParentVmRSS=actualRSS,reason='Linux rusage highwater inherited across exec; /proc self VmHWM resets for current exec. Parent counter was not a current Python physical peak.',fix='Guard current process RSS+sampled child peak, retain raw inherited rusage as historical metadata. No RLIMIT_DATA/AS raised.',rawStartupReceipt='checker-startup.json',rawCheckerReceipt='evidence-check.json',rawParentPeakRSSKeyQualification='Raw parentPeakRSS key contains inheritedRusageHistoricalHighwater, not observed current Python memory.',correctedTestAggregateConservative=max(jread('checker-startup.json')['childPeakRSS'],jread('evidence-check.json')['childPeakRSS'])+actualHWM,physicalCap=268435456,helperPhysicalCap=67108864,checkerPassReused=True)
assert r['correctedTestAggregateConservative']<268435456 and actualHWM<67108864
save('checker-wrapper-incident.json',r)
# Capture ordinary internal helper incidents rather than silently lose them.
save('closeout-incidents.json',dict(cleanupSyntax='Global H placeholder replacement corrupted moduleSHA256; first-api-rejection.json retained. Fixed placeholder, resumed only cleanup.',publicationSyntax='Initial publish helper had one unmatched closing parenthesis; fixed before any operation executed.',watchExit='Initially present and observed21:44:53 then absent21:46 publication; never signaled byworker, board notification delivered.',checkerWrapper=r))
(e/'checker-wrapper-incident.json').write_text(json.dumps(r,indent=2)+'\n')
s=(e/'README.md').read_text();s+='\nLocal checker-wrapper incident: the initial startup guard compared inherited rusage highwater against256MiB and stopped. Fresh /proc parent VmRSS/VmHWM18256KiB versus inherited352528KiB established the attribution error. Corrected wrapper kept DATA/ASunlimited and guarded actual parent RSS plus child peak; checker passed one run with no errors/missing/invalid. Raw parentPeakRSS key in its receipts is explicitly historical inherited rusage, not current Python physical use; checker-wrapper-incident.json qualifies it. No passed checker replay after success. Initial publication helper parenthesis typo was fixed before it executed.\n'
(e/'README.md').write_text(s)
q=json.loads((e/'receipt.json').read_text());q['localCheckerWrapperIncident']=r;q['evidenceCheck']=dict(exit=0,runs=1,errors=[],missing=[],invalid=[]);(e/'receipt.json').write_text(json.dumps(q,indent=2)+'\n')
for n in ['evidence-check.json','checker-parent-preflight.json','checker-wrapper-incident.json','closeout-incidents.json','lifecycle.json','publication.json']:shutil.copy2(O/n,e/n)
with tarfile.open(e/'final-operations.tar.gz','w:gz') as t:
 for p in sorted(O.iterdir()):
  if p.is_file() and p.suffix!='.png' and p.name!='board-watch.log':t.add(p,arcname=p.name)
manifest=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(e.iterdir()) if p.name!='evidence-manifest.json'];(e/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for x in manifest:assert sha((e/x['path']).read_bytes())==x['sha256']
remoteExtra=sum(x['allocated'] for x in json.loads(jread('remote-capture-footprint.json')['stdout']).values());gate('final-before-commit',measure()['allocated']+remoteExtra)
git('add',E);git('diff','--cached','--check');git('commit','-m','docs: qualify Ricochet cleanup and inherited memory accounting incidents');commit=git('rev-parse','HEAD')
gate('final-before-push',jread('remote-measure.json')['allocated']+remoteExtra);git('push','origin','refs/heads/'+BRANCH+':refs/heads/'+BRANCH);ref=git('ls-remote','origin','refs/heads/'+BRANCH);assert ref.split()[0]==commit
assert git('status','--porcelain')==''
# Stop only the board watcher created by this task; retain box and every runtime asset.
w=jread('board-watch.json')['pid'];p=pathlib.Path('/proc/'+str(w)+'/cmdline');stopped=False
if p.exists():
 cmd=p.read_bytes().split(b'\0');assert cmd[:3]==[b'tail',b'-f',b'/home/user/wine-assembly/messageboard.txt'];os.kill(w,signal.SIGTERM);stopped=True
save('final-publication.json',dict(commit=commit,branch=BRANCH,exactRemoteRef=ref,priorCheckpoint='54ebc4093832aae685ad075536c8407663fa558d',evidence=str(e),dashboard=str(ROOT/'scratch/runs/ricochet-serial-progress-gameplay-api-oct26'),gitStatus='clean',ownedBoardWatcherStopped=stopped,ownedGuestLive=[],box=BOX,boxState='RUNNING lastAPIexec',expiry='2026-10-26T22:31:02.949Z',shutdownOwner='coordinator',shutdownWatchPID=3176727,shutdownWatchFinalLive=False,mainPublication=False))
gate('final',measure()['allocated']+remoteExtra);print(json.dumps(jread('final-publication.json')))
