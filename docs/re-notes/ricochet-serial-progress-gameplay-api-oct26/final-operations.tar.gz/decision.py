# Production protocol confirmed from pinned test/run.js handleControlCommand.
def validate(c,state,now):
 if state.get('done') or now>=state['deadline']-3:raise ValueError('controller finished or insufficient decision window; do not queue')
 if set(c)-{'commands','step','png','quit'}:raise ValueError('unknown decision fields')
 n=c.get('step',0)
 if type(n) is not int or n<0 or n>256:raise ValueError('step outside0..256')
 for x in c.get('commands',[]):
  if set(x)!={'cmd'} or not isinstance(x['cmd'],str):raise ValueError('production input requires exactly cmd, not input')
  if x['cmd'].split(':')[0] not in ['mousemove','mousedown','mouseup','keydown','keyup']:raise ValueError('unsupported ordinary input')
 return c
