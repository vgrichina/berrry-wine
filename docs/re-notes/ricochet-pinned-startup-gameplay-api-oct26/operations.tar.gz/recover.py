from work import *
import re,datetime
OLD=pathlib.Path('/tmp/ricochet-current-gameplay-api-oct26')
PRIOR=pathlib.Path('/tmp/ricochet-retained-module-gameplay-api-oct26')
SOURCE=pathlib.Path('/tmp/civ2-win16-ordinary-gameplay-oct26/source')
L=ROOT/'scratch/usage-watch/ricochet-pinned-startup-gameplay-api-oct26'
SESSION=os.environ['CODEX_SESSION_ID']
def gate(stage,remoteBytes,incremental=0):
 base=json.loads((OLD/'ops/sqlite-baseline.json').read_text())
 wal=sum(max(0,allocated(pathlib.Path(p))-v) for p,v in base.items() if p.endswith('-wal'))
 session=next(pathlib.Path('/home/user/.codex/sessions/2026/10/26').glob('*'+SESSION+'.jsonl'))
 charges=dict(remote=remoteBytes,priorLocal=allocated(OLD)+allocated(PRIOR),ownLocalGit=allocated(H),launcherEvents=allocated(L)+sum(allocated(pathlib.Path(str(L)+s)) for s in ['.task.txt','.task.runtime.json','-dispatch.json']),session=allocated(session),positiveWALOnce=wal,future=33554432,reserve=8388608,incremental=incremental)
 mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;free=shutil.disk_usage(H).free
 r=dict(at=time.time(),stage=stage,charges=charges,total=sum(charges.values()),cap=201326592,memAvailable=mem,aggregateRAMMinimum=2550136832,hostFree=free,projectedFree=free-33554432-incremental,hostFloor=2982150144,cacheCountedOnce=True,walBaseline=str(OLD/'ops/sqlite-baseline.json'),residentClientsAlreadyDeducted=True)
 r['pass']=r['total']<=r['cap'] and r['projectedFree']>=2982150144 and mem>=2550136832
 save('admission-'+stage+'.json',r);assert r['pass'],r;return r
def measure():
 r=py('''import pathlib,json,time,hashlib
roots=[pathlib.Path(p) for p in ROOTS]
print(json.dumps(dict(at=time.time(),remoteAllocated=sum(p.lstat().st_blocks*512 for h in roots if h.exists() for p in [h,*h.rglob('*')]),memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024,moduleSHA256=hashlib.file_digest((roots[0]/'canonical.wasm').open('rb'),'sha256').hexdigest())))
'''.replace('ROOTS',repr([str(OLD),str(PRIOR),str(H)])))
 save('measurement.json',r);v=json.loads(r['stdout']);assert v['moduleSHA256']=='f3f3cd439c50a2bc441de67c5f138e32cc060186d84d37d85de2b200ca806d75';return v
if __name__=='__main__':
 assert time.time()+180<1793051400
 v=measure();gate('before-transfer',v['remoteAllocated'],1048576)
 manifest=json.loads((ROOT/'scratch/usage-watch/civ2-win16-pinned-inputs-oct26.json').read_text());pins={x['path']:x for x in manifest['files']}
 # Inspect the exact pinned runner's relative require closure, not the dirty worktree.
 seen=set();edges=[];missing=[]
 def visit(rel):
  if rel in seen:return
  seen.add(rel);p=SOURCE/rel;pin=pins.get(rel)
  assert pin and p.stat().st_size==pin['bytes'] and sha(p.read_bytes())==pin['sha256'],rel
  if p.suffix!='.js':return
  for req in re.findall(r"require\(\s*['\"]([^'\"]+)['\"]\s*\)",p.read_text()):
   if not req.startswith('.'):continue
   target=os.path.normpath(str(pathlib.Path(rel).parent/req))
   q=next((x for x in [target,target+'.js',target+'.json',target+'/index.js'] if (SOURCE/x).is_file()),None)
   edges.append(dict(parent=rel,request=req,resolved=q))
   if q:visit(q)
   else:missing.append(dict(parent=rel,request=req))
 visit('test/run.js')
 save('startup-closure.json',dict(source=str(SOURCE),revision=C,files=sorted(seen),edges=edges,conditionalUnresolved=missing,readInspection=['test/run.js2719 api_table unconditional','test/run.js2857 system data manifest','test/run.js2861 bundled bitmap fonts','test/run.js2873 substitutions and subset fonts','no-build pinned module excludes compiler','Win32 route excludes Win16 ordinals']))
 a=json.loads((PRIOR/'ops/validation.json').read_text())
 table=dict(pins['src/api_table.json'],target='runner/src/api_table.json',mode=(SOURCE/'src/api_table.json').stat().st_mode&511)
 assert table['sha256']=='562acd9c5870750d29cc88ed1ec12112c9da7164b8d9c3fe470a109842d39486'
 save('supplementary-startup-manifest.json',[table])
 # Transfer exactly one authorized file; retained canonical module remains in place.
 import work
 work.R=str(OLD);r=send((SOURCE/'src/api_table.json').read_bytes(),table['target']);save('api-table-transfer.json',r)
 py('import os;os.chmod('+repr(str(OLD/table['target']))+','+str(table['mode'])+')')
 work.R=str(H)
 a.append(table);send(json.dumps(a).encode(),'validation.json')
 code='''import pathlib,json,hashlib,time
h=pathlib.Path(OLD);n=pathlib.Path(NEW);a=json.loads((n/'validation.json').read_text())
for x in a:
 p=h/x['target'];assert p.stat().st_size==x['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==x['sha256'],x['target'];assert p.stat().st_mode&511==x['mode'],x['target']
(n/'diagnostics').mkdir(exist_ok=True);p=n/'diagnostics/append.txt';p.open('ab').write(b'probe\\n');assert p.read_bytes().endswith(b'probe\\n')
print(json.dumps(dict(verified=len(a),moduleSHA256=hashlib.file_digest((h/'canonical.wasm').open('rb'),'sha256').hexdigest(),supplementary=a[-1],at=time.time())))
'''.replace('OLD',repr(str(OLD))).replace('NEW',repr(str(H)))
 save('runtime-verification.json',py(code))
 # Same argv and parser as the successful exact-configuration receipt.
 args=json.loads((PRIOR/'ops/guest-args.json').read_text());parser=json.loads((PRIOR/'ops/canonical-parser.json').read_text())
 assert args[3:]==parser['argv']
 src=(SOURCE/'test/run.js').read_text();part=src[src.index('const getArg ='):src.index('// Was `--name=...`')];assert sha(part.encode())==parser['parserSHA256']
 save('configuration-reuse.json',dict(argv=args,parserReceipt=str(PRIOR/'ops/canonical-parser.json'),parserSHA256=sha(part.encode()),enumerated=len(parser['enumerated']),commaFiles=parser['commaFilenames'],startupReceipt=str(OLD/'ops/guest-preflight-api.json'),unchangedExecutableFlagsEnvironmentLimits=True))
 save('guest-args.json',args);send(json.dumps(args).encode(),'guest-args.json');send((O/'supervisor.py').read_bytes(),'supervisor.py')
 v=measure();assert v['memAvailable']>=3758096384;gate('before-execution',v['remoteAllocated'])
 print(json.dumps(dict(ready=True,remote=v,admission=jread('admission-before-execution.json')['total'])))
