import pathlib
old=pathlib.Path('/tmp/enigma-tracked-runner-pin-repair-oct26/ops/common.py').read_text()
old=old.replace('enigma-tracked-runner-pin-repair-oct26','enigma-start-game-input-delivery-repair-oct26').replace("/tmp/enigma-uncertainty-independent-publication-oct26/repo","/tmp/enigma-capture-budget-gameplay-oct26/repo").replace('b5b4b2b8da9da56b189ab4417896e9b7b76b35a8','50e60eae2987c826bb72de02398cac04cc6533f7')
old=old.replace('cap=67108864','cap=100663296').replace('projection<=67108864','projection<=100663296').replace('max(41943040,sum(charges.values()))','max(67108864,sum(charges.values()))').replace('mem>=2415919104','mem>=max(3489660928,sum(x["rss"] for x in clients)+805306368+805306368+536870912+268435456+268435456+3*67108864)')
pathlib.Path(__file__).with_name('common.py').write_text(old)
from common import *
save('db-baseline.json',{str(p):alloc(p) for p in pathlib.Path('/home/user/.codex').glob('*.sqlite*')})
gate('initial')
save('configuration.json',dict(ssh=SSH,mountArgv=[],intendedFiles=[],runtime=False,rootRefReceipt=json.load(open(ROOT/'scratch/usage-watch'/H.name/'root-ref-digest.json'))))
pins=json.load(open(ROOT/'scratch/usage-watch/enigma-start-game-input-delivery-repair-oct26-handoff.json'))['pins']
for x in pins:assert sha(pathlib.Path(x['path']).read_bytes())==x['sha256']
save('pins.json',pins)
f=open(O/'board-watch.log','ab');p=subprocess.Popen(['tail','-n','0','-f',str(ROOT/'messageboard.txt')],stdout=f,stderr=f,start_new_session=True);f.close();save('watcher.json',dict(pid=p.pid))
print('INITIAL ADMISSION PASS')
