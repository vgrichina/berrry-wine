from common import *
import signal,sys
cmd=[NODE,'--max-old-space-size=64',*sys.argv[1:]]
gate('node-'+('startup' if '-e' in cmd else 'fixture'))
p=subprocess.Popen(cmd,cwd=H,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits,env=dict(os.environ,TMPDIR=str(O),GIT_SSH_COMMAND=SSH))
os.set_blocking(p.stdout.fileno(),False);buf=bytearray();start=time.monotonic();peak=0;reason='natural';cpu=0
try:
 while True:
  try:
   st=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split(') ')[1].split();rss=int(st[21])*4096+int(pathlib.Path('/proc/self/status').read_text().split('VmRSS:')[1].split()[0])*1024;cpu=(int(st[11])+int(st[12]))/os.sysconf('SC_CLK_TCK');peak=max(peak,rss)
  except (OSError,IndexError):pass
  try:b=os.read(p.stdout.fileno(),8192)
  except BlockingIOError:b=b''
  buf.extend(b)
  if len(buf)>2097152:reason='output';break
  if peak>268435456:reason='rss';break
  if cpu>90:reason='cpu';break
  if time.monotonic()-start>120:reason='wall';break
  if shutil.disk_usage(H).free<2982150144:reason='disk';break
  if p.poll() is not None:
   buf.extend(p.stdout.read() or b'');break
  time.sleep(.01)
finally:
 if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
 p.wait()
name='startup' if '-e' in cmd else 'fixture'
(O/(name+'-output.log')).write_bytes(buf[:2097152])
save(name+'-execution.json',dict(argv=cmd,exit=p.returncode,reason=reason,peakRSS=peak,childCPU=cpu,wall=time.monotonic()-start,outputBytes=len(buf),physicalCap=268435456,remainingOwned=[],dataAS='inherited unlimited; Git DATA only on Git',physicalScope='Node plus enclosing supervisor; fixture spawns no subprocesses'))
print(buf[:8192].decode(errors='replace'));assert reason=='natural' and p.returncode==0
