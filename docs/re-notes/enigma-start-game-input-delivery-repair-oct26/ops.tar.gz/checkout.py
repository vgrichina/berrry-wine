from common import *
import zlib,gzip
save('admission-initial-incident.json',json.load(open(O/'admission-initial.json')))
gate('checkout-pre')
save('db-baseline-note.json',dict(incident='Initial gate double-counted own256MiB in new-client and test allowance; no checkout/test executed. Corrected to actual clients+host768+Civ768+GL512+helpers3x64+own256; baseline retained.'))
pins=json.load(open(ROOT/'scratch/usage-watch/enigma-start-game-input-delivery-repair-oct26-handoff.json'))['pins']
for x in pins:assert sha(pathlib.Path(x['path']).read_bytes())==x['sha256']
save('pins.json',pins)
f=open(O/'board-watch.log','ab');p=subprocess.Popen(['tail','-n','0','-f',str(ROOT/'messageboard.txt')],stdout=f,stderr=f,start_new_session=True);f.close();save('watcher.json',dict(pid=p.pid))
save('configuration.json',dict(ssh=SSH,mountArgv=[],intendedFiles=[],runtime=False,rootRefReceipt=json.load(open(ROOT/'scratch/usage-watch'/H.name/'root-ref-digest.json'))))
R.mkdir();g('init','-q',str(R),cwd=H)
seen=set();ordered=[]
def visit(p):
 p=p.resolve()
 if p in seen or not p.exists():return
 seen.add(p)
 f=p/'info/alternates'
 if f.exists():
  for line in f.read_text().splitlines():visit(pathlib.Path(line) if line.startswith('/') else p/line)
 ordered.append(str(p))
visit(D/'.git/objects');(R/'.git/objects/info/alternates').write_text('\n'.join(ordered)+'\n')
objects=[(REV,'commit'),(g('rev-parse',REV+'^{tree}').decode().strip(),'tree')]
for l in g('ls-tree','-r','-t',REV).decode().splitlines():
 head,p=l.split('\t');mode,kind,oid=head.split()
 if kind=='tree':objects.append((oid,kind))
for oid,kind in objects:
 b=g('cat-file',kind,oid);raw=(kind+' '+str(len(b))+'\0').encode()+b;assert hashlib.sha1(raw).hexdigest()==oid
 p=R/'.git/objects'/oid[:2]/oid[2:];p.parent.mkdir(exist_ok=True);p.write_bytes(zlib.compress(raw))
(R/'.git/objects/info/alternates').unlink();(R/'.git/shallow').write_text(REV+'\n')
for k,v in [('core.sparseCheckout','true'),('core.sparseCheckoutCone','false'),('core.sshCommand',SSH),('user.name','Wine Ops'),('user.email','wine-ops@local')]:g('config',k,v)
(R/'.git/info/sparse-checkout').write_text('/docs/re-notes/'+H.name+'/\n')
g('update-ref','refs/heads/'+BR,REV);g('symbolic-ref','HEAD','refs/heads/'+BR);g('read-tree','-mu','HEAD');g('remote','add','origin','git@github.com:vgrichina/wine-assembly.git')
manifest=pathlib.Path('/tmp/enigma-small-step-production-gameplay-oct26/ops/resolved-inputs.json.gz')
m=json.loads(gzip.decompress(manifest.read_bytes()));selected=[x for x in m if x['target'] in ['runner/lib/renderer-input.js','runner/lib/renderer.js','runner/lib/host-window.js','runner/test/input-consumption-trace.js','runner/lib/region-map.generated.js','runner/lib/mem-utils.js','runner/lib/surface.js','runner/lib/presentation-filter.js']]
for x in selected:
 b=pathlib.Path(x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
save('exact-related-source.json',dict(manifest=str(manifest),manifestSHA256=sha(manifest.read_bytes()),files=selected,readOnly=True))
save('checkout.json',dict(base=REV,branch=BR,objects=len(objects),mountArgv=[],intendedFiles=[],noGuest=True))
gate('checkout-post');print('CHECKOUT/SOURCE PASS')
