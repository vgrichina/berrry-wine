from common import *
import tarfile,io
E=R/'docs/re-notes'/H.name
# Complete projection: actual task+session+events+positiveDB/WAL growth once;
# 32MiB prospective client/events,8MiB local/remote Git,8MiB reserve.
gate('prepublication')
j=json.load(open(O/'admission-prepublication.json'));current=sum(v for k,v in j['charges'].items() if k not in ['future','reserve']);projected=max(67108864,current+33554432+8388608+8388608)
j.update(projectedBytes=projected,allocation=100663296,prospectiveClientSessionEvents=33554432,prospectiveLocalRemoteGit=8388608,reserve=8388608,positiveWALCountedOnce=True,standingInputsExcluded=True,hostProjectedRemaining=j['hostFree']-projected)
assert projected<=100663296 and j['hostProjectedRemaining']>=2982150144
save('complete-ledger.json',j)
# Check all pinned inputs again without re-executing passing groups.
for x in json.load(open(O/'pins.json')):assert sha(pathlib.Path(x['path']).read_bytes())==x['sha256']
for x in json.load(open(O/'exact-related-source.json'))['files']:assert sha(pathlib.Path(x['path']).read_bytes())==x['sha256']
node=pathlib.Path(NODE);save('standing-tools.json',dict(node=dict(path=NODE,bytes=node.stat().st_size,sha256=sha(node.read_bytes())),git=run(['git','--version'],git=True).decode().strip(),limits=dict(gitDATA=536870912,nodeDATA='unlimited',nodeAS='unlimited',nodeHeapOldSpace=67108864,physicalTree=268435456,cpu=90,wall=120,file=25165824,output=2097152,excerpt=8192)))
readme=(E/'README.md').read_text();readme+='\nCompleted behavioral fixture PASS: exact-production atomic-to-renderer-to-host-poll, split-press state discriminant, stale-batch/outstanding-credit/replay rejection and original trace/frame identity. Peak enclosing supervisor+Node sampled RSS78,692,352B, CPU0.06s, wall0.0742s, output623B; RSS is sampled, not a claim of exact continuous peak. First extraction-marker assertion (before behavior) is retained and corrected by selecting the unique full production expression. Original memory admission denials and double-counted reserve incident are preserved. Later fresh capacity and successful startup/fixture admission receipts are retained. No broader prior groups rerun.\n'
(E/'README.md').write_text(readme)
for n in ['boundary-results.json','checkpoint.json','fixture-execution.json','fixture-output.log','startup-execution.json','startup-output.log','complete-ledger.json','standing-tools.json']:
 shutil.copyfile(O/n,E/n)
# Only bounded task-owned helpers/evidence; archive excludes itself and future Git logs.
with tarfile.open(E/'ops.tar.gz','w:gz') as tf:
 for p in sorted(O.iterdir()):
  if p.is_file() and p.stat().st_size<2097152:tf.add(p,arcname=p.name,recursive=False)
manifest=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(E.iterdir()) if p.is_file() and p.name!='evidence-manifest.json']
(E/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for p in E.rglob('*'):
 if p.is_file():assert p.stat().st_size<=25165824
# Root status/refs are not changed. Only task-owned diagnostic directory staged.
g('add','--','docs/re-notes/'+H.name)
changed=g('diff','--cached','--name-only').decode().splitlines();assert changed and all(p.startswith('docs/re-notes/'+H.name+'/') for p in changed)
g('diff','--cached','--check')
g('commit','-q','-m','Document exact Enigma Start Game host input delivery and regression fixture')
commit=g('rev-parse','HEAD').decode().strip();save('local-commit.json',dict(commit=commit,branch=BR,changed=changed))
g('push','origin','HEAD:refs/heads/'+BR)
remote=g('ls-remote','--exit-code','origin','refs/heads/'+BR).decode().strip();assert remote==commit+'\trefs/heads/'+BR
save('publication.json',dict(commit=commit,branch=BR,remoteRef=remote,exactRemoteVerified=True,changed=changed,status=g('status','--porcelain').decode()))
assert not g('status','--porcelain')
print(json.dumps(dict(commit=commit,branch=BR,exactRemoteVerified=True)))
