from common import *
import ast
j=json.loads(py("import pathlib,json,os;H=pathlib.Path("+repr(REM)+");p=pathlib.Path('/proc/20660');print(json.dumps(dict(launcherStillPresent=p.exists(),launcherCommand=(p/'cmdline').read_bytes().decode().replace('\\u0000',' ') if p.exists() else None,stderr=pathlib.Path('/home/user/.ascii/processes/20660.err.log').read_text()[:6500],completeBytes=sum(p.lstat().st_blocks*512 for p in [H,*H.rglob('*')] if not p.is_symlink()),memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024)))"))
save('remote-handback.json',j)
b=raw(['boat','--json','info',BOX]);save('box-state.json',json.loads(b))
A=json.loads((ROOT/('scratch/usage-watch/'+H.name+'-admission.json')).read_text())
for r in A['pins']+A['fixturePins']:assert sha(P(r['path']))==r['sha256'],r['path']
save('local-after-integrity.json',dict(sourceFiles=149,fixtureFiles=10,unchanged=True))
cp=dict(success=False,outcome='BLOCKED_REQUIRED_DIRECTORY_NAMESPACE_ACCOUNTING',candidate=REV,tree='fc94bfbe7ed6e499bf3d8a55bdb7d88e9dbc4bd2',WebGL1='0/42',WebGL2='0/42',testInvoked=False,nodeStartupInvoked=False,compileInvoked=False,moduleSHA256Required=json.loads((O/'pins.json').read_text())['moduleSHA256'],moduleSHA256Observed=None,browserBackend=None,remaining=['coordinator disposition of production accounting defect','exact Node startup and sole unchanged framebuffer qualification after repair/authorization'],priorFailure='95297d0d272eefd0cc0d5e15f9c16f30961e7d37 startup1083064320B>1073741824B preserved',box=BOX,boxLeftRunning=True,expiry='2026-10-27T00:32:36.350Z',shutdownOwner='coordinator',gameplayClaim=False)
save('checkpoint.json',cp);gate('closeout');print(json.dumps(cp));print(json.dumps(j))
