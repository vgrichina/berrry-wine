import sys,os,importlib.util,pathlib
H=pathlib.Path(__file__).parent.parent;O=H/'ops';M=1048576
spec=importlib.util.spec_from_file_location('sup','/tmp/gl-required-version-independent-integrate-oct26/repo/test/helpers/palette-browser-supervisor.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
pool=pathlib.Path('/proc')/str(os.getppid())/'statm';overhead=int(pool.read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
cap=(256 if os.environ.get('GL_GIT_SLOT')=='2' else 128)*M
r=s.supervise([sys.executable,str(O/sys.argv[1]),*sys.argv[2:]],rss_limit=cap-overhead,cpu_limit=90,wall_limit=120,output_limit=2*M)
out=r.pop('output');(O/(sys.argv[1]+'.controller.log')).write_bytes(out)
import json
(O/(sys.argv[1]+'.controller.json')).write_text(json.dumps(dict(r,poolRSS=overhead,totalPhysicalCap=cap),indent=2))
print(out.decode(errors='replace')[-6500:]);print(json.dumps({k:v for k,v in r.items() if k!='owned'}));sys.exit(1 if r['stopReason'] or r['exit'] else 0)
