from common import *
import base64
gate('before-probe')
b=bytes(i%251 for i in range(34000));dest=REM+'/transfer-probe'
code="import pathlib,base64,hashlib,json,shutil,resource;H=pathlib.Path("+repr(REM)+");assert not H.exists();H.mkdir();(H/'ops').mkdir();(H/'tmp').mkdir();(H/'parts').mkdir();p=H/'transfer-probe';b=base64.b64decode("+repr(base64.b64encode(b).decode())+");p.write_bytes(b);assert p.read_bytes()==b;print(json.dumps(dict(bytes=len(b),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),free=shutil.disk_usage(H).free,limits=pathlib.Path('/proc/self/limits').read_text(),mem=pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])))"
save('bounded-transfer-probe.json',json.loads(py(code)))
print('PASS 34000 decoded bytes API transfer/readback')
