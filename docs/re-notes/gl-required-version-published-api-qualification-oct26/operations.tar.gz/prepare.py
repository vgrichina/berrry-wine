from common import *
import tarfile,base64
gate('prepare')
A=json.loads((ROOT/('scratch/usage-watch/'+H.name+'-admission.json')).read_text());plan=json.loads((ROOT/'scratch/usage-watch/gl-palette-current-webgl-closure-plan-oct26.json').read_text())
for r in A['pins']+A['fixturePins']:assert sha(P(r['path']))==r['sha256'],r['path']
mount=json.loads(P('/tmp/gl-palette-current-webgl-qualification-oct26/ops/mount-configuration.json').read_text());src=(ROOT/'test/run.js').read_text();parser=src[src.index('const getArg ='):src.index('// Was `--name=...`')];assert sha(P('/tmp/gl-palette-current-webgl-qualification-oct26/ops/mount-configuration.json'))
assert hashlib.sha256(parser.encode()).hexdigest()==mount['parserSHA256'] and mount['argv']==mount['enumeration']==mount['commaFilenames']==[] and mount['trustedSSH']==SSH
save('launch-configuration.json',dict(mount=mount,actualMountArgv=[],reusedExactConfiguration=True,trustedSSH=SSH))
R.mkdir();g('init','-q');g('config','remote.origin.url','git@github.com:vgrichina/wine-assembly.git');g('config','remote.origin.promisor','true');g('config','remote.origin.partialclonefilter','blob:none');(R/'.git/objects/info/alternates').write_text(str(D/'.git/objects')+'\n')
files={r['relative']:r['sha256'] for r in A['fixturePins']};g('config','core.sparseCheckout','true');g('config','core.sparseCheckoutCone','false');(R/'.git/info/sparse-checkout').write_text(''.join('/'+p+'\n' for p in files));g('checkout','-b',BR,REV)
assert g('show','-s','--format=%H %T',REV).decode().strip()==REV+' fc94bfbe7ed6e499bf3d8a55bdb7d88e9dbc4bd2'
for p,h in files.items():assert sha(R/p)==h,p
rows=g('ls-tree','-r','-t',REV).decode().splitlines();ids=[REV]+[r.split()[2] for r in rows if r.split()[1]=='tree' or r.split('\t',1)[1] in files]
(O/'fixture.pack').write_bytes(g('pack-objects','--stdout',input=('\n'.join(ids)+'\n').encode()))
deps=P('/tmp/wa-local-runtime-deps/node_modules');packages={}
def dep(n):
 if n in packages:return
 data=json.loads((deps/n/'package.json').read_text());packages[n]=data
 for c in data.get('dependencies',{}):dep(c)
dep('puppeteer');manifest={}
with tarfile.open(H/'inputs.tar.gz','w:gz',compresslevel=6) as t:
 def add(p,n):
  assert p.is_file() and not p.is_symlink(),p
  t.add(p,arcname=n,recursive=False);manifest[n]=dict(bytes=p.stat().st_size,sha256=sha(p))
 for r in plan['files']:add(S/r['path'],'source/'+r['path'])
 for p in (S/'.git').rglob('*'):
  if p.is_file():add(p,'source/.git/'+str(p.relative_to(S/'.git')))
 for p in files:add(R/p,'repo/'+p)
 for p in (R/'.git').rglob('*'):
  if p.is_file() and 'objects' not in p.relative_to(R/'.git').parts:add(p,'repo/.git/'+str(p.relative_to(R/'.git')))
 add(O/'fixture.pack','fixture.pack')
 for n in packages:
  for p in (deps/n).rglob('*'):
   rel=p.relative_to(deps/n)
   if p.is_file() and not p.is_symlink() and p.suffix not in ('.map','.ts','.md') and not any(x in rel.parts for x in ('test','tests','docs')):add(p,'deps/node_modules/'+n+'/'+str(rel))
save('inputs-manifest.json',manifest);save('dependency-closure.json',{n:dict(version=d['version'],dependencies=d.get('dependencies',{})) for n,d in packages.items()})
save('pins.json',dict(source=plan,fixture=dict(head=REV,tree='fc94bfbe7ed6e499bf3d8a55bdb7d88e9dbc4bd2',files=files),archiveSHA256=sha(H/'inputs.tar.gz'),moduleSHA256='558b66e4787a2808a89de68efe7b158915e93992f6d4950e9ee11d93b4ba00b6'))
save('reused-receipt.json',json.loads((D.parent/'ops/consolidated-receipt.json').read_text()))
gate('prepared');print(json.dumps(dict(archiveBytes=(H/'inputs.tar.gz').stat().st_size,files=len(manifest),packages=len(packages))))
