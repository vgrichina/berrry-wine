from common import *
import base64
# Runtime completed; retain exact evidence with <=8192-byte API responses.
inventory=json.loads(py("import pathlib,json,hashlib;O=pathlib.Path("+repr(REM+'/ops')+");print(json.dumps({p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in O.iterdir() if p.is_file() and p.name not in ['inputs-manifest.json','pins.json']}))"))
dest=O/'remote';dest.mkdir(exist_ok=True)
for name,row in inventory.items():
 data=bytearray()
 for off in range(0,row['bytes'],4500):
  out=py("import pathlib,base64;p=pathlib.Path("+repr(REM+'/ops/'+name)+");f=p.open('rb');f.seek("+str(off)+");print(base64.b64encode(f.read(4500)).decode())")
  data.extend(base64.b64decode(out.strip()))
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],name
 (dest/name).write_bytes(data)
save('remote-evidence-manifest.json',inventory)
# Identity-aware live cleanup verification, no process execution or replay.
cleanup=json.loads(py("import pathlib,json;H=pathlib.Path("+repr(REM)+");recs=[json.loads(p.read_text()) for p in (H/'ops').glob('*-receipt.json')];left=[]\nfor rec in recs:\n for pid,start in rec['owned']:\n  try:\n   raw=pathlib.Path('/proc',str(pid),'stat').read_text();s=raw[raw.rindex(')')+2:].split()\n   if s[19]==start:left.append([pid,start])\n  except FileNotFoundError:pass\nprint(json.dumps({'remainingOwned':left,'cleanupComplete':all(r['cleanupComplete'] for r in recs),'receiptCount':len(recs),'testInvoked':(H/'ops/invocation-start.json').exists(),'boxLeftRunning':True,'expiry':'2026-10-27T00:32:36.350Z','shutdownOwner':'coordinator'}))"))
assert cleanup['remainingOwned']==[] and cleanup['cleanupComplete'];save('cleanup.json',cleanup)
print(json.dumps(dict(collected=len(inventory),bytes=sum(v['bytes'] for v in inventory.values()),cleanup=cleanup)))
