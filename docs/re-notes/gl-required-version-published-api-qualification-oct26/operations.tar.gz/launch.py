from common import *
import base64
# Before invoking runtime, send the parameterized production runner immutably.
gate('immediate-before-runtime')
b=(O/'remote-run.py').read_bytes()
assert len(b)<34000
py("import pathlib,base64,hashlib;p=pathlib.Path("+repr(REM+'/ops/remote-run.py')+");assert not p.exists();b=base64.b64decode("+repr(base64.b64encode(b).decode())+");p.write_bytes(b);assert hashlib.sha256(p.read_bytes()).hexdigest()=="+repr(hashlib.sha256(b).hexdigest())+";print('runner verified')")
cmd=shlex.join(['python3',REM+'/ops/remote-run.py',REM+'/repo/test/helpers/palette-browser-supervisor.py'])
b=raw(['boat','exec','--json','--detach',BOX,cmd],30)
j=json.loads(b);save('runtime-launch.json',j);print(json.dumps(j))
