import pathlib,os,json,hashlib,subprocess,resource,shutil,time,shlex,importlib.util
P=pathlib.Path;M=1048576;H=P('/tmp/gl-required-version-published-api-qualification-oct26');O=H/'ops';R=H/'repo';ROOT=P('/home/user/wine-assembly');BOX='bx_bwf4vkqh';REM=str(H)
S=P('/tmp/gl-palette-current-webgl-qualification-oct26/source');D=P('/tmp/gl-required-version-independent-integrate-oct26/repo');REV='ddaff339bd7e1b10b2579a7ab7aed71d86d8edcd';BR='task/'+H.name
SSH='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
os.environ.update(GIT_SSH_COMMAND=SSH,BOAT_NO_UPDATE='1',PYTHONDONTWRITEBYTECODE='1')
def save(n,j):
 p=O/n;t=p.with_suffix('.new');t.write_text(json.dumps(j,indent=2)+'\n');os.replace(t,p)
def sha(p):
 h=hashlib.sha256()
 with P(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def alloc(p):
 if not p.exists():return 0
 return sum(q.lstat().st_blocks*512 for q in ([p,*p.rglob('*')] if p.is_dir() else [p]) if not q.is_symlink())
def gate(stage):
 a=json.loads((ROOT/('scratch/usage-watch/'+H.name+'-admission.json')).read_text());charges={str(H):alloc(H),str(ROOT/'scratch/usage-watch'/H.name):alloc(ROOT/'scratch/usage-watch'/H.name)}
 sessions=list(P('/home/user/.codex/sessions/2026/10/26').glob('*'+os.environ['CODEX_THREAD_ID']+'*'));charges['sessions']=sum(alloc(p) for p in sessions)
 baseline=json.loads((O/'wal-baseline.json').read_text());charges['positiveWALOnce']=sum(max(0,alloc(P(p))-v) for p,v in baseline.items());charges.update(futureArchiveGitPublication=32*M,futureSessionEvents=16*M,reserve=8*M)
 peers={}
 for n,v in a['peerRemaining'].items():
  peer=P('/tmp')/n;receipt=peer/'ops/publication.json'
  if (peer/'ops/result.json').exists() and receipt.exists():
   peers[n]=0
  else:
   materialized=alloc(peer)+alloc(ROOT/'scratch/usage-watch'/n)
   peers[n]=min(v,max(0,(64 if n.startswith('alien') else 96)*M-materialized))
 clients=[]
 for p in P('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if os.readlink(p/'exe').endswith('/codex') and b'exec' in (p/'cmdline').read_bytes().split(b'\0'):clients.append(dict(pid=int(p.name),rss=int((p/'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')))
  except OSError:pass
 growth=sum(max(0,320*M-c['rss']) for c in clients);mem=int(P('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
 projection=sum(charges.values());incremental=max(0,128*M-sum(v for k,v in charges.items() if not k.startswith('future') and k!='reserve'))
 free=shutil.disk_usage(H).free-incremental-sum(peers.values());required=(768+256)*M+growth
 j=dict(stage=stage,charges=charges,projection=projection,allocation=128*M,peerRemaining=peers,projectedFree=free,floor=2982150144,clients=clients,remainingGrowthOnce=growth,memAvailable=mem,required=required)
 j['passAdmission']=projection<=128*M and free>=j['floor'] and mem>=required;save('admission-'+stage+'.json',j);assert j['passAdmission'],j
 return j
def raw(a,timeout=30):
 p=subprocess.run(a,capture_output=True,timeout=timeout,env=os.environ)
 assert len(p.stdout)+len(p.stderr)<=8192
 assert p.returncode==0,(a[:4],p.returncode,p.stdout[:2000],p.stderr[:2000])
 return p.stdout
def api(cmd,timeout=30):
 b=raw(['boat','exec','--json','--timeout',str(timeout),BOX,cmd],timeout+15);j=json.loads(b)
 with (O/'api-receipts.jsonl').open('a') as f:f.write(json.dumps(j)+'\n')
 assert j.get('exitCode')==0 and not j.get('stdoutTruncated') and not j.get('stderrTruncated'),j
 return j['stdout']
def py(code):return api('python3 -c '+shlex.quote(code))
def g(*a,cwd=R,input=None):
 spec=importlib.util.spec_from_file_location('sup',D/'test/helpers/palette-browser-supervisor.py');sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
 old=P.cwd();os.chdir(cwd)
 argv=['/usr/bin/prlimit','--data=536870912:536870912','--','/usr/bin/git','-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*a]
 if input is not None:
  ip=O/'git-input';ip.write_bytes(input);argv=['/bin/sh','-c','exec '+shlex.join(argv)+' < '+shlex.quote(str(ip))]
 rec=sup.supervise(argv,rss_limit=240*M,cpu_limit=90,wall_limit=120,output_limit=2*M);os.chdir(old);out=rec.pop('output');n=len(list(O.glob('git-*-receipt.json')))+1;(O/('git-%02d.log'%n)).write_bytes(out);save('git-%02d-receipt.json'%n,rec)
 assert rec['exit']==0 and rec['stopReason'] is None and rec['cleanupComplete'],rec
 return out
