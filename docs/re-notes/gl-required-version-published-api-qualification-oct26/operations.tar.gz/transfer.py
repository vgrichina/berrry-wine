from common import *
import base64,concurrent.futures
gate('before-staging')

def transfer(src,label):
 data=src.read_bytes()
 def one(i):
  part=data[i:i+34000];dest=REM+'/parts/'+label+'-%06d'%i
  code="import pathlib,base64,hashlib;p=pathlib.Path("+repr(dest)+");b=base64.b64decode("+repr(base64.b64encode(part).decode())+");assert not p.exists();p.write_bytes(b);assert hashlib.sha256(p.read_bytes()).hexdigest()=="+repr(hashlib.sha256(part).hexdigest())+";print('verified')"
  py(code)
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(one,range(0,len(data),34000)))
 return dict(label=label,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),chunks=(len(data)+33999)//34000)
receipts=[transfer(H/'inputs.tar.gz','archive'),transfer(O/'inputs-manifest.json','manifest'),transfer(O/'pins.json','pins')]
save('transfer.json',receipts)
code='''import pathlib,hashlib,json,tarfile,subprocess,resource,os
H=pathlib.Path(REMDIR)
for r in RECEIPTS:
 p=H/({'archive':'inputs.tar.gz','manifest':'ops/inputs-manifest.json','pins':'ops/pins.json'}[r['label']])
 with p.open('wb') as f:
  for c in sorted((H/'parts').glob(r['label']+'-*'),key=lambda p:int(p.name.rsplit('-',1)[1])):f.write(c.read_bytes())
 assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
manifest=json.loads((H/'ops/inputs-manifest.json').read_text())
with tarfile.open(H/'inputs.tar.gz') as t:
 members=t.getmembers();assert len(members)==len(manifest)
 for m in members:
  assert m.isfile() and m.name in manifest and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts
 t.extractall(H,filter='data')
for n,r in manifest.items():
 p=H/n;assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],n
def lim():resource.setrlimit(resource.RLIMIT_DATA,(536870912,536870912));resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
(H/'repo/.git/objects').mkdir(exist_ok=True)
with (H/'fixture.pack').open('rb') as f:
 p=subprocess.run(['/usr/bin/git','-C',str(H/'repo'),'index-pack','--stdin'],stdin=f,capture_output=True,timeout=120,preexec_fn=lim);assert p.returncode==0,p.stderr[:2000]
for root in ['source','repo']:
 for args in [['rev-parse','HEAD'],['diff','--stat']]:
  p=subprocess.run(['/usr/bin/git','-C',str(H/root),*args],capture_output=True,timeout=120,preexec_fn=lim);assert p.returncode==0,p.stderr[:2000]
  if args[0]=='diff':assert not p.stdout,p.stdout[:2000]
print(json.dumps({'verifiedFiles':len(manifest),'archiveSHA256':hashlib.sha256((H/'inputs.tar.gz').read_bytes()).hexdigest(),'safeExtraction':True,'gitIdentitiesClean':True}))
'''.replace('REMDIR',repr(REM)).replace('RECEIPTS',repr(receipts))
save('remote-extract-result.json',json.loads(py(code)))
print('PASS immutable transfer/full hashes/safe extraction/real Git identities')
