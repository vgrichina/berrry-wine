from common import *
print(py("import pathlib,json;O=pathlib.Path("+repr(REM+'/ops')+");print(json.dumps({n:json.loads((O/n).read_text()) for n in ['failure.json','checkpoint.json'] if (O/n).exists()}))"))
