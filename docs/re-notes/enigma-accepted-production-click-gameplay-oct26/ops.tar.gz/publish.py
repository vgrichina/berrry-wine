from work import *
import tarfile,io,datetime
REV='754c97d3ff22ce0a0cd06d08ac06dc0446fbcbb2'
ri=json.loads(jread('cleanup.json')['stdout']);assert ri['remainingOwnGroup']==[]
actual=43933696+131072+4096
admission('prepublication',actual+2097152)
receipt=dict(outcome='BLOCKED_BEFORE_CONTROLLER_INVOCATION',blocker='The first frozen control step {action:step,n:100000} was submitted once at20:35:55.946Z; its urllib response timed out after45seconds at20:36:41.373Z. Step completion and zero outstanding credits were never acknowledged. Stopped at the first runtime rejection, without retrying step or invoking the one-shot Start Game controller.',
 controllerRejected=False,clickControllerInvocations=0,clickDispatches=0,actualInputDelivery=False,pngManifest=[],screenshotsInspected=False,gameplayObserved=False,levelSelectionObserved=False,menuEvidence='guest trace only: [SetWindowText] "Enigma - Main Menu"; no framebuffer inspected',
 source=dict(main=REV,runnerBlob='4b8461338f4bcddde6b5d5504991523b28d3ac35',runnerSHA256='87ab63d768eb59a09a8b69df2ccb3843270dd867a67405abd82f02c25c1628e7',controllerSHA256='c4d6c24cc8c0d321b8e6dd17e299116ef4b94fb71899e0f4801e4330cf1adac6',derivativeSHA256='a9625e1d102883c27b1bd2de0bab560a44ab3bc7eb589b18e7a736100eb2a0da',moduleSHA256='8fac39936b6df2418ad86cab118cef19a65a727f649fbc14c412b37818904686',moduleQualification='historical static-unpack diagnostic, not untouched original or current-main binary qualification',originalManifestSHA256='4ccbdd4e9bab80a88bf9565f813681c5369e4b16ef5dcd34291b87c361a793fe',stagedManifestSHA256=jread('standing-inputs.json')['manifestSHA256'],stagingHelperSHA256='d3b2a9c152de0a7cfbe61facf1d847d6192e4bd399e1638091417070ffdb1f3b',standingCaptureSHA256='6d64a146f2daf8b598dbf13e3c13f890dbc783d8f5286aacba6d343758d22079'),
 replacements='replacements.json inventories all98 exact accepted-donor dependency files;2661 destination entries37503235logical bytes verified',command=jread('retained/command.json'),traceManifest=jread('remote-evidence-manifest.json'),startup='retained/node-startup.json; actualNode24.22.1 heap2048, CPU90/file24MiB; DATA/AS unlimited, no GitDATA inherited',
 resource=dict(cap=67108864,reserve=8388608,remoteMeasuredPreGuest=43933696,remotePhysicalRequired=3758096384,localPhysicalRequired=1879048192,actualGuest=ri['terminal'],receipts=['admission-prestage.json','first-storage-gate.json','storage-reduction.json','admission-preguest.json','admission-prepublication.json']),
 incidents=['Owned scanner initially misclassified .generated suffix and a commented require; fixed before staging; no accepted source changes.','Initial screenshot/publication storage projection rejected; no guest started. Removed own unnecessary1.75MiB Git index and compressed1.09MiB manifest; actual capacity changed, same64MiB cap/reserve passed.','Runtime control step timed out; first rejection retained verbatim; no replay or controller invocation.','Initial messageboard timestamp estimate corrected append-only.'],
 reusedEvidence='coordinator accepted29 independent and prior passing offline groups;0 offline test replay; fresh actual environment/parser/transform/startup only',
 lifecycle=dict(box='bx_27q8zz3v',state='RUNNING verified by API exec',createdAt='2026-10-26T20:27:42.639Z',guestStartedAt='2026-10-26T20:35:54.740Z',guestCutoff='2026-10-26T20:55:00Z',handback='2026-10-26T21:00:00Z',coordinatorShutdown='2026-10-26T21:05:00Z',expiry='2026-10-26T21:57:42.639Z',shutdownOwner='coordinator',ownGroupsRemaining=[]),remaining='A future coordinator decision is required; this worker stops. No source repair/build/acquisition/MAIN publication/workers or F1 replay.')
save('final-receipt.json',receipt)
e=REPO/E;e.mkdir(parents=True,exist_ok=True)
(e/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(e/'README.md').write_text('Enigma production click attempt — blocked before click\n\nExact accepted production runner/controller startup and transform passed. The one guest reached the main-menu title in its trace. The first frozen 100000-batch step exceeded its45s response wait, so completion and zero credits were not established. No controller invocation, PNG, ordinary input delivery, level selection or gameplay is claimed. No retry. Guest stopped after56.4s; process group empty; bx_27q8zz3v remains RUNNING for coordinator handback.\n\nreceipt.json binds all pins, command, limitations and lifecycle. ops.tar.gz retains the actual command, first timeout, trace, destination manifest/replacements, admission incidents and bounded recipes. Historical diagnostic module qualification only. No production source changed.\n')
with tarfile.open(e/'ops.tar.gz','w:gz',compresslevel=9) as t:
 for p in sorted(O.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts or p.name.startswith('board-watch') or p.name=='git-commands.jsonl':continue
  t.add(p,arcname=str(p.relative_to(O)),recursive=False)
manifest=[dict(path=str(p.relative_to(e)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(e.iterdir())]
(e/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
admission('packaged',actual+3145728)
git('read-tree',REV)
for p in sorted(e.iterdir()):
 name=str(p.relative_to(REPO));blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo','100644',blob,name)
tree=git('write-tree','--missing-ok');changed=git('diff','--cached','--name-only',REV).splitlines();assert changed and all(x.startswith(E+'/') for x in changed)
commit=git('commit-tree',tree,'-p',REV,'-m','docs: retain Enigma production click attempt timeout evidence')
git('update-ref','refs/heads/'+BRANCH,commit,REV)
git('push','origin','refs/heads/'+BRANCH+':refs/heads/'+BRANCH)
remoteRef=git('ls-remote','origin','refs/heads/'+BRANCH);assert remoteRef.split()[0]==commit
save('publication.json',dict(commit=commit,remote=remoteRef,branch=BRANCH,tree=tree,changed=changed,manifestSHA256=sha((e/'evidence-manifest.json').read_bytes())))
print(json.dumps(jread('publication.json')))
