from work import *
def control(c,timeout=25):
 return py('import json,urllib.request;r=urllib.request.Request("http://127.0.0.1:18127/ctl",data='+repr(json.dumps(c).encode())+',headers={"Content-Type":"application/json"})\nwith urllib.request.urlopen(r,timeout='+str(timeout)+') as f:print(f.read(8192).decode())',timeout+3)
save('step-menu.json',control(dict(action='step',n=100000),45))
save('before-snapshot.json',control(dict(action='snapshot')))
save('click-api.json',remote('cd '+shlex.quote(R)+' && timeout 20 '+shlex.quote(NODE)+' --max-old-space-size=192 click.cjs',25,allow_exit=True))
j=jread('click-api.json');r=json.loads(j['stdout'])
if r.get('enqueueOutcome')=='acknowledged':
 save('step-after.json',control(dict(action='step',n=3000),25));save('after-snapshot.json',control(dict(action='snapshot')));save('after-png.json',control(dict(action='png',path=R+'/guest/after.png')))
save('stop.json',py('import pathlib;pathlib.Path('+repr(R+'/guest/stop')+').touch()'))
print(json.dumps(r))
