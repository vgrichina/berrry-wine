from work import *
old=pathlib.Path('/tmp/enigma-verified-input-menu-gameplay-api-oct26/ops');a=[x.replace(str(old.parent),R) for x in json.loads((old/'guest-args.json').read_text())];a=[x for x in a if not x.startswith('--require=') and not x.startswith('--input=')];a[1]='--max-old-space-size=2048';a[a.index(R+'/runner/test/run.js')]=R+'/runner/test/run-presented.cjs';a+=['--frozen'];a.insert(2,'--require='+R+'/capture-wrapper.cjs')
source=payload(jread('manifest.json')[0]).decode();parser=source[source.index('const getArg ='):source.index('// Was `--name=...`')]
idx=a.index(R+'/runner/test/run-presented.cjs');code='const assert=require("assert"),args='+json.dumps(a[idx+1:])+';'+parser+';assert.deepEqual(getArgs("vfs-tree"),['+json.dumps(R+'/vfs')+']);assert.equal(getArgs("vfs-mount").length,0);assert.equal(getArgs("dlls").length,8);assert(hasFlag("no-build"));assert(hasFlag("frozen"));console.log("PASS exact production canonical argv")'
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
p=subprocess.run(['node','--max-old-space-size=192','-e',code],capture_output=True,text=True,timeout=30,preexec_fn=limits);save('canonical-parser.json',dict(exit=p.returncode,stdout=p.stdout,stderr=p.stderr,parserSHA256=sha(parser.encode()),argv=a,enumeration=[x['target'] for x in jread('manifest.json') if x['target'].startswith('vfs/')],commaFilenames=[x['target'] for x in jread('manifest.json') if ',' in x['target']]))
assert p.returncode==0,p.stderr
save('trusted-ssh-config.json',dict(command=SSH,unchanged=True,source='user exact launch checkpoint'))
print(p.stdout)
