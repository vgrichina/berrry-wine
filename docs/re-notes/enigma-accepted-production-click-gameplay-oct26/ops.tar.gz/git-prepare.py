from work import *
assert jread('canonical-parser.json')['exit']==0
REV='754c97d3ff22ce0a0cd06d08ac06dc0446fbcbb2';DON=pathlib.Path('/tmp/enigma-tracked-pin-independent-publication-oct26/repo')
git('init','-q',str(REPO),repo=H);(REPO/'.git/objects/info/alternates').write_text(str(DON/'.git/objects')+'\n')
for k,v in [('user.name','Wine Ops'),('user.email','wine-ops@local'),('core.sshCommand',SSH),('gc.auto','0')]:git('config',k,v)
git('read-tree',REV);git('update-ref','refs/heads/'+BRANCH,REV);git('symbolic-ref','HEAD','refs/heads/'+BRANCH);git('remote','add','origin',URL)
save('git-prepared.json',dict(parent=REV,branch=BRANCH,mode='index only, immutable donor objects, no full checkout',ssh=SSH))
print('minimal Git prepared')
