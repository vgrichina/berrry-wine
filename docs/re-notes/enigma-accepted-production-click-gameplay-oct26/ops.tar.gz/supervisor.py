import os,sys,pathlib,subprocess,resource,time,json,signal
H=pathlib.Path(__file__).parent;E=H/'guest';assert time.time()<1793048100
a=json.loads((H/'guest-args.json').read_text());env=dict(os.environ);env.pop('WINE_RUN_EXTRA_ARGS',None);env.pop('WINE_REGION_MAP',None)
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
assert not (E/'command.json').exists()
mem=lambda:int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
assert mem()>=3758096384
with (E/'output.log').open('wb') as f:
 p=subprocess.Popen(a,cwd=H/'runner',env=env,preexec_fn=limits,start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);os.set_blocking(p.stdout.fileno(),False);start=time.monotonic();n=0;peak=0;reason='natural'
 (E/'command.json').write_text(json.dumps(dict(argv=a,pid=p.pid,pgid=p.pid,at=time.time(),memAvailable=mem(),limits=dict(cpu=90,wall=89,file=25165824,output=2097152,arena=536870912,oldSpaceMiB=2048))))
 try:
  while p.poll() is None:
   try:b=os.read(p.stdout.fileno(),8192)
   except BlockingIOError:b=b''
   if b:f.write(b);f.flush();n+=len(b)
   try:rss=int(pathlib.Path('/proc/'+str(p.pid)+'/status').read_text().split('VmRSS:')[1].split()[0])*1024;peak=max(peak,rss)
   except (OSError,IndexError):rss=0
   if n>131072 or rss>2684354560 or mem()<805306368 or time.monotonic()-start>89 or time.time()>=1793048100 or (E/'stop').exists():reason='guard-or-owned-stop';break
   time.sleep(.02)
 finally:
  try:os.killpg(p.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:p.wait(timeout=1)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  try:
   while b:=os.read(p.stdout.fileno(),8192):f.write(b);n+=len(b)
  except BlockingIOError:pass
 (E/'terminal.json').write_text(json.dumps(dict(reason=reason,returncode=p.returncode,elapsed=time.monotonic()-start,peakRSS=peak,outputBytes=n,box='bx_27q8zz3v',boxState='RUNNING',shutdownOwner='coordinator')))
