from work import *
j=py('''import pathlib,json,shutil,importlib.util,os,time
h=pathlib.Path('''+repr(R)+''');spec=importlib.util.spec_from_file_location('s',h/'bounded-staging.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
ps=[]
for p in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  cmd=(p/'cmdline').read_bytes().replace(b'\\0',b' ').decode(errors='replace')
  if '/bin/node' in cmd or 'stream-stage.py' in cmd:ps.append(dict(pid=int(p.name),rss=int((p/'status').read_text().split('VmRSS:')[1].split()[0])*1024,cmd=cmd[:200]))
 except (OSError,IndexError):pass
mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
j=dict(at=time.time(),memAvailable=mem,requiredPhysical=2684354560+268435456+805306368,diskFree=shutil.disk_usage('/tmp').free,inventory=s.inventory(h),processes=ps,uid=os.getuid())
assert mem>=j['requiredPhysical'] and j['uid']==1000
assert not any('run-presented' in p['cmd'] for p in ps)
print(json.dumps(j))''',30);save('remote-preguest.json',j);ri=json.loads(j['stdout'])
j=admission('preguest',ri['inventory']['physicalOwnedBytes']+4194304)
assert j['memAvailable']>=268435456+805306368+805306368
assert j['total']+4194304<=67108864,'extra local/remote PNG/publication growth gate'
save('guest-detach.json',remote('cd '+shlex.quote(R)+' && python3 supervisor.py',detach=True));print('GUEST LAUNCHED')
