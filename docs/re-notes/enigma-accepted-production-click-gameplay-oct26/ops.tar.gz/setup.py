import pathlib,os,json,subprocess,hashlib,resource,re,posixpath,importlib.util,shutil,time
H=pathlib.Path('/tmp/enigma-accepted-production-click-gameplay-oct26');O=H/'ops'
old=pathlib.Path('/tmp/enigma-verified-input-menu-gameplay-api-oct26/ops')
s=(old/'work.py').read_text().replace('enigma-verified-input-menu-gameplay-api-oct26','enigma-accepted-production-click-gameplay-oct26').replace("BOX='bx_xfbwmcty'","BOX='bx_27q8zz3v'")
(O/'work.py').write_text(s)
from work import *
DON='/tmp/enigma-tracked-pin-independent-publication-oct26/repo';REV='754c97d3ff22ce0a0cd06d08ac06dc0446fbcbb2'
save('sqlite-baseline.json',{str(p):allocated(p) for p in pathlib.Path('/home/user/.codex').glob('*sqlite*')})
argv=pathlib.Path('/proc/3071013/cmdline').read_bytes().split(b'\0');save('launch.json',dict(pid=3071013,argv=[x.decode() for x in argv if x],session=json.loads((L/'events.jsonl').open().readline())['thread_id']))
assert all(x.encode() in argv for x in ['gpt-6.1-sol','model_reasoning_effort="medium"','model_auto_compact_token_limit=200000','model_auto_compact_token_limit_scope="total"'])
m=json.loads((P/'manifest.json').read_text());assert sha((P/'manifest.json').read_bytes())=='4ccbdd4e9bab80a88bf9565f813681c5369e4b16ef5dcd34291b87c361a793fe'
cache={};pending=['test/run.js'];missing=[];excluded=[]
paths=set(subprocess.check_output(['git','-C',DON,'ls-tree','-rz','--name-only',REV],preexec_fn=glimits).decode().split('\0'))
def get(p):
 if p not in cache:cache[p]=subprocess.check_output(['git','-C',DON,'show',REV+':'+p],preexec_fn=glimits,stderr=subprocess.DEVNULL)
 return cache[p]
while pending:
 p=pending.pop()
 if p in cache:continue
 try:b=get(p)
 except subprocess.CalledProcessError:missing.append(p);continue
 if not p.endswith(('.js','.cjs')):continue
 for ref in re.findall(r'''(?:require\s*\(|import\s*\()\s*['"](\.[^'"]+)['"]''',b.decode()):
  q=posixpath.normpath(posixpath.join(posixpath.dirname(p),ref));candidates=[q,q+'.js',q+'.json',q+'/index.js']
  for c in candidates:
   if c in paths:
    if c not in cache:pending.append(c)
    break
  else:
   lines=[l for l in b.decode().splitlines() if ref in l]
   if all(l.strip().startswith('//') for l in lines):excluded.append(dict(source=p,reference=ref,lines=lines))
   else:missing.append(q)
assert not missing,missing
save('scanner-incidents.json',dict(firstFailure='suffix handling for .generated and commented require snippet',excluded=excluded))
repl=[];by={x['target']:x for x in m}
for p,b in cache.items():
 target='runner/'+p;x=dict(path=p,bytes=len(b),sha256=sha(b),target=target,kind='git',revision=REV,donor=DON)
 repl.append(dict(old=by.get(target),new=x));by[target]=x
m=list(by.values());save('replacements.json',dict(replacements=repl,count=len(cache),missing=missing));save('manifest.json',m)
spec=importlib.util.spec_from_file_location('staging',D/'tools/enigma-bounded-staging.py');st=importlib.util.module_from_spec(spec);spec.loader.exec_module(st);st.validate(m)
modes=[None if st.font(x['target']) else st.regular_mode(x) for x in m];save('source-modes.json',modes)
save('standing-inputs.json',dict(priorPreflight=str(ROOT/'scratch/usage-watch/enigma-accepted-click-input-preflight-oct26.json'),reused2659Hashes=True,production=REV,closureFiles=len(cache),closureLogicalBytes=sum(map(len,cache.values())),manifestSHA256=sha((O/'manifest.json').read_bytes())))
admission('prestage',43679744+sum(len(b) for p,b in cache.items() if 'runner/'+p not in {x['target'] for x in json.loads((P/'manifest.json').read_text())}))
save('remote-prestage.json',py('import pathlib,json,shutil,resource;print(json.dumps(dict(memAvailable=int(pathlib.Path("/proc/meminfo").read_text().split("MemAvailable:")[1].split()[0])*1024,diskFree=shutil.disk_usage("/tmp").free,limits={k:resource.getrlimit(getattr(resource,k)) for k in ["RLIMIT_DATA","RLIMIT_AS","RLIMIT_FSIZE","RLIMIT_CPU"]})))'))
r=json.loads(jread('remote-prestage.json')['stdout']);assert r['memAvailable']>=3758096384 and r['diskFree']-67108864>=2982150144
remote('test ! -e '+shlex.quote(R)+' && mkdir '+shlex.quote(R))
b=os.urandom(32769);rr=send(b,'transfer-control.bin');assert json.loads(rr['stdout'])==dict(bytes=len(b),sha256=sha(b));save('transfer-control.json',dict(bytes=len(b),sha256=sha(b),remote=rr));py('import pathlib;pathlib.Path('+repr(R+'/transfer-control.bin')+').unlink()')
print('PREPARED production closure',len(cache),'files; transfer hash/readback PASS',flush=True)
