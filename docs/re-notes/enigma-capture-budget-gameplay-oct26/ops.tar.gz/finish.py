from work import *
import tarfile
r=O/'retained';out=json.loads((r/'outcome.json').read_text());term=json.loads((r/'terminal.json').read_text())
rows=[json.loads(x) for x in gzip.open(r/'requests.jsonl.gz','rt')];steps=[];snaps=[]
for i,row in enumerate(rows):
 c=json.loads(row['request']);v=json.loads(row['originalResponse']).get('value') if 'originalResponse' in row else None
 if c['action']=='step' and v:
  assert 1<=c['n']<=256 and v['ran']==v['steps']==c['n'] and v['frozen']
  s=json.loads(rows[i+1]['originalResponse'])['value'];assert json.loads(rows[i+1]['request'])['action']=='snapshot' and s['frozen']['credits']==0 and s['batch']==v['batch'];steps.append(c['n'])
 if c['action']=='snapshot' and v:assert v['frozen']['credits']==0;snaps.append(v)
 assert i==0 or rows[i-1]['ended']<=row['at']
assert steps[0]==1 and sum(steps)==out['acknowledgedBatches']
imgs=[]
for p in r.glob('*.png'):
 b=p.read_bytes();imgs.append(dict(name=p.name,sha256=sha(b),bytes=len(b),width=int.from_bytes(b[16:20],'big'),height=int.from_bytes(b[20:24],'big')))
 assert len(b)<=2097152 and imgs[-1]['width']<=800 and imgs[-1]['height']<=600
assert len(imgs)<=3 and sum(x['bytes'] for x in imgs)<=6291456
save('trace-verification.json',dict(firstN1=steps[0],steps=len(steps),batches=sum(steps),zeroCreditSnapshots=len(snaps),allAcknowledged=True,noOverlap=True,images=imgs))
dest=REPO/E;dest.mkdir(parents=True,exist_ok=True)
prior=pathlib.Path('/tmp/enigma-measured-allocation-gameplay-oct26/repo/docs/re-notes/enigma-measured-allocation-gameplay-oct26/receipt.json');(dest/'previous-receipt.json').write_bytes(prior.read_bytes())
receipt=dict(task=H.name,outcome=out,terminal=term,traceVerification=jread('trace-verification.json'),pixelInspection=jread('pixel-inspection.json'),admission=jread('admission-immediate-preguest.json'),readback=jread('readback.json'),startup=jread('fresh-node-startup.json'),reused=jread('reused-acceptance.json'),captureWrapperSHA=sha((O/'capture-wrapper.cjs').read_bytes()),priorPublishedCommit='97e4530c163c011513366259cf2ffebb067dffa3',priorReceiptSHA=sha(prior.read_bytes()),historicalIncident='Original third capture failed 1MiB cumulative cap; prior no-gameplay claim preserved. No game failure inferred.',moduleQualification='Retained historical static unpack; not current main or original acceptance.',lifecycle=dict(box=BOX,state='RUNNING',guestCutoff='2026-10-26T21:38:00Z',handback='2026-10-26T21:42:00Z',shutdown='2026-10-26T21:45:00Z',expiry='2026-10-26T22:23:15.028Z',watchPID=3103171,shutdownOwner='coordinator'))
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for p in r.glob('*.png'):(dest/p.name).write_bytes(p.read_bytes())
with tarfile.open(dest/'ops.tar.gz','w:gz') as t:
 for p in O.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:t.add(p,arcname=str(p.relative_to(O)),recursive=False)
(dest/'README.md').write_text('# Enigma bounded capture-budget continuation\n\n'+jread('pixel-inspection.json')['description']+'\n\nOriginal failed capture and published receipt remain unchanged. This task uses its own three-frame, 2 MiB-per-frame/6 MiB cumulative wrapper and unchanged lossless encoder, controller and production runner. No compilation, full staging or passed acceptance groups repeated. Serial trace and cleanup are in receipt.json and ops.tar.gz. Historical static-unpack module only. Coordinator retains shutdown ownership; no further attempt authorized.\n')
print(json.dumps(out));print(json.dumps(imgs))
