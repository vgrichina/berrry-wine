const fs={writeFileSync(){}},assert=require('assert'),PNG={};
const lossless={};const write=fs.writeFileSync;let count=0,total=0;
function admit(bytes){assert(++count<=3,'capture frame limit');assert(bytes<=2097152,'capture per-frame limit');total+=bytes;assert(total<=6291456,'task cumulative capture allocation');}
fs.writeFileSync=function(file,data,...args){if(typeof file==='string'&&file.endsWith('.png')){data=lossless.encode(PNG,data,'single-frame');admit(data.length);process.stderr.write('[capture] lossless '+count+' '+data.length+' bytes\n');}return write.call(this,file,data,...args)};
module.exports={admit};
