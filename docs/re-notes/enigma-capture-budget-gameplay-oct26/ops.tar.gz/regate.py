from work import *
v=json.loads(jread("cleanup-readback.json")["stdout"]);v["logs"]=v["detachedLogs"]
# Reconcile all retained attempts and current task from earliest baseline, WAL once.
hs=[pathlib.Path('/tmp')/x for x in ['enigma-small-step-production-gameplay-oct26','enigma-retained-bounded-progress-gameplay-oct26','enigma-presented-menu-progress-gameplay-oct26','enigma-measured-allocation-gameplay-oct26',H.name]]
base=json.loads((hs[0]/'ops/sqlite-baseline.json').read_text());db=sum(max(0,allocated(pathlib.Path(p))-b) for p,b in base.items())
launchers=[];sessions=[]
for h in hs:
 l=ROOT/'scratch/usage-watch'/h.name;launchers.append(l)
 sid=json.loads((h/'ops/launch.json').read_text())['session'];sessions+=list(pathlib.Path('/home/user/.codex/sessions/2026/10/26').glob('*'+sid+'.jsonl'))
charges=dict(localOwned=sum(allocated(h) for h in hs),remoteOwned=v['inventory']['physicalOwnedBytes']+sum(x['allocated'] for x in v['logs']),launchers=sum(allocated(l)+sum(allocated(pathlib.Path(str(l)+s)) for s in ['.task.txt','.task.runtime.json','-dispatch.json']) for l in launchers),sessions=sum(allocated(p) for p in sessions),positiveWALOnce=max(db,9371648),prospectiveGrowth=67108864,captureCollectionPublication=10313728,reserve=8388608)
mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;free=shutil.disk_usage(H).free
j=dict(at=time.time(),charges=charges,total=sum(charges.values()),cap=201326592,memAvailable=mem,minimumMemory=2550136832,free=free,projectedFree=free-sum(charges.values()),diskFloor=2982150144,earliestBaseline=base,accounting='earliest inter-task DB bridge included; positive WAL once; clients already resident deducted; Civ768 GL256 helpers256 client320 host768 local64 MiB')
j['pass']=j['total']<=j['cap'] and mem>=j['minimumMemory'] and j['projectedFree']>=j['diskFloor'];save('admission-prepublication.json',j);print(json.dumps(j),flush=True);assert j['pass']
