import pathlib,json,hashlib
O=pathlib.Path(__file__).parent
old=pathlib.Path('/tmp/enigma-measured-allocation-gameplay-oct26/ops')
for n in ['work.py','supervisor.py','operate.py','click.cjs','collect.py','exact-closeout.py','gate.py']:
 s=(old/n).read_text().replace('enigma-measured-allocation-gameplay-oct26','enigma-capture-budget-gameplay-oct26')
 if n in ['collect.py','exact-closeout.py']:s=s.replace('measured-allocation','capture-budget')
 if n=='supervisor.py':s=s.replace("a=json.loads((H/'guest-args.json').read_text());env", "a=json.loads((H/'guest-args.json').read_text());a[2]='--require='+str(E.parent/'capture-wrapper.cjs');env").replace('free-134217728','free-201326592')
 (O/n).write_text(s)
wrapper="""const fs=require('fs'),assert=require('assert'),{PNG}=require('../runner/node_modules/pngjs');
const lossless=require('../lossless-capture-png.cjs');const write=fs.writeFileSync;let count=0,total=0;
function admit(bytes){assert(++count<=3,'capture frame limit');assert(bytes<=2097152,'capture per-frame limit');total+=bytes;assert(total<=6291456,'task cumulative capture allocation');}
fs.writeFileSync=function(file,data,...args){if(typeof file==='string'&&file.endsWith('.png')){data=lossless.encode(PNG,data,'single-frame');admit(data.length);process.stderr.write('[capture] lossless '+count+' '+data.length+' bytes\\n');}return write.call(this,file,data,...args)};
module.exports={admit};
"""
(O/'capture-wrapper.cjs').write_text(wrapper)
