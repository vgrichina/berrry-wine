import os,sys,json,pathlib,subprocess,hashlib,time,shutil,resource,importlib.util,shlex,base64,zlib,gzip,math
H=pathlib.Path('/tmp/enigma-capture-budget-gameplay-oct26');O=H/'ops';REPO=H/'repo'
ROOT=pathlib.Path('/home/user/wine-assembly');P=pathlib.Path('/tmp/enigma-provider-complete-startup-oct24')
D=pathlib.Path('/tmp/enigma-accepted-retained-publication-oct26/repo');OLD=pathlib.Path('/tmp/enigma-accepted-mode-api-single-frame-oct26')
R='/tmp/enigma-small-step-production-gameplay-oct26';BOX='bx_eugbptb7';C='754c97d3ff22ce0a0cd06d08ac06dc0446fbcbb2';BRANCH='task/enigma-capture-budget-gameplay-oct26'
E='docs/re-notes/enigma-capture-budget-gameplay-oct26';L=ROOT/'scratch/usage-watch/enigma-capture-budget-gameplay-oct26'
SSH='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
URL='git@github.com:vgrichina/wine-assembly.git';NODE='/home/user/.nvm/versions/node/v24.22.1/bin/node'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,j):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.new');t.write_text(json.dumps(j,indent=2)+'\n');os.replace(t,p)
def jread(n):return json.loads((O/n).read_text())
def allocated(p):
 if not p.exists():return 0
 seen=set();total=0
 for q in ([p,*p.rglob('*')] if p.is_dir() else [p]):
  s=q.lstat();key=s.st_dev,s.st_ino
  if key not in seen:total+=s.st_blocks*512;seen.add(key)
 return total
def remote(cmd,timeout=30,allow_exit=False,detach=False):
 cmd='timeout 120 prlimit --cpu=90 --fsize=25165824 -- sh -c '+shlex.quote(cmd)
 assert len(cmd.encode())<60000
 argv=['boat','--no-update','--json','exec']+(['--detach'] if detach else ['--timeout',str(timeout)])+[BOX,cmd]
 p=subprocess.run(argv,capture_output=True,text=True,timeout=timeout+15)
 with (O/'api-history.jsonl').open('a') as f:f.write(json.dumps(dict(at=time.time(),command=cmd if len(cmd)<1800 else None,sha256=sha(cmd.encode()),requestBytes=len(cmd.encode()),responseBytes=len(p.stdout.encode())+len(p.stderr.encode())))+'\n')
 j=json.loads(p.stdout)
 assert len(p.stdout.encode())+len(p.stderr.encode())<=8192,'single API output gate'
 if (p.returncode or (not detach and j.get('exitCode')!=0)) and not allow_exit or j.get('stdoutTruncated') or j.get('stderrTruncated'):
  save('first-api-rejection.json',j);raise RuntimeError('FIRST remote rejection; no unchanged retry')
 return j
def py(code,timeout=30,**kw):return remote('python3 -c '+shlex.quote(code),timeout,**kw)
def glimits():
 resource.setrlimit(resource.RLIMIT_DATA,(536870912,536870912));resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
_popen=subprocess.Popen
def git_only_popen(args,*a,**kw):
 if isinstance(args,(list,tuple)) and args and args[0]=='git' and kw.get('preexec_fn') is None:kw['preexec_fn']=glimits
 return _popen(args,*a,**kw)
subprocess.Popen=git_only_popen
def git(*args,repo=REPO):
 argv=['git','-c','pack.threads=1','-c','pack.window=0','-c','pack.windowMemory=16m','-c','core.preloadIndex=false','-c','index.threads=1','-C',str(repo),*args]
 p=subprocess.run(argv,capture_output=True,text=True,timeout=120,preexec_fn=glimits,env=dict(os.environ,GIT_SSH_COMMAND=SSH,TMPDIR=str(O)))
 assert len(p.stdout.encode())+len(p.stderr.encode())<=8192
 with (O/'git-commands.jsonl').open('a') as f:f.write(json.dumps(dict(argv=argv,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
 assert p.returncode==0,p.stderr[:2048]
 return p.stdout.strip()
def payload(x):
 if x['kind']=='file':return pathlib.Path(x['path']).read_bytes()
 return subprocess.check_output(['git','-C',x['donor'],'show',x['revision']+':'+x['path']],preexec_fn=glimits,timeout=120)
def send(b,target):
 for off in range(0,len(b),30000):
  part=b[off:off+30000];enc=base64.b64encode(zlib.compress(part)).decode()
  j=py('import pathlib,base64,zlib,hashlib;p=pathlib.Path('+repr(R+'/'+target)+');p.parent.mkdir(parents=True,exist_ok=True);b=zlib.decompress(base64.b64decode('+repr(enc)+'));p.open('+repr('wb' if off==0 else 'ab')+').write(b);print(hashlib.sha256(b).hexdigest())')
  assert j['stdout'].strip()==sha(part)
 return py('import pathlib,hashlib,json;p=pathlib.Path('+repr(R+'/'+target)+');h=hashlib.sha256();f=p.open("rb")\nwhile b:=f.read(8192):h.update(b)\nprint(json.dumps(dict(bytes=p.stat().st_size,sha256=h.hexdigest())))')
def admission(stage,remote_bytes=45973504):
 base=jread('sqlite-baseline.json');db=sum(max(0,allocated(pathlib.Path(p))-v) for p,v in base.items())
 session=next(pathlib.Path('/home/user/.codex/sessions/2026/10/26').glob('*'+jread('launch.json')['session']+'.jsonl'))
 charges=dict(localOwned=allocated(H),remoteOwned=remote_bytes,launcher=allocated(L)+allocated(session)+sum(allocated(pathlib.Path(str(L)+s)) for s in ['.task.txt','.task.runtime.json','-dispatch.json']),positiveWAL=db,futureSessionAndDB=1048576,futurePublication=1048576,reserve=8388608)
 mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;free=shutil.disk_usage(H).free
 clients=[]
 for p in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   c=p.joinpath('cmdline').read_bytes().replace(b'\0',b' ')
   if b'/bin/codex' in c and (b' exec ' in c or b' resume ' in c):
    rss=int(p.joinpath('status').read_text().split('VmRSS:')[1].split()[0])*1024;clients.append(dict(pid=int(p.name),rss=rss))
  except (OSError,IndexError,ValueError):pass
 # Live RSS is already absent from MemAvailable. Charge only the prospective helper/Git demand.
 j=dict(stage=stage,charges=charges,total=sum(charges.values()),cap=67108864,memAvailable=mem,liveClients=clients,prospectiveGitAndHelper=570425344,remainingMemory=mem-570425344-1879048192-268435456,memoryFloor=805306368,localCivIIReserve=1879048192,localGLReserve=268435456,diskFree=free,projectedFree=free-sum(charges.values()),diskFloor=2982150144)
 j['pass']=j['total']<=67108864 and j['remainingMemory']>=805306368 and j['projectedFree']>=2982150144
 save('admission-'+stage+'.json',j);assert j['pass'],j
 return j
