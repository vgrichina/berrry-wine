from work import *
OLD=pathlib.Path('/tmp/enigma-measured-allocation-gameplay-oct26/ops');N=R+'/capture-budget'
assert time.time()+100<1793050680
save('launch.json',dict(session=json.loads((L/'events.jsonl').open().readline())['thread_id']))
save('trusted-config.json',dict(ssh=SSH,rootRef=json.loads((L/'root-ref-digest.json').read_text())))
handoff=json.loads((L.parent/(H.name+'-handoff.json')).read_text())
for p,v in handoff['pins'].items():assert sha(pathlib.Path(p).read_bytes())==v['sha256']
code='''import pathlib,json,hashlib,shutil,resource
h=pathlib.Path(ROOT);n=h/'capture-budget';assert not n.exists();n.mkdir();(n/'guest').mkdir();(n/'guest/logger-probe').open('ab').write(b'append');assert (n/'guest/logger-probe').read_bytes()==b'append';(n/'guest/logger-probe').unlink()
pins={'runner/test/run.js':'87ab63d768eb59a09a8b69df2ccb3843270dd867a67405abd82f02c25c1628e7','runner/test/run-presented.cjs':'a9625e1d102883c27b1bd2de0bab560a44ab3bc7eb589b18e7a736100eb2a0da','controller.cjs':'c4d6c24cc8c0d321b8e6dd17e299116ef4b94fb71899e0f4801e4330cf1adac6','click.cjs':'8574aa3a46e9b969083cca5d85e2ace502d8e7dc4241ed352bf594e097c2e7d9','runtime/build/wine-assembly.wasm':'8fac39936b6df2418ad86cab118cef19a65a727f649fbc14c412b37818904686'}
for p,w in pins.items():assert hashlib.file_digest((h/p).open('rb'),'sha256').hexdigest()==w,p
assert json.loads((h/'guest-args.json').read_text())==ARGV
t=json.loads((h/'measured-allocation/guest/terminal.json').read_text());assert not t['remainingOwnedLive']
for pid,s in t['identities'].items():
 p=pathlib.Path('/proc')/pid/'stat'
 if p.exists():
  x=p.read_text();v=x[x.rfind(')')+2:].split();assert v[19]!=s['start'] or v[0]=='Z'
print(json.dumps(dict(pins=pins,argvUnchanged=True,oldGuestClean=True,loggerAppend=True,memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024)))
'''.replace('ROOT',repr(R)).replace('ARGV',repr(json.loads(pathlib.Path('/tmp/enigma-small-step-production-gameplay-oct26/ops/guest-args.json').read_text())))
save('readback.json',py(code))
for name in ['supervisor.py','operate.py','click.cjs','capture-wrapper.cjs']:send((O/name).read_bytes(),'capture-budget/'+name)
# Exact new wrapper startup; test its real admission function locally with require dependencies redirected to standing identical local sources.
test=(O/'capture-wrapper.cjs').read_text().replace("'../runner/node_modules/pngjs'",repr('/tmp/enigma-small-step-production-gameplay-oct26/repo/node_modules/pngjs')).replace("'../lossless-capture-png.cjs'",repr('/tmp/enigma-accepted-mode-api-single-frame-oct26/repo/tools/lossless-capture-png.cjs'))
# Dependencies may live in a retained runner checkout; locate a standing pngjs only.
test=test.replace("const fs=require('fs'),assert=require('assert'),{PNG}=require('/tmp/enigma-small-step-production-gameplay-oct26/repo/node_modules/pngjs');", "const fs={writeFileSync(){}},assert=require('assert'),PNG={};")
test=test.replace("const lossless=require('/tmp/enigma-accepted-mode-api-single-frame-oct26/repo/tools/lossless-capture-png.cjs');", "const lossless={};")
(O/'local-wrapper.cjs').write_text(test)
js="const a=require('./local-wrapper.cjs').admit;a(2097152);a(2097152);a(2097152);require('assert').throws(()=>a(1),/frame limit/);delete require.cache[require.resolve('./local-wrapper.cjs')];require('assert').throws(()=>require('./local-wrapper.cjs').admit(2097153),/per-frame/);console.log('PASS legal 3x2MiB, fourth and oversize rejected')"
p=subprocess.run(['node','--max-old-space-size=48','-e',js],cwd=O,capture_output=True,text=True,timeout=10);save('local-capture-control.json',dict(exit=p.returncode,stdout=p.stdout,stderr=p.stderr,wrapperSHA=sha((O/'capture-wrapper.cjs').read_bytes()),scope='exact admission function, dependencies stubbed; lossless encoder retained unchanged and real startup remote'));assert p.returncode==0
startup='''import pathlib,json,subprocess,resource,os
h=pathlib.Path(ROOT);a=json.loads((h/'guest-args.json').read_text());a[2]='--require='+str(h/'capture-budget/capture-wrapper.cjs');env=dict(os.environ)
for k in ['WINE_RUN_EXTRA_ARGS','WINE_REGION_MAP']:env.pop(k,None)
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(25165824,25165824))
p=subprocess.run(a[:3]+['-e',"console.log(JSON.stringify({executable:process.execPath,version:process.version,argv:process.execArgv,limits:require('fs').readFileSync('/proc/self/limits','utf8'),environment:Object.fromEntries(Object.entries(process.env).filter(([k])=>/^(NODE|ENIGMA|WINE|MAELSTROM)/.test(k)))}))"],cwd=h/'runner',env=env,preexec_fn=limits,capture_output=True,text=True,timeout=10);assert p.returncode==0,p.stderr;print(p.stdout)
'''.replace('ROOT',repr(R))
save('fresh-node-startup.json',py(startup))
exec((O/'exact-closeout.py').read_text())
v=json.loads(jread('exact-remote-accounting.json')['stdout']);assert v['memAvailable']>=3758096384
# Reconcile all retained attempts and current task from earliest baseline, WAL once.
hs=[pathlib.Path('/tmp')/x for x in ['enigma-small-step-production-gameplay-oct26','enigma-retained-bounded-progress-gameplay-oct26','enigma-presented-menu-progress-gameplay-oct26','enigma-measured-allocation-gameplay-oct26',H.name]]
base=json.loads((hs[0]/'ops/sqlite-baseline.json').read_text());db=sum(max(0,allocated(pathlib.Path(p))-b) for p,b in base.items())
launchers=[];sessions=[]
for h in hs:
 l=ROOT/'scratch/usage-watch'/h.name;launchers.append(l)
 sid=json.loads((h/'ops/launch.json').read_text())['session'];sessions+=list(pathlib.Path('/home/user/.codex/sessions/2026/10/26').glob('*'+sid+'.jsonl'))
charges=dict(localOwned=sum(allocated(h) for h in hs),remoteOwned=v['inventory']['physicalOwnedBytes']+sum(x['allocated'] for x in v['logs']),launchers=sum(allocated(l)+sum(allocated(pathlib.Path(str(l)+s)) for s in ['.task.txt','.task.runtime.json','-dispatch.json']) for l in launchers),sessions=sum(allocated(p) for p in sessions),positiveWALOnce=max(db,9371648),prospectiveGrowth=67108864,captureCollectionPublication=10313728,reserve=8388608)
mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;free=shutil.disk_usage(H).free
j=dict(at=time.time(),charges=charges,total=sum(charges.values()),cap=201326592,memAvailable=mem,minimumMemory=2550136832,free=free,projectedFree=free-sum(charges.values()),diskFloor=2982150144,earliestBaseline=base,accounting='earliest inter-task DB bridge included; positive WAL once; clients already resident deducted; Civ768 GL256 helpers256 client320 host768 local64 MiB')
j['pass']=j['total']<=j['cap'] and mem>=j['minimumMemory'] and j['projectedFree']>=j['diskFloor'];save('admission-immediate-preguest.json',j);print(json.dumps(j),flush=True);assert j['pass']
assert time.time()+100<1793050680 and pathlib.Path('/proc/3103171/cmdline').exists()
save('reused-acceptance.json',dict(fullManifest2661=str(OLD/'readback.json'),groups='29/13/9/7 unchanged',canonicalParser=str(OLD/'reused-canonical-parser.json'),mountArgvUnchanged=True))
save('guest-detach.json',remote('python3 '+shlex.quote(N+'/operate.py'),detach=True));print('ONE GUEST LAUNCHED',flush=True)
