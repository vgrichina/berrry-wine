from work import *
exec((O/'regate.py').read_text())
dest=REPO/E
p=dest/'receipt.json';j=json.loads(p.read_text());j['finalStatus']='INSPECTED_POSTCLICK_MENU_NO_GAMEPLAY';j['closeoutAdmission']=jread('admission-prepublication.json');j['verifiedCounts']=jread('trace-verification.json');p.write_text(json.dumps(j,indent=2)+'\n')
(dest/'admission-prepublication.json').write_bytes((O/'admission-prepublication.json').read_bytes())
assert not (REPO/'.git').exists()
git('init','-q',str(REPO),repo=H)
for k,v in [('user.name','Wine Ops'),('user.email','wine-ops@local'),('core.sshCommand',SSH),('gc.auto','0')]:git('config',k,v)
git('symbolic-ref','HEAD','refs/heads/'+BRANCH);git('remote','add','origin',URL)
git('add',E);assert all(x.startswith(E+'/') for x in git('diff','--cached','--name-only').splitlines());git('diff','--cached','--check')
git('commit','-m','docs: retain bounded Enigma post-click pixels with task-local capture budget')
commit=git('rev-parse','HEAD');git('push','origin','refs/heads/'+BRANCH+':refs/heads/'+BRANCH);ref=git('ls-remote','origin','refs/heads/'+BRANCH);assert ref.split()[0]==commit
rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss*1024;assert rss<=67108864
save('publication.json',dict(commit=commit,branch=BRANCH,remoteRef=ref,normalTrustedPush=True,gitPeakRSS=rss,parentDATA=resource.getrlimit(resource.RLIMIT_DATA),parentAS=resource.getrlimit(resource.RLIMIT_AS),gitChildDATA=536870912));assert git('status','--porcelain')==''
print(json.dumps(jread('publication.json')))
