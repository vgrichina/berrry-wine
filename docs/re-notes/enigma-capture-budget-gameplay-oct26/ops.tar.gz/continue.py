from work import *
OLD=pathlib.Path('/tmp/enigma-measured-allocation-gameplay-oct26/ops');N=R+'/capture-budget'
s=(O/'run.py').read_text();exec(s[s.index('# Exact new wrapper'):])
