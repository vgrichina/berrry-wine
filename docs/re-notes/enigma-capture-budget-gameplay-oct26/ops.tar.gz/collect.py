from work import *
N=R+'/capture-budget';dest=O/'retained';dest.mkdir(exist_ok=True)
j=py('''import pathlib,json,hashlib,importlib.util,shutil
h=pathlib.Path(ROOT);n=h/'capture-budget';rows=[]
assert (n/'guest/terminal.json').exists() and (n/'guest/outcome.json').exists()
for p in list((n/'guest').glob('*'))+[n/'node-startup.json']:
 if p.is_file():rows.append(dict(path=str(p.relative_to(n)),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()))
t=json.loads((n/'guest/terminal.json').read_text());remaining=[]
for pid,s in t['identities'].items():
 p=pathlib.Path('/proc')/pid/'stat'
 if p.exists():
  b=p.read_text();v=b[b.rfind(')')+2:].split()
  if v[19]==s['start'] and v[0]!='Z':remaining.append(pid)
spec=importlib.util.spec_from_file_location('s',h/'bounded-staging.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
logs=[]
for p in pathlib.Path('/home/user/.ascii/processes').glob('*'):
 if p.is_file():logs.append(dict(path=str(p),bytes=p.stat().st_size,allocated=p.stat().st_blocks*512))
print(json.dumps(dict(rows=rows,terminal=t,remainingOwnedLive=remaining,inventory=s.inventory(h),detachedLogs=logs,diskFree=shutil.disk_usage('/tmp').free,boxState='RUNNING confirmed API execution')))
'''.replace('ROOT',repr(R)))
save('cleanup-readback.json',j);r=json.loads(j['stdout']);assert not r['remainingOwnedLive'] and not r['terminal']['remainingOwnedLive']
save('remote-evidence-manifest.json',r['rows'])
for x in r['rows']:
 assert x['bytes']<=2097152,x
 p=dest/pathlib.Path(x['path']).name
 with p.open('wb') as f:
  for off in range(0,x['bytes'],5000):
   a=py('import pathlib,base64;p=pathlib.Path('+repr(N+'/'+x['path'])+');f=p.open("rb");f.seek('+str(off)+');print(base64.b64encode(f.read(5000)).decode())');f.write(base64.b64decode(a['stdout']))
 assert p.stat().st_size==x['bytes'] and sha(p.read_bytes())==x['sha256']
print((dest/'outcome.json').read_text());print((dest/'terminal.json').read_text())
