from work import *
code='''import pathlib,json,importlib.util,shutil,resource
h=pathlib.Path(ROOT);spec=importlib.util.spec_from_file_location('s',h/'bounded-staging.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
logs=[dict(path=str(p),allocated=p.stat().st_blocks*512,bytes=p.stat().st_size) for p in pathlib.Path('/home/user/.ascii/processes').glob('*') if p.is_file()]
owned=[]
for p in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  a=p.joinpath('cmdline').read_bytes().split(b'\\0');exe=pathlib.Path(a[0].decode()).name
  if exe in ['node','python3'] and any(x.decode(errors='replace') in [str(h/'runner/test/run-presented.cjs'),str(h/'capture-budget/operate.py'),str(h/'capture-budget/supervisor.py')] for x in a[1:]):owned.append(int(p.name))
 except (OSError,IndexError):pass
print(json.dumps(dict(inventory=s.inventory(h),logs=logs,ownedGuestLive=owned,memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024,diskFree=shutil.disk_usage('/tmp').free,box='bx_eugbptb7',state='RUNNING confirmed APIexec',limits={k:resource.getrlimit(getattr(resource,k)) for k in ['RLIMIT_DATA','RLIMIT_AS','RLIMIT_CPU','RLIMIT_FSIZE']})))
'''.replace('ROOT',repr(R))
save('exact-remote-accounting.json',py(code))
v=json.loads(jread('exact-remote-accounting.json')['stdout']);assert not v['ownedGuestLive']
print(json.dumps(v))
