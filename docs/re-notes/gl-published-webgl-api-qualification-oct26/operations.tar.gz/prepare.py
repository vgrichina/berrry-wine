from common import *
import tarfile
gate('before-git',True)
plan=json.loads((ROOT/'scratch/usage-watch/gl-palette-current-webgl-closure-plan-oct26.json').read_text()); fixture=json.loads((D.parent/'ops/fixture-overlay.json').read_text())
for r in plan['files']:assert sha(S/r['path'])==r['sha256'],r['path']
for p,h in fixture['files'].items():assert sha(D/p)==h,p
mount=json.loads(P('/tmp/gl-palette-current-webgl-qualification-oct26/ops/mount-configuration.json').read_text());src=(ROOT/'test/run.js').read_text();parser=src[src.index('const getArg ='):src.index('// Was `--name=...`')]
assert hashlib.sha256(parser.encode()).hexdigest()==mount['parserSHA256'] and mount['argv']==mount['enumeration']==mount['commaFilenames']==[] and mount['trustedSSH']==SSH
save('launch-configuration.json',dict(mount=mount,actualMountArgv=[],canonicalParserRehashed=True,trustedSSH=SSH,rootRefReceipt=str(ROOT/'scratch/usage-watch'/H.name/'root-ref-digest.json')))
R.mkdir();g('init','-q');g('config','remote.origin.url','git@github.com:vgrichina/wine-assembly.git');g('config','remote.origin.promisor','true');g('config','remote.origin.partialclonefilter','blob:none');(R/'.git/objects/info/alternates').write_text(str(D/'.git/objects')+'\n')
g('config','core.sparseCheckout','true');g('config','core.sparseCheckoutCone','false');(R/'.git/info/sparse-checkout').write_text(''.join('/'+p+'\n' for p in fixture['files']));g('checkout','-b',BR,REV)
assert g('show','-s','--format=%H %T',REV).decode().strip()==REV+' ef4fa7219aadb4241e9eb20c0d969bbb1cf139ce'
assert not g('diff','--stat').strip()
# Retain only commit, all tree metadata and exact seven fixture blobs remotely.
rows=g('ls-tree','-r','-t',REV).decode().splitlines();ids=[REV]+[r.split()[2] for r in rows if r.split()[1]=='tree' or r.split('\t',1)[1] in fixture['files']]
pack=g('pack-objects','--stdout',input=('\n'.join(ids)+'\n').encode());(O/'fixture.pack').write_bytes(pack)
# Dependency package closure from declared runtime dependencies, no dev/test/docs.
deps=P('/tmp/wa-local-runtime-deps/node_modules');packages={}
def dep(n):
 if n in packages:return
 p=deps/n;data=json.loads((p/'package.json').read_text());packages[n]=data
 for child in data.get('dependencies',{}):dep(child)
dep('puppeteer')
manifest={};archive=H/'inputs.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 def add(p,n):
  assert p.is_file() and not p.is_symlink(),p
  t.add(p,arcname=n,recursive=False);manifest[n]=dict(bytes=p.stat().st_size,sha256=sha(p))
 for r in plan['files']:add(S/r['path'],'source/'+r['path'])
 for p in (S/'.git').rglob('*'):
  if p.is_file():add(p,'source/.git/'+str(p.relative_to(S/'.git')))
 for p in fixture['files']:add(R/p,'repo/'+p)
 for p in (R/'.git').rglob('*'):
  if p.is_file() and 'objects' not in p.relative_to(R/'.git').parts:add(p,'repo/.git/'+str(p.relative_to(R/'.git')))
 add(O/'fixture.pack','fixture.pack')
 for n in packages:
  for p in (deps/n).rglob('*'):
   rel=p.relative_to(deps/n)
   if p.is_file() and not p.is_symlink() and p.suffix not in ('.map','.ts','.md') and not any(x in rel.parts for x in ('test','tests','docs','src')):add(p,'deps/node_modules/'+n+'/'+str(rel))
save('inputs-manifest.json',manifest);save('dependency-closure.json',{n:dict(version=d['version'],dependencies=d.get('dependencies',{})) for n,d in packages.items()});save('pins.json',dict(source=plan,fixture=fixture,archiveSHA256=sha(archive),archiveBytes=archive.stat().st_size,files=len(manifest),moduleSHA256=fixture['moduleExpectedSHA256']))
gate('prepared');print(json.dumps(dict(archiveBytes=archive.stat().st_size,files=len(manifest),packages=list(packages),allocated=alloc(H))))
