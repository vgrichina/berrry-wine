import pathlib,os,json,hashlib,subprocess,resource,shutil,time,shlex
P=pathlib.Path; M=1048576; H=P('/tmp/gl-published-webgl-api-qualification-oct26'); O=H/'ops'; R=H/'repo'; ROOT=P('/home/user/wine-assembly'); BOX='bx_bcpdmz2t'; REM=str(H)
S=P('/tmp/gl-palette-current-webgl-qualification-oct26/source'); D=P('/tmp/gl-published-webgl-recovered-qualification-oct26/repo'); REV='c57ba2b0d7dc63fb159580772d530db873c28325'; BR='task/'+H.name
SSH='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
def save(n,j):
 p=O/n;t=p.with_suffix('.new');t.write_text(json.dumps(j,indent=2)+'\n');os.replace(t,p)
def sha(p):
 h=hashlib.sha256()
 with P(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def alloc(p):
 try:return sum(q.lstat().st_blocks*512 for q in ([p,*p.rglob('*')] if p.is_dir() else [p]) if not q.is_symlink())
 except FileNotFoundError:return 0
def limits(git=False):
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(24*M,24*M))
 if git:resource.setrlimit(resource.RLIMIT_DATA,(512*M,512*M))
def run(a,cwd=H,git=False,input=None,cap=2*M,timeout=120):
 if git and input is None and os.environ.get('GL_PUBLICATION_SUPERVISED')=='1':
  import importlib.util
  spec=importlib.util.spec_from_file_location('accepted',D/'test/helpers/palette-browser-supervisor.py');sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
  os.environ.update(GIT_SSH_COMMAND=SSH,BOAT_NO_UPDATE='1',PYTHONDONTWRITEBYTECODE='1')
  before=P.cwd();os.chdir(cwd)
  rec=sup.supervise(['/usr/bin/prlimit','--data=536870912:536870912','--',*a],rss_limit=512*M,cpu_limit=90,wall_limit=120,output_limit=2*M)
  os.chdir(before);out=rec.pop('output');number=len(list(O.glob('publication-git-*-receipt.json')))+1;(O/('publication-git-%02d.log'%number)).write_bytes(out);save('publication-git-%02d-receipt.json'%number,rec)
  assert rec['exit']==0 and rec['stopReason'] is None and rec['cleanupComplete'],rec
  return out
 p=subprocess.run(a,cwd=cwd,input=input,capture_output=True,timeout=timeout,preexec_fn=lambda:limits(git),env=dict(os.environ,GIT_SSH_COMMAND=SSH,BOAT_NO_UPDATE='1',PYTHONDONTWRITEBYTECODE='1'))
 assert len(p.stdout)+len(p.stderr)<=cap
 if p.returncode:
  with (O/'incidents.jsonl').open('a') as f:f.write(json.dumps(dict(argv=a[:8],exit=p.returncode,stdout=p.stdout.decode(errors='replace')[:4000],stderr=p.stderr.decode(errors='replace')[:4000]))+'\n')
 assert p.returncode==0,(p.returncode,p.stdout[:3500],p.stderr[:3500])
 return p.stdout
def g(*a,cwd=R,input=None):return run(['/usr/bin/git','-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*a],cwd,True,input)
def api(cmd,timeout=30):
 b=run(['boat','exec','--json','--timeout',str(timeout),BOX,cmd],cap=8192,timeout=timeout+15);j=json.loads(b)
 with (O/'api-receipts.jsonl').open('a') as f:f.write(json.dumps(j)+'\n')
 assert j.get('exitCode')==0 and not j.get('stdoutTruncated') and not j.get('stderrTruncated'),j
 return j['stdout']
def py(code):return api('python3 -c '+shlex.quote(code))
def gate(stage,git=False):
 clients=[]
 for p in P('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if os.readlink(p/'exe').endswith('/codex') and b'exec' in (p/'cmdline').read_bytes().split(b'\0'):clients.append(dict(pid=int(p.name),rss=int((p/'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')))
  except OSError:pass
 growth=sum(max(0,320*M-r['rss']) for r in clients)
 mem=int(P('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
 required=(768+1024+(512 if git else 128))*M+growth
 wal=sum(max(0,alloc(P(p))-n) for p,n in json.loads((O/'wal-baseline.json').read_text()).items())
 charges={str(H):alloc(H),str(ROOT/'scratch/usage-watch'/H.name):alloc(ROOT/'scratch/usage-watch'/H.name),'session':sum(alloc(p) for p in P('/home/user/.codex/sessions/2026/10/26').glob('*'+os.environ['CODEX_THREAD_ID']+'*')),'positiveWALOnce':wal,'futureArchiveGitEvidencePublication':32*M,'futureSessionEvents':16*M,'reserve':8*M}
 projected=sum(charges.values());free=shutil.disk_usage(H).free-56*M
 j=dict(stage=stage,memAvailable=mem,required=required,clients=clients,growthOnce=growth,charges=charges,projection=projected,cap=128*M,projectedFree=free,passAdmission=mem>=required and projected<=128*M and free>=2982150144)
 save('admission-'+stage+'.json',j);assert j['passAdmission'],j
 return j
