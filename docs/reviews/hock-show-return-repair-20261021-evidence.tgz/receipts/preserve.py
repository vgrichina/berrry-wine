import pathlib,json,base64,hashlib,tarfile
from remote import run
r=pathlib.Path(__file__).resolve().parent
cmd="""python3 - <<'PY2'
import pathlib,json,hashlib,tarfile
r=pathlib.Path('/home/user/hock-show-return-repair');old=pathlib.Path('/home/user/hock-placement-notify-repair');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in ['controls.json','related-tests.json']:
 s=json.loads((old/'SHA256SUMS.json').read_text());assert sha(old/f)==s[f];print(f,sha(old/f))
files=[p for p in r.iterdir() if p.is_file() and p.suffix not in ['.tgz'] and p.name!='SHA256SUMS.json']
files += [p for p in (r/'original-held').iterdir() if p.is_file()]
seals={str(p.relative_to(r)):sha(p) for p in files};(r/'SHA256SUMS.json').write_text(json.dumps(seals,indent=2)+'\\n')
with tarfile.open(r/'evidence.tgz','w:gz') as t:
 for p in files+[r/'SHA256SUMS.json']:t.add(p,arcname=str(p.relative_to(r)))
print(json.dumps(dict(size=(r/'evidence.tgz').stat().st_size,sha256=sha(r/'evidence.tgz'),files=len(files))))
PY2"""
d=run(cmd,'seal-evidence',60);meta=json.loads(d['stdout'].splitlines()[-1]);parts=[]
for off in range(0,meta['size'],18000):
 d=run("python3 - <<'PY2'\nimport pathlib,base64\nb=pathlib.Path('/home/user/hock-show-return-repair/evidence.tgz').read_bytes();print(base64.b64encode(b["+str(off)+":"+str(off+18000)+"]).decode())\nPY2",'download-'+str(off),60)
 assert not d['stdoutTruncated'];parts.append(base64.b64decode(d['stdout']))
b=b''.join(parts);assert len(b)==meta['size'] and hashlib.sha256(b).hexdigest()==meta['sha256'];p=r/'remote-evidence.tgz';p.write_bytes(b)
out=r/'remote-evidence';out.mkdir()
with tarfile.open(p) as t:t.extractall(out,filter='data')
seals=json.loads((out/'SHA256SUMS.json').read_text())
for f,h in seals.items():assert hashlib.sha256((out/f).read_bytes()).hexdigest()==h,f
(r/'preservation.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta)
