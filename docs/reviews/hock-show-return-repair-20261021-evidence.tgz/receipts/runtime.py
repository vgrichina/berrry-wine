import pathlib,base64
from remote import run
r=pathlib.Path(__file__).resolve().parent
s=(r.parent/'20261021-hock-placement-notify-repair/drive-candidate.py').read_text().replace('/home/user/hock-placement-notify-repair','/home/user/hock-show-return-repair')
(r/'drive-candidate.py').write_text(s)
b=base64.b64encode(s.encode()).decode()
run("python3 - <<'PY2'\nimport pathlib,base64\npathlib.Path('/home/user/hock-show-return-repair/drive-candidate.py').write_bytes(base64.b64decode('"+b+"'))\nPY2\npython3 /home/user/hock-show-return-repair/drive-candidate.py",'original-held',90)
