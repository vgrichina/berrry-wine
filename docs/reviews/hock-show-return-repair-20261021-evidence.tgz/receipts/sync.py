import pathlib,base64,gzip,json,subprocess
from remote import run
r=pathlib.Path(__file__).resolve().parent
files=subprocess.check_output(['git','-C',str(r/'repo'),'diff','--name-only']).decode().splitlines()
patch=subprocess.check_output(['git','-C',str(r/'repo'),'diff']).decode()
b=base64.b64encode(gzip.compress(json.dumps(dict(files=files,patch=patch)).encode())).decode();assert len(b)<100000
run("python3 - <<'PY2'\nimport pathlib,base64,gzip,json,shutil,subprocess\nr=pathlib.Path('/home/user/hock-show-return-repair/repo');base=pathlib.Path('/home/user/hock-placement-notify-repair/repo')\nd=json.loads(gzip.decompress(base64.b64decode('"+b+"')))\nfor f in d['files']:shutil.copyfile(base/f,r/f)\nsubprocess.run(['git','apply','-'],input=d['patch'],text=True,cwd=r,check=True)\nPY2",'sync-final')
