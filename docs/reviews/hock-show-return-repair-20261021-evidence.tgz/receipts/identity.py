import pathlib,subprocess,json,hashlib,base64
from remote import run
r=pathlib.Path(__file__).resolve().parent;repo=r/'repo';old=r.parent/'20261021-hock-placement-notify-repair'
manifest=json.loads((old/'remote-evidence/candidate-source-seals.json').read_text())
files=subprocess.check_output(['git','-C',str(repo),'diff','--name-only']).decode().splitlines()
sha=lambda b:hashlib.sha256(b).hexdigest()
expected={f:sha((repo/f).read_bytes()) for f in files}
# Prove inherited manifest against candidate Git blobs, not just a copied tree.
p=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for f,h in manifest.items():
 p.stdin.write(('HEAD:'+f+'\n').encode());p.stdin.flush();header=p.stdout.readline().split();size=int(header[2]);b=p.stdout.read(size);p.stdout.read(1);assert sha(b)==h,f
p.stdin.close();p.wait()
(r/'expected-source-delta.json').write_text(json.dumps(expected,indent=2)+'\n')
script="""import pathlib,json,hashlib,subprocess
r=pathlib.Path('/home/user/hock-show-return-repair');old=pathlib.Path('/home/user/hock-placement-notify-repair');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=EXPECTED
original=json.loads((old/'candidate-source-seals.json').read_text());candidate={}
for f,h in original.items():
 assert sha(old/'repo'/f)==h,('parent changed',f)
 candidate[f]=sha(r/'repo'/f);assert candidate[f]==expected.get(f,h),f
pkg=json.loads((old/'package-seals.json').read_text())
for f,h in pkg.items():assert sha(pathlib.Path('/home/user/hock-accepted-canonical-runtime/intake')/f)==h,f
(r/'candidate-source-seals.json').write_text(json.dumps(candidate,indent=2)+'\\n')
(r/'package-seals.json').write_text(json.dumps(pkg,indent=2)+'\\n')
modules={p.name:sha(p) for p in (r/'repo/build').glob('wine-assembly*.wasm')}
result=dict(parent='c4718fb5204a0f4541c1575e84557cfefad6959d',sourceFiles=len(candidate),changed=expected,packageFiles=len(pkg),modules=modules,parentUnchanged=True,node=subprocess.check_output(['node','--version']).decode().strip())
(r/'candidate-identity.json').write_text(json.dumps(result,indent=2)+'\\n');print(json.dumps(result))
""".replace('EXPECTED',repr(expected))
(r/'verify-identity.py').write_text(script)
run("python3 - <<'PY2'\n"+script+'\nPY2','candidate-identity',120)
