import pathlib
from remote import run
r=pathlib.Path(__file__).resolve().parent
old=pathlib.Path('scratch/runs/20261021-hock-placement-notify-repair')
cmd=(old/'related-tests.command.txt').read_text().replace('/home/user/hock-placement-notify-repair','/home/user/hock-show-return-repair')
run(cmd,'related-tests',120)
cmd=(old/'controls.command.txt').read_text().replace('cd /home/user/hock-placement-notify-repair','cd /home/user/hock-show-return-repair')
cmd=cmd.replace('cases=[','cases=[("zero-destruction",dict(PLACEMENT_CONTROL="zero-destruction",PLACEMENT_GROUP="show-return")),("keep-success",dict(PLACEMENT_CONTROL="keep-success",PLACEMENT_GROUP="startup")),')
run(cmd,'controls',120)
run('cd /home/user/hock-show-return-repair/repo && node tools/callback-ownership-census.js --dump > ../census-current.json && python3 - <<\'PY2\'\nimport json,pathlib\nr=pathlib.Path("."); a=json.loads((r/"tools/callback-ownership-census.json").read_text()); b=json.loads(pathlib.Path("../census-current.json").read_text()); bm={(x["file"],x["name"]):x for x in b["entries"]}; changes=[]\nfor x in a["entries"]:\n y=bm[(x["file"],x["name"])]; dif=[k for k in ["sha256","writes","boundaryCalls","exports","targets","ownershipWrites"] if x.get(k)!=y.get(k)]\n if dif:\n  assert (x["file"],x["name"]) in [("src/09a5-handlers-window.wat","$show_window_core"),("src/09b-dispatch.wat","$win32_dispatch_inner")] and dif==["sha256"], (x,dif)\n  x["sha256"]=y["sha256"];changes.append(dict(file=x["file"],name=x["name"],sha256=x["sha256"]))\nprint(json.dumps(changes));(r/"tools/callback-ownership-census.json").write_text(json.dumps(a,indent=2)+"\\n")\nPY2\nnode tools/callback-ownership-census.js && node test/test-callback-ownership-census.js','reviewed-census',120)
