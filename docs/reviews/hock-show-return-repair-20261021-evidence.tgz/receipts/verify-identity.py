import pathlib,json,hashlib,subprocess
r=pathlib.Path('/home/user/hock-show-return-repair');old=pathlib.Path('/home/user/hock-placement-notify-repair');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected={'src/09a5-handlers-window.wat': '17796a5857796d9e2c4c3a8b92d7a45562b7b1bb0dd59f8fffbd1530c9ab6419', 'src/09b-dispatch.wat': '7ebbe7ab396518ae1ae512d06af7aa8b37d053623f5a3590cb0cf7f114fd1e85', 'test/test-callback-ownership-census.js': 'c223da4adccf61f98ec0f71a7ea356e55a0800daa1622c905286ce084f4df659', 'test/test-window-placement-notify.js': '655f8a9a30d8edc5be65468a3ccc4a5a8e7c4fc7999aeb9eddcdd63d56f2e785', 'tools/callback-ownership-census.json': '9c6d485af6d03977664cb5629d33e7f32986f9ed242c680fb9adc7f92242ec1a'}
original=json.loads((old/'candidate-source-seals.json').read_text());candidate={}
for f,h in original.items():
 assert sha(old/'repo'/f)==h,('parent changed',f)
 candidate[f]=sha(r/'repo'/f);assert candidate[f]==expected.get(f,h),f
pkg=json.loads((old/'package-seals.json').read_text())
for f,h in pkg.items():assert sha(pathlib.Path('/home/user/hock-accepted-canonical-runtime/intake')/f)==h,f
(r/'candidate-source-seals.json').write_text(json.dumps(candidate,indent=2)+'\n')
(r/'package-seals.json').write_text(json.dumps(pkg,indent=2)+'\n')
modules={p.name:sha(p) for p in (r/'repo/build').glob('wine-assembly*.wasm')}
result=dict(parent='c4718fb5204a0f4541c1575e84557cfefad6959d',sourceFiles=len(candidate),changed=expected,packageFiles=len(pkg),modules=modules,parentUnchanged=True,node=subprocess.check_output(['node','--version']).decode().strip())
(r/'candidate-identity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
