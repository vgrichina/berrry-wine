import pathlib,tarfile,hashlib,json,io
r=pathlib.Path(__file__).resolve().parent; old=r.parent/'20261021-hock-placement-notify-repair'
sha=lambda b:hashlib.sha256(b).hexdigest()
archive=old/'repo/docs/reviews/hock-placement-notify-repair-20261021-evidence.tgz'
with tarfile.open(archive) as t: files={m.name.removeprefix('remote-evidence/'):t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
seals=json.loads(files['SHA256SUMS.json']); mismatch=[]
for f,h in seals.items():
 if sha(files[f])!=h:
  original=(old/'remote-evidence'/f).read_bytes();receipt=(old/f).read_bytes()
  assert sha(original)==h and files[f]==receipt
  d=json.loads(receipt); assert d['exitCode']==0 and not d['stdoutTruncated']
  mismatch.append(dict(file=f,expected=h,archived=sha(files[f]),original=sha(original),receiptId=d['commandId'],receiptExactMatch=True))
  files['publication-receipts/'+f]=files[f];files[f]=original
assert len(mismatch)==2
reconciliation=dict(supersedes='Only the blanket 40-file seal acceptance for evidence commit 695c9e8d5b71e0ee5d0974c7b1feb660aa111e22; old archive and claims remain unchanged. This corrected bundle is historical evidence, not acceptance of the defective candidate.',oldArchiveSha256=sha(archive.read_bytes()),cause='Publication path collision: Boat command receipts replaced same-named summary arrays after sealing. Each archived replacement is byte-identical to the local command receipt; preserved original summary arrays match the old manifest. Both originals and receipts retained under distinct paths.',mismatches=mismatch,matchingOriginalEntries=38)
files['RECONCILIATION.json']=(json.dumps(reconciliation,indent=2)+'\n').encode()
files['original-SHA256SUMS.json']=files.pop('SHA256SUMS.json')
files['SHA256SUMS.json']=(json.dumps({f:sha(b) for f,b in files.items()},indent=2)+'\n').encode()
out=r/'repo/docs/reviews';out.mkdir(parents=True,exist_ok=True)
p=out/'hock-placement-notify-repair-20261021-corrected-evidence.tgz'
with tarfile.open(p,'w:gz') as t:
 for f,b in files.items():
  info=tarfile.TarInfo(f);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(p) as t:
 s=json.load(t.extractfile('SHA256SUMS.json'))
 for f,h in s.items():assert sha(t.extractfile(f).read())==h
reconciliation.update(correctedArchiveSha256=sha(p.read_bytes()),correctedSealedFiles=len(s))
(r/'reconciliation.json').write_text(json.dumps(reconciliation,indent=2)+'\n')
print(json.dumps(reconciliation,indent=2))
