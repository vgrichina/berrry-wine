# Recover ShowWindow result repair

Production commit dd6c585bba95422da631fb59a24245f6566135c8 on
refs/heads/task/hock-show-return-repair-oct21. Main remains
1d8dbd7a44656178d01869f28869be624a59fa39. Independent acceptance required.

Assigned bx_3f3x23m3 remains RUNNING (Boat state idle, health ok), expiry
2026-10-21T05:56:19.894Z. Coordinator owns lifecycle. No stop, snapshot,
resume, new or fork was requested by this worker.

Remote candidate: /home/user/hock-show-return-repair/repo
Remote evidence: /home/user/hock-show-return-repair
Preserved parent: /home/user/hock-placement-notify-repair/repo
Preserved independent repro: /home/user/hock-notify-independent-integrate
Original 39 assets: /home/user/hock-accepted-canonical-runtime/intake/game

Replay from candidate:

    PLACEMENT_GROUP=review PLACEMENT_FIXTURE=/home/user/hock-accepted-canonical-runtime/intake/game/BBLOOGIE.EXE node ../independent-show.js
    PLACEMENT_FIXTURE=/home/user/hock-accepted-canonical-runtime/intake/game/BBLOOGIE.EXE node test/test-window-placement-notify.js
    node tools/callback-ownership-census.js
    node test/test-callback-ownership-census.js
    bash tools/build.sh

Rejecting controls use PLACEMENT_CONTROL=zero-destruction with
PLACEMENT_GROUP=show-return and PLACEMENT_CONTROL=keep-success with
PLACEMENT_GROUP=startup; each must exit 1 on the specific assertion.
Existing controls/commands and all receipts are in the new evidence archive.

After exact source/package/module verification, the preserved
`drive-candidate.py` runs the original held route. Change its output directory
before replaying; preserve the accepted original-held evidence. Do not reuse an
unverified module. Full runtime modules and original assets are intentionally
not committed. Restore the task branch into a fresh checkout and run the
canonical all-gates build; restore the original package through its existing
intake recipe and compare package-seals.json before runtime.

Canonical module f9bd92c5774f3bc332889f8765e75e4f85bef81692314c19186aff1c0dfe1271
Compat module eef7dc134267cb24314e4259c61430566d7d2f05664e8abeb441646dc7a51e05

Old evidence archive remains unchanged in commit695c9e8d. The separately
corrected historical archive explicitly supersedes its blanket seal claim,
retains the original manifest and stores displaced Boat receipts under
publication-receipts/. It does not accept the old defective production code.
