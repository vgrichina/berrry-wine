"""Independent OFFLINE production CLI/Bridge.run challenge; no gameplay."""
import copy,hashlib,importlib.util,json,pathlib,subprocess,sys,threading
H=pathlib.Path(__file__).parent;R=H.parent/'repo'
sp=importlib.util.spec_from_file_location('fixture',R/'test/test-airstrike-console-obscuration.py');t=importlib.util.module_from_spec(sp);sp.loader.exec_module(t)
if len(sys.argv)>1 and sys.argv[1]=='--transport':
 d=pathlib.Path(sys.argv[2]);cfg=json.loads((d/'case.json').read_text());count=0
 print('Independent OFFLINE fake protocol transport; no guest',file=sys.stderr,flush=True)
 for line in sys.stdin:
  cmd=json.loads(line)
  with (d/'received.jsonl').open('a') as f:f.write(json.dumps(cmd)+'\n')
  if 'cmd' in cmd:print('OFFLINE terminal after first input',file=sys.stderr,flush=True);break
  if cmd['action']=='snapshot':
   count+=1;v=copy.deepcopy(cfg['initial'])
   if count>=3:v=copy.deepcopy(cfg['fresh'])
  elif cmd['action']=='png':
   data=b'independent unchanged synthetic pixels';pathlib.Path(cmd['path']).write_bytes(data);v=dict(path=cmd['path'],bytes=len(data))
  else:raise AssertionError(cmd)
  print('[ctl] '+json.dumps(dict(id=cmd['id'],ok=True,value=v)),flush=True)
 sys.exit(0)

report=json.loads((H/'independent-rejection.json').read_text());q=json.loads((H/'first-original.json').read_text())
assert report['verdict']=='PASS' and report['controllerCLI']['commands']==[] and report['controllerCLI']['exit']==2
assert report['bridge']['inputs']==[] and report['bridge']['result']['cleanup']['complete'] and q['exit']==1 and q['cleanupComplete']
assert hashlib.sha256((H/'reproduce.py').read_bytes()).hexdigest()=='1c257e171582abb4e6ba1a5f54a0bfc9a30bd4f628f388a8a129fd9f5312b68d'
cases=[]
def case(name,edit=None,accept=False,change=None):
 s=copy.deepcopy(t.SNAPSHOT)
 if edit:edit(s)
 f=copy.deepcopy(s)
 if change:change(f)
 cases.append((name,s,f,accept,change is not None))
def mainfield(k,v):return lambda s:s['windows'][0].__setitem__(k,v)
case('normal-806x608-on-800x600',accept=True)
for h in (0,1,8,13,14,26):case('height-'+str(h),mainfield('h',h))
case('full-caption-27',mainfield('h',27),True)
case('full-caption-screen-exact',lambda s:(s['windows'][0].__setitem__('h',27),s['screen'].__setitem__('h',47)),True)
case('caption-clipped-one-pixel',lambda s:s['screen'].__setitem__('h',46))
for k,v in [('x',-1),('y',-1),('y',600),('w',0),('h',-1),('w',88),('h',27.0),('h',True),('x',20.5),('w','806')]:case('main-'+k+'-'+str(v),mainfield(k,v))
case('point-right-edge-offscreen',lambda s:s['screen'].__setitem__('w',656))
case('point-last-screen-pixel',lambda s:s['screen'].__setitem__('w',657),True)
case('point-at-caption-buttons',mainfield('w',700))
case('point-last-before-caption-buttons',mainfield('w',701),True)
case('console-covers-entire-caption',lambda s:s['windows'][1].__setitem__('w',800))
case('console-fractional',lambda s:s['windows'][1].__setitem__('w',648.5))
case('console-offscreen',lambda s:s['windows'][1].__setitem__('y',-1))
case('screen-boolean',lambda s:s['screen'].__setitem__('h',True))
case('fresh-height8',accept=False,change=mainfield('h',8))
case('fresh-still-valid-height607',accept=False,change=mainfield('h',607))
case('fresh-x-shift',accept=False,change=mainfield('x',21))
case('fresh-console-shift',accept=False,change=lambda s:s['windows'][1].__setitem__('x',1))
results=[]
for name,s,f,accept,changed in cases:
 d=H/('challenge-'+name);d.mkdir();(d/'case.json').write_text(json.dumps(dict(initial=s,fresh=f)))
 o=t.approved();o['startupSnapshot']=s;o['consoleObstruction']=copy.deepcopy(s['windows'][1])
 with (d/'cli.stdout').open('w') as out,(d/'cli.stderr').open('w') as err:
  cli=subprocess.run([sys.executable,'-B',str(R/'tools/airstrike-menu-controller.py')],input=json.dumps(dict(observation=o))+'\n',text=True,stdout=out,stderr=err,timeout=5)
 cmds=[json.loads(x) for x in (d/'cli.stdout').read_text().splitlines()]
 expected=[dict(id='airstrike-1',cmd='click:656:33')] if accept or changed else []
 assert cmds==expected,(name,cmds,expected)
 obj=t.b.Bridge([sys.executable,'-B',__file__,'--transport',str(d)],R/'tools/airstrike-menu-controller.py',d/'evidence',guest_seconds=12)
 done=threading.Event();errors=[]
 def review():
  seen=set()
  try:
   while not done.wait(.005):
    p=obj.root/'review-request.json'
    if not p.exists():continue
    req=json.loads(p.read_text())
    if req['token'] in seen:continue
    seen.add(req['token']);obs=t.approved();obs.pop('startupSnapshot');obs['consoleObstruction']=copy.deepcopy(req['snapshot']['windows'][1]);obs['evidence']=req['path']
    reply={k:req[k] for k in ('session','token','sha256','after')};reply['observation']=obs;t.b.save(obj.root/('review-'+req['token']+'.json'),reply)
  except Exception as e:errors.append(str(e))
 th=threading.Thread(target=review);th.start()
 try:r=obj.run()
 finally:done.set();th.join(2)
 inputs=[json.loads(x) for x in (d/'received.jsonl').read_text().splitlines() if '"cmd"' in x]
 assert not errors and not th.is_alive() and r['cleanup']['complete'],(name,errors,r)
 expected=expected if accept else []
 assert inputs==expected,(name,inputs,r)
 if accept:
  x,y=656,33;m=s['windows'][0];c=s['windows'][1]
  assert m['x']+24<=x<m['x']+m['w']-64 and m['y']+1<y<m['y']+26
  assert x<s['screen']['w'] and y<s['screen']['h'] and not(c['x']<=x<c['x']+c['w'] and c['y']<=y<c['y']+c['h'])
 item=dict(case=name,cliExit=cli.returncode,cliCommands=cmds,bridgeInputs=inputs,result=r)
 (d/'assertions.json').write_text(json.dumps(item,indent=2));results.append(item)
 (H/'challenge-checkpoint.json').write_text(json.dumps(dict(completed=len(results),results=results),indent=2))
(H/'challenge-result.json').write_text(json.dumps(dict(verdict='PASS',offline=True,cases=results),indent=2))
print(str(len(results))+' independent actual CLI and Bridge.run geometry/fresh-snapshot cases PASS; all cleanup complete; OFFLINE only')
