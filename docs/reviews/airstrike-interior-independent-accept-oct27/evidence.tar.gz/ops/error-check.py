import run as c
import importlib.util,json,hashlib
s=importlib.util.spec_from_file_location('fixture',c.R/'test/test-airstrike-console-obscuration.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
pins=json.loads((c.H/'input-checkpoint.json').read_text())['sourcePins']
for p,h in pins.items():assert hashlib.sha256((c.R/p).read_bytes()).hexdigest()==h,(p,h)
obj=t.b.Bridge(['/nonexistent-airstrike-independent-owned-fixture'],c.R/'tools/airstrike-menu-controller.py',c.H/'spawn-error-evidence',guest_seconds=12)
r=obj.run()
assert r['status']=='refused' and r['cleanup']['complete'] and obj.p is None,r
assert (obj.root/'runner.stdout').exists() and (obj.root/'runner.stderr').stat().st_size>0
assert json.loads((obj.root/'spawn-status.json').read_text())['state']=='spawn-failed'
c.dump('error-check-result.json',dict(result=r,sourcePinsVerified=pins,failedSpawnDiagnostics='spawn-error-evidence/{runner.stdout,runner.stderr,spawn-status.json,controller.stderr}',offline=True))
prior=json.loads((c.H/'input-checkpoint.json').read_text())
c.dump('acceptance-checkpoint.json',dict(candidate=prior['candidate'],sourcePins=pins,completed=dict(firstUnchanged='PASS zero CLI commands and zero Bridge inputs; intentional vulnerability assertion exit1',independent='33 geometry and fresh-snapshot cases PASS',positive='See affected-positive.json; actual CLI and Bridge.run normal-Quit fake path',error='Missing executable records distinct streams and spawn failure; cleanup complete'),reused=dict(manifest=prior['manifest'],manifestSHA256=prior['manifestSHA256'],focused='Reported 10 passing tests reused; rerun only affected actual CLI and Bridge.run positive methods',controls='Reported 8 passing controls reused unchanged'),remaining=['source review closure and evidence publication'],runtime='No guest/Node/API/Boat execution'))
print('Exact4sourcePins PASS; failedspawn diagnostics/cleanup PASS; durable acceptance checkpoint written')
