import run as c
import hashlib,json,tarfile
p=c.R/'docs/reviews/airstrike-interior-independent-accept-oct27'
hs=json.loads((p/'sha256.json').read_text())
for name,h in hs.items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
with tarfile.open(p/'evidence.tar.gz','r:gz') as tar:
 members=tar.getmembers();names={m.name for m in members}
 for name in ('reproduce.py','first-original.json','independent-rejection.json','challenge-result.json','affected-positive.json','error-check-result.json','first-admission-manifest.json','report.stderr','exact-source-review.stdout'):
  assert 'ops/'+name in names,name
 q=json.load(tar.extractfile('ops/challenge-result.json'));assert len(q['cases'])==32 and q['verdict']=='PASS'
 assert hashlib.sha256(tar.extractfile('ops/reproduce.py').read()).hexdigest()=='1c257e171582abb4e6ba1a5f54a0bfc9a30bd4f628f388a8a129fd9f5312b68d'
 c.dump('payload-validation.json',dict(passVerdict=True,files=hs,archiveMembers=len(members),acceptedCases=32))
print('Report hashes, archive causal evidence and unchanged original oracle verified')
