import run as c
import pathlib,hashlib,json
D=pathlib.Path('/tmp/airstrike-caption-interior-geometry-repair-oct27')
manifest=D/'ops/receipt-manifest.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest()=='84e46aae879bb0fae3632b67e6a56bee0dda1407f71c469cea2a75a703ad9f55'
assert hashlib.sha256((D/'ops/reproduce.py').read_bytes()).hexdigest()=='1c257e171582abb4e6ba1a5f54a0bfc9a30bd4f628f388a8a129fd9f5312b68d'
stores=[str(D/'repo/.git/objects'),* (D/'repo/.git/objects/info/alternates').read_text().splitlines()]
(c.R/'.git/objects/info/alternates').write_text('\n'.join(stores)+'\n')
(c.R/'.git/config').write_text('[core]\n repositoryformatversion = 0\n bare = false\n sparseCheckout = true\n[remote "origin"]\n url = git@github.com:vgrichina/wine-assembly.git\n[user]\n name = Wine Ops\n email = wine-ops@localhost\n[gc]\n auto = 0\n')
paths=['tools/airstrike-menu-controller.py','tools/airstrike-observation-bridge.py','test/test-airstrike-console-obscuration.py','test/test-airstrike-caption-interior.py']
(c.R/'.git/info/sparse-checkout').write_text('\n'.join('/'+p for p in paths)+'\n/docs/reviews/airstrike-interior-independent-accept-oct27/\n')
for name in ['reproduce.py','production-renderer-input.js']:
 (c.H/name).write_bytes((D/'ops'/name).read_bytes())
c.dump('input-checkpoint.json',dict(candidate='a6a5cda53242adba9738a30811cee60fa696548a',manifest=str(manifest),manifestSHA256=hashlib.sha256(manifest.read_bytes()).hexdigest(),sourcePins=json.loads(manifest.read_text())['sourcePins'],ssh=c.SSH,stores=stores,paths=paths,mountArgv=[],mountValidation='Offline Python only: no filename-bearing mount argv or Node configuration',rootRefReceipt=str(c.ROOT/'scratch/usage-watch/airstrike-interior-independent-accept-oct27/root-ref-digest.json')))
print('Immutable pins, strict SSH, sparse paths verified; no runtime/mount argv.')
