import run as c
import hashlib,json,tarfile
pins=json.loads((c.H/'input-checkpoint.json').read_text())
first=json.loads((c.H/'independent-rejection.json').read_text())
challenge=json.loads((c.H/'challenge-result.json').read_text())
assert len(challenge['cases'])==32 and challenge['verdict']=='PASS'
for name in ('independent-geometry','affected-positive','error-check','exact-source-review'):
 q=json.loads((c.H/(name+'.json')).read_text());assert q['exit']==0 and q['cleanupComplete'] and not q['stopReason']
assert json.loads((c.H/'first-original.json').read_text())['exit']==1
review='''PASS independent acceptance for candidate a6a5cda53242adba9738a30811cee60fa696548a.

Acceptance boundary: OFFLINE actual Controller CLI and Bridge.run, using fake protocol transports and retained factual fixture inputs. No renderer, guest, runtime, main merge, or public deployment. This establishes dispatch refusal and retained protocol behavior; it does not establish gameplay, real focus activation, or real ordinary Quit.

FIRST the byte-identical original reproduce.py ran against the pinned production controller/Bridge. Both emitted zero inputs for main height8. The original vulnerability assertion intentionally exited1 after saving its own PASS/no-input report. Distinct stdout/stderr and owned cleanup remain in the archive.

32 independent cases exercised actual CLI and Bridge.run: short/degenerate/noninteger/boolean/negative/offscreen geometry, full-caption clipping, exact minimum27px caption, Console coverage, caption-button horizontal boundary, screen-point boundary, and geometry changed after review at the fresh snapshot. The806x608 window on800x600 remains accepted; client/bottom/right oversize is allowed while the whole vertical caption band and selected interior point must be on screen. Exact source diff and4source hashes were independently verified. The production bridge retains the controller SHA pin.

Two affected original positive methods passed: actual CLI startup wiring and actual Bridge.run full normal-Quit fake positive (plus its wrong-target/stale-review modes). The remaining original10focused group and8controls are reused from the unchanged pinned canonical producer manifest; no full payload audit was duplicated. A missing-executable challenge additionally verified spawn-failed diagnostics, distinct streams and complete cleanup.

Production review: strict integer main/screen geometry rejects booleans/floats; minimum width89/height27 and nonnegative origins prevent degenerate rectangles. main.y+27<=screen.h requires the full vertical caption band. The candidate selects Console.right+8, main.y+13; x must be in [main.x+24,main.right-64), y strictly inside the caption, on canvas and outside Console. Python integer arithmetic cannot overflow. Conservative rejection does not search alternate safe points. Bridge.observation validates activation geometry before controller dispatch; Bridge.send checks the exact reviewed action, fresh pixels/focus/full snapshot, revalidates geometry, then writes with no intervening request. Refusal exceptions become Stop and run finally retains bounded diagnostics and cleanup. No semantic repair was made.

Incidents preserved: initial oversized display; nonexistent exploratory test path; aggregate RAM admission initially denied before Git, then continued only after measured actual capacity increase with identical limits; unchanged vulnerability assertion exit1 is expected; historical producer source-diff receipt was an intermediate version, so final review uses fresh exact candidate Git diff. Initial blocker manifest is historical, superseded by final receipt. Initial report asserted33cases; raw passing result has32, corrected without repeating tests. No test group was restarted after passing.

Resources: Python physical128MiB/CPU90/wall120/file24MiB/output2MiB, cumulative stdout/stderr1MiB. Git physical256MiB and DATA512MiB on Git only, two shared permits and flock. Trusted supervisor identity pinned; no Node or mount invocation. Fresh admissions include this client320MiB once, four futureclients1280MiB, shared child pool512MiB and805306368B headroom.192MiB task allocation includes session/events/positive WAL once,24MiB future control,16MiB publication,8MiB reserve and8MiB margin. Raw admission failures remain causal evidence.

Reproduction: under the assigned resource wrappers run ops/reproduce.py FIRST (expected exit1 with saved zero-input report), then ops/challenge.py, the two selected Startup methods listed in affected-positive.command.json, and ops/error-check.py. Source/retained fixture donors must remain available at their pinned read-only paths. The task archive is evidence, not a standalone guest distribution.
'''
out=c.R/'docs/reviews/airstrike-interior-independent-accept-oct27';out.mkdir(parents=True,exist_ok=True)
(out/'README.md').write_text(review)
manifest=dict(schema=1,task='airstrike-interior-independent-accept-oct27',verdict='PASS_OFFLINE_DISPATCH_GEOMETRY',candidate=pins['candidate'],sourcePins=pins['sourcePins'],canonicalInputManifest=pins['manifest'],canonicalInputManifestSHA256=pins['manifestSHA256'],first=dict(receipt='independent-rejection.json',expectedExit=1,actualCLI=first['controllerCLI'],actualBridgeInputs=first['bridge']['inputs'],cleanup=first['bridge']['result']['cleanup']),independentCases=32,affectedPositiveMethods=2,reused='Unchanged producer10focused+8controls; affected two positive methods rerun',remaining=[],reviewBoundary='OFFLINE protocol dispatch only, no actual guest/renderer/gameplay acceptance',publication=dict(branch='refs/heads/task/airstrike-interior-independent-accept-oct27',commit=None,exactRemoteVerified=False),rootRefReceipt=pins['rootRefReceipt'],diagnostics='All raw files under ops; historical blocker preserved as first-admission-manifest.json',cleanup='Supervisor receipts all complete; no boxes assigned; watcher cleanup at closeout')
c.dump('receipt-manifest.json',manifest)
(out/'acceptance.json').write_text(json.dumps(manifest,indent=2)+'\n')
files=[p for p in c.H.rglob('*') if p.is_file()]
with tarfile.open(out/'evidence.tar.gz','w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname='ops/'+str(p.relative_to(c.H)),recursive=False)
hashes={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='sha256.json'}
(out/'sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
c.dump('publication-payload.json',dict(paths=hashes,archiveMembers=len(files),branch=manifest['publication']['branch']))
print('PASS report and causal archive prepared: '+str(len(files))+' evidence files; publication pending')
