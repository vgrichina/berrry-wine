# Recovery

Use the report adjacent to this file. Extract the tracked
`docs/reviews/army-repaired-canonical-runtime-20261021-evidence.tgz` into an
empty directory, then run `python3 verify.py` there. This validates every
sealed evidence file and core build/closure assertions. No assets or module
are copied locally; their exact hashes and remote location are recorded.

The assigned box is bx_e8a7pw8v; only access while still running and explicitly
assigned. Never resume it under this task. Coordinator owns shutdown.
Remote fresh module is /home/user/army-current-main/repo/build/wine-assembly.wasm.
`build.sh` records exact-source checkout, inventory, cheap checks and canonical
build. `remote.py` calls documented Boat exec API, `file-api.js` the file API;
no credentials/signed URLs are stored. `transfer.js` verifies the 419 originals
against the historical manifest and uploads only those files. `provision.js`
checks original closure/CPU exports/real DLL graph; `closure-diagnostic.js`
adds failure evidence before the same assertion. Both intentionally stop at
missing real DLLs. Do not rerun a game until a separately assigned staging
repair closes the graph. `preserve.sh` revalidates source and records module.

Old /home/user/army-current-main/evidence from the prior failed build remains
unchanged. No stopped box is needed. The new module can be rebuilt from exact
30a2c3fb with normal tools/build.sh gates and production npm dependencies.
