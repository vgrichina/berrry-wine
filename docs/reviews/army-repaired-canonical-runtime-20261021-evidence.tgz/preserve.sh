set -eu
cd /home/user/army-current-main/repo
python3 - <<'END'
import pathlib,json,hashlib,subprocess
r=pathlib.Path('.'); e=pathlib.Path('../repaired-evidence'); m=json.loads((e/'source-manifest.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==m['revision']
for f in m['files']:
 b=(r/f['path']).read_bytes(); assert len(b)==f['size'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
status=subprocess.check_output(['git','status','--porcelain'],text=True);assert not status,status
module=r/'build/wine-assembly.wasm'
post=dict(source=m['revision'],sourceFiles=len(m['files']),status=status,moduleSha256=hashlib.sha256(module.read_bytes()).hexdigest(),moduleBytes=module.stat().st_size,guestLaunched=False)
(e/'postflight.json').write_text(json.dumps(post,indent=2));print(json.dumps(post))
END
sha256sum build/wine-assembly.wasm build/wine-assembly.compat.wasm > ../repaired-evidence/modules.sha256
cp build/build-info.json ../repaired-evidence/ 2>/dev/null || true
tar -czf ../repaired-evidence.tgz -C .. repaired-evidence
