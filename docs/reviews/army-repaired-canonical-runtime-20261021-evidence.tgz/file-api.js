'use strict';
const fs=require('fs'),cp=require('child_process'),assert=require('assert/strict');
const box='bx_e8a7pw8v';
async function fileUrl(op,path){
 const {token}=JSON.parse(fs.readFileSync('/home/user/.config/ascii/boat/config.json'));
 const r=await fetch(`https://boat.dev/api/v1/sandboxes/${box}/files/${op}-url`,{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({path,ttlSeconds:900})});
 assert(r.ok,`${op}-url HTTP ${r.status}`);return (await r.json()).url;
}
async function upload(path,bytes){const r=await fetch(await fileUrl('upload',path),{method:'PUT',headers:{'Content-Type':'application/octet-stream'},body:bytes});assert(r.ok,'upload '+r.status);}
async function download(path){const r=await fetch(await fileUrl('download',path));assert(r.ok,'download '+r.status);return Buffer.from(await r.arrayBuffer());}
function exec(args,name,timeout=30){
 const b=cp.execFileSync('boat',['exec',box,'--json','--timeout',String(timeout),'--',...args],{maxBuffer:12e6});
 fs.writeFileSync(__dirname+'/'+name+'.json',b);const r=JSON.parse(b);assert(r.success,JSON.stringify(r));return r.stdout;
}
module.exports={upload,download,exec};
