import pathlib,json,hashlib
p=pathlib.Path(__file__).resolve().parent
seals=json.loads((p/'SHA256SUMS.json').read_text())
for f in seals:
 b=(p/f['path']).read_bytes();assert len(b)==f['size'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
e=p/'repaired-evidence'; post=json.loads((e/'postflight.json').read_text()); closure=json.loads((e/'dependency-closure.json').read_text())
assert post['source']=='30a2c3fb1b5c2bfa8a6b001d7394d5cf50df295d'
assert post['sourceFiles']==7299 and post['status']=='' and not post['guestLaunched']
assert post['moduleSha256']=='728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c'
assert (e/'build.exit').read_text().strip()=='0'
assert json.loads((p/'build-receipt.json').read_text())['exitCode']==0
assert closure['verifiedOriginals']==419 and len(closure['excluded'])==14
assert closure['missingDlls']==['comctl32.dll','ole32.dll','mfc42.dll','msvcrt.dll']
for cpu in closure['cpu']:
 assert all(any(e['name']==n and e['rva']>0 for e in cpu['exports']) for n in ['wincpuid','cpunormspeed'])
print('PASS',len(seals),'evidence seals; exact build and prerequisite blocker assertions')
