set -eu
cd /home/user/army-current-main/repo
test -z "$(git status --porcelain)"
git fetch origin 30a2c3fb1b5c2bfa8a6b001d7394d5cf50df295d
git checkout --detach 30a2c3fb1b5c2bfa8a6b001d7394d5cf50df295d
mkdir -p ../repaired-evidence
python3 - <<'PY'
import pathlib,subprocess,json,hashlib
r=pathlib.Path('.'); rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert rev=='30a2c3fb1b5c2bfa8a6b001d7394d5cf50df295d'
assert not subprocess.check_output(['git','status','--porcelain'])
files=[]
for row in subprocess.check_output(['git','ls-tree','-rz','HEAD']).split(b'\0'):
 if not row: continue
 meta,name=row.split(b'\t'); mode,kind,oid=meta.decode().split(); p=name.decode(); b=(r/p).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid,p
 files.append(dict(path=p,oid=oid,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
pathlib.Path('../repaired-evidence/source-manifest.json').write_text(json.dumps(dict(revision=rev,files=files),indent=2))
print('Exact source verified:',rev,len(files))
PY
node --version
npm ls --depth=0 > ../repaired-evidence/npm-ls.log 2>&1
node tools/check-claude-size.js
node tools/check-wat-manifest.js
node tools/check-wat-fragments.js
set +e
bash tools/build.sh > ../repaired-evidence/build.log 2>&1
code=$?
printf '%s\n' "$code" > ../repaired-evidence/build.exit
tail -n 35 ../repaired-evidence/build.log
if [ "$code" -eq 0 ]; then sha256sum build/wine-assembly.wasm > ../repaired-evidence/module.sha256; fi
exit "$code"
