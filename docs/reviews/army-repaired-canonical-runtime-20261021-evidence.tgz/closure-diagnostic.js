'use strict';
const fs=require('fs'),cp=require('child_process'),crypto=require('crypto'),assert=require('assert/strict'),path=require('path');
const root='/home/user/army-current-main/repo',out='/home/user/army-current-main/repaired-evidence',vroot='/home/user/army-current-main/vfs';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 fs.mkdirSync(vroot,{recursive:true});
 const all=JSON.parse(fs.readFileSync(out+'/original-manifest.json'));
 const excluded=all.filter(p=>p.path.startsWith('state/vfs/windows/system/')&&p.size<=1024);
 assert.equal(excluded.length,14);const wanted=all.filter(p=>!excluded.includes(p));assert.equal(wanted.length,419);
 cp.execFileSync('tar',['-xzf','/home/user/army-current-main/original419.tgz','-C',vroot]);
 for(const p of wanted){const b=fs.readFileSync(vroot+'/'+p.path.slice(10));assert.equal(b.length,p.size);assert.equal(sha(b),p.sha256,p.path);}
 for(const p of excluded)assert(!fs.existsSync(vroot+'/'+p.path.slice(10)));
 const {findVfsDllBytes,resolveDllGraph}=require(root+'/lib/process-boot');
 const {detectRequiredDlls}=require(root+'/lib/dll-loader');
 const {readPE}=require(root+'/lib/pe');
 const files=new Map(wanted.map(p=>['c:\\'+p.path.slice(10).replaceAll('/','\\'),{data:fs.readFileSync(vroot+'/'+p.path.slice(10))}]));
 const vfs={files,_resolvePath:n=>'c:\\program files\\the 3do company\\army men demo\\'+n.toLowerCase()};
 const cpu=[];
 for(const name of ['cpuinf32.dll','cpuinfo.dll']){
  const b=findVfsDllBytes(vfs,name,name);assert(b,name);
  const p=all.find(p=>p.path==='state/vfs/windows/system/'+name);assert.equal(sha(b),p.sha256);
  const pe=readPE(b),off=rva=>pe.va2off(pe.imageBase+rva);
  const exp=off(b.readUInt32LE(pe.peOff+24+96)),count=b.readUInt32LE(exp+24),table=off(b.readUInt32LE(exp+32)),ord=off(b.readUInt32LE(exp+36)),funcs=off(b.readUInt32LE(exp+28));
  const exports=[];
  for(let i=0;i<count;i++){const at=off(b.readUInt32LE(table+i*4));const name=b.subarray(at,b.indexOf(0,at)).toString();const rva=b.readUInt32LE(funcs+b.readUInt16LE(ord+i*2)*4);exports.push({name,rva});}
  for(const name of ['wincpuid','cpunormspeed'])assert(exports.some(e=>e.name===name&&e.rva>0));
  cpu.push({name,sha256:sha(b),exports,imports:detectRequiredDlls(b),discovery:'actual findVfsDllBytes system-path fallback'});
 }
 const exeDir=vroot+'/program files/the 3do company/army men demo';
 const dirs=[exeDir+'/dlls',exeDir,path.join(exeDir,'..','Shared_DLLs'),path.join(exeDir,'..','shared_dlls'),root+'/test/binaries/dlls'];
 const resolved=[],missingDlls=[];
 await resolveDllGraph({exeBytes:fs.readFileSync(exeDir+'/armymendemo.exe'),detectRequiredDlls,onMissing:n=>missingDlls.push(n),loadSpec:n=>{
  for(const dir of dirs){if(!fs.existsSync(dir))continue;const file=fs.readdirSync(dir).find(f=>f.toLowerCase()===n.toLowerCase());if(file){const p=dir+'/'+file,b=fs.readFileSync(p);resolved.push({name:n,path:p,sha256:sha(b),imports:detectRequiredDlls(b)});return {name:n,bytes:b};}}return null;
 }});
 fs.writeFileSync(out+'/dependency-closure.json',JSON.stringify({at:new Date().toISOString(),verifiedOriginals:wanted.length,excluded,cpu,resolved,missingDlls,searchDirectories:dirs,filesByDirectory:dirs.map(p=>({path:p,exists:fs.existsSync(p),names:fs.existsSync(p)?fs.readdirSync(p):[]}))},null,2));
 assert.deepEqual(missingDlls,[]);
 const reg=fs.readFileSync(out+'/registry.json');
 fs.writeFileSync(out+'/registry.json',reg);
 const {createCanvas}=require(root+'/lib/canvas-compat');
 const {Win98Renderer}=require(root+'/lib/renderer');
 const canvas=createCanvas(640,480);new Win98Renderer(canvas);fs.writeFileSync(out+'/renderer-preflight.png',canvas.toBuffer('image/png'));
 const r={at:new Date().toISOString(),source:'30a2c3fb1b5c2bfa8a6b001d7394d5cf50df295d',module:sha(fs.readFileSync(root+'/build/wine-assembly.wasm')),historical:all.length,staged:419,verified:wanted.length,excluded:excluded.map(p=>({...p,reason:'historical generated system placeholder; not an original asset'})),missingOriginal:[],cpu,resolved,missingDlls,registrySha256:sha(reg),node:process.version,freeBytes:fs.statfsSync(root).bavail*fs.statfsSync(root).bsize};
 fs.writeFileSync(out+'/preflight.json',JSON.stringify(r,null,2));console.log(JSON.stringify(r));
})().catch(e=>{fs.writeFileSync(out+'/preflight-failure.json',JSON.stringify({error:e.stack}));console.error(e);process.exitCode=1});
