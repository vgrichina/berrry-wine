const fs=require('fs'),cp=require('child_process'),crypto=require('crypto'),assert=require('assert/strict');
const api=require('./file-api');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const all=JSON.parse(fs.readFileSync('/home/user/wine-assembly/scratch/runs/20261020-army-original-closure-capture/original-manifest.json'));
 const excluded=all.filter(p=>p.path.startsWith('state/vfs/windows/system/')&&p.size<=1024);
 const wanted=all.filter(p=>!excluded.includes(p));assert.equal(wanted.length,419);assert.equal(excluded.length,14);
 const root='/home/user/army-men-local-stage-v14-20261019';
 for(const p of wanted){const b=fs.readFileSync(root+'/'+p.path);assert.equal(b.length,p.size);assert.equal(sha(b),p.sha256,p.path);}
 const archive=cp.execFileSync('tar',['-czf','-','-C',root+'/state/vfs','--null','-T','-'],{input:wanted.map(p=>p.path.slice(10)).join('\0')+'\0',maxBuffer:128*1024**2});
 await api.upload('/home/user/army-current-main/original419.tgz',archive);
 await api.upload('/home/user/army-current-main/repaired-evidence/original-manifest.json',Buffer.from(JSON.stringify(all,null,2)));
 await api.upload('/home/user/army-current-main/repaired-evidence/registry.json',fs.readFileSync('/home/user/wine-assembly/scratch/runs/20261020-army-unobscured-scroll/registry.json'));
 fs.writeFileSync(__dirname+'/transfer.json',JSON.stringify({at:new Date().toISOString(),verified:419,excluded,archiveBytes:archive.length,archiveSha256:sha(archive),remote:'/home/user/army-current-main/original419.tgz'},null,2));
 console.log('Uploaded verified 419 originals',archive.length,sha(archive));
})().catch(e=>{console.error(e);process.exitCode=1});
