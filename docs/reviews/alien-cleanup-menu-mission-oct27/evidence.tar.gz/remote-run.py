import importlib.util,pathlib,os,sys,time,json,resource,hashlib,subprocess
h=pathlib.Path(__file__).parent;op=sys.argv[1];p=h/'trusted-supervisor.py';assert hashlib.sha256(p.read_bytes()).hexdigest()=='9d10f7c8c75b5f0dfebff2299eef8ddc27988cf112e0e9c255e89f772c2cee85'
s=importlib.util.spec_from_file_location('trusted',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
for k in ['WINE_RUN_EXTRA_ARGS','WINE_REGION_MAP','NODE_OPTIONS','NODE_PATH']:os.environ.pop(k,None)
def check():
 total=sum(x.lstat().st_blocks*512 for x in [h,*h.rglob('*')] if x.exists())
 if total>256*2**20:return 'remote task allocation'
 logs=list(h.glob('*-streams/*.log'));output=sum(x.stat().st_size for x in logs)
 if output>2*2**20:return 'combined stdout/stderr output'
 if any(x.stat().st_size>24*2**20 for x in h.rglob('*') if x.is_file()):return 'combined file guard'
 if time.time()>=1793092500:return 'guest cutoff'
 if int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024<805306368:return 'host memory floor'
 if __import__('shutil').disk_usage(h).free<2982150144:return 'host disk floor'
 if (h/'guest/terminal.json').exists() and op=='guest':return None
 return None
if op=='guest':
 assert not (h/'guest-invocation-once').exists();(h/'guest-invocation-once').write_text(str(time.time()))
 argv=['python3',str(h/'runner/tools/alien-supervised-gameplay.py'),'--invocation',str(h/'guest'),'--endpoint','http://127.0.0.1:18129/ctl','--cwd',str(h/'runner'),'--deadline',str(time.time()+118),'--startup-maximum','75','--action-reserve','30','--cleanup-reserve','10','--capture-limit','8','--captures-used','0','--capture-bytes',str(24*2**20),'--rss-limit',str(3*2**30),'--after-batches','512','--startup-batches','4722','--','python3',str(h/'exec-node.py'),'guest']
else:argv=['python3',str(h/'exec-node.py'),op]
(h/(op+'-launch.json')).write_text(json.dumps(dict(argv=argv,at=time.time())))
r=m.supervise(argv,rss_limit=3*2**30,cpu_limit=90,wall_limit=120,output_limit=2*2**20,check=check);output=r.pop('output');(h/(op+'-supervisor.log')).write_bytes(output);(h/(op+'-supervision.json')).write_text(json.dumps(r));print(json.dumps(r))
raise SystemExit(0 if r['exit']==0 and not r['stopReason'] else 1)
