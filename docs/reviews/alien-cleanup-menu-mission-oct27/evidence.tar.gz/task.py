import pathlib,os,sys,json,time,hashlib,subprocess,resource,shutil,fcntl,shlex,base64,zlib
H=pathlib.Path('/tmp/alien-cleanup-menu-mission-oct27');O=H/'ops';ROOT=pathlib.Path('/home/user/wine-assembly');BOX='bx_yydnx5av';R=str(H)
NODE='/home/user/.nvm/versions/node/v24.22.1/bin/node'
SSH='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,j):
 p=O/n;t=p.with_name(p.name+'.new');t.write_text(json.dumps(j,indent=2)+'\n');t.replace(p)
def alloc(p):
 n=0
 if not p.exists():return n
 for x in [p,*p.rglob('*')] if p.is_dir() else [p]:
  try:n+=x.lstat().st_blocks*512
  except FileNotFoundError:pass
 return n
def admission():
 mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;free=shutil.disk_usage(H).free
 # Five clients already materialized in MemAvailable; reserve only their remaining future RSS.
 clients=[]
 for p in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   a=(p/'cmdline').read_bytes()
   if b'codex' in a and b'--model' in a and b'wine-worker' in a:
    rss=int((p/'statm').read_text().split()[1])*4096;clients.append(dict(pid=int(p.name),rss=rss))
  except (OSError,ValueError):pass
 future=sum(max(0,320*2**20-x['rss']) for x in clients)+max(0,5-len(clients))*320*2**20
 # Conservative entire five allocations remain future; avoids subtracting stale completed reservations.
 projected=free-5*96*2**20-16*2**20
 j=dict(at=time.time(),free=free,projectedFree=projected,diskFloor=2982150144,memAvailable=mem,clients=clients,remainingClientFuture=future,requiredRAM=future+256*2**20+805306368,ownActual=alloc(H),ownCap=96*2**20,conservativeFullFleetFuture=5*96*2**20,coordinatorAndDrift=16*2**20)
 save('admission-latest.json',j);assert projected>=2982150144 and mem>=j['requiredRAM'] and alloc(H)<56*2**20,j
 return j
def remote(cmd,timeout=30,detach=False):
 admission();assert len(cmd.encode())<=60000
 a=['boat','--no-update','--json','exec']+(['--detach'] if detach else ['--timeout',str(timeout)])+[BOX,cmd]
 k='api-'+str(time.time_ns());(O/(k+'.command')).write_text(cmd)
 p=subprocess.run(a,capture_output=True,timeout=timeout+15);(O/(k+'.stdout')).write_bytes(p.stdout);(O/(k+'.stderr')).write_bytes(p.stderr)
 assert len(p.stdout)+len(p.stderr)<=8192
 j=json.loads(p.stdout);save(k+'.json',dict(commandSHA256=sha(cmd.encode()),argv=a[:7],returncode=p.returncode,responseBytes=len(p.stdout)+len(p.stderr),at=time.time()))
 if p.returncode or (not detach and j.get('exitCode')!=0) or j.get('stdoutTruncated') or j.get('stderrTruncated'):
  save('first-api-failure.json',j);raise RuntimeError('API failure: stop without retry')
 return j
def py(c,**kw):return remote('python3 -c '+shlex.quote(c),**kw)
def transfer(items):
 batch=[];size=0
 def flush():
  nonlocal batch,size
  if not batch:return
  code='import pathlib,base64,zlib,hashlib,os\nh=pathlib.Path('+repr(R)+')\n'
  for target,off,mode,b in batch:
   enc=base64.b64encode(zlib.compress(b)).decode();code+='p=h/'+repr(target)+';p.parent.mkdir(parents=True,exist_ok=True);b=zlib.decompress(base64.b64decode('+repr(enc)+'));assert hashlib.sha256(b).hexdigest()=='+repr(sha(b))+';p.open('+repr('wb' if off==0 else 'ab')+').write(b);os.chmod(p,'+str(mode)+')\n'
  assert len(code)<50000;py(code);batch=[];size=0
 for target,p in items:
  with p.open('rb') as f:
   off=0
   while b:=f.read(30000):
    n=len(base64.b64encode(zlib.compress(b)))+650
    if size+n>47000:flush()
    batch.append((target,off,p.stat().st_mode&0o777,b));size+=n;off+=len(b)
 flush()
if __name__=='__main__':
 if sys.argv[1]=='admit':print(json.dumps(admission()))
 elif sys.argv[1]=='stage':
  M=ROOT/'scratch/usage-watch/alien-cleanup-verified-runtime-map-oct27.json';assert sha(M.read_bytes())=='d8c670ba75041e084e2be480ee17238ce41832fc721bc5ee1d54053c95ac4ca4';m=json.loads(M.read_text());rows=m['files'];assert len(rows)==617
  for x in rows:
   p=pathlib.Path(x['source']);assert p.stat().st_size==x['bytes'] and sha(p.read_bytes())==x['sha256'],x
  save('input-pins.json',dict(map=str(M),sha256=sha(M.read_bytes()),files=len(rows),bytes=sum(x['bytes'] for x in rows)))
  j=py("import pathlib,shutil,json,resource;print(json.dumps(dict(memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024,free=shutil.disk_usage('/tmp').free,limits={str(x):resource.getrlimit(x) for x in [resource.RLIMIT_AS,resource.RLIMIT_DATA,resource.RLIMIT_CPU,resource.RLIMIT_FSIZE]})))")
  v=json.loads(j['stdout']);assert v['memAvailable']>=3758096384+805306368 and v['free']-256*2**20>=2982150144;save('remote-admission-stage.json',v)
  transfer([(x['target'],pathlib.Path(x['source'])) for x in rows[int(sys.argv[2]):int(sys.argv[3])]]);
  if int(sys.argv[3])<617:print('stage group complete',sys.argv[2:]);sys.exit(0)
  e=O/'expected.json';e.write_text(json.dumps([{k:x[k] for k in ['target','sha256','bytes','mode']} for x in rows]));transfer([('expected.json',e)])
  j=py("import pathlib,json,hashlib,shutil;h=pathlib.Path("+repr(R)+");rows=json.loads((h/'expected.json').read_text());bad=[x['target'] for x in rows if not (h/x['target']).is_file() or (h/x['target']).stat().st_size!=x['bytes'] or hashlib.file_digest((h/x['target']).open('rb'),'sha256').hexdigest()!=x['sha256']];print(json.dumps(dict(files=len(rows),bad=bad,allocated=sum(p.lstat().st_blocks*512 for p in [h,*h.rglob('*')]),free=shutil.disk_usage(h).free)));assert not bad")
  save('remote-readback.json',j);print(j['stdout'])
