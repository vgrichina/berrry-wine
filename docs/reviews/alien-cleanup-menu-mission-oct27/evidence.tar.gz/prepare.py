from task import *
# Read the pinned production parser verbatim; initializer input uses the existing production CLI.
m=json.loads((ROOT/'scratch/usage-watch/alien-cleanup-verified-runtime-map-oct27.json').read_text());row=next(x for x in m['files'] if x['target']=='runner/test/run.js');s=pathlib.Path(row['source']).read_text();parser=s[s.index('const getArg ='):s.index('// Was `--name=...`')]
a=[NODE,'--max-old-space-size=2048','--require='+R+'/capture-wrapper.cjs',R+'/runner/test/run.js','--app=alien_shooter','--no-build','--wasm='+R+'/current.wasm','--d3d9-renderer=software','--trace-render-wait','--tick-ms-per-batch=5','--batch-size=200000','--max-seconds=110','--no-close','--quiet-api','--frozen','--control=18129','--input=50:dlg-click:1,3698:keypress:13']
save('guest-argv.json',a)
code='const fs=require("fs"),assert=require("assert"),path=require("path"),args='+json.dumps(a[4:])+';'+parser+''';assert.equal(getArg('app'),'alien_shooter');assert(hasFlag('no-build')&&hasFlag('trace-render-wait')&&hasFlag('frozen'));assert.equal(getArgs('vfs-tree').length,0);assert.equal(getArgs('vfs-mount').length,0);assert.equal(getArg('input'),'50:dlg-click:1,3698:keypress:13');const {APPS}=require('./lib/apps'),e=APPS.alien_shooter;fs.accessSync(e.exe);const m=JSON.parse(fs.readFileSync(e.localFileManifest));let dir=path.dirname(e.localFileManifest),files=m.files.map(x=>({...x,host:path.join(dir,x.url)}));for(let x of files)fs.accessSync(x.host);fs.writeFileSync('''+json.dumps(R+'/filename-enumeration.json')+''',JSON.stringify({exe:e.exe,manifest:e.localFileManifest,files,commaNames:files.filter(x=>x.url.includes(','))},null,2));console.log(JSON.stringify({count:files.length,exe:e.exe,manifest:e.localFileManifest,commaNames:files.filter(x=>x.url.includes(',')),noCommaSplitForRegisteredManifest:true}));'''
(O/'parser.cjs').write_text(code)
save('configuration-pins.json',dict(runner=row,parserSHA256=sha(parser.encode()),guestArgvSHA256=sha(json.dumps(a).encode()),initializer='production --input=50:dlg-click:1,3698:keypress:13; setup dialog/default OK and title Enter, never New Game',authority='unchanged original supervisor, no attach',stdoutStderr='exec wrapper dup2 before os.execvpe; original owned PID/start retained through exec',next='fresh remote exact startup/filename parser and production no-build module read'))
old=pathlib.Path('/tmp/alien-accepted-dispatch-menu-mission-oct27/ops/capture-wrapper.cjs').read_text().replace('/tmp/alien-accepted-dispatch-menu-mission-oct27',R);(O/'capture-wrapper.cjs').write_text(old)
# Wrapper does not launch another process: the original supervisor-owned PID becomes Node.
(O/'exec-node.py').write_text('''import os,sys,pathlib,resource,json,hashlib
h=pathlib.Path(__file__).parent;op=sys.argv[1];a=json.loads((h/(op+'-argv.json')).read_text());d=h/(op+'-streams');d.mkdir(exist_ok=False)
receipt=dict(argv=a,pid=os.getpid(),limits={str(k):resource.getrlimit(k) for k in [resource.RLIMIT_AS,resource.RLIMIT_DATA,resource.RLIMIT_CPU,resource.RLIMIT_FSIZE]},environmentSHA256=hashlib.sha256(json.dumps(sorted(os.environ.items())).encode()).hexdigest())
(d/'startup.json').write_text(json.dumps(receipt))
for fd,name in [(1,'stdout.log'),(2,'stderr.log')]:
 f=os.open(d/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.dup2(f,fd);os.close(f)
os.execvpe(a[0],a,os.environ)
''')
startup=a[:3]+['-e','console.log(JSON.stringify({node:process.version,execPath:process.execPath,argv:process.execArgv}));console.error("STARTUP_STDERR_DISTINCT")'];save('startup-argv.json',startup)
# Trusted outer supervisor accounts physical descendants and retains resource/cleanup evidence.
(O/'remote-run.py').write_text('''import importlib.util,pathlib,os,sys,time,json,resource,hashlib,subprocess
h=pathlib.Path(__file__).parent;op=sys.argv[1];p=h/'trusted-supervisor.py';assert hashlib.sha256(p.read_bytes()).hexdigest()=='9d10f7c8c75b5f0dfebff2299eef8ddc27988cf112e0e9c255e89f772c2cee85'
s=importlib.util.spec_from_file_location('trusted',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
for k in ['WINE_RUN_EXTRA_ARGS','WINE_REGION_MAP','NODE_OPTIONS','NODE_PATH']:os.environ.pop(k,None)
def check():
 total=sum(x.lstat().st_blocks*512 for x in [h,*h.rglob('*')] if x.exists())
 if total>256*2**20:return 'remote task allocation'
 logs=list(h.glob('*-streams/*.log'));output=sum(x.stat().st_size for x in logs)
 if output>2*2**20:return 'combined stdout/stderr output'
 if any(x.stat().st_size>24*2**20 for x in h.rglob('*') if x.is_file()):return 'combined file guard'
 if time.time()>=1793092500:return 'guest cutoff'
 if int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024<805306368:return 'host memory floor'
 if __import__('shutil').disk_usage(h).free<2982150144:return 'host disk floor'
 if (h/'guest/terminal.json').exists() and op=='guest':return None
 return None
if op=='guest':
 assert not (h/'guest-invocation-once').exists();(h/'guest-invocation-once').write_text(str(time.time()))
 argv=['python3',str(h/'runner/tools/alien-supervised-gameplay.py'),'--invocation',str(h/'guest'),'--endpoint','http://127.0.0.1:18129/ctl','--cwd',str(h/'runner'),'--deadline',str(time.time()+118),'--startup-maximum','75','--action-reserve','30','--cleanup-reserve','10','--capture-limit','8','--captures-used','0','--capture-bytes',str(24*2**20),'--rss-limit',str(3*2**30),'--after-batches','512','--startup-batches','4722','--','python3',str(h/'exec-node.py'),'guest']
else:argv=['python3',str(h/'exec-node.py'),op]
(h/(op+'-launch.json')).write_text(json.dumps(dict(argv=argv,at=time.time())))
r=m.supervise(argv,rss_limit=3*2**30,cpu_limit=90,wall_limit=120,output_limit=2*2**20,check=check);output=r.pop('output');(h/(op+'-supervisor.log')).write_bytes(output);(h/(op+'-supervision.json')).write_text(json.dumps(r));print(json.dumps(r))
raise SystemExit(0 if r['exit']==0 and not r['stopReason'] else 1)
''')
transfer([('guest-argv.json',O/'guest-argv.json'),('startup-argv.json',O/'startup-argv.json'),('runner/parser.cjs',O/'parser.cjs'),('capture-wrapper.cjs',O/'capture-wrapper.cjs'),('exec-node.py',O/'exec-node.py'),('remote-run.py',O/'remote-run.py'),('trusted-supervisor.py',pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo/test/helpers/palette-browser-supervisor.py'))])
print('launch configuration staged')
