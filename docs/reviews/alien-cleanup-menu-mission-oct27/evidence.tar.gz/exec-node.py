import os,sys,pathlib,resource,json,hashlib
h=pathlib.Path(__file__).parent;op=sys.argv[1];a=json.loads((h/(op+'-argv.json')).read_text());d=h/(op+'-streams');d.mkdir(exist_ok=False)
receipt=dict(argv=a,pid=os.getpid(),limits={str(k):resource.getrlimit(k) for k in [resource.RLIMIT_AS,resource.RLIMIT_DATA,resource.RLIMIT_CPU,resource.RLIMIT_FSIZE]},environmentSHA256=hashlib.sha256(json.dumps(sorted(os.environ.items())).encode()).hexdigest())
(d/'startup.json').write_text(json.dumps(receipt))
for fd,name in [(1,'stdout.log'),(2,'stderr.log')]:
 f=os.open(d/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.dup2(f,fd);os.close(f)
os.execvpe(a[0],a,os.environ)
