from task import *
import tarfile,io
admission()
sup=[]
for p in sorted(O.glob('supervision*.json')):
 j=json.loads(p.read_text());sup.append(dict(path=p.name,**{k:j.get(k) for k in ['exit','stopReason','peakRSS','cpuSeconds','wallSeconds','cleanupComplete']}))
failed=[x for x in sup if x['stopReason']]
assert len(failed)==1 and failed[0]['stopReason']=='wall deadline'
# Keep all request receipts and exactly identify incomplete receipt creation.
incomplete=[];completed=0
for p in O.glob('api-*.stdout'):
 try:j=json.loads(p.read_text())
 except (ValueError,OSError):incomplete.append(dict(path=p.name,reason='empty or invalid response'));continue
 if j.get('exitCode')==0 and j.get('success'):completed+=1
 else:incomplete.append(dict(path=p.name,reason='non-success response',response=j))
 if not p.with_suffix('.json').exists():incomplete.append(dict(path=p.name,reason='API stdout response present but local post-response hash receipt missing',responseSuccess=j.get('success')))
save('staging-checkpoint.json',dict(completedResponseFiles=completed,incompleteLocalReceipts=incomplete,failedLocalOperation=failed,acceptedFullGroup='stage 0..100 completed',interruptedGroup='stage 100..300 stopped by trusted local wall120; never retried',remoteReadback='remote-handback-readback.json',nextGate='coordinator decides fresh bounded continuation using remote per-file hash readback and only remaining file/chunks; never replay uncertain writes or start guest until complete617-file readback, exact startup and canonical mount receipts pass'))
retired=json.loads(pathlib.Path('/tmp/alien-supported-owner-accepted-main-integration-oct27/ops/result.json').read_text())
save('reused-acceptance.json',dict(acceptedMain=retired['publication']['commit'],pins=retired['sourcePins'],groups=4,childLifetimes=5,controls=45,replayed=False,historicalUnchangedReproducerPassed=False,supportedSetupAdaptationAccepted=True,limitations=retired['limitations']))
remote=json.loads((O/'remote-handback-readback.json').read_text());v=json.loads(remote['stdout'])
result=dict(status='BLOCKED_STAGING_WALL_LIMIT_STOP',task=H.name,session=os.environ.get('CODEX_THREAD_ID'),branch='task/'+H.name,source='ebf70036c96e0c3267b4943822a446a0b13e8336',runtimeMapSHA256='d8c670ba75041e084e2be480ee17238ce41832fc721bc5ee1d54053c95ac4ca4',guestInvocations=0,guestControlCommands=0,staging= v,blocker='Local supervised 100..300 transfer group exhausted wall120 at120.037s. No API timeout/denial returned; final API/local receipt boundary retained, not replayed. Task stops before exact startup/mount/guest.',incidents=['Transfer command payload retention exceeded ops20MiB bucket historically (~31MiB); completed bodies replaced with byte-exact tested pinned-source reconstruction recipes; no retrospective compliance claim.','Broad read-only rg --files /tmp scan emitted permission-denied diagnostics for unrelated protected paths; no denied-access retries or file reads.','Optional accepted donor fixture README missing in sparse checkout; launch/controller source and accepted ops result/checkpoint read directly.'],sourceEdits=False,mainWrite=False,publicDeployment=False,workersSpawned=False,remainingGates=['Complete617-file exact remote hash/size/mode readback','Fresh exact Node startup with intended flags/environment/inheritedlimits and distinct stdout/stderr','Canonical filename-bearing registered mount parser; full production no-build module-read boundary','Original supervised process startup, serial step ACK and following frozen zero','Same-run inspected actual menu and matching approval before New Game','Mission/gameplay inspected evidence and ordinary Quit/terminal proof'],lifecycle=dict(box='bx_yydnx5av',state='RUNNING_API_EXEC_OBSERVED',owner='coordinator',guestCutoff='2026-10-27T09:15:00Z',handback='2026-10-27T09:20:00Z',shutdown='2026-10-27T09:25:00Z',expiry='2026-10-27T09:43:30Z',workerStopAction=False),noComplianceClaimForHistoricalOpsOverage=True,cleanup='All supervised local operations cleanupComplete=true; owned board watcher to stop at final handoff; staged remote files retained, no guest to clean')
save('result.json',result);save('checkpoint.json',dict(phase='blocked before guest; report publication',result='result.json',reused='reused-acceptance.json',remaining=result['remainingGates'],localSupervision=sup))
# Source recipes preserve exact request reconstruction; archive all current ops payloads, no game media/module/secrets.
d=H/'repo/docs/reviews'/H.name;d.mkdir(parents=True,exist_ok=True)
files=[p for p in sorted(O.rglob('*')) if p.is_file() and p.name not in ['evidence-manifest.json']]
rows=[dict(path=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()) for p in files]
save('evidence-manifest.json',rows)
a=d/'evidence.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(O)),recursive=False)
# Verify every archived byte against retained manifest; no execution or passed-group replay.
with tarfile.open(a,'r:gz') as t:
 seen=[]
 for x in t:
  b=t.extractfile(x).read();seen.append(dict(path=x.name,bytes=len(b),sha256=sha(b)))
assert seen==rows
(d/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
(d/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(d/'REPORT.md').write_text('''# Alien menu-to-mission attempt: staging blocked

No guest was launched and no gameplay input was sent. The assigned Boat bx_yydnx5av remains running for coordinator handback.

The first 100 pinned files transferred successfully. The next supervised transfer operation (file range100..300) exhausted its unchanged120-second wall allowance at120.037 seconds, sampled peak49,299,456 bytes and68.227 CPU seconds. It was not replayed. Final read-only API execution observed267 staged files (31,705,751 logical bytes,32,468,992 allocated bytes), no guest invocation marker/directory, and no startup receipt. API stdout/stderr and each response remain distinct. Incomplete local post-response receipts are listed in staging-checkpoint.json; this is not a617-file closure verification.

The worker mistakenly retained encoded request payload bodies, historically exceeding the20MiB ops bucket at roughly31MiB. This is an accounting failure, not a compliant run.716 completed request bodies were replaced with byte-exact reconstruction recipes from immutable pinned sources. Each recipe was reconstructed and checked against its original command hash before the owned redundant body was removed. Unacknowledged/failed request bodies were preserved. All original failed supervisor receipts remain. Local data returned below its bucket; this does not erase the historical overage.

Accepted original-supervisor source ebf70036c96e0c3267b4943822a446a0b13e8336 and four original-live groups/five child lifetimes/45 controls were reused without replay. The retired attachment reproducer remains incompatible; the supported new original-process launch is accepted, not same-UID security isolation. No semantic source edits, main ownership, public deployment, other box access or worker launch occurred.

The prepared launch configuration was transferred but never executed: original production CLI with setup/title initializers, retained module, software D3D9, frozen control and opt-in render-wait tracing; exec wrapper planned distinct process logs while preserving original PID through exec. Neither its startup nor canonical mount/parser check is qualified by preparing it.

Next gate: coordinator-owned continuation must first inventory/hash staged files and admit only remaining exact chunks, preserving any uncertain write. Then fresh full617-file readback, exact Node startup/inherited limits/environment, canonical filename-bearing mounts and production boundary must pass before one admitted original guest. A fresh same-run menu inspection must authorize New Game. Mission, gameplay, ordinary Quit and terminal evidence remain entirely open.

Evidence archive contains exact local scripts/commands or reconstruction recipes, distinct API stdout/stderr, source/config pins, accepted evidence references, admissions, supervisor failures and cleanup receipts. manifest.json records every archived payload; archive roundtrip was verified once without replaying accepted suites. Runtime deadlines are09:15 cutoff,09:20 handback,09:25 coordinator snapshot-stop,09:43:30 expiry UTC. Remote staged files are retained for recovery; worker never stops the box.
''')
save('package-validation.json',dict(payloads=len(rows),archive=str(a),archiveBytes=a.stat().st_size,archiveSHA256=sha(a.read_bytes()),allPayloadHashesPass=True,sourceSemanticChanges=False))
print(json.dumps(json.loads((O/'package-validation.json').read_text())))
