import importlib.util,pathlib,sys,json,time,hashlib
P=pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo/test/helpers/palette-browser-supervisor.py')
assert hashlib.sha256(P.read_bytes()).hexdigest()=='9d10f7c8c75b5f0dfebff2299eef8ddc27988cf112e0e9c255e89f772c2cee85'
s=importlib.util.spec_from_file_location('trusted',P);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.supervise(sys.argv[1:],rss_limit=128*2**20,cpu_limit=90,wall_limit=120,output_limit=2*2**20)
o=pathlib.Path(__file__).parent/('supervision-'+str(time.time_ns())+'.json');o.write_text(json.dumps(r,default=str));print(json.dumps(r,default=str)[:8192])
if r.get('exit',0) or r.get('stopReason'):sys.exit(1)
