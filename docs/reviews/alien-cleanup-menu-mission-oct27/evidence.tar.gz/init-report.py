from task import *
admission();r=H/'repo';r.mkdir(exist_ok=False)
# Git init and all own refs/index mutations occur only in this new report repo.
save('trusted-ssh-config.json',dict(command=SSH,identity='/home/user/.ssh/wine_github_ed25519',knownHosts='/home/user/.ssh/wine_github_known_hosts',batch=True,identitiesOnly=True,strict=True,donor='/tmp/alien-supported-owner-accepted-main-integration-oct27/repo',revision='ebf70036c96e0c3267b4943822a446a0b13e8336',readOnlyAlternates=True))
print('report repo directory and immutable donor configuration prepared')
