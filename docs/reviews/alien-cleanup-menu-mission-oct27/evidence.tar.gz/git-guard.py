import importlib.util,pathlib,sys,os,json,time,fcntl,resource,subprocess,hashlib,shutil
H=pathlib.Path('/tmp/alien-cleanup-menu-mission-oct27');O=H/'ops';R=H/'repo'
P=pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo/test/helpers/palette-browser-supervisor.py');assert hashlib.sha256(P.read_bytes()).hexdigest()=='9d10f7c8c75b5f0dfebff2299eef8ddc27988cf112e0e9c255e89f772c2cee85'
s=importlib.util.spec_from_file_location('trusted',P);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
os.environ['GIT_SSH_COMMAND']='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes';os.environ['GIT_OPTIONAL_LOCKS']='0'
orig=m.subprocess.Popen
class GitPopen(orig):
 def __init__(self,argv,**kw):
  prior=kw.get('preexec_fn')
  def onlygit():
   if prior:prior()
   if argv[0]=='/usr/bin/git':resource.setrlimit(resource.RLIMIT_DATA,(512*2**20,512*2**20))
  kw['preexec_fn']=onlygit
  super().__init__(argv,**kw)
m.subprocess.Popen=GitPopen
argv=['/usr/bin/git','-c','gc.auto=0','-c','pack.threads=1','-c','pack.window=0','-C',str(R),*sys.argv[1:]]
def check():
 if shutil.disk_usage(H).free-5*96*2**20-16*2**20<2982150144:return 'full conservative fleet disk admission'
 try:used=sum(p.lstat().st_blocks*512 for p in [R,*R.rglob('*')])
 except FileNotFoundError:return None
 if used>20*2**20:return 'sourceGit20MiB bucket'
 return None
assert not check(),check()
with open('/tmp/wine-ops-production-git.lock','a') as f:
 fcntl.flock(f,fcntl.LOCK_EX)
 result=m.supervise(argv,rss_limit=256*2**20,cpu_limit=90,wall_limit=120,output_limit=2*2**20,check=check)
b=result.pop('output');tag='git-'+str(time.time_ns());(O/(tag+'.log')).write_bytes(b);result.update(argv=argv,outputSHA256=hashlib.sha256(b).hexdigest(),gitOnlyDATA=512*2**20,physical=256*2**20);(O/(tag+'.json')).write_text(json.dumps(result));sys.stdout.buffer.write(b[:8192]);print(json.dumps(dict(receipt=tag,result={k:v for k,v in result.items() if k!='owned'})))
raise SystemExit(0 if result['exit']==0 and not result['stopReason'] else 1)
