from task import *
import re
rows=json.loads((ROOT/'scratch/usage-watch/alien-cleanup-verified-runtime-map-oct27.json').read_text())['files'];sources={x['target']:pathlib.Path(x['source']) for x in rows};receipts=[]
commands=sorted(O.glob('api-*.command'))
for p in commands:
 # Preserve last stage request verbatim and every unacknowledged/failed request.
 ack=p.with_suffix('.stdout');meta=p.with_suffix('.json')
 if not ack.exists() or not meta.exists():continue
 a=json.loads(ack.read_text())
 if a.get('exitCode')!=0 or not a.get('success'):continue
 text=p.read_text();matches=list(re.finditer(r"p=h/([^;]+);p.parent.mkdir\(parents=True,exist_ok=True\);b=zlib.decompress\(base64.b64decode\('([A-Za-z0-9+/=]+)'\)\)",shlex.split(text)[2] if text.startswith('python3 -c ') else ''))
 if not matches or p.stat().st_size<10000:continue
 code=shlex.split(text)[2];chunks=[];reconstructed=code;template=code
 for i,m in reversed(list(enumerate(matches))):
  import ast
  target=ast.literal_eval(m.group(1));data=zlib.decompress(base64.b64decode(m.group(2)));src=sources.get(target)
  if src is None:break
  full=src.read_bytes();off=full.find(data);assert off>=0
  regenerated=base64.b64encode(zlib.compress(full[off:off+len(data)])).decode();assert regenerated==m.group(2)
  marker='@@PINNED_CHUNK_'+str(i)+'@@';start,end=m.span(2);template=template[:start]+marker+template[end:]
  chunks.append(dict(marker=marker,target=target,source=str(src),offset=off,bytes=len(data),sha256=sha(data)))
 else:
  restored=template
  for c in chunks:restored=restored.replace(c['marker'],base64.b64encode(zlib.compress(pathlib.Path(c['source']).read_bytes()[c['offset']:c['offset']+c['bytes']])).decode())
  assert restored==code and 'python3 -c '+shlex.quote(restored)==text
  r=dict(originalCommandSHA256=sha(text.encode()),template=template,chunks=chunks,sourceMapSHA256='d8c670ba75041e084e2be480ee17238ce41832fc721bc5ee1d54053c95ac4ca4',reconstructionByteExact=True,acknowledged=True)
  q=p.with_suffix('.recipe.json');q.write_text(json.dumps(r));receipts.append(dict(path=p.name,originalBytes=p.stat().st_size,sha256=sha(p.read_bytes()),replacement=q.name));p.unlink()
save('owned-command-compaction.json',dict(reason='owned transfer commands accidentally retained encoded pinned payloads; replace completed request bodies with byte-exact tested immutable-source recipes, preserve all unacknowledged/failed command bodies',beforeBytes=sum(x['originalBytes'] for x in receipts),converted=receipts,afterAllocated=alloc(H),historicalOpsBucketExceeded=True,noHistoricalComplianceClaim=True))
print(json.dumps(dict(converted=len(receipts),allocated=alloc(H))))
