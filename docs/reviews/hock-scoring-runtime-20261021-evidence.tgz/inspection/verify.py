import pathlib,hashlib,json,subprocess
r=pathlib.Path('/home/user/hock-final-size-canonical-runtime');repo=r/'repo';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD']).decode().strip()=='776d37d55d2f749dcb29203e3bd26b8a5e9c05bd'
manifest={};entries=subprocess.check_output(['git','-C',str(repo),'ls-tree','-rz','HEAD']).split(b'\0')
p=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for entry in entries:
 if not entry:continue
 meta,f=entry.split(b'\t');mode,typ,obj=meta.split();assert typ==b'blob'
 p.stdin.write(obj+b'\n');p.stdin.flush();size=int(p.stdout.readline().split()[2]);b=p.stdout.read(size);p.stdout.read(1)
 path=repo/f.decode();actual=path.read_bytes() if mode!=b'120000' else str(path.readlink()).encode()
 assert b==actual,f
 manifest[f.decode()]=sha(b)
p.stdin.close();p.wait()
assert json.loads((r/'source-seals.json').read_text())==manifest
pkg=json.loads((r/'package-seals.json').read_text());assert len(pkg)==44
for f,h in pkg.items():assert sha((r/'intake'/f).read_bytes())==h,f
assets=list((r/'intake/game').glob('*'));assert len(assets)==39;assert sum(p.stat().st_size for p in assets)==2224918
result=dict(commit='776d37d55d2f749dcb29203e3bd26b8a5e9c05bd',tree=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD^{tree}']).decode().strip(),sourceFiles=len(manifest),sourceManifestSHA256=sha((r/'source-seals.json').read_bytes()),packageEntries=len(pkg),gameFiles=len(assets),gameBytes=sum(p.stat().st_size for p in assets),node=subprocess.check_output(['node','--version']).decode().strip(),modules={p.name:sha(p.read_bytes()) for p in (repo/'build').glob('wine-assembly*.wasm')},status=subprocess.check_output(['git','-C',str(repo),'status','--porcelain']).decode())
print(json.dumps(result))
