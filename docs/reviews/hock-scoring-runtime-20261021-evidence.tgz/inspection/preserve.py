import pathlib,json,base64,hashlib,tarfile,os
from remote import run
REMOTE='/home/user/hock-scoring-runtime'
r=pathlib.Path(__file__).resolve().parent
script="""import pathlib,json,hashlib,tarfile
r=pathlib.Path(REMOTE);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[p for p in r.rglob('*') if p.is_file() and p.name not in ['SHA256SUMS.json','evidence.tgz']]
seals={str(p.relative_to(r)):sha(p) for p in files};(r/'SHA256SUMS.json').write_text(json.dumps(seals,indent=2)+'\\n')
with tarfile.open(r/'evidence.tgz','w:gz') as t:
 for p in files+[r/'SHA256SUMS.json']:t.add(p,arcname=str(p.relative_to(r)))
print(json.dumps(dict(size=(r/'evidence.tgz').stat().st_size,sha256=sha(r/'evidence.tgz'),files=len(files))))
""".replace('REMOTE',repr(REMOTE))
d=run("python3 - <<'PY2'\n"+script+'\nPY2','seal-evidence',60);meta=json.loads(d['stdout'].splitlines()[-1]);parts=[]
assert meta['size']<12*1024*1024
assert os.statvfs(r).f_bavail*os.statvfs(r).f_frsize>2285895680+64*1024*1024
for off in range(0,meta['size'],18000):
 d=run("python3 - <<'PY2'\nimport pathlib,base64\nb=pathlib.Path('"+REMOTE+"/evidence.tgz').read_bytes();print(base64.b64encode(b["+str(off)+":"+str(off+18000)+"]).decode())\nPY2",'download-'+str(off),60)
 assert not d['stdoutTruncated'];parts.append(base64.b64decode(d['stdout']))
b=b''.join(parts);assert len(b)==meta['size'] and hashlib.sha256(b).hexdigest()==meta['sha256'];p=r/'remote-evidence.tgz';p.write_bytes(b)
out=r/'remote-evidence';out.mkdir(exist_ok=True)
with tarfile.open(p) as t:t.extractall(out,filter='data')
seals=json.loads((out/'SHA256SUMS.json').read_text())
for f,h in seals.items():assert hashlib.sha256((out/f).read_bytes()).hexdigest()==h,f
(r/'preservation.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta)
