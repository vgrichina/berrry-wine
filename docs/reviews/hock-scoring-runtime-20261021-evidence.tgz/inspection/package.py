import pathlib,json,hashlib,tarfile,io,shutil
r=pathlib.Path(__file__).resolve().parent
assert shutil.disk_usage(r).free>2285895680+16*1024*1024
files={}
for p in (r/'remote-evidence').rglob('*'):
 if p.is_file():files['runtime/'+str(p.relative_to(r/'remote-evidence'))]=p
for p in r.iterdir():
 if p.is_file() and (p.suffix in ['.py','.json','.txt','.log'] or p.name=='RECOVERY.md') and p.name not in ['result.json','containment-all.json','publication.json']:
  name=p.name if p.name in ['RECOVERY.md','validation.json','preservation.json','containment.json'] else 'inspection/'+p.name
  files[name]=p
seals={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in files.items()}
out=r/'repo/docs/reviews/hock-scoring-runtime-20261021-evidence.tgz'
with tarfile.open(out,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
 b=(json.dumps(seals,indent=2)+'\n').encode();i=tarfile.TarInfo('SHA256SUMS.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
with tarfile.open(out) as t:
 actual=json.load(t.extractfile('SHA256SUMS.json'))
 for n,h in actual.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
meta={'files':len(seals),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'allSealsVerified':True}
(r/'archive-validation.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta)
