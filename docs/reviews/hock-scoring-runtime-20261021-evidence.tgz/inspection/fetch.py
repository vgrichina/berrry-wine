import pathlib,subprocess,json,base64,sys,hashlib,shlex
root=pathlib.Path(__file__).resolve().parent
remote=sys.argv[1];dest=root/sys.argv[2];dest.parent.mkdir(exist_ok=True,parents=True)
parts=[];offset=0
while True:
 s='import pathlib,base64; b=pathlib.Path('+repr(remote)+').read_bytes(); print(base64.b64encode(b['+str(offset)+':'+str(offset+18000)+']).decode())'
 p=subprocess.run(['boat','--json','exec','bx_c6f3np32','--timeout','60','--','python3','-c',s],text=True,capture_output=True);d=json.loads(p.stdout);assert d['exitCode']==0 and not d.get('stdoutTruncated'),d
 b=base64.b64decode(d['stdout']);parts.append(b)
 if len(b)<18000:break
 offset+=len(b)
b=b''.join(parts);dest.write_bytes(b);print(dest,len(b),hashlib.sha256(b).hexdigest())
