# Recover the bounded original Hock scoring evidence

Fetch `task/hock-scoring-runtime-oct21` and extract
`docs/reviews/hock-scoring-runtime-20261021-evidence.tgz` into an empty directory.
Verify each SHA256 in `SHA256SUMS.json`, then `runtime/SHA256SUMS.json` relative
to `runtime/`. No game binaries, module or credentials are committed.

Local raw evidence: `remote-evidence/`, separately sealed in
`remote-evidence.tgz` (4,776,090 bytes; SHA256
`ba9d1dc27096bce1299cae82b36b9191456830c1a5f7d7364f8c306cfe9f7422`).
The committed archive maps this directory to `runtime/`.

Inspect run2/shot-02.png and shot-34.png (score 0/20), after.png and final.png
(score 5/20). `timings.json` gives every actual send time; `command.json`
records exact argv; `run.log` contains all acknowledgments, read-only score
dumps and exit limit. Acknowledgments alone do not establish game acceptance.

Assigned box bx_c6f3np32 remains RUNNING, expiry 2026-10-21T08:14:54.696Z;
coordinator alone owns shutdown. Do not create/resume/fork/stop/delete a box
from this recipe. Remote roots are `/home/user/hock-scoring-runtime` (new
evidence) and `/home/user/hock-final-size-canonical-runtime` (existing repo,
qualified modules, original intake). The latter source is exact 776d37d5;
all 7,146 tracked files and 44 package seals were checked before/after.

For an explicitly authorized replay on that assigned runtime, verify module
and package seals first, then run the preserved `drive2.py` with a NEW run name:

    python3 /home/user/hock-scoring-runtime/drive2.py authorized-replay

The script refuses an existing output directory. It uses real clock and actual
renderer mouse input, never state writes. Its 72-second wall limit is intentional.
Wall timing and target phases can vary: this is the successful observed route,
not a promise every replay scores identically. Do not run it solely for packaging.

If the original intake must later be recovered on an authorized runtime, copy
`runtime/recover-original.py` into an empty intake directory as `recover.py`;
it downloads only the pinned archive and verifies bytes, with no retries on
access failure. Verify all entries of `runtime/package-seals.json` against
that intake. Source/module rebuilding is a separate authorized activity after
loss of the existing qualified module; do not silently substitute a build.
The prior all-gates build/recovery is documented in
`docs/reviews/hock-final-size-canonical-runtime-20261021.md`.

Keep local evidence below 64 MiB allocated and free space above 2,285,895,680
bytes. Temporary shared-host pressure delayed this transfer; no unrelated
cleanup was performed. Publication commit, independent remote verification and
final resource/lifecycle receipt are in local `publication.json`.
