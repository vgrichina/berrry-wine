import hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parent
e=r/'support-gameplay-evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((e/'SHA256SUMS.json').read_text())
for row in rows:
 b=(e/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
p=json.loads((e/'preflight.json').read_text());q=json.loads((e/'postflight.json').read_text())
assert p['verified']==419 and len(p['excluded'])==14 and p['missingDlls']==[]
assert len(p['resolved'])==5 and len(p['cpu'])==2
assert p['module']==q['module']=='728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c'
assert q['moduleBytes']==1878508 and q['status']=='' and q['processes']==[]
for n in ['run1','run2']:
 ex=json.loads((e/n/'exit.json').read_text());assert ex['code']==1 and ex['reason'] is None and ex['signal'] is None
 log=(e/n/'output.log').read_text()
 for marker in ['Authority deadline exceeded','module=0xa26000','EIP=0xa481b9','ETIMEDOUT'] :assert marker in log
 assert not list((e/n).glob('*.png'))
assert (e/'run1/output.log').read_bytes()==(e/'run2/output.log').read_bytes()
a={'verifiedArtifacts':len(rows),'originals':419,'supportDLLs':4,'completeRealDllGraph':True,'reproducedIdenticalFailureLogs':True,'gameplayQualified':False}
(r/'verification.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a))
