const fs=require('fs'),crypto=require('crypto'),assert=require('assert/strict');
const api=require('./file-api');
(async()=>{
const receipt=JSON.parse(fs.readFileSync('/home/user/wine-assembly/scratch/usage-watch/army-support-closure-admission-oct21.json'));
const results=[];
for(const f of receipt.files){const b=fs.readFileSync(f.path);assert.equal(b.length,f.size);assert.equal(b.subarray(0,2).toString(),'MZ');assert.equal(crypto.createHash('sha256').update(b).digest('hex'),f.sha256);const remote='/home/user/army-current-main/repo/test/binaries/dlls/'+f.path.split('/').pop();await api.upload(remote,b);const check=await api.download(remote);assert.equal(crypto.createHash('sha256').update(check).digest('hex'),f.sha256);results.push({...f,remote,verified:true});}
fs.writeFileSync(__dirname+'/support-transfer.json',JSON.stringify(results,null,2));
for(const n of ['preflight.js','controller.js'])await api.upload('/home/user/army-current-main/'+n,fs.readFileSync(__dirname+'/'+n));
console.log(api.exec(['node','/home/user/army-current-main/preflight.js'],'preflight-receipt',60));
})().catch(e=>{console.error(e);process.exitCode=1});
