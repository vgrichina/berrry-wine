const fs=require('fs'),cp=require('child_process');
const root='/home/user/army-current-main/repo',out='/home/user/army-current-main/support-gameplay-evidence/run1',vfs='/home/user/army-current-main/vfs';
fs.mkdirSync(out);fs.copyFileSync('/home/user/army-current-main/support-gameplay-evidence/registry.json',out+'/registry.json');
const args=['--require','./tools/army-bltfast-observer.js','test/run.js',
 '--exe='+vfs+'/program files/the 3do company/army men demo/armymendemo.exe',
 '--exe-guest-path=C:\\Program Files\\The 3DO Company\\Army Men Demo\\ArmyMenDemo.exe',
 '--cwd=C:\\Program Files\\The 3DO Company\\Army Men Demo',
 '--vfs-tree='+vfs,'--reg-import='+out+'/registry.json','--no-build',
 '--wasm='+root+'/build/wine-assembly.wasm','--quiet-api','--no-close','--no-threads',
 '--batch-size=200000','--max-batches=750','--max-seconds=90','--trace-input',
 '--trace-api=__army_bltfast_observer_only__','--png='+out+'/final.png',
 '--input=200:png:'+out+'/menu.png,279:click:320:180,450:png:'+out+'/bootcamp.png,500:keydown:13,501:keyup:13,600:png:'+out+'/dismissed.png,670:png:'+out+'/turn-before.png,674:keydown:102,706:keyup:102,713:png:'+out+'/turn-after.png'];
const env=Object.fromEntries(Object.entries(process.env).filter(([k])=>!(/^(WA_|WINE_|ARMY_)/.test(k)||['NODE_OPTIONS','NODE_PATH'].includes(k))));
env.ARMY_BLTFAST_OUTPUT=out+'/paired.json';
fs.writeFileSync(out+'/launch.json',JSON.stringify({at:new Date().toISOString(),root,args,observerOutput:env.ARMY_BLTFAST_OUTPUT,inputRoute:'Ordinary Boot Camp click279; Enter down500/up501 dismiss; baseline670; Numpad6 down674/up706; after713'},null,2));
const fd=fs.openSync(out+'/output.log','wx'),child=cp.spawn(process.execPath,args,{cwd:root,env,stdio:['ignore','pipe','pipe']});
let bytes=0,reason=null;
const recv=b=>{bytes+=b.length;fs.writeSync(fd,b);};
child.stdout.on('data',recv);child.stderr.on('data',recv);
const timer=setTimeout(()=>{reason='controller 105s deadline';child.kill('SIGTERM');},105000);
child.on('close',(code,signal)=>{clearTimeout(timer);fs.closeSync(fd);fs.writeFileSync(out+'/exit.json',JSON.stringify({at:new Date().toISOString(),code,signal,reason,bytes}));console.log({code,signal,reason,bytes});process.exitCode=code??1;});
