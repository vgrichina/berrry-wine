Recover from docs/reviews/army-support-closure-gameplay-20261021.evidence.tgz
on the task branch; extract into a fresh directory and run python3 verify.py.
The nested remote-evidence.tgz is the untouched remote evidence archive.
For same-box recovery before expiry, file-api.js downloads
/home/user/army-current-main/support-gameplay-evidence.tgz from bx_e8a7pw8v.
Do not invoke stage.js or either controller merely to recover evidence.
Do not rebuild. Original build provenance is the prior repaired canonical run.
Four required support hashes/source paths/remote destinations are in
support-transfer.json. No ignored PE binaries are in this archive.
Coordinator owns lifecycle; leave box running and do not resume stopped boxes.
