const fs=require('fs'),api=require('./file-api');
(async()=>{await api.upload('/home/user/army-current-main/postflight.js',fs.readFileSync(__dirname+'/postflight.js'));
console.log(api.exec(['node','/home/user/army-current-main/postflight.js'],'postflight-receipt',60));
console.log(api.exec(['tar','-czf','/home/user/army-current-main/support-gameplay-evidence.tgz','-C','/home/user/army-current-main','support-gameplay-evidence'],'archive-receipt',30));
fs.writeFileSync(__dirname+'/remote-evidence.tgz',await api.download('/home/user/army-current-main/support-gameplay-evidence.tgz'));
})();
