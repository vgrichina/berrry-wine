import os, pathlib, subprocess, json, time
run=pathlib.Path(__file__).resolve().parent
repo=run/'repo'
results=json.loads((run/'tests.json').read_text())
def guard():
 used=int(subprocess.check_output(['du','-sk',str(run)]).split()[0])*1024
 free=os.statvfs(run).f_bavail*os.statvfs(run).f_frsize
 assert used+262144<67108864 and free>2285895680,(used,free)
def check(name,cmd,expected=0,needle=None,env=None):
 guard(); start=time.time()
 p=subprocess.run(cmd,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120,env={**os.environ,**(env or {})})
 log=run/(name+'.log');guard();log.write_bytes(p.stdout)
 ok=p.returncode==expected and (needle is None or needle in p.stdout.decode(errors='replace'))
 results.append(dict(name=name,command=cmd,env=env or {},exit=p.returncode,expectedExit=expected,accepted=ok,seconds=round(time.time()-start,3),log=log.name))
 (run/'tests.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,p.returncode,'PASS' if ok else 'FAIL',flush=True)
 return ok

check('startup-submitted',['node','docs/reviews/shell-startup-complete-path-fix-20261020.js'])
check('startup-independent',['node','../independent.js','../independent.json'],env={'REVIEW_REV':'5b078c91d5cf6da5e337cda5e7665803c03c99e5'})
check('startup-transport-adapted',['node','../validation.js'])
# Confirm independent A/W failure at the unchanged exact base, then restore.
f=repo/'src/00-regions.wat'; fixed=f.read_bytes()
try:
 guard();f.write_bytes(subprocess.check_output(['git','show','5b078c91d5cf6da5e337cda5e7665803c03c99e5:src/00-regions.wat'],cwd=repo))
 check('aw-exact-base',['node','tools/aw-census.js','--check'],1,'NEW DIVERGENT RegisterClassExA/W')
finally:
 guard();f.write_bytes(fixed)
check('owners-restored',['node','tools/check-region-decls.js','--check-owners'])
check('census-restored',['node','tools/callback-ownership-census.js'])
check('diff-restored',['git','diff','--check'])
