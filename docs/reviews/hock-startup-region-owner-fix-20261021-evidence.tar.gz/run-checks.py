import os, pathlib, subprocess, json, time
run=pathlib.Path(__file__).resolve().parent
repo=run/'repo'
results=[]
def guard():
 used=int(subprocess.check_output(['du','-sk',str(run)]).split()[0])*1024
 free=os.statvfs(run).f_bavail*os.statvfs(run).f_frsize
 assert used+262144<67108864 and free>2285895680,(used,free)
def check(name,cmd,expected=0,needle=None,env=None):
 guard(); start=time.time()
 p=subprocess.run(cmd,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120,env={**os.environ,**(env or {})})
 log=run/(name+'.log');guard();log.write_bytes(p.stdout)
 ok=p.returncode==expected and (needle is None or needle in p.stdout.decode(errors='replace'))
 results.append(dict(name=name,command=cmd,env=env or {},exit=p.returncode,expectedExit=expected,accepted=ok,seconds=round(time.time()-start,3),log=log.name))
 (run/'tests.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,p.returncode,'PASS' if ok else 'FAIL',flush=True)
 return ok
f=repo/'src/00-regions.wat'; fixed=f.read_text()
try:
 for name,owner,needle in [('owner-original-control','$STARTUP_SHOW_STATE','does not define top-level $STARTUP_SHOW_STATE'),('owner-indirect-control','$startup_info_init','no longer references $STARTUP_SHOW_STATE')]:
  guard();f.write_text(fixed.replace('09a-handlers3-sync.wat:$startup_show_set','09a-handlers3-sync.wat:'+owner))
  assert check(name,['node','tools/check-region-decls.js','--check-owners'],1,needle)
finally:
 guard();f.write_text(fixed)
commands=[
'node tools/check-claude-size.js','node tools/check-wat-manifest.js','node tools/check-wat-fragments.js',
'node tools/callback-ownership-census.js','node test/test-callback-ownership-census.js',
'node test/test-wat-memory-map.js','node tools/check-region-decls.js --strict','node tools/check-region-decls.js --check-owners',
'node test/test-region-owner-ratchet.js','node tools/aw-census.js --check','node tools/wat-dup-census.js --check',
'node tools/region-census.js --gate','node tools/gen-region-map.js --check','node tools/region-census.js --js-copies',
'node tools/region-census.js --embedded-wat','node tools/region-census.js --dup-payloads','node tools/region-census.js --hand-rolled',
'node tools/region-alloc.js --shake-all','node test/test-wat-rpc-region.js','node tools/check-wat-js-constants.js',
'bash tools/check-test-manifest.sh','node tools/check-api-table.js','node tools/gen_api_table.js --check',
'node tools/gen_dispatch.js --check','node tools/gen-kernel32-image.js --check','node tools/check-hash-table.js',
'node tools/check-data-strings.js','node tools/check-handler-count.js','node tools/check-handler-esp.js',
'node tools/check-wat-logical-and.js','node tools/check-silent-stubs.js','node tools/check-gl-barriers.js',
'node tools/gen-host-import-sigs.js --check','node tools/check-browser-cache-versions.js --self-test',
'node tools/toyvm/bundle-browser.js --check','node tools/esp-epilogue.js --check','node tools/check-watx-provenance.js',
'node tools/gen-layout-offsets.js --check']
for i,c in enumerate(commands):check('%02d-'%i+c.split()[1].split('/')[-1],c.split())
check('startup-latch',['node','docs/reviews/startup-latch-valid-show-fix-20261020.js',str(run/'startup-latch.json')])
check('startup-transport-layout',['node','docs/reviews/shell-startup-finish-validation-20261020.js'])
check('diff-check',['git','diff','--check'])
guard()
