'use strict';
// Independent acceptance oracles. Reuse exact submitted assembler/driver only.
const fs=require('fs'),cp=require('child_process'),vm=require('vm'),assert=require('assert/strict'),crypto=require('crypto');
const REV=process.env.REVIEW_REV||'aa8f7e23362eca7db7a71beb3deab3f20bbb916e';
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
function gate(){const s=fs.statfsSync('.');assert(s.bavail*s.bsize>=2285895680,'RESOURCE BLOCKER '+s.bavail*s.bsize);}
function git(p,rev=REV){return cp.execFileSync('git',['show',rev+':'+p],{encoding:'utf8',maxBuffer:16*1024*1024,stdio:['ignore','pipe','pipe']});}
const p='docs/reviews/startup-latch-valid-show-fix-20261020.js', original=git(p,'aa8f7e23362eca7db7a71beb3deab3f20bbb916e');
let machinery=original.slice(0,original.indexOf('\nfunction main()'));
// No submitted main/test assertions run here. The reader always uses Git blobs.
process.env.REVIEW_REV=REV;
const mutations={
 ownership:['src/09b-dispatch.wat','(call $startup_create_show\n              (call $gl32 (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 8))))','(call $startup_create_show (global.get $createwnd_saved_hwnd))'],
};
const key=process.env.FINAL_MUTATION||'';
if(key){assert(mutations[key]);machinery=machinery.replace('const m = changes[mutation];','const m = injectedMutation;');}
const context={require,console,process,WebAssembly,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,DataView,Buffer,setTimeout,clearTimeout,setImmediate,injectedMutation:mutations[key]};
vm.runInNewContext(machinery+'\nglobalThis.driver={harness,setup,result};',context,{filename:p,timeout:30000});
const d=context.driver,r={revision:REV,machinery:{path:p,sha256:sha(original)},mutation:key||process.env.REVIEW_MUTATION||'',acceptance:[],failures:[]};
gate();const h=d.harness();
function test(name,fn){if(process.env.FINAL_PROBE&&!name.includes(process.env.FINAL_PROBE))return;
 for(let i=0;i<30;i++){try{const f=h.make(),s=d.setup(f);const detail=fn(f,s);r.acceptance.push({name,detail});return;}catch(e){const m=e.message.match(/^UNIMPLEMENTED FIXTURE DEPENDENCY (\w+)/);if(m&&h.funcs.has(m[1])&&!h.selected.has(m[1])){h.selected.add(m[1]);continue;}r.failures.push({name,error:e.stack});return;}}
 throw Error('dependency expansion limit');}
const H=0x10001,R=0xABCDEF;
function cleanup(f){for(const n of ['wnd_send_message','timer_kill_hwnd','post_queue_purge_hwnd','host_destroy_window'])f.boundary[n]=(...args)=>{f.trace.push({name:n,args});return 0;};}
function state(f,s,h=H){return {latch:s.latch(),visible:f.renderer.windows[h].visible,style:s.e.wnd_get_style(h)>>>0,min:s.e.wnd_min_get(h),max:s.e.wnd_max_get(h)};}
for(const hwnd of [0,0xDEAD,-1])test('invalid handle '+hwnd,(f,s)=>{
 s.e.set_startup_show(0);s.show(1,hwnd);assert.equal(s.latch(),1);assert.equal(s.retval(),0);assert.equal(s.e.get_last_error(),1400);assert.equal(s.d.getUint32(s.reg+16,true),s.stack+12);
 s.create(0x10C00000);s.finish();assert.equal(f.renderer.windows[H].visible,false);return {error:1400,retryHidden:true};});
for(const cmd of [0,1,2,3,4,5,6,7,8,9,11])test('successful boundary command '+cmd,(f,s)=>{
 s.e.set_startup_show(cmd);s.create(0x10C00000);
 const before=[];for(const msg of [0x81,1]){const c=s.callback();assert.equal(c.msg,msg);before.push(state(f,s));assert.equal(s.latch(),1,'latch remains armed through both callbacks');assert.equal(f.renderer.windows[H].visible,false,'no premature renderer visibility');assert.equal(s.e.wnd_min_get(H),0);assert.equal(s.e.wnd_max_get(H),0);s.resume(c,msg===0x81?1:0);}
 assert.equal(s.latch(),0,'commit after successful WM_CREATE');s.finish();assert.equal(s.retval(),H);assert.equal(s.d.getUint32(s.reg+16,true),s.stack+52);
 assert.equal(!!(s.e.wnd_get_style(H)&0x10000000),cmd!==0);assert.equal(s.e.wnd_min_get(H),[2,6,7,11].includes(cmd)?1:0);assert.equal(s.e.wnd_max_get(H),cmd===3?1:0);assert.equal(f.renderer.windows[H].visible,![0,2,6,7,11].includes(cmd));return {before,after:state(f,s)};});
for(const stage of [0x81,1])for(const nested of [false,true])test('failure '+stage+' nested '+nested,(f,s)=>{
 cleanup(f);s.create();s.finish();s.e.set_startup_show(0);s.create(0x10C00000);if(stage===1)s.resume(s.callback(),1);const outer=s.callback();assert.equal(outer.msg,stage);assert.equal(s.latch(),1);
 if(nested){s.show(1,H,outer.esp-512,0xABC123);assert.equal(s.latch(),0);assert.equal(f.renderer.windows[H].visible,false);}
 s.resume(outer,stage===1?-1:0);assert.equal(s.e.get_eip(),R);assert.equal(s.retval(),0);assert.equal(s.e.wnd_table_find(H+1),-1);assert.equal(s.latch(),nested?0:1);
 s.create(0x10C00000);s.finish();assert.equal(f.renderer.windows[H+2].visible,nested);return {outerRemoved:true,nestedConsumptionPreserved:nested,retryVisible:nested};});
for(const stage of [0x81,1])test('saved HWND ownership '+stage,(f,s)=>{
 s.e.set_startup_show(0);s.e.set_show_window_activated(1);s.create(0x10C00000);if(stage===1)s.resume(s.callback(),1);const outer=s.callback();
 s.create(0x80C00000,H,outer.esp-512,0xABC123);s.finish(0xABC123);assert.equal(s.retval(),H+1);assert.equal(s.e.get_createwnd_saved_hwnd(),H+1);assert.equal(s.latch(),1);
 s.resume(outer,stage===0x81?1:0);s.finish();assert.equal(s.retval(),H);assert.equal(s.latch(),0,'outer saved HWND must consume');assert.equal(f.renderer.windows[H].visible,false);assert.equal(f.renderer.windows[H+1].visible,false);return {globalSaved:H+1,returned:H,outerHidden:true};});
for(const [label,style,owner] of [['child',0x50C00000,H],['owned',0x90C00000,H],['bare-popup',0x90000000,0]])test('excluded implicit and explicit '+label,(f,s)=>{
 s.create();s.finish();s.e.set_show_window_activated(1);s.e.set_active_hwnd(H);s.e.set_focus_hwnd(H);s.e.set_startup_show(0);s.create(style,owner);s.finish();assert.equal(s.latch(),1);s.e.set_active_hwnd(H+1);s.e.set_focus_hwnd(H+1);s.show(1,H+1);assert.equal(s.latch(),1);s.create(0x10C00000);s.finish();assert.equal(s.latch(),0);assert.equal(f.renderer.windows[H+2].visible,false);return {excludedVisible:f.renderer.windows[H+1].visible,eligibleHidden:true};});
test('explicit first show and retained default',(f,s)=>{s.create();s.finish();s.e.set_startup_show(2);s.show(1);assert.equal(s.retval(),0);assert.equal(s.latch(),0);assert.equal(s.e.wnd_min_get(H),1);s.show(1);assert.equal(s.retval(),1);assert.equal(s.e.wnd_min_get(H),0);s.show(10);assert.equal(s.e.wnd_min_get(H),1);return {firstPriorVisible:0,secondPriorVisible:1,defaultMinimized:true};});
r.inputs=d.result.inputs;r.effectiveInputs=d.result.effectiveInputs;r.controls=d.result.controls;r.assembler=d.result.assembler;r.modules=h.result.modules;r.status=r.failures.length?'REJECT':'ACCEPT_SOURCE_SLICES';
if(process.argv[2]){gate();fs.writeFileSync(process.argv[2],JSON.stringify(r,null,2)+'\n');}console.log(JSON.stringify({status:r.status,passed:r.acceptance.length,failures:r.failures}));if(r.failures.length)process.exitCode=1;
