from common import *
import zlib
D=pathlib.Path('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/repo'); A=pathlib.Path('/tmp/enigma-canonical-msg-independent-source-accept-oct26/repo/docs/reviews/enigma-canonical-msg-independent-source-accept-oct26')
save('db-baseline.json',{str(p):alloc(p) for p in pathlib.Path('/home/user/.codex').glob('*sqlite-wal')})
save('configuration.json',dict(ssh=SSH,mountArgv=[],mountParser='N/A: no mount or runtime authorized',rootRef=json.load(open(ROOT/'scratch/usage-watch'/H.name/'root-ref-digest.json')),inheritedReadIncident='Initial combined readonly excerpts exceeded8192; no execution capture gate changed'))
pins=json.load(open(ROOT/'scratch/usage-watch'/ (H.name+'-dispatch.json')))['pins']
for p in pins:assert sha(pathlib.Path(p['path']).read_bytes())==p['sha256'],p
save('pins.json',pins);gate('initial')
watch=subprocess.Popen(['tail','-f',str(ROOT/'messageboard.txt')],stdout=open(O/'board-watch.log','ab'),stderr=subprocess.DEVNULL,start_new_session=True);save('watcher.json',dict(pid=watch.pid))
R.mkdir();g('init','-q',str(R),cwd=H)
g('remote','add','origin','git@github.com:vgrichina/wine-assembly.git')
main=g('ls-remote','origin','refs/heads/main').decode().split()[0]
assert main=='ddaff339bd7e1b10b2579a7ab7aed71d86d8edcd',main
meta=pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo/.git/objects');seen=set();entries={}
def obj(oid):
 p=meta/oid[:2]/oid[2:];b=p.read_bytes();raw=zlib.decompress(b);assert hashlib.sha1(raw).hexdigest()==oid
 kind,body=raw.split(b'\0',1);typ,size=kind.split();assert int(size)==len(body)
 out=R/'.git/objects'/oid[:2]/oid[2:];out.parent.mkdir(exist_ok=True);out.write_bytes(b)
 return typ,body
def recover(oid,prefix=''):
 typ,b=obj(oid);seen.add(oid)
 if typ==b'commit':recover(b.splitlines()[0].split()[1].decode())
 else:
  assert typ==b'tree';i=0
  while i<len(b):
   end=b.index(b'\0',i);mode,name=b[i:end].split(b' ',1);child=b[end+1:end+21].hex();i=end+21;p=prefix+name.decode()
   if mode==b'40000':recover(child,p+'/')
   else:entries[p]=dict(mode=mode.decode(),oid=child)
recover(main);save('main-entries.json',entries);save('base.json',dict(main=main,treeMetadataObjects=len(seen)))
(R/'.git/shallow').write_text(main+'\n')
for k,v in [('core.sparseCheckout','true'),('core.sparseCheckoutCone','false'),('core.sshCommand',SSH),('user.name','Wine Ops'),('user.email','wine-ops@local')]:g('config',k,v)
(R/'.git/info/sparse-checkout').write_text('/src/\n/lib/host-imports.js\n/lib/host-import-sigs.generated.json\n/lib/wat-manifest.js\n/tools/gen-host-import-sigs.js\n/test/run.js\n/test/*message*\n/docs/reviews/'+H.name+'/\n')
g('update-ref','refs/heads/'+BR,main);g('symbolic-ref','HEAD','refs/heads/'+BR);g('read-tree','--reset','-i','HEAD')
# Materialize only final source include closure and affected offline tooling. No asset checkout.
paths=[p for p in entries if p.startswith('src/') and p.endswith(('.wat','.watx'))]
paths += [p['path'] for p in json.load(open(A/'source-review-result.json'))['reconstructedFiles'] if p['path'] in entries]
paths += ['lib/wat-manifest.js','tools/gen-host-import-sigs.js']
sources=[ROOT,pathlib.Path('/tmp/alien-render-wait-accepted-main-integration-oct26/repo'),pathlib.Path('/tmp/alien-accepted-opt-in-menu-gameplay-oct26/source'),pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo'),pathlib.Path('/tmp/civ2-win16-ordinary-gameplay-oct26/source'),D]
recovered=[]
for p in dict.fromkeys(paths):
 oid=entries[p]['oid'];b=None;origin=None
 for s in sources:
  q=s/p
  if q.is_file():
   data=q.read_bytes();raw=b'blob '+str(len(data)).encode()+b'\0'+data
   if hashlib.sha1(raw).hexdigest()==oid:b=data;origin=str(q);break
 if b is None:
  # Read a known present loose blob only, never ask Git to retry an absent blob.
  for s in sources:
   q=s/'.git/objects'/oid[:2]/oid[2:]
   if q.is_file():
    raw=zlib.decompress(q.read_bytes());assert hashlib.sha1(raw).hexdigest()==oid
    hdr,b=raw.split(b'\0',1);assert hdr==b'blob '+str(len(b)).encode();origin=str(q);break
 assert b is not None,('missing-local-verified-input',p,oid)
 dest=R/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 raw=b'blob '+str(len(b)).encode()+b'\0'+b;out=R/'.git/objects'/oid[:2]/oid[2:];out.parent.mkdir(exist_ok=True);out.write_bytes(zlib.compress(raw))
 recovered.append(dict(path=p,sha256=sha(b),oid=oid,origin=origin,bytes=len(b)))
save('recovered-current-files.json',recovered)
startup='const fs=require("fs");console.log(JSON.stringify({execPath:process.execPath,execArgv:process.execArgv,limits:fs.readFileSync("/proc/self/limits","utf8"),env:{TMPDIR:process.env.TMPDIR,NODE_OPTIONS:process.env.NODE_OPTIONS||null}}))'
b=pool([NODE,'--max-old-space-size=64','-e',startup],label='node-startup');print(b[:4000].decode())
save('startup-configuration.json',dict(executable=NODE,sha256=sha(pathlib.Path(NODE).read_bytes()),flags=['--max-old-space-size=64'],environment=dict(TMPDIR=str(O),NODE_OPTIONS=os.environ.get('NODE_OPTIONS')),cpu=90,wall=120,file=25165824,physical=134217728,output=2097152,excerpt=8192,gitDATAOnlyGit=True))
print('PASS current remote metadata/local selective source recovery; Node startup')
