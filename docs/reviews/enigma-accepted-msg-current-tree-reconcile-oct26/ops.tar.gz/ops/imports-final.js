'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto');
const root=path.resolve(process.argv[3]),out=process.argv[2];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const tool=fs.readFileSync(path.join(root,'tools/gen-host-import-sigs.js'),'utf8');
const start=tool.indexOf('function parse(text) {'),end=tool.indexOf('\nfunction main()',start);
assert(start>=0&&end>start);const parserText=tool.slice(start,end),parse=new Function(parserText+'\nreturn parse;')();
const {WAT_FILES}=require(path.join(root,'lib/wat-manifest.js'));
const inputs=JSON.parse(fs.readFileSync(out+'/signature-inputs.json'));
assert.equal(inputs.mainSHA256,sha(fs.readFileSync(path.join(root,'src/main.watx'))));
assert.deepEqual(inputs.closure.map(x=>x.path),WAT_FILES.map(x=>'src/'+x));
const sigs={},closure=[];let declared=0;
for(const [index,file] of WAT_FILES.entries()){
 const entry=inputs.closure[index];assert.equal(entry.path,'src/'+file);
 const b=fs.readFileSync(path.join(root,'src',file));assert.equal(sha(b),entry.sha256);
 const text=entry.declarations.join('\n');
 const parsed=parse(text),count=(text.match(/\(import\s+"host"\s+"[A-Za-z_0-9]+"\s+\(func/g)||[]).length;
 assert.equal(Object.keys(parsed).length,count,file);declared+=count;
 for(const [name,sig] of Object.entries(parsed)){assert(!(name in sigs),name);sigs[name]=sig;}
 closure.push({path:'src/'+file,sha256:sha(b),bytes:b.length,imports:count});
}
assert.equal(Object.keys(sigs).length,declared);
const baseline=JSON.parse(fs.readFileSync('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/ops/baseline-import-sigs.json'));
for(const [name,sig] of Object.entries(baseline.sigs))assert.deepEqual(sigs[name],sig,name);
assert.equal(declared,baseline.count+5);
for(const [name,n,m] of [['message_begin',8,1],['message_park',1,0],['message_bind',3,0],['message_resume',2,1],['message_complete',2,0]])assert.deepEqual(sigs[name],{params:Array(n).fill('i32'),results:Array(m).fill('i32')});
const output=JSON.stringify({generated_from:'src/main.watx include closure',count:declared,sigs},null,2)+'\n';
fs.writeFileSync(path.join(root,'lib/host-import-sigs.generated.json'),output);
const accepted=fs.readFileSync('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/repo/lib/host-import-sigs.generated.json');assert.equal(sha(output),sha(accepted));
fs.writeFileSync(path.join(out,'imports-final-result.json'),JSON.stringify({pass:true,method:'Exact unchanged generator parser per self-contained source fragment; duplicate/declaration gates retained; no compilation',generatorSHA256:sha(tool),parserSHA256:sha(parserText),parserBytes:Buffer.byteLength(parserText),mainSHA256:sha(fs.readFileSync(path.join(root,'src/main.watx'))),closure,declared,signatureSHA256:sha(output),normalWholeClosureCheck:'Stopped at physical cap; deferred to separately admitted build',compiled:false},null,2)+'\n');
console.log('PASS final main.watx closure signature generation: '+declared+' imports; all prior imports unchanged, five exact completion imports; same accepted output');
