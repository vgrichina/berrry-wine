from common import *
import gzip,re
D=pathlib.Path('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/repo');P=pathlib.Path('/tmp/enigma-msg-boundary-measured-client-implementation-oct26/repo');A=pathlib.Path('/tmp/enigma-canonical-msg-independent-source-accept-oct26/repo/docs/reviews/enigma-canonical-msg-independent-source-accept-oct26');review=json.load(open(A/'source-review-result.json'))
def parsepatch(data):
 lines=data.decode().splitlines(True);i=0;files=[]
 while i<len(lines):
  assert lines[i].startswith('--- ');old=lines[i][4:].strip();path=lines[i+1][4:].strip().removeprefix('b/');i+=2;hunks=[]
  while i<len(lines) and lines[i].startswith('@@ '):
   header=lines[i];i+=1;before=[];after=[]
   while i<len(lines) and not lines[i].startswith(('@@ ','--- ')):
    l=lines[i];assert l[0] in ' +-'
    if l[0] in ' -':before.append(l[1:])
    if l[0] in ' +':after.append(l[1:])
    i+=1
   hunks.append((header,''.join(before),''.join(after)))
  files.append((path,old,hunks))
 return files
partial=gzip.decompress((A/'partial-runner-prerequisite.patch.gz').read_bytes());completion=gzip.decompress((D/'docs/re-notes/enigma-canonical-msg-completion-hook-repair-oct26/completion.patch.gz').read_bytes())
assert sha(partial)==review['partialRunnerPrerequisitePatchSHA'];assert sha(completion)==review['patchSHA256']
for x in review['reconstructedFiles']:
 assert sha((D/x['path']).read_bytes())==x['candidateSHA256']
 if x['baseline']=='partialJS40699f72':assert sha((P/x['path']).read_bytes())==x['baselineSHA256']
 elif x['baseline']=='source239754c97d3':assert sha((SRC/x['path']).read_bytes())==x['baselineSHA256']
 elif x['baseline']=='retained-signature-baseline':assert sha(pathlib.Path('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/ops/baseline-import-sigs.json').read_bytes())==x['baselineSHA256']
assert sha((SRC/'test/run.js').read_bytes())==review['partialRunnerBaselineSHA']
records=[];conflicts=[]
def apply(data,group):
 for p,old,hunks in parsepatch(data):
  if p=='lib/host-import-sigs.generated.json':continue
  dest=R/p;current=dest.read_text() if dest.exists() else '';original=current
  for index,(header,before,after) in enumerate(hunks):
   if old=='/dev/null':assert current=='';current=after
   elif current.count(before)==1:current=current.replace(before,after,1)
   else:
    conflicts.append(dict(group=group,path=p,hunk=index,header=header,before=before,after=after,matches=current.count(before)));continue
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(current)
  records.append(dict(group=group,path=p,beforeSHA256=sha(original.encode()),afterSHA256=sha(current.encode())))
apply(partial,'partial-runner')
entries=json.load(open(O/'main-entries.json'))
for p in ['test/message-boundary-trace.js','test/test-message-boundary-trace.js']:
 assert p not in entries,p
 b=(P/p).read_bytes();dest=R/p;dest.write_bytes(b);records.append(dict(group='partial-helpers',path=p,afterSHA256=sha(b)))
apply(completion,'completion')
save('reconciliation.json',dict(records=records,conflicts=conflicts,partialSHA256=sha(partial),completionSHA256=sha(completion)))
print(json.dumps(dict(applied=len(records),conflicts=[dict(group=x['group'],path=x['path'],hunk=x['hunk']) for x in conflicts])))
