import pathlib,re,json,hashlib
H=pathlib.Path(__file__).resolve().parent.parent;R=H/'repo';O=H/'ops';main=(R/'src/main.watx').read_bytes();files=re.findall(r'^\(include "([^"]+)"\)$','\n'.join(line.strip() for line in main.decode().splitlines()),re.M);closure=[]
for file in files:
 b=(R/'src'/file).read_bytes();text=re.sub(r';;[^\n]*',' ',b.decode());decl=[]
 heads=list(re.finditer(r'\(import\s+"host"\s+"[A-Za-z_0-9]+"\s+\(func',text))
 for m in heads:
  i=m.start();depth=0
  while i<len(text):
   if text[i]=='(':depth+=1
   elif text[i]==')':depth-=1
   i+=1
   if depth==0:break
  assert depth==0,(file,m.start());decl.append(text[m.start():i])
 closure.append(dict(path='src/'+file,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),declarations=decl))
(O/'signature-inputs.json').write_text(json.dumps(dict(mainSHA256=hashlib.sha256(main).hexdigest(),closure=closure),indent=2)+'\n')
print('PASS extracted final closure import forms with balanced boundaries, all file hashes retained; no WAT compilation')
