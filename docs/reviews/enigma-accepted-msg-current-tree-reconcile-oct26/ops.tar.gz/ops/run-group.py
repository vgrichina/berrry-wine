from common import *
group=sys.argv[1]
commands={
 'preserve-current':['python3',str(O/'preserve-current.py')],
 'extract-imports':['python3',str(O/'extract-imports.py')],
 'imports-final':[NODE,'--max-old-space-size=64',str(O/'imports-final.js'),str(O),str(R)],
 'production-boundary':[NODE,'--max-old-space-size=64',str(O/'production-boundary.js'),str(O),str(R)],
 'generate-signatures':[NODE,'--max-old-space-size=64','tools/gen-host-import-sigs.js'],
 'check-signatures':[NODE,'--max-old-space-size=64','tools/gen-host-import-sigs.js','--check'],
 'runner-syntax':[NODE,'--max-old-space-size=64','--check','test/run.js'],
 'source-equivalence':[NODE,'--max-old-space-size=64',str(O/'source-equivalence.js'),str(O),str(R)],
}
print(pool(commands[group],label=group)[:8192].decode())
done=json.load(open(O/'checkpoint.json'))['completed'] if (O/'checkpoint.json').exists() else []
if group not in done:done.append(group)
paths={p['path'] for p in json.load(open(O/'reconciliation.json'))['records']}|{'lib/host-import-sigs.generated.json','src/main.watx'}
save('checkpoint.json',dict(base=json.load(open(O/'base.json'))['main'],acceptedCandidate=REV,completed=done,files={p:sha((R/p).read_bytes()) for p in sorted(paths)},remaining=['changed-context preservation check','review minimal diff and publish task branch','independent reconciled-source acceptance','separately admitted build/module/runtime qualification'],compiled=False,canonicalRuntimeQualified=False))
