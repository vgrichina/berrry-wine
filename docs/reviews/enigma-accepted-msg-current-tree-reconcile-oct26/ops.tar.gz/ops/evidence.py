from common import *
import tarfile
A=pathlib.Path('/tmp/enigma-canonical-msg-independent-source-accept-oct26/repo/docs/reviews/enigma-canonical-msg-independent-source-accept-oct26');D=pathlib.Path('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/repo/docs/re-notes/enigma-canonical-msg-completion-hook-repair-oct26')
N=R/'docs/reviews'/H.name;N.mkdir(parents=True,exist_ok=True)
gate('evidence')
reuse={}
for directory in [A,D]:
 for p in directory.rglob('*'):
  if p.is_file() and p.name!='ops.tar.gz':reuse[str(p)]=dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size)
save('reused-evidence.json',dict(acceptedCandidate=REV,acceptance='ffeadab427cfff4fdeae4ca7375678c6a89d699e',receipts=reuse,proof='source-equivalence-result.json binds all relevant unchanged helper/WAT/test/dispatcher inputs. Runner excerpts exact; changed whole runner retested by production-boundary and reverse-to-main preservation.',groups='Donor six behavior groups incl96 baseline state comparisons; independent33 continuation cases,396 ownership completions, route checks; original uncompiled/resource qualifications retained',rerun=False,compiled=False,canonicalRuntimeQualified=False))
save('incidents.json',dict(current=[
 'Initial readonly combined tool excerpts exceeded8192; no test capture gate raised.',
 'Selective recovery initial donor list omitted actual opt-in runner and retained signature baseline. Verified actual Alien opt-in integration and immutable local signature baseline by main blob OID; no missing blob request/retry.',
 'Whole-closure production generator stopped by physical cap at141721600B; unchanged reproducer retained, not retried. Per-fragment full-string attempt also stopped at its recorded peak; retained first-imports-final receipt.',
 'Declaration extraction initially missed four indented GL include lines; canonical manifest comparison rejected before generation. Trimming lines fixed extraction, not manifest or acceptance. Failed oracle receipt retained.',
 'Function comparison initially recognized only space after function name; newline keyboard_hook_begin rejected. Accepting actual WAT whitespace fixed owned fixture; complete fragment hashes already exact. First receipt retained.'
 ],historical='All donor/acceptance real denials, timeout100000-batch request, memory/disk/sparse-index incidents and erroneous individual128MiB client rule remain in immutable referenced evidence; not reclassified or retried.',sourceRejection=False,limitsRaised=False))
clients=json.load(open(O/'admission-evidence.json'))['clients'];thread=os.environ.get('CODEX_THREAD_ID')
save('launch-configuration.json',dict(thread=thread,clients=clients,model='Actual argv retained; this single task launches no clients/workers',mount='N/A offline/no mount argv',ssh=SSH))
peaks={p.name:json.load(open(p)) for p in O.glob('*-execution.json')}
save('resources.json',dict(measurement='sampled RSS, includes pool/supervisors/descendants, not continuous maximum; Node oldspace64MiB separate',executions=peaks,limits=dict(testPhysical=134217728,gitPhysical=268435456,gitChildDATA=536870912,cpu=90,wall=120,file=25165824,output=2097152,excerpt=8192),memoryPolicy='Resident RSS already deducted from fresh MemAvailable.64MiB future each resident once; prospective320MiB only remaining unlaunched clients (zero). Host768MiB plus shared256MiB execution pool. No individual client RSS cap/heavy3.25GiB floor.'))
readme='''# Enigma accepted completion reconciliation

Reconciled accepted candidate e8bceb042bc3eff6bab73642988be29a7522287e
and source acceptance ffeadab427cfff4fdeae4ca7375678c6a89d699e onto current
remote main ddaff339bd7e1b10b2579a7ab7aed71d86d8edcd. Task branch only;
main publication forbidden and untouched. No substantive conflict.

The separate partialJS40699f72 runner prerequisite and its actual boundary
helper/tests were verified and applied before the minimal completion patch.
All hunks matched uniquely. Reversing only those deltas reproduces the complete
current-main runner blob exactly, preserving Alien diagnostic/default-off wiring.
All other current tree entries, including Ricochet/GL, are preserved by exact
parent/tree comparison. No historical whole source replacement or broad checkout.

All 13 non-runner candidate files match the accepted source exactly. This includes
WAT helpers, production completion owner, boundary helper/tests and fixture.
Final runner SHA256 is55be42cbcaedee9d7f56f578cd7d36841bba86861b38bf5d61a7a0415a880c2e.
Exact production runner installation/qualification/earliest loader statements pass
3 modes and4 omitted-control/order rejections. Runner syntax passes. Accepted
function/whole-fragment/dispatcher/excerpt identity checks and reverse-to-main
preservation pass. Unchanged original donor and independent behavioral groups
are reused by actual hashes, with original uncompiled qualifications.

Signatures were regenerated from the FINAL main.watx include list, including all
indented GL entries, using the unchanged generator parser on balanced import
declarations per self-contained fragment. All closure hashes and parser identity
are retained.295 imports: prior290 unchanged plus five completion imports; final
output equals the accepted signature output. The ordinary whole-closure generator
hit the physical128MiB aggregate limit and was stopped. A full-fragment attempt
also hit the same enforced cap. Neither limit was raised. Those exact reproducers
and receipts remain; normal tools/gen-host-import-sigs.js --check is deferred to
the separately admitted build stage. Declaration extraction's whitespace oracle
and function-name newline fixture mistakes were corrected with failures retained.

Evidence: tested-tree.json binds all14 source/test paths; source-equivalence-result,
preserve-current-result, production-boundary-result and imports-final-result bind
affected checks. ops.tar.gz retains supervisors, reproducible checks and incidents.
Extract it beside the selective repo and use python3 ops/run-group.py GROUP;
preserve inputs/paths as in common.py. Do not rerun unchanged passing groups.
The compact reuse manifest binds original acceptance/donor evidence without
copying it. Historical real denials/guest timeouts/resource incidents, including
the erroneous old128MiB individual client rule, remain truthful and unchanged.

Fresh admission covers own96MiB including selective source/.git/outputs/evidence,
launcher/session/events, positive WAL once, future16MiB/reserve8MiB plus10MiB
publication/Git growth. Standing immutable inputs excluded, no links/alternates.
All tests use shared pool1 and physical128MiB; Git uses pool2 before exclusive
Git flock, physical256MiB and DATA512MiB on Git child only. CPU90/wall120,
file24MiB/output2MiB/excerpt8192. Node24.18.1 heap64; DATA/AS unlimited startup
verified. Actual measurements and exact argv are in resource/admission receipts.

Remaining: independent reconciled-source acceptance, then separately admitted
normal generator check/build and exact changed-module/runtime qualification of
initializers, thunk/decoded CALL/JMP dispatch, park/retry and async hooks before
the next guest instruction. Exact step-completion gate is required before any
Enigma input. Compiled=false; canonicalRuntimeQualified=false; original-game,
input and gameplay qualification unknown. No guest/browser/Wasm compile or
instantiation/Boat/API/runtime SSH/resume/creation/service/restart/deployment,
game semantics or workers/refill. No assigned box: ID/state/expiry N/A;
coordinator retains lifecycle ownership and no box was queried or changed.
'''
(N/'README.md').write_text(readme)
for name in ['base.json','tested-tree.json','checkpoint.json','configuration.json','startup-configuration.json','node-startup-execution.json','node-startup-output.log','reconciliation.json','recovered-current-files.json','production-boundary-result.json','production-boundary-execution.json','source-equivalence-result.json','preserve-current-result.json','imports-final-result.json','imports-final-execution.json','signature-inputs.json','reused-evidence.json','incidents.json','resources.json','admission-evidence.json','launch-configuration.json']:
 (N/name).write_bytes((O/name).read_bytes())
with tarfile.open(N/'ops.tar.gz','w:gz') as tar:
 for p in sorted(O.iterdir()):
  if p.is_file() and p.name not in ['board-watch.log','request.json']:tar.add(p,arcname='ops/'+p.name,recursive=False)
save('evidence-manifest.json',{str(p.relative_to(R)):dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in N.rglob('*') if p.is_file()})
print('PASS compact evidence prepared; no source/main/runtime changes during packaging')
