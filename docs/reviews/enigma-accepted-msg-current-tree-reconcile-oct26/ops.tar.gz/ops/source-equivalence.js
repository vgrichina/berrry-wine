'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto');
const root=path.resolve(process.argv[3]),out=process.argv[2],donor='/tmp/enigma-canonical-msg-completion-hook-repair-oct26/repo',accept='/tmp/enigma-canonical-msg-independent-source-accept-oct26/repo';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const review=JSON.parse(fs.readFileSync(accept+'/docs/reviews/enigma-canonical-msg-independent-source-accept-oct26/source-review-result.json'));
const files=[];
for(const x of review.reconstructedFiles){
 const b=fs.readFileSync(path.join(root,x.path));
 if(x.path!=='test/run.js')assert.equal(sha(b),x.candidateSHA256,x.path);
 files.push({path:x.path,sha256:sha(b),sameAcceptedFile:x.path!=='test/run.js'});
}
const oldReceipt=JSON.parse(fs.readFileSync(accept+'/docs/reviews/enigma-canonical-msg-independent-source-accept-oct26/production-boundary-result.json'));
const current=JSON.parse(fs.readFileSync(out+'/production-boundary-result.json'));
for(const name of Object.keys(oldReceipt.excerpts)){assert.equal(current.excerpts[name].sha256,oldReceipt.excerpts[name].sha256,name);assert.equal(current.excerpts[name].bytes,oldReceipt.excerpts[name].bytes);}
const routeFiles=review.dispatchProvenance.files;
for(const x of routeFiles)if(x.path!=='src/13-exports.wat')assert.equal(sha(fs.readFileSync(path.join(root,x.path))),x.sha256,x.path);
// Independently bind all accepted function text rather than infer equivalence
// from return-address coincidence. Whole fragment identity includes every pump.
const {extract}=require(path.join(root,'test/wat-completion-function-fixture.js'));
const names=['handle_GetMessageA','handle_GetMessageW','handle_PeekMessageA','handle_PeekMessageW','handle_GetMessage_observed','handle_PeekMessage_observed','keyboard_hook_begin','getmessage_hook_begin','getmessage_hook_continue','keyboard_hook_finish'];
const fragments=['src/09a5-handlers-window.wat','src/09a5b-handlers-window-late.wat','src/09a-handlers4-late.wat'];
const functions={};for(const name of names){const p=fragments.find(p=>fs.readFileSync(path.join(root,p),'utf8').match(new RegExp('\\(func \\$'+name+'[ \\n]')));assert(p,name);const text=extract(fs.readFileSync(path.join(root,p),'utf8'),name);assert.equal(text,extract(fs.readFileSync(path.join(donor,p),'utf8'),name));functions[name]=sha(text);}
fs.writeFileSync(out+'/source-equivalence-result.json',JSON.stringify({pass:true,files,functions,acceptedRunnerExcerptsUnchanged:true,dispatcherRouteFilesUnchanged:true,reusedGroups:'Original six groups/96 baseline comparisons, independent33 continuation cases/396 ownership schedules/route checks, original uncompiled qualifications retained',compiled:false,canonicalRuntimeQualified:false},null,2)+'\n');
console.log('PASS accepted functions/whole WAT fragments/helper tests/signatures/dispatcher routes byte exact; all production installation, qualification, earliest loader excerpts unchanged');
