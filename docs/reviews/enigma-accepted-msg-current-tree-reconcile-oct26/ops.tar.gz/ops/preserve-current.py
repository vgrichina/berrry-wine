from common import *
import gzip,re
D=pathlib.Path('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/repo');A=pathlib.Path('/tmp/enigma-canonical-msg-independent-source-accept-oct26/repo/docs/reviews/enigma-canonical-msg-independent-source-accept-oct26')
def parse(data):
 lines=data.decode().splitlines(True);i=0;files=[]
 while i<len(lines):
  assert lines[i].startswith('--- ');old=lines[i][4:].strip();p=lines[i+1][4:].strip().removeprefix('b/');i+=2;hs=[]
  while i<len(lines) and lines[i].startswith('@@ '):
   i+=1;before=[];after=[]
   while i<len(lines) and not lines[i].startswith(('@@ ','--- ')):
    l=lines[i]
    if l[0] in ' -':before.append(l[1:])
    if l[0] in ' +':after.append(l[1:])
    i+=1
   hs.append((''.join(before),''.join(after)))
  files.append((p,old,hs))
 return files
entries=json.load(open(O/'main-entries.json'));state={};checks=[]
for compressed in [D/'docs/re-notes/enigma-canonical-msg-completion-hook-repair-oct26/completion.patch.gz',A/'partial-runner-prerequisite.patch.gz']:
 for p,old,hunks in parse(gzip.decompress(compressed.read_bytes())):
  if p=='lib/host-import-sigs.generated.json':continue
  text=state.get(p,(R/p).read_text())
  for before,after in reversed(hunks):
   assert text.count(after)==1,(p,'reverse-hunk-not-unique')
   text=text.replace(after,before,1)
  state[p]=text
for p in ['test/message-boundary-trace.js','test/test-message-boundary-trace.js']:
 assert sha(state[p].encode())==json.load(open(A/'source-review-result.json'))['reconstructedFiles'][[x['path'] for x in json.load(open(A/'source-review-result.json'))['reconstructedFiles']].index(p)]['baselineSHA256']
 state[p]=''
for p,text in state.items():
 b=text.encode();oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 if p in entries:assert oid==entries[p]['oid'],(p,oid,entries[p]['oid'])
 else:assert not b,p
 checks.append(dict(path=p,reverseToCurrentMain=True,mainBlob=entries.get(p,{}).get('oid'),newPath=p not in entries))
runner=(R/'test/run.js').read_text()
# Existing Alien opt-in integration is preserved byte-for-byte because the
# complete runner, with only these two accepted deltas reversed, is current main.
assert "hasFlag('trace-render-wait') ? createRenderWaitAttribution() : null" in runner
save('preserve-current-result.json',dict(pass_=True,base=json.load(open(O/'base.json'))['main'],paths=checks,wholeRunnerReverseIdentity=True,unrelatedRunnerBehavior='All original current-main bytes including Alien plumbing retained; actual guest execution unqualified',signatureDelta='Five diagnostic imports only, all other signatures unchanged; final closure regenerated',compiled=False))
print('PASS all minimal Enigma deltas reverse exactly to current-main blob identities; new helpers absent in main; entire Alien runner delta preserved')
