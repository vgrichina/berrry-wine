from common import *
paths=sorted({p['path'] for p in json.load(open(O/'reconciliation.json'))['records']}|{'lib/host-import-sigs.generated.json'})
assert len(paths)==14,paths
g('add','--sparse','--',*paths)
staged=g('diff','--cached','--name-only').decode().splitlines();assert sorted(staged)==paths,(staged,paths)
g('diff','--cached','--check')
tree=g('write-tree','--missing-ok').decode().strip()
save('tested-tree.json',dict(base=json.load(open(O/'base.json'))['main'],tree=tree,paths=paths,files={p:sha((R/p).read_bytes()) for p in paths},compiled=False,canonicalRuntimeQualified=False))
save('checkpoint.json',dict(**json.load(open(O/'checkpoint.json'))|dict(testedTree=tree,remaining=['publish reviewed candidate/tests/compact evidence on task branch','independent reconciled-source acceptance','separately admitted normal generator/build/module/runtime qualification'])))
print(json.dumps(dict(testedTree=tree,paths=paths)))
