from common import *
import zlib
entries=json.load(open(O/'main-entries.json'));D=pathlib.Path('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/repo');A=pathlib.Path('/tmp/enigma-canonical-msg-independent-source-accept-oct26/repo/docs/reviews/enigma-canonical-msg-independent-source-accept-oct26')
# Materialize only final source include closure and affected offline tooling. No asset checkout.
paths=[p for p in entries if p.startswith('src/') and p.endswith(('.wat','.watx'))]
paths += [p['path'] for p in json.load(open(A/'source-review-result.json'))['reconstructedFiles'] if p['path'] in entries]
paths += ['lib/wat-manifest.js','tools/gen-host-import-sigs.js']
sources=[ROOT,pathlib.Path("/tmp/d3d-late-batch-oct23/repo"),pathlib.Path("/tmp/alien-opt-in-independent-integrate-oct26/repo"),pathlib.Path('/tmp/alien-render-wait-accepted-main-integration-oct26/repo'),pathlib.Path('/tmp/alien-accepted-opt-in-menu-gameplay-oct26/source'),pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo'),pathlib.Path('/tmp/civ2-win16-ordinary-gameplay-oct26/source'),D]
recovered=[]
for p in dict.fromkeys(paths):
 oid=entries[p]['oid'];b=None;origin=None
 for s in sources:
  q=s/p
  if q.is_file():
   data=q.read_bytes();raw=b'blob '+str(len(data)).encode()+b'\0'+data
   if hashlib.sha1(raw).hexdigest()==oid:b=data;origin=str(q);break
 if b is None:
  # Read a known present loose blob only, never ask Git to retry an absent blob.
  for s in sources:
   q=s/'.git/objects'/oid[:2]/oid[2:]
   if q.is_file():
    raw=zlib.decompress(q.read_bytes());assert hashlib.sha1(raw).hexdigest()==oid
    hdr,b=raw.split(b'\0',1);assert hdr==b'blob '+str(len(b)).encode();origin=str(q);break
 assert b is not None,('missing-local-verified-input',p,oid)
 dest=R/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 raw=b'blob '+str(len(b)).encode()+b'\0'+b;out=R/'.git/objects'/oid[:2]/oid[2:];out.parent.mkdir(exist_ok=True);out.write_bytes(zlib.compress(raw))
 recovered.append(dict(path=p,sha256=sha(b),oid=oid,origin=origin,bytes=len(b)))
save('recovered-current-files.json',recovered)
startup='const fs=require("fs");console.log(JSON.stringify({execPath:process.execPath,execArgv:process.execArgv,limits:fs.readFileSync("/proc/self/limits","utf8"),env:{TMPDIR:process.env.TMPDIR,NODE_OPTIONS:process.env.NODE_OPTIONS||null}}))'
b=pool([NODE,'--max-old-space-size=64','-e',startup],label='node-startup');print(b[:4000].decode())
save('startup-configuration.json',dict(executable=NODE,sha256=sha(pathlib.Path(NODE).read_bytes()),flags=['--max-old-space-size=64'],environment=dict(TMPDIR=str(O),NODE_OPTIONS=os.environ.get('NODE_OPTIONS')),cpu=90,wall=120,file=25165824,physical=134217728,output=2097152,excerpt=8192,gitDATAOnlyGit=True))
print('PASS current remote metadata/local selective source recovery; Node startup')
