import pathlib,json,hashlib,subprocess,struct,shutil,re
r=pathlib.Path(__file__).resolve().parent
e=r/'remote-evidence'
rev='1d8dbd7a44656178d01869f28869be624a59fa39'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert shutil.disk_usage(r).free>2285895680+1048576
seals=json.loads((e/'SHA256SUMS.json').read_text())
for f,h in seals.items():assert sha((e/f).read_bytes())==h,f
sources=json.loads((e/'source-seals.json').read_text())
p=subprocess.Popen(['git','-C',str(r/'repo'),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for f,h in sources.items():
 p.stdin.write((rev+':'+f+'\n').encode());p.stdin.flush()
 header=p.stdout.readline().split();assert len(header)==3,(f,header)
 data=p.stdout.read(int(header[2]));assert p.stdout.read(1)==b'\n'
 assert sha(data)==h,f
p.stdin.close();assert p.wait()==0
checks=[]
for n,duration in [('baseline',45),('screen800',45),('resize-controls',30)]:
 d=json.loads((e/n/'held-timings.json').read_text())
 assert d['exit']==0 and d['wallSeconds']>=duration
 log=(e/n/'held.log').read_text()
 assert 'msg=0x201' in log and 'msg=0x202' in log
 assert '78 02 00 00 9e 01 00 00' in log
 checks.append(dict(run=n,exit=d['exit'],seconds=d['wallSeconds'],inputs=len(d['events'])))
baseline=(e/'baseline/held.log').read_text()
assert 'size=564x480 client={"x":42,"y":42,"w":556,"h":434}' in baseline
large=(e/'screen800/held.log').read_text()
assert 'size=648x546 client={"x":80,"y":69,"w":640,"h":500}' in large
control=(e/'resize-controls/held.log').read_text()
assert 'canvas-resize 640x480 -> 800x600' in control
assert 'main-resize hwnd=0x10001 -> 564x480' in control
assert control.index('78 02 00 00 9e 01 00 00')<control.index('main-resize')<control.index('2c 02 00 00 9e 01 00 00')
trace=(e/'wm-size.log').read_text()
assert trace.count('[TRACE-AT #')==1
assert '0100010005000000000000007802b201' in trace
geometry=(e/'geometry.log').read_text()
assert '320x-240' in geometry
assert '0x00000278, 0x0000019e' in geometry
assert 'out: rect=&{l=0 t=0 r=556 b=434}' in geometry
sizes={}
for f in ['baseline/held-selected.png','baseline/held-back.png','screen800/held-selected.png','resize-controls/canvas-only.png','resize-controls/resize-commit.png']:
 b=(e/f).read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n'
 sizes[f]=list(struct.unpack('>II',b[16:24]))
assert sizes['baseline/held-selected.png']==[640,480]
assert sizes['baseline/held-back.png']==[564,480]
assert sizes['resize-controls/canvas-only.png']==sizes['resize-controls/resize-commit.png']==[800,600]
identity=json.loads((e/'identity.json').read_text())
assert identity['wasm_sha256']=='eafeaa142c98fe60c489865c89a676c20afffe51002fe36799f42aa46d19ac2c'
for name in ['geometry','wm-size','baseline','screen800','resize-controls','contracts']:
 assert json.loads((r/(name+'.json')).read_text())['exitCode']==0
result=dict(passed=True,sourceCommit=rev,sourceFilesCompared=len(sources),artifactSeals=len(seals),runs=checks,pngDimensions=sizes,productionChanges=0,scope='diagnosis and normal host resize controls; no candidate fix or fresh build')
(r/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
