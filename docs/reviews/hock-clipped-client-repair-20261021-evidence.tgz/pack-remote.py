import pathlib,json,hashlib,tarfile,shutil
r=pathlib.Path('/home/user/hock-clipped-client-repair')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['identity.json','source-seals.json','package-seals.json']:
 shutil.copyfile(pathlib.Path('/home/user/hock-placement-loop-repair')/name,r/name)
files=sorted(p for p in r.rglob('*') if p.is_file() and p.name not in ['SHA256SUMS.json','evidence.tgz'])
seals={str(p.relative_to(r)):sha(p) for p in files}
(r/'SHA256SUMS.json').write_text(json.dumps(seals,indent=2))
with tarfile.open(r/'evidence.tgz','w:gz') as t:
 for p in files+[r/'SHA256SUMS.json']:t.add(p,arcname=str(p.relative_to(r)))
print(json.dumps({'bytes':(r/'evidence.tgz').stat().st_size,'sha256':sha(r/'evidence.tgz'),'files':len(files)}))
