# Recover Hock clipping diagnosis

Same running bx_3f3x23m3, TTL 2026-10-21T05:56:19.894Z. Coordinator owns all
lifecycle actions. This task made none. Evidence-only outcome; no candidate
source or repaired module exists.

Remote original source: /home/user/hock-placement-loop-repair/repo
Remote original 39 game files: /home/user/hock-accepted-canonical-runtime/intake/game
Remote new evidence: /home/user/hock-clipped-client-repair

The inherited canonical module SHA256 is
eafeaa142c98fe60c489865c89a676c20afffe51002fe36799f42aa46d19ac2c.
7,133 source/test hashes map to main1d8dbd7a44656178d01869f28869be624a59fa39.
verify-remote.py freshly checks source/package/module seals. Run its content
through the documented Boat exec API, using a NEW output directory if repeated.
No SSH, denied-route retry or lifecycle action is needed for the running box.

Preserved remote drive-baseline.py reproduces the 45s original held route.
drive-screen800.py is a larger-screen control; drive-resize-controls.py tests
canvas enlargement followed by normal host_resize_commit at unchanged outer
dimensions. Change each driver's output directory before replay to preserve
all originals. Exact argv/input wall times and logs are under baseline/,
screen800/ and resize-controls/. The latter is a diagnostic intervention,
not a candidate build. Root held* is a perturbed watch/count probe and is not
the accepted baseline. geometry.command.txt and wm-size.command.txt reproduce
bounded API and callback-stack diagnostics; use new log destinations.

remote-evidence.tgz SHA256:
6f4b2217100f2085f7c4d6fd710393b7dad8e844d169a143e4373c87bd9a1178
Its SHA256SUMS.json seals 53 files. validate.py additionally maps the remote
source manifests to local exact Git objects and checks runtime observations.
The committed evidence archive adds local receipts, disassembly and this
recipe. Game assets/dependencies/modules remain remote, excluded from Git.

No general notification repair was accepted: startup delivers creation-time
WM_SIZE, and subsequent ordinary placement sends no updated resize. Preserve
the existing CLIENT_RECT refresh. A follow-up needs an owned, reentrant
placement notification transaction plus reviewed startup-size semantics;
do not bypass/refresh ownership or callback gates to hide the prerequisite.
