import subprocess,pathlib,time,json,datetime
r=pathlib.Path('/home/user/hock-clipped-client-repair/resize-controls')
r.mkdir(exist_ok=True)
args=['node','test/run.js','--no-build','--wasm=/home/user/hock-placement-loop-repair/repo/build/wine-assembly.wasm','--exe=/home/user/hock-accepted-canonical-runtime/intake/game/BBLOOGIE.EXE','--exe-guest-path=C:\\BBLOOGIE.EXE','--cwd=C:\\','--vfs-include=**/*','--quiet-api','--max-seconds=30','--max-batches=1000000','--real-ticks','--control-stdin','--trace-input','--trace-input-dispatch','--png='+str(r/'held-final.png')]
events=[(3,{'action':'png','path':str(r/'before.png')}),(4,{'cmd':'mousemove:124:386'}),(5,{'cmd':'mousedown:124:386'}),(7,{'cmd':'mouseup:124:386'}),(10,{'action':'png','path':str(r/'selected.png')}),(11,{'cmd':'canvas-resize:800:600'}),(14,{'action':'png','path':str(r/'canvas-only.png')}),(15,{'cmd':'dump-windows:canvas-only'}),(16,{'cmd':'dump-mem:0x41eca4:8'}),(19,{'cmd':'main-resize:564:480'}),(21,{'cmd':'dump-windows:resize-commit'}),(22,{'cmd':'dump-mem:0x41eca4:8'}),(25,{'action':'png','path':str(r/'resize-commit.png')}),(26,{'cmd':'hwnd-png-pixels:65537:'+str(r/'resize-back.png')})]
(r/'held-command.json').write_text(json.dumps(args,indent=2))
start=time.monotonic(); records=[]
with (r/'held.log').open('w') as log:
 p=subprocess.Popen(args,cwd='/home/user/hock-placement-loop-repair/repo',stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,text=True)
 for at,cmd in events:
  time.sleep(max(0,start+at-time.monotonic()))
  if p.poll() is not None:break
  cmd['id']=len(records)+1;p.stdin.write(json.dumps(cmd)+'\n');p.stdin.flush()
  records.append({'wallSeconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd})
 p.stdin.close();rc=p.wait(timeout=20)
(r/'held-timings.json').write_text(json.dumps({'events':records,'exit':rc,'wallSeconds':time.monotonic()-start},indent=2));print('exit',rc);raise SystemExit(rc)
