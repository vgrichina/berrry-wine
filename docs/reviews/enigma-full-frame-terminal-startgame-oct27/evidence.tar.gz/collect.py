gate('collect')
def get(remote,name):
 code='import pathlib,json,hashlib;p=pathlib.Path('+repr(remote)+');print(json.dumps(dict(exists=p.exists(),bytes=p.stat().st_size if p.exists() else 0,sha256=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None)))'
 m=json.loads(py(code)['stdout']);save(name+'.metadata.json',m)
 if m['exists']:fetch(remote,name,m['bytes'],m['sha256'])
for n in ['startup-environment.json','supervisor-stdout.log','supervisor-stderr.log','supervisor-pid.json','cli-exit.json','launch/node-startup.json','launch/node-startup-stdout.log','launch/node-startup-stderr.log','launch/output.log','launch/stderr.log','launch/supervisor-outcome.json','launch/controller/outcome.json','launch/controller/first-n1-completion-gate.json','launch/controller/phase.json','launch/launch-config.json']:
 get(str(O/n),'remote-'+n.replace('/','-'))
code='''import pathlib,json,time,os
o=pathlib.Path(OPS); owned=json.loads((o/'launch/supervisor-outcome.json').read_text());pids=owned.get('owned',[]); live=[]
for pid,start in pids:
 p=pathlib.Path('/proc')/str(pid)
 try:
  st=(p/'stat').read_text().split(') ')[1].split()
  if st[19]==str(start) and st[0]!='Z':live.append([pid,start])
 except FileNotFoundError:pass
sp=json.loads((o/'supervisor-pid.json').read_text());p=pathlib.Path('/proc')/str(sp['pid'])
try:
 st=(p/'stat').read_text().split(') ')[1].split();supervisorLive=st[19]==str(sp['start']) and st[0]!='Z'
except FileNotFoundError:supervisorLive=False
print(json.dumps(dict(at=time.time(),owned=pids,live=live,supervisorLive=supervisorLive,terminal=json.loads((o/'cli-exit.json').read_text()),remainingOwnedLive=owned['remainingOwnedLive'])))
'''.replace('OPS',repr(str(O)))
save('new-owned-absence.json',json.loads(py(code)['stdout']))
assert not json.loads((O/'new-owned-absence.json').read_text())['live']
save('inspection.json',dict(at=time.time(),frame=json.loads((O/'new-menu-metadata.json').read_text()),fullFrameInspected=True,visible='Enigma v1.01 Loading Enigma levels',startGameVisible=False,reviewedWithinWindow=True,decision=False,input=False,gameplay=False,reason='Loading screen cannot authorize correlated StartGame; controller captured before menu readiness. No unchanged retry.'))
save('result.json',dict(status='BLOCKED_LOADING_FRAME_NO_STARTGAME',at=time.time(),box=BOX,boxState='RUNNING_API_EXEC_OBSERVED',leaveRunning=True,shutdownOwner='coordinator',expiry='2026-10-27T09:42:54Z',guestCutoff='2026-10-27T09:30:00Z',handback='2026-10-27T09:32:00Z',shutdown='2026-10-27T09:35:00Z',originalCommand='cmd_hqtwflmxdxp3',originalTerminalRecovered=True,originalOwnedAbsent=True,newCommand=json.loads((O/'launch-api.json').read_text())['commandId'],guestInvocations=1,fullFrameInspected=True,frameSHA256=sha((O/'new-menu.png').read_bytes()),frameBatch=49665,decisions=0,inputs=0,gameplay=False,ordinaryGuestQuit=False,cleanup='new-owned-absence.json',historicalOvershoot=27860,apiCaptureBytes=sum(p.stat().st_size for p in (O/'responses').iterdir()),apiCap=8388608,source='425755ee5ee9be0734c7aca187521100f5487674',acceptedSupervisor='b160b5403e69f28e92e218849cc8165c67776bd2',module='af202eea3c5c11aadb117b5c8eed1851d50ce2ce4246a4122845699b472fcc2b',remainingGate='Production controller must reach an actual menu before its single frozen reviewed capture; current 35s checkpoint presents Loading Enigma levels. Coordinator assigns any repair/new invocation. No click at loading.'))
save('checkpoint.json',json.loads((O/'result.json').read_text()))
print('Terminal, distinct streams and owned absence retained; full frame is loading, no input')
