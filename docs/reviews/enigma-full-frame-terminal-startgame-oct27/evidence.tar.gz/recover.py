gate('recover')
old='/tmp/enigma-cleanup-startgame-oct27'
code='''import pathlib,json,os,time,hashlib
o=pathlib.Path(OLD)/'ops'; names=['cli-exit.json','supervisor-pid.json','launch/supervisor-outcome.json','launch/controller/outcome.json','launch/node-startup.json']; result={}
for n in names:
 p=o/n;result[n]=json.loads(p.read_text()) if p.exists() else None
matches=[]
for p in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  cmd=(p/'cmdline').read_bytes().split(b'\\0')
  if any(x.startswith(OLD.encode()+b'/') and (x.endswith(b'/enigma-supervised-gameplay.py') or x.endswith(b'/enigma-frozen-gameplay-controller.py') or x.endswith(b'/runner/test/run.js')) for x in cmd):matches.append(dict(pid=int(p.name),argv=[x.decode(errors='replace') for x in cmd]))
 except OSError:pass
result['ownedLiveMatches']=matches;result['at']=time.time();print(json.dumps(result))
'''.replace('OLD',repr(old))
v=json.loads(py(code)['stdout']);save('original-terminal-cleanup-exact-argv.json',v)
assert v['cli-exit.json'] is not None and not v['ownedLiveMatches'], 'Original terminal/absence not established'
print(json.dumps(v))
