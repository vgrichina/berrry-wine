gate('preguest')
assert time.time()+130<1793093400
used=sum(p.stat().st_size for p in (O/'responses').iterdir())
plan=dict(at=time.time(),alreadyCaptured=used,menuExpectedBytes=413407,menuEnvelope=((413407+4095)//4096)*8192,afterActionMaximumBytes=2097152,afterActionEnvelope=512*8192,terminalReserve=1048576,otherResponses=524288,totalCap=8388608,guestSeconds=110,actionReserveSeconds=30,cleanupReserveSeconds=10)
plan['pass']=used+plan['menuEnvelope']+plan['afterActionEnvelope']+plan['terminalReserve']+plan['otherResponses']<=plan['totalCap'];save('capture-readiness.json',plan);assert plan['pass']
j=api('timeout 120 python3 '+shlex.quote(str(O/'launch.py')),detach=True);save('launch-api.json',j);save('launch-at.json',dict(at=time.time(),guestInvocations=1,box=BOX))
def readjson(remote):
 return json.loads(py('import pathlib,json;p=pathlib.Path('+repr(remote)+');print(p.read_text() if p.exists() else "null")')['stdout'])
def getframe(f,name):
 used=sum(p.stat().st_size for p in (O/'responses').iterdir());chunks=(f['bytes']+4095)//4096
 assert f['bytes']<=2097152 and used+chunks*8192+1048576<=8388608, 'Complete frame+terminal envelope cannot fit'
 save(name+'.admission.json',dict(at=time.time(),used=used,pendingEnvelope=chunks*8192,terminalReserve=1048576,passGate=True))
 fetch(f['path'],name,f['bytes'],f['sha256'],False)
f=None
for i in range(300):
 v=readjson(str(O/'launch/controller/menu-candidate.png.json'))
 if v:f=v;break
 t=readjson(str(O/'cli-exit.json'))
 if t:raise RuntimeError(('terminal before frame',t))
 time.sleep(.15)
assert f,'No frame'
save('new-menu-metadata.json',f);getframe(f,'new-menu.png');print('FRAME_READY '+json.dumps(f),flush=True)
until=time.monotonic()+17
while time.monotonic()<until and not (O/'inspection-approved.txt').exists():time.sleep(.05)
if (O/'inspection-approved.txt').exists():
 assert (O/'inspection-approved.txt').read_text().strip()=='INSPECTED_ACTUAL_NEW_MENU_START_GAME_343_213'
 d=dict(reviewed=True,safeStartGame=True,frameSHA256=f['sha256'],batch=f['batch'],x=343,y=213);save('decision.json',d)
 save('decision-delivery.json',py('import pathlib,json,time;p=pathlib.Path('+repr(str(O/'decision.json'))+');assert not p.exists();p.write_text('+repr(json.dumps(d))+');print(json.dumps(dict(at=time.time(),delivered=True)))'))
 print('DECISION_DELIVERED',flush=True)
else:save('no-decision.json',dict(at=time.time(),reason='No inspection within local window',inputs=0))
for i in range(180):
 t=readjson(str(O/'cli-exit.json'))
 if t:save('cli-exit.json',t);break
 time.sleep(.25)
else:raise RuntimeError('Terminal not yet retrieved; no input retry')
for name in ['launch/supervisor-outcome.json','launch/controller/outcome.json','launch/controller/first-n1-completion-gate.json','launch/controller/start-game-action-ACK.json','launch/controller/after-action.png.json','launch/node-startup.json']:
 v=readjson(str(O/name));save(name.replace('/','-'),v)
 if name.endswith('after-action.png.json') and v:getframe(v,'after-action.png')
print('TERMINAL_COLLECTED',flush=True)
