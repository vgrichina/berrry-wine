gate('prepare')
OLD=pathlib.Path('/tmp/enigma-cleanup-startgame-oct27')
save('task-profile.json',dict(localAllocation=134217728,bucketsMiB=[20,16,52,40],apiCumulative=8388608,apiPerResponse=8192,terminalReserve=1048576,guestPhysical=3221225472,nodeHeapMiB=2048,cpu=90,guestWall=110,localPhysical=134217728,localWall=120,file=25165824,output=2097152,displayPerOperation=8192,displayCumulative=1048576,noWorkers=True,noMain=True,noDeployment=True,rootDonorsReadOnly=True,ssh=SSH,box=BOX,lifecycle=dict(guestCutoff='2026-10-27T09:30:00Z',handback='2026-10-27T09:32:00Z',shutdown='2026-10-27T09:35:00Z',expiry='2026-10-27T09:42:54Z',owner='coordinator'),historicalOvershoot=27860,incidents=['Initial policy reads exceeded 8192-byte display operation; preserved tool history, subsequent bounded reads applied.','Recovery scan matched own python -c; exact filename argument matcher corrected, failed receipt retained.']))
code='''import pathlib,json,hashlib,shutil,time
h=pathlib.Path('/tmp/enigma-cleanup-startgame-oct27');o=pathlib.Path(NEWOPS);o.mkdir(parents=True,exist_ok=True)
rs=json.loads((h/'ops/runtime-manifest.json').read_text());rs.append(dict(target='modules/wine-assembly.wasm',bytes=1880854,sha256='af202eea3c5c11aadb117b5c8eed1851d50ce2ce4246a4122845699b472fcc2b'))
bad=[]
for r in rs:
 b=(h/r['target']).read_bytes()
 if len(b)!=r['bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:bad.append(r['target'])
v=dict(at=time.time(),files=len(rs),bytes=sum(r['bytes'] for r in rs),bad=bad,used=sum(p.stat().st_blocks*512 for p in [h,*h.rglob('*')] if p.exists()),free=shutil.disk_usage(h).free,memAvailable=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024,allocation=268435456,reserve=33554432)
v['pass']=not bad and v['used']+v['reserve']<=v['allocation'] and v['free']-max(0,v['allocation']-v['used'])>=2982150144 and v['memAvailable']>=4563402752
(o/'closure.json').write_text(json.dumps(v,indent=2));print(json.dumps(v));assert v['pass']
'''.replace('NEWOPS',repr(str(O)))
save('closure.json',json.loads(py(code)['stdout']))
c=json.loads((OLD/'ops/launch-config.json').read_text());c['launch_dir']=str(O/'launch');c['controller']['decision_path']=str(O/'decision.json');c['cutoff_at']=1793093400
assert c['command'][3]=='--no-build' and c['limits']['physical']==3221225472
save('launch-config.json',c)
parser=(OLD/'ops/parser-check.cjs').read_text().replace(str(OLD/'ops'),str(O));(O/'parser-check.cjs').write_text(parser)
launch=(OLD/'ops/launch.py').read_text();launch=launch.replace("c=json.loads((h/'ops/launch-config.json').read_text())","o=pathlib.Path("+repr(str(O))+")\nc=json.loads((o/'launch-config.json').read_text())")
launch=launch.replace("(h/'ops/","(o/'").replace("str(h/'ops/launch-config.json')","str(o/'launch-config.json')")
(O/'launch.py').write_text(launch)
for n in ['launch-config.json','parser-check.cjs','launch.py']:put_bytes(str(O/n),(O/n).read_bytes(),n.replace('.','-'))
code='''import pathlib,json,os,importlib.util,subprocess
o=pathlib.Path(OPS);old=pathlib.Path('/tmp/enigma-cleanup-startgame-oct27/ops');s=importlib.util.spec_from_file_location('s',old/'trusted-supervisor.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env={'HOME':'/home/user','PATH':'/home/user/.nvm/versions/node/v24.22.1/bin:/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1'};os.environ.clear();os.environ.update(env)
wrapper="import subprocess,pathlib,sys; o=pathlib.Path("+repr(str(o))+"); out=(o/'mount.stdout').open('xb'); err=(o/'mount.stderr').open('xb'); p=subprocess.Popen(['/home/user/.nvm/versions/node/v24.22.1/bin/node','--max-old-space-size=2048',str(o/'parser-check.cjs')],stdout=out,stderr=err); sys.exit(p.wait())"
r=m.supervise(['/usr/bin/python3','-c',wrapper],rss_limit=134217728,cpu_limit=90,wall_limit=120,output_limit=2097152);r.pop('output');(o/'mount-check.json').write_text(json.dumps(r));print(json.dumps(dict(receipt=r,stdout=(o/'mount.stdout').read_text(),stderr=(o/'mount.stderr').read_text())));assert r['exit']==0 and not r['stopReason']
'''.replace('OPS',repr(str(O)))
save('mount-check.json',json.loads(py(code)['stdout']))
save('checkpoint.json',dict(status='ORIGINAL_TERMINAL_ABSENT_CLOSURE_MOUNT_PASS',remaining=['fresh admission','one guest/frame inspect/correlated StartGame','after-action review','terminal and publication'],at=time.time()))
print('Closure and mount PASS; no new guest yet')
