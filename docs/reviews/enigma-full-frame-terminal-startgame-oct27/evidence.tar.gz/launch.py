import os,sys,json,pathlib,subprocess,time,hashlib,resource
h=pathlib.Path('/tmp/enigma-cleanup-startgame-oct27')
env={'HOME': '/home/user', 'PATH': '/home/user/.nvm/versions/node/v24.22.1/bin:/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8', 'TZ': 'UTC', 'PYTHONDONTWRITEBYTECODE': '1'}
o=pathlib.Path('/tmp/enigma-full-frame-terminal-startgame-oct27/ops')
c=json.loads((o/'launch-config.json').read_text())
assert time.time()+120 < c['cutoff_at']
assert int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024 >= 4563402752
assert (o/'mount-check.json').is_file()
receipt=dict(at=time.time(),environment=env,environmentSHA256=hashlib.sha256(json.dumps(env,sort_keys=True).encode()).hexdigest(),inheritedLimits=pathlib.Path('/proc/self/limits').read_text(),configSHA256=hashlib.sha256((o/'launch-config.json').read_bytes()).hexdigest(),identities={p:hashlib.sha256((h/p).read_bytes()).hexdigest() for p in ['runner/test/run.js','runner/lib/host-imports.js','modules/wine-assembly.wasm','runner/tools/enigma-supervised-gameplay.py','runner/tools/enigma-frozen-gameplay-controller.py','vfs/Enigma-1.01/enigma.exe']})
(o/'startup-environment.json').write_text(json.dumps(receipt,indent=2))
with (o/'supervisor-stdout.log').open('xb') as out,(o/'supervisor-stderr.log').open('xb') as err:
 p=subprocess.Popen(['/usr/bin/python3',str(h/'runner/tools/enigma-supervised-gameplay.py'),'--launch-config',str(o/'launch-config.json')],cwd=h/'runner',env=env,stdout=out,stderr=err,start_new_session=True)
 (o/'supervisor-pid.json').write_text(json.dumps(dict(pid=p.pid,start=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split(') ')[1].split()[19])))
 try:r=p.wait(timeout=118)
 except subprocess.TimeoutExpired:
  p.terminate();r=p.wait(timeout=1)
 (o/'cli-exit.json').write_text(json.dumps(dict(exit=r,at=time.time())))
print(json.dumps(dict(supervisorExit=r)))
