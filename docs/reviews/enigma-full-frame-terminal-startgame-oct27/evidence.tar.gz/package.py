gate('package')
old=pathlib.Path('/tmp/enigma-cleanup-startgame-oct27/ops')
for n in ['result.json','checkpoint.json','capture-budget-incident.json','readback-recovery.json','key-source-pins.json','module-supplement.json']:
 b=(old/n).read_bytes();(O/('prior-'+n)).write_bytes(b)
save('source-reuse.json',dict(mapPath=str(ROOT/'scratch/usage-watch/enigma-cleanup-verified-runtime-map-oct27.json'),mapSHA256=sha((ROOT/'scratch/usage-watch/enigma-cleanup-verified-runtime-map-oct27.json').read_bytes()),expectedMapSHA256='06a72d86b409850d73a8158d4f12d974b517ed0c9532652a1fc5f0ee2cb09f83',originalRefDigest=json.loads((ROOT/'scratch/usage-watch/enigma-full-frame-terminal-startgame-oct27/root-ref-digest.json').read_text()),priorOriginalTaskSHA256=sha((ROOT/'scratch/usage-watch/enigma-cleanup-startgame-oct27.task.txt').read_bytes()),freshTaskSHA256=sha((ROOT/'scratch/usage-watch/enigma-full-frame-terminal-startgame-oct27.task.txt').read_bytes()),sourceUnchanged=True,noBuild=True,noCopyOfStagedClosure=True))
assert json.loads((O/'source-reuse.json').read_text())['mapSHA256']=='06a72d86b409850d73a8158d4f12d974b517ed0c9532652a1fc5f0ee2cb09f83'
g=H/'repo/.git';assert g.is_dir();(g/'objects/info/alternates').write_text('/tmp/enigma-streams-independent-accept-integrate-oct27/repo/.git/objects\n');(g/'info/sparse-checkout').write_text('/docs/reviews/'+H.name+'/\n')
with (g/'config').open('a') as f:f.write('\n[remote "origin"]\n url = git@github.com:vgrichina/wine-assembly.git\n[user]\n name = Wine Ops\n email = wine-ops@localhost\n[core]\n sparseCheckout = true\n')
D=H/'repo/docs/reviews'/H.name;D.mkdir(parents=True,exist_ok=True)
paths=[p for p in sorted(O.rglob('*')) if p.is_file() and p.name not in ['package.log','package.execution.json']]
manifest=[dict(path=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in paths]
with tarfile.open(D/'evidence.tar.gz','w:gz') as t:
 for p in paths:t.add(p,arcname=str(p.relative_to(O)),recursive=False)
with tarfile.open(D/'evidence.tar.gz') as t:
 for r in manifest:
  b=t.extractfile(r['path']).read();assert len(b)==r['bytes'] and sha(b)==r['sha256']
(D/'manifest.json').write_text(json.dumps(dict(files=manifest,archiveSHA256=sha((D/'evidence.tar.gz').read_bytes()),roundTripPass=True),indent=2)+'\n')
(D/'result.json').write_bytes((O/'result.json').read_bytes());(D/'loading-frame.png').write_bytes((O/'new-menu.png').read_bytes())
(D/'README.md').write_text('''# Enigma full-frame terminal and StartGame attempt

BLOCKED: the complete newly captured production frame shows “Loading Enigma levels”, not a StartGame control. Full 413407-byte frame inspected at batch 49665 inside the decision window; no decision or input sent, gameplay unqualified. One new invocation only. No retries, builds, recopy, source changes, main ownership or deployment.

Recovered spent cmd_hqtwflmxdxp3 terminal and independently checked owned absence first. Fresh cmd_5nhycfujopzh passed exact 2665-file closure plus explicit af202 module supplemental pin, canonical full mount enumeration, Node startup and serial n=1 ACK/frozen-zero gate. Frame fetched in 3.594 seconds with entire pending envelope and terminal reserve preadmitted. New supervisor terminal child exit0, owned absence independently checked; status NO_REVIEWED_ACTION_NO_INPUT. The supervisor also recorded control-listener-identity-changed during shutdown, retained without reinterpretation.

Historical 27860-byte API capture overshoot remains an incident. This fresh allowance is 8 MiB; all raw API stdout/stderr and command hashes retained in lossless archive. Initial display overage and recovery self-match error remain recorded. The repository is an isolated sparse orphan evidence report with read-only donor alternates; never merge it as production code.

Boat bx_mueag3dn stays RUNNING; coordinator owns handback09:32, snapshot-stop09:35, expiry09:42:54 UTC. Inputs and staged closure remain intact. Next prerequisite is a production controller checkpoint that reaches an actual StartGame menu before frozen review, under a new coordinator assignment.
''')
save('publication-validation.json',dict(at=time.time(),files=len(manifest),archiveBytes=(D/'evidence.tar.gz').stat().st_size,archiveSHA256=sha((D/'evidence.tar.gz').read_bytes()),allPayloadHashesPass=True,sourceEdits=0,behavioralSuitesRepeated=0))
print(json.dumps(json.loads((O/'publication-validation.json').read_text())))
