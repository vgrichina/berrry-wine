import pathlib,json,hashlib,subprocess
r=pathlib.Path(__file__).resolve().parent
rev='1d8dbd7a44656178d01869f28869be624a59fa39'
def sha(b):return hashlib.sha256(b).hexdigest()
s=json.loads((r/'source-seals.json').read_text())
p=subprocess.Popen(['git','-C',str(r/'repo'),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for f,h in s.items():
 p.stdin.write((rev+':'+f+'\n').encode());p.stdin.flush();hdr=p.stdout.readline().split();assert len(hdr)==3,(f,hdr)
 b=p.stdout.read(int(hdr[2]));assert p.stdout.read(1)==b'\n';assert sha(b)==h,f
p.stdin.close();assert p.wait()==0
seals=json.loads((r/'remote-evidence/SHA256SUMS.json').read_text())
for f,h in seals.items():assert sha((r/'remote-evidence'/f).read_bytes())==h,f
for f in ['selection','sustained','held']:assert json.loads((r/(f+'.json')).read_text())['exitCode']==0
events=json.loads((r/'remote-evidence/held-timings.json').read_text());assert len(events['events'])==15 and events['exit']==0 and events['wallSeconds']>=45
log=(r/'remote-evidence/held.log').read_text()
for text in ['mousedown 124,386','mouseup 124,386','mousedown 320,250','mouseup 320,250','mousedown 450,300','mouseup 450,300','27391908 API calls, 22777 batches','msg=0x201','msg=0x202']:assert text in log,text
result={'sourceFilesMappedToIntegratedMain':len(s),'remoteArtifactSeals':len(seals),'runtimeExits':[0,0,0],'heldInputs':15,'wallSeconds':events['wallSeconds'],'passed':True}
(r/'validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
