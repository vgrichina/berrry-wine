import pathlib,hashlib,json,tarfile,wave,math
r=pathlib.Path('/home/user/hock-original-gameplay')
stats={}
for p in r.glob('*.wav'):
 with wave.open(str(p),'rb') as w:
  b=w.readframes(w.getnframes());stats[p.name]={'channels':w.getnchannels(),'rate':w.getframerate(),'sampleBytes':w.getsampwidth(),'frames':w.getnframes(),'pcmBytes':len(b),'seconds':w.getnframes()/w.getframerate(),'min':min(b),'max':max(b),'rmsAroundUnsignedMidpoint':math.sqrt(sum((x-128)**2 for x in b)/len(b)),'nonMidpointSamples':sum(x!=128 for x in b)}
(r/'audio-analysis.json').write_text(json.dumps(stats,indent=2))
files=sorted(p for p in r.iterdir() if p.is_file() and p.name not in ['evidence.tgz','SHA256SUMS.json'])
seals={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(r/'SHA256SUMS.json').write_text(json.dumps(seals,indent=2))
with tarfile.open(r/'evidence.tgz','w:gz') as t:
 for p in files+[r/'SHA256SUMS.json']:t.add(p,arcname=p.name)
p=r/'evidence.tgz';print(json.dumps({'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(files)+1,'audio':stats}))
