# Hock original gameplay recovery — 2026-10-21

SAME running Boat `bx_3f3x23m3`, TTL `2026-10-21T05:56:19.894Z`.
Coordinator owns lifecycle. This task issued zero lifecycle operations.
Remote evidence: `/home/user/hock-original-gameplay`.
Source/module: `/home/user/hock-placement-loop-repair/repo`.
Original 39 game files: `/home/user/hock-accepted-canonical-runtime/intake/game`.

The module is the inherited canonical candidate build, NOT a fresh main
compilation. All 7,133 sealed source/test files map to integrated main
`1d8dbd7a44656178d01869f28869be624a59fa39`. `verify-remote.py` rehashes the
actual remote files, package and both modules before reuse; `validate.py`
compares local Git objects without materializing assets or compiling.
The source/package manifests and inherited identity are retained alongside.
WASM SHA256: `eafeaa142c98fe60c489865c89a676c20afffe51002fe36799f42aa46d19ac2c`.

To reproduce in an authorized runtime, retain those directories, verify seals,
and run `python3 /home/user/hock-original-gameplay/drive-held.py` from its
preserved copy. Use a NEW output directory in the driver to avoid overwriting
evidence. `held-command.json` is the exact argv; `held-timings.json` records
wall input times and UTC; `held.log` records batch delivery and guest dispatch.
The driver uses unmodified `test/run.js --no-build --real-ticks --control-stdin`
with 45-second bounds. At 4s move to (124,386), hold left button at 5–7s;
at 12s move to (320,250), hold at 13–15s; at 20s move to (450,300), hold
at 21–23s. Capture at 3,6,10,18,30,40 seconds plus final exit.
No state injection, game asset mutation or source modification is involved.

The instantaneous-click routes are preserved as unsuccessful selection attempts,
not gameplay proof. Mouse polling in the original executable motivates the
held-button route. Keyboard inputs on the unsuccessful route do not establish
supported gameplay keys. The successful route selects the left character and
shows sustained street gameplay, mouse-controlled movement and attempted shots.
Score remains 0/20, so hits/scoring/level completion are unqualified. The right
edge and timer remain clipped. Audio PCM is non-silent, but audible quality and
sync are unverified; recorded sample duration exceeds wall time. FPS was not
measured; batch rate is not frame rate.

`remote-evidence.tgz` is the downloaded archive, verified against `pack.json`.
Its `SHA256SUMS.json` seals 31 files. The committed evidence archive also retains
local command receipts, source/package identity, drivers, validation and this
recipe. It does not contain original game assets, dependencies or WASM binaries.
Those remain remote; prior canonical recovery recipes describe restoring them.
