import subprocess,json,base64,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent
REMOTE='/home/user/hock-placement-loop-repair'
def run(cmd,name,timeout=60):
 (ROOT/(name+'.command.txt')).write_text(cmd)
 p=subprocess.run(['boat','--json','exec','bx_3f3x23m3','--timeout',str(timeout),'--','bash','-lc',cmd],capture_output=True,text=True)
 (ROOT/(name+'.json')).write_text(p.stdout)
 if p.stderr:(ROOT/(name+'.stderr')).write_text(p.stderr)
 d=json.loads(p.stdout);
 if not name.startswith('download-'): print(d.get('stdout',''));print(d.get('stderr',''),file=sys.stderr)
 if d.get('exitCode')!=0:raise RuntimeError(f'{name}: {d}')
 return d
if __name__=='__main__':run(sys.argv[2],sys.argv[1],int(sys.argv[3]) if len(sys.argv)>3 else 60)
