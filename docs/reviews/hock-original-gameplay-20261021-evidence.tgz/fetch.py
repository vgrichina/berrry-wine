import sys,pathlib,base64,json,hashlib,shlex
from remote import run
r=pathlib.Path(__file__).resolve().parent
assert __import__('shutil').disk_usage(r).free>2285895680+67108864
for name in sys.argv[1:]:
 assert '/' not in name and '..' not in name
 d=run('base64 -w0 '+shlex.quote('/home/user/hock-original-gameplay/'+name),'download-'+name)
 b=base64.b64decode(d['stdout']);(r/name).write_bytes(b)
 print(name,len(b),hashlib.sha256(b).hexdigest())
