import subprocess,pathlib,time,json,datetime
r=pathlib.Path('/home/user/hock-original-gameplay')
args=['node','test/run.js','--no-build','--wasm=/home/user/hock-placement-loop-repair/repo/build/wine-assembly.wasm','--exe=/home/user/hock-accepted-canonical-runtime/intake/game/BBLOOGIE.EXE','--exe-guest-path=C:\\BBLOOGIE.EXE','--cwd=C:\\','--vfs-include=**/*','--quiet-api','--max-seconds=45','--max-batches=1000000','--real-ticks','--control-stdin','--trace-input','--trace-input-dispatch','--audio-stats','--audio-out='+str(r/'sustained.wav'),'--audio-out-max=2097152','--png='+str(r/'sustained-final.png')]
events=[(3,{'action':'png','path':str(r/'live-before.png')}),(4,{'cmd':'click:124:386'}),(7,{'action':'png','path':str(r/'live-selected.png')}),(9,{'cmd':'keydown:13'}),(9.2,{'cmd':'keyup:13'}),(11,{'cmd':'keydown:32'}),(12,{'cmd':'keyup:32'}),(14,{'cmd':'keydown:39'}),(16,{'cmd':'keyup:39'}),(17,{'action':'png','path':str(r/'live-action.png')}),(19,{'cmd':'mousemove:320:250'}),(20,{'cmd':'mousedown:320:250'}),(22,{'cmd':'mouseup:320:250'}),(25,{'action':'png','path':str(r/'live-25s.png')}),(40,{'action':'png','path':str(r/'live-40s.png')})]
(r/'sustained-command.json').write_text(json.dumps(args,indent=2))
start=time.monotonic(); records=[]
with (r/'sustained.log').open('w') as log:
 p=subprocess.Popen(args,cwd='/home/user/hock-placement-loop-repair/repo',stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,text=True)
 for at,cmd in events:
  time.sleep(max(0,start+at-time.monotonic()))
  if p.poll() is not None:break
  cmd['id']=len(records)+1;p.stdin.write(json.dumps(cmd)+'\n');p.stdin.flush()
  records.append({'wallSeconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd})
 p.stdin.close();rc=p.wait(timeout=20)
(r/'sustained-timings.json').write_text(json.dumps({'events':records,'exit':rc,'wallSeconds':time.monotonic()-start},indent=2));print('exit',rc);raise SystemExit(rc)
