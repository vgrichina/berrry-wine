import pathlib,os,sys,json,time,hashlib,subprocess,resource,shutil,shlex,base64,zlib
H=pathlib.Path('/tmp/alien-retained-staging-menu-mission-oct27');O=H/'ops';ROOT=pathlib.Path('/home/user/wine-assembly');R='/tmp/alien-cleanup-menu-mission-oct27';BOX='bx_yydnx5av'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,j):
 p=O/n;t=p.with_suffix(p.suffix+'.new');t.write_text(json.dumps(j,indent=2)+'\n');t.replace(p)
def alloc(p):
 total=0
 for x in [p,*p.rglob('*')] if p.is_dir() else [p]:
  try:total+=x.lstat().st_blocks*512
  except FileNotFoundError:pass
 return total
def admission():
 tasks=['alien-retained-staging-menu-mission-oct27','enigma-full-frame-terminal-startgame-oct27','airstrike-sixteen-capture-ordinary-quit-oct27','ricochet-measured-cpu-round-gameplay-oct27','penguin-accepted-causal-main-integration-oct27']
 peers=[]
 for name in tasks:
  used=alloc(pathlib.Path('/tmp')/name)+alloc(ROOT/'scratch/usage-watch'/name)
  peers.append(dict(task=name,actual=used,remaining=max(0,128*2**20-used)))
 future=sum(x['remaining'] for x in peers)+max(0,5-len(peers))*128*2**20+16*2**20
 clients=[]
 for p in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   a=(p/'cmdline').read_bytes()
   if a.split(b'\0')[0].endswith(b'/codex') and b'wine-worker\0' in a and b'\0-m\0' in a:
    clients.append(dict(pid=int(p.name),rss=int((p/'statm').read_text().split()[1])*4096))
  except (OSError,ValueError):pass
 ram=sum(max(0,320*2**20-x['rss']) for x in clients)+max(0,5-len(clients))*320*2**20+256*2**20+805306368
 mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;free=shutil.disk_usage(H).free
 j=dict(at=time.time(),peers=peers,clients=clients,free=free,projectedFree=free-future,memAvailable=mem,remainingRAM=ram,own=alloc(H),cap=128*2**20,actualRSSAlreadyInMemAvailable=True)
 save('admission.json',j);assert free-future>=2982150144 and mem>=ram and alloc(H)<88*2**20,j
 return j
def remote(cmd,timeout=30,detach=False):
 admission();assert len(cmd.encode())<=60000
 prior=sum(p.stat().st_size for p in O.glob('api-*.stdout'))+sum(p.stat().st_size for p in O.glob('api-*.stderr'))
 assert prior+8192+1024*1024<=8*2**20,'API envelope reserve exhausted'
 a=['boat','--no-update','--json','exec']+(['--detach'] if detach else ['--timeout',str(timeout)])+[BOX,cmd]
 k='api-'+str(time.time_ns());save(k+'.request.json',dict(commandSHA256=sha(cmd.encode()),bytes=len(cmd.encode()),argvPrefix=a[:-1],pendingResponseReserve=8192,cumulativeBefore=prior))
 with (O/(k+'.stdout')).open('wb') as out,(O/(k+'.stderr')).open('wb') as err:
  p=subprocess.run(a,stdout=out,stderr=err,timeout=timeout+15)
 b=(O/(k+'.stdout')).read_bytes();e=(O/(k+'.stderr')).read_bytes();assert len(b)+len(e)<=8192
 j=json.loads(b);save(k+'.json',dict(returncode=p.returncode,responseBytes=len(b)+len(e),responseSHA256=sha(b),at=time.time()))
 assert not p.returncode and (detach or j.get('exitCode')==0) and not j.get('stdoutTruncated') and not j.get('stderrTruncated'),j
 return j
def py(c,**kw):return remote('python3 -c '+shlex.quote(c),**kw)
M=ROOT/'scratch/usage-watch/alien-cleanup-verified-runtime-map-oct27.json'
assert sha(M.read_bytes())=='d8c670ba75041e084e2be480ee17238ce41832fc721bc5ee1d54053c95ac4ca4'
rows=json.loads(M.read_text())['files'];assert len(rows)==617
for x in rows:x.setdefault('mode',pathlib.Path(x['source']).stat().st_mode&511)
def transfer(target,p,offset=0):
 b=p.read_bytes();mode=p.stat().st_mode&0o777
 for off in range(offset,len(b),30000):
  chunk=b[off:off+30000];enc=base64.b64encode(zlib.compress(chunk)).decode()
  code='import pathlib,base64,zlib,hashlib,os;p=pathlib.Path('+repr(R+'/'+target)+');p.parent.mkdir(parents=True,exist_ok=True);b=zlib.decompress(base64.b64decode('+repr(enc)+'));assert hashlib.sha256(b).hexdigest()=='+repr(sha(chunk))+';assert (p.stat().st_size if p.exists() else 0)=='+str(off)+';p.open("ab").write(b);os.chmod(p,'+str(mode)+');print("written",len(b))'
  py(code)
if __name__=='__main__':
 op=sys.argv[1];admission()
 if op=='verify':
  expected=[{k:x[k] for k in ['target','sha256','bytes','mode']} for x in rows]
  enc=base64.b64encode(zlib.compress(json.dumps(expected).encode())).decode()
  code='import pathlib,json,base64,zlib,hashlib,shutil;h=pathlib.Path('+repr(R)+');rows=json.loads(zlib.decompress(base64.b64decode('+repr(enc)+')));missing=[];bad=[]\nfor i,x in enumerate(rows):\n p=h/x["target"]\n if not p.exists():missing.append([i,0]);continue\n n=p.stat().st_size\n if n==x["bytes"] and hashlib.file_digest(p.open("rb"),"sha256").hexdigest()==x["sha256"] and p.stat().st_mode&511==x["mode"]:continue\n if n<x["bytes"]:missing.append([i,n,hashlib.file_digest(p.open("rb"),"sha256").hexdigest()]);continue\n bad.append(i)\nprint(json.dumps(dict(missing=missing,bad=bad,free=shutil.disk_usage(h).free,memAvailable=int(pathlib.Path("/proc/meminfo").read_text().split("MemAvailable:")[1].split()[0])*1024)))'
  j=json.loads(py(code)['stdout']);assert not j['bad'];save('remote-verify.json',j)
  for a in j['missing']:
   x=rows[a[0]];p=pathlib.Path(x['source']);assert p.stat().st_size==x['bytes'] and sha(p.read_bytes())==x['sha256']
   if len(a)>2:assert sha(p.read_bytes()[:a[1]])==a[2]
  save('remaining.json',j['missing']);print(json.dumps(dict(missing=len(j['missing']),partial=[x for x in j['missing'] if x[1]],free=j['free'])))
 elif op=='stage':
  remaining=json.loads((O/'remaining.json').read_text());a=int(sys.argv[2]);group=remaining[a:a+20];start=time.monotonic()
  for i,off,*_ in group:
   assert time.monotonic()-start<90,'group90s predispatch deadline'
   x=rows[i];transfer(x['target'],pathlib.Path(x['source']),off)
   save('progress.json',dict(lastIndex=i,nextGroup=a+len(group),at=time.time()))
  print('completed',a,len(group),time.monotonic()-start)
