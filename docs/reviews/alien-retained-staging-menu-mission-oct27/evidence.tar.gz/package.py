from task import *
import tarfile,io
admission()
remote=O/'remote';sup=json.loads((remote/'guest-supervision.json').read_text());cleanup=json.loads((remote/'guest/cleanup.json').read_text());ledger=json.loads((remote/'guest/sequence-ledger.json').read_text())
assert sup['stopReason']=='aggregate CPU limit' and sup['cleanupComplete'] and not cleanup['remainingOwnedLive']
assert json.loads((O/'remote-verify.json').read_text())['missing']==[]
assert '[input] click 98,296 at batch 4722' in (remote/'guest-streams/stdout.log').read_text()
assert sha((O/'menu-before.png').read_bytes())==sha((O/'new-game-response.png').read_bytes())=='52c354de883bf99e0d7ab65faae0d7dc6ae21e82dd07bacc0b101b32d0ec3fe5'
apiBytes=sum(p.stat().st_size for p in O.glob('api-*.stdout'))+sum(p.stat().st_size for p in O.glob('api-*.stderr'));assert apiBytes+2**20<8*2**20
result=dict(status='BLOCKED_AGGREGATE_CPU_AFTER_REVIEWED_MENU_CLICK',task=H.name,session=os.environ.get('CODEX_THREAD_ID'),source='ebf70036c96e0c3267b4943822a446a0b13e8336',branch='task/'+H.name,staging=dict(files=617,hashSizeModePass=True,remaining=0,missingOnly=True,maximumFilesPerGroup=20,retainedRoot=R),startup=dict(node='24.22.1',heapMiB=2048,DATA='unlimited',AS='unlimited',CPU=90,file=24*2**20,registeredFiles=431,wasmBytes=1880280,wasmSHA256='f3f3cd439c50a2bc441de67c5f138e32cc060186d84d37d85de2b200ca806d75',canonicalParserPass=True,distinctStdoutStderr=True),guest=dict(invocations=1,commandId='cmd_wcylrxz03bwn',runId=ledger['runId'],startedAt='2026-10-27T09:20:17.754Z',reviewedMenu=True,menuBatch=4722,menuSHA256=sha((O/'menu-before.png').read_bytes()),approvalBeforeInput=True,actualInputLog='[input] click 98,296 at batch 4722',newGameResponseBatch=5234,newGameResponseIdenticalToMenu=True,mission=False,gameplay=False,ordinaryQuit=False,lastAcknowledgedBatch=ledger['lastAcknowledgedBatch'],lastFrozenBatch=ledger['lastFrozenBatch'],pending=ledger['pending'],supervisor=sup,cleanup=cleanup,generatedCaptures=2,reviewedCaptures=2),API=dict(rawBytes=apiBytes,cap=8*2**20,rawEachCap=8192,terminalReserve=2**20,noGuardReplay=True),lifecycle=dict(box=BOX,state='RUNNING_API_EXEC_OBSERVED',owner='coordinator',guestCutoff='2026-10-27T09:30:00Z',handback='2026-10-27T09:32:00Z',shutdown='2026-10-27T09:35:00Z',expiry='2026-10-27T09:43:30Z',workerStopResumeDelete=False),sourceEdits=False,mainWrite=False,publicDeployment=False,workersSpawned=False,remaining=['Menu transition after actual acknowledged click','Mission selection and actual gameplay','Ordinary Quit'],incidents='historical-incidents.json')
save('result.json',result)
save('checkpoint.json',dict(phase='BLOCKED_RUNTIME_COMPLETE_EVIDENCE_READY',result='result.json',reusedAcceptance='reused-acceptance.json',remaining=result['remaining'],noRepeatExecution=True,remoteCleanup='remote/guest/cleanup.json',freshOwnedAbsence='remote-recovery.json'))
files=[p for p in sorted(O.rglob('*')) if p.is_file() and p.name not in ['evidence-manifest.json','package-validation.json'] and '__pycache__' not in p.parts]
manifest=[dict(path=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in files];save('evidence-manifest.json',manifest)
d=H/'repo/docs/reviews'/H.name;d.mkdir(parents=True,exist_ok=True)
archive=d/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(O)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 actual=[dict(path=x.name,bytes=x.size,sha256=sha(t.extractfile(x).read())) for x in t]
assert actual==manifest
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(d/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(d/'REPORT.md').write_text('''# Alien retained staging and reviewed menu attempt

Completed and verified all 617 exact runtime files by size, SHA-256 and mode. Existing complete files and the verified prefix of the partial file were retained; only missing portions transferred in supervised groups of at most 20 files. No compile or source repair occurred. Exact Node 24.22.1, heap 2048 MiB, unlimited DATA/AS, CPU90 and file24MiB startup passed with canonical registered-file parser enumeration of431 files and the pinned1880280-byte module. Distinct process stdout/stderr, original initializer and original supervisor/controller identities are retained. Prior accepted groups were reused without replay.

One guest invocation reached the actual Alien Shooter main menu at frozen batch4722. The complete221145-byte image was transferred, hash checked and visually reviewed before matching New Game approval. Production stdout records the actual click at98,296 at batch4722. The next captured frame at5234 is byte-identical to the reviewed main menu: it proves no visible transition. The final completed step acknowledged5490 followed by frozen zero; the next256-batch step remained pending when the trusted supervisor stopped at aggregate CPU limit. No replay, reset, semantic change, mission/gameplay claim or ordinary Quit occurred. The final outer receipt reports193.815829 conservatively charged CPU seconds including cleanup,73.051995wall and580911104-byte peakRSS. This final charge is not claimed to be the threshold-crossing measurement. Both original cleanup and fresh exact PID/start checks show no owned live processes.

The assigned bx_yydnx5av remains RUNNING and retained files are recoverable. Coordinator owns09:30 guest cutoff,09:32 handback,09:35 snapshot-stop,09:43:30 expiry UTC. The worker does not stop/delete/resume it. Root tracked files/index/refs and immutable donors were read only; initial launcher root-ref digest reused, no later comparison claimed. No main ownership, public deployment or worker launch.

Preserved incidents include the predecessor's wall-limit and ops-bucket overage, this task's missing-mode setup error before API, conservative client-detector admission failure and its actual-launch-flag correction, obsolete retained-sidecar overreservation, and omitted initial WAL baseline. Current WAL is a conservative growth upper bound, not an exact positive-growth compliance claim. API raw responses are individually bounded8192B; complete frame and recovery envelopes were reserved before chunk dispatch with1MiB cleanup reserve. Each request has an environment-safe command hash and distinct stdout/stderr; encoded transfer bodies were not retained. Local/Git operations remain under the shared two-permit pool and production Git flock; DATA512MiB applies only to the Git child. No limit was relaxed.

The archive and manifest preserve causal diagnostics, complete startup/controller ledgers, process streams and cleanup, exact configuration pins, admissions and failed setup receipts. Every archived payload was hash-verified once; passed behavior suites were not repeated for packaging. Mission/gameplay and ordinary Quit remain open. Any next attempt requires a coordinator-assigned bounded task and fresh real admission; this worker stops on the concrete CPU blocker.
''')
run=H/'repo/scratch/runs'/H.name;run.mkdir(parents=True,exist_ok=True)
for name in ['menu-before.png','new-game-response.png']:(run/name).write_bytes((O/name).read_bytes())
capture=dict(candidateId='reflexive-alien-shooter',startedAt='2026-10-27T09:20:17.754Z',outcome='failed',verification='reviewed',summary='Reviewed main menu; actual New Game click logged, response identical; aggregate CPU stop before mission or gameplay.',route='main-menu',screenshots=['menu-before.png','new-game-response.png'],build=dict(commit=result['source'],wasmSHA256=result['startup']['wasmSHA256']),environment=dict(node='24.22.1',renderer='software D3D9',viewport='640x480'),artifacts=[])
(run/'result.json').write_text(json.dumps(capture,indent=2)+'\n')
save('package-validation.json',dict(payloads=len(manifest),archiveBytes=archive.stat().st_size,archiveSHA256=sha(archive.read_bytes()),hashRoundtripPass=True,ownAllocated=alloc(H)))
print(json.dumps(json.loads((O/'package-validation.json').read_text())))
