from task import *
prior=pathlib.Path('/tmp/alien-cleanup-menu-mission-oct27/ops')
N=str(H)
for name in ['guest-argv.json','capture-wrapper.cjs','parser.cjs','configuration-pins.json']:
 (O/name).write_bytes((prior/name).read_bytes())
a=json.loads((O/'guest-argv.json').read_text())
# Keep original production executable, flags and initializer; only output wrapper home is new.
(O/'exec-node.py').write_bytes((prior/'exec-node.py').read_bytes())
startup=a[:3]+['-e','console.log(JSON.stringify({node:process.version,execPath:process.execPath,argv:process.execArgv}));console.error("STARTUP_STDERR_DISTINCT");require('+json.dumps(R+'/runner/parser.cjs')+');const fs=require("fs"),crypto=require("crypto");let b=fs.readFileSync('+json.dumps(R+'/current.wasm')+');console.log(JSON.stringify({wasmBytes:b.length,wasmSHA256:crypto.createHash("sha256").update(b).digest("hex")}));']
save('startup-argv.json',startup)
s=(prior/'remote-run.py').read_text().replace('1793092500','1793093400').replace("str(h/'runner/tools/alien-supervised-gameplay.py')",repr(R+'/runner/tools/alien-supervised-gameplay.py')).replace("str(h/'runner')",repr(R+'/runner'))
# Remote aggregate materialization includes retained exact inputs as well as this invocation.
s=s.replace("total=sum(x.lstat().st_blocks*512 for x in [h,*h.rglob('*')] if x.exists())","total=sum(x.lstat().st_blocks*512 for root in [h,pathlib.Path("+repr(R)+")] for x in [root,*root.rglob('*')] if x.exists())")
(O/'remote-run.py').write_text(s)
# Distinct stdout/stderr exist from exec wrapper initialization, including failed setup.
s=(O/'exec-node.py').read_text();s=s.replace("receipt=dict(argv=a", "for fd,name in [(1,'stdout.log'),(2,'stderr.log')]:\n f=os.open(d/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.dup2(f,fd);os.close(f)\nreceipt=dict(argv=a")
s=s[:s.index("for fd,name",s.index("receipt=dict"))]+"os.chdir("+repr(R+'/runner')+")\nos.execvpe(a[0],a,os.environ)\n"
(O/'exec-node.py').write_text(s)
# Transfer helper writes beneath retained root: use relative traversal only to exact owned new task home.
items=[('guest-argv.json',O/'guest-argv.json'),('startup-argv.json',O/'startup-argv.json'),('exec-node.py',O/'exec-node.py'),('remote-run.py',O/'remote-run.py'),('trusted-supervisor.py',pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo/test/helpers/palette-browser-supervisor.py'))]
for target,p in items:transfer('../'+H.name+'/'+target,p)
save('fresh-configuration.json',dict(home=N,retainedInputRoot=R,source='ebf70036c96e0c3267b4943822a446a0b13e8336',argv=a,guestCutoff=1793093400,files={p.name:sha(p.read_bytes()) for _,p in items}))
print('configuration staged')
