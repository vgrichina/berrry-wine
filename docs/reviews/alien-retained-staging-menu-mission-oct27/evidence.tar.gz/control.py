from task import *
N=str(H)
op=sys.argv[1]
if op=='startup':
 j=remote('cd '+shlex.quote(R+'/runner')+' && python3 '+shlex.quote(N+'/remote-run.py')+' startup',timeout=20);save('startup-api.json',j);print(j['stdout'])
elif op=='launch':
 assert time.time()+120<1793093400
 j=remote('cd '+shlex.quote(R+'/runner')+' && python3 '+shlex.quote(N+'/remote-run.py')+' guest',detach=True);save('guest-api-launch.json',j);print(json.dumps(j))
elif op in ['status','guest-status']:
 names=['startup-supervision.json','startup-streams/startup.json','startup-streams/stdout.log','startup-streams/stderr.log'] if op=='status' else ['guest/menu-frame.json','guest/terminal.json','guest/result.json','guest/original-child.json','guest/startup-usage.json','guest-supervision.json','guest-streams/stderr.log','guest-streams/stdout.log']
 j=py('import pathlib,json,time;h=pathlib.Path('+repr(N)+');names='+repr(names)+';r={n:(h/n).read_text()[:1600] for n in names if (h/n).is_file()};print(json.dumps(r))');save('status-'+str(time.time_ns())+'.json',j);print(j['stdout'])
elif op=='fetch':
 name=sys.argv[2];assert name in ['menu-before.png','new-game-response.png','mission-observation.png','before-quit.png']
 j=py('import pathlib,zlib,hashlib,json; p=pathlib.Path('+repr(N+'/guest/'+name)+');b=p.read_bytes();c=zlib.compress(b);print(json.dumps(dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),compressed=len(c))))');v=json.loads(j['stdout']);assert v['bytes']<=2*2**20
 for existing in O.glob('*.png'):
  b=existing.read_bytes()
  if len(b)==v['bytes'] and sha(b)==v['sha256']:
   (O/name).write_bytes(b);save('frame-exact-reuse-'+name+'.json',dict(source=str(existing),**v,remoteFreshHashVerified=True));print('exact frame reused',name,v['sha256']);sys.exit(0)
 chunks=(v['compressed']+4095)//4096
 prior=sum(p.stat().st_size for p in O.glob('api-*.stdout'))+sum(p.stat().st_size for p in O.glob('api-*.stderr'))
 assert prior+chunks*8192+2**20<=8*2**20,'entire frame plus cleanup envelope rejected before chunk dispatch'
 save('frame-envelope-'+name+'.json',dict(**v,chunks=chunks,responseEnvelope=chunks*8192,prior=prior,terminalReserve=2**20,pendingCounted=True))
 parts=[]
 for i in range(chunks):
  j=py('import pathlib,zlib,base64; b=zlib.compress(pathlib.Path('+repr(N+'/guest/'+name)+').read_bytes());print(base64.b64encode(b['+str(i*4096)+':'+str((i+1)*4096)+']).decode())');parts.append(base64.b64decode(j['stdout'].strip()))
 b=zlib.decompress(b''.join(parts));assert len(b)==v['bytes'] and sha(b)==v['sha256'];(O/name).write_bytes(b);print(json.dumps(dict(path=str(O/name),**v)))
elif op=='approve':
 frame=json.loads(json.loads(py('import pathlib;print(pathlib.Path('+repr(N+'/guest/menu-frame.json')+').read_text())')['stdout']) if False else '{}')
 j=py('import pathlib,json;h=pathlib.Path('+repr(N+'/guest')+');f=json.loads((h/"menu-frame.json").read_text());a=dict(humanReviewed=True,action="New Game",runId=f["runId"],batch=f["batch"],reviewId="same-run-agent-visual-review-oct27",frameSHA256=f["sha256"],command="click:98:296");assert not (h/"approval.json").exists();(h/"approval.json").write_text(json.dumps(a));print(json.dumps(a))');save('approval-api.json',j);print(j['stdout'])
elif op=='collect':
 j=py('import pathlib,json;h=pathlib.Path('+repr(N)+');files=[p for p in h.rglob("*") if p.is_file() and p.suffix!=".png"];r=[dict(path=str(p.relative_to(h)),bytes=p.stat().st_size) for p in files];print(json.dumps(r))');save('remote-evidence-index.json',j);print(j['stdout'])
