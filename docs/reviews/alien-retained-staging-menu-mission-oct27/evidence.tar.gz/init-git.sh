set -eu
gitop() {
 python3 /home/user/wine-assembly/scratch/usage-watch/light-execution-pool-oct26.py --slots 2 -- python3 /tmp/alien-retained-staging-menu-mission-oct27/ops/git-guard.py "$@"
}
gitop init -b task/alien-retained-staging-menu-mission-oct27
mkdir -p /tmp/alien-retained-staging-menu-mission-oct27/repo/.git/objects/info /tmp/alien-retained-staging-menu-mission-oct27/repo/.git/info
printf '%s\n' /tmp/alien-supported-owner-accepted-main-integration-oct27/repo/.git/objects > /tmp/alien-retained-staging-menu-mission-oct27/repo/.git/objects/info/alternates
printf '%s\n' /docs/reviews/alien-retained-staging-menu-mission-oct27/ > /tmp/alien-retained-staging-menu-mission-oct27/repo/.git/info/sparse-checkout
gitop config core.sparseCheckout true
gitop config core.sparseCheckoutCone false
gitop config gc.auto 0
gitop config user.name 'Wine Ops'
gitop config user.email wine-ops@users.noreply.github.com
gitop remote add origin git@github.com:vgrichina/wine-assembly.git
gitop update-ref refs/heads/task/alien-retained-staging-menu-mission-oct27 ebf70036c96e0c3267b4943822a446a0b13e8336
gitop read-tree -mu ebf70036c96e0c3267b4943822a446a0b13e8336
