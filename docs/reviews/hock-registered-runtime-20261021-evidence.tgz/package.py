import pathlib,json,hashlib,tarfile,datetime,os
r=pathlib.Path(__file__).resolve().parent
assert os.statvfs(r).f_bavail*os.statvfs(r).f_frsize>2285895680+600000000+64*1024*1024
result={'candidateId':'hock-a-loogie-1995','agentId':'codex:hock-registered-runtime-oct21','startedAt':'2026-10-21T08:48:03.747Z','finishedAt':'2026-10-21T08:50:58.225Z','outcome':'timeout','route':'registered-candidate-cli-smoke','command':'NODE_OPTIONS=--require=/home/user/hock-registered-runtime/evidence/observe.cjs node test/test-cli-candidate-corpus.js --id=hock-a-loogie-1995 --strict','build':{'commit':'d4ba733fb0d1c9e6d67ff0db715a5c0535307e6f','dirtyPatchSha256':None,'wasmSha256':'a5972cbaf915aa1d155b301da5fae1c80298b2be381034945c7e58cc81e02f72','canonicalWasmSha256':'728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c'},'environment':{'host':'bx_egnm3u4y','mode':'CLI registered candidate consumer','engine':'Node v24.18.1','renderer':'CLI default JS raster; no screenshot','threadMode':'default; guest worker thread observed'},'summary':'Fresh canonical all-gates build passed; actual registered CLI exits1 BLOCKED timeout (0ready1blocked0skipped). Default 120s child timeout failed to finish child; externally killed owned overdue child after approximately171s to recover ETIMEDOUT logs. Original39files/38companions verified. Browser catalog has no Hock app route. No gameplay or screenshot acceptance.','verification':'reviewed','artifacts':['remote-evidence/build.log','remote-evidence/corpus.log','remote-evidence/guest.stdout.log','remote-evidence/guest.stderr.log','remote-evidence/actual-child-command.json','remote-evidence/actual-child-result.json','remote-evidence/actual-vfs-resolution.json','remote-evidence/identity-after.json','remote-evidence/payload-verification.json','remote-evidence/browser-route.json','child-termination-receipt.json','corpus-overdue.json','RECOVERY.md']}
tmp=r/'result.json.tmp';tmp.write_text(json.dumps(result,indent=2)+'\n');tmp.rename(r/'result.json')
files=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.json','.py','.cjs','.sh','.md'] and p.name not in ['publication.json']]
files+=list((r/'remote-evidence').rglob('*'))
files=[p for p in files if p.is_file()]
seals={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
archive=r/'repo/docs/reviews/hock-registered-runtime-20261021-evidence.tgz'
with tarfile.open(archive,'w:gz') as t:
    for p in sorted(files):t.add(p,arcname=str(p.relative_to(r)),recursive=False)
    import io
    b=(json.dumps(seals,indent=2)+'\n').encode();m=tarfile.TarInfo('SHA256SUMS.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
    saved=json.load(t.extractfile('SHA256SUMS.json'))
    for n,h in saved.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
    inner=json.load(t.extractfile('remote-evidence/SHA256SUMS.json'))
    for n,h in inner.items():assert hashlib.sha256(t.extractfile('remote-evidence/'+n).read()).hexdigest()==h,n
for p in result['artifacts']:assert (r/p).is_file(),p
receipt={'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archiveBytes':archive.stat().st_size,'outerSeals':len(seals),'innerSeals':len(inner),'artifactPaths':'all exist','resultSchema':'required fields present; timeout; reviewed logs, no screenshot claim'}
(r/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
