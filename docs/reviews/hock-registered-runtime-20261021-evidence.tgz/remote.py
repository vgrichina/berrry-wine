import subprocess, sys, json, base64
from pathlib import Path
ROOT = Path(__file__).resolve().parent
def run(command, receipt, timeout=600):
    result = subprocess.run(['boat','exec','bx_egnm3u4y','--timeout',str(timeout),'--json','--','bash','-lc',command], capture_output=True, text=True)
    (ROOT/receipt).write_text(result.stdout)
    if result.stderr: print(result.stderr)
    try:
        data=json.loads(result.stdout); print(data.get('stdout','')); print(data.get('stderr','')); return data
    except Exception: print(result.stdout); raise
def upload(local, remote):
    encoded=base64.b64encode(Path(local).read_bytes()).decode()
    import shlex
    return run('mkdir -p '+shlex.quote(str(Path(remote).parent))+' && printf %s '+shlex.quote(encoded)+' | base64 -d > '+shlex.quote(remote), 'upload-'+Path(local).name+'.json')
if __name__=='__main__':
    if sys.argv[1]=='upload': upload(*sys.argv[2:])
    else: run(Path(sys.argv[1]).read_text(),sys.argv[2])
