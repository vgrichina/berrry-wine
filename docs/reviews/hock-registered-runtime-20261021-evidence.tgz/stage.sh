set -e
cd /home/user/hock-registered-runtime
python3 intake/recover.py > evidence/recovery.log 2>&1
mkdir -p repo/test/binaries/candidates/hock-a-loogie-1995/distribution
cp -a intake/extracted/. repo/test/binaries/candidates/hock-a-loogie-1995/distribution/
cd repo
node tools/fetch-candidate-corpus.js --id=hock-a-loogie-1995 --prepare > ../evidence/fetch-prepare.log 2>&1
cd ..
python3 - <<'PY'
import json,hashlib,pathlib,subprocess
r=pathlib.Path('.')
seals=json.loads((r/'evidence/accepted-package-seals.json').read_text())
fixture=r/'repo/test/binaries/candidates/hock-a-loogie-1995'
verified=[]
for name,sha in seals.items():
    p=r/'intake'/name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==sha,name
    if name.startswith('game/'):
        assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==sha,name
        verified.append({'path':name,'size':p.stat().st_size,'sha256':sha})
assert len(verified)==39
inventory=json.loads((fixture/'.wine-assembly-browser.json').read_text())
assert len(inventory['files'])==38
for row in inventory['files']:
    p=fixture/row['url']
    assert row['vfsPath']=='c:\\'+p.name
    assert row['size']==p.stat().st_size
    assert hashlib.sha256(p.read_bytes()).hexdigest()==seals[row['url']]
(r/'evidence/payload-verification.json').write_text(json.dumps({'verifiedOriginalFiles':verified,'companions':inventory,'packageSealCount':len(seals)},indent=2))
source={}
repo=r/'repo'
for name in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'):
    if name: source[name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
(r/'evidence/source-sha256.json').write_text(json.dumps(source,indent=2))
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo)
print('PASS exact clean source',len(source),'files; original seals',len(seals),'all39files/38companions')
PY
