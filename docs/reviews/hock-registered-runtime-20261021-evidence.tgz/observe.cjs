// Observation only: preserve original argv, options, return values and bytes.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cp = require('child_process');
const Module = require('module');
const out = '/home/user/hock-registered-runtime/evidence';
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
const originalSpawn = cp.spawnSync;
cp.spawnSync = function(command, args, options) {
  const guest = args?.some(a => String(a).endsWith('/test/run.js'));
  if (guest) {
    const wasm = args.find(a => a.startsWith('--wasm='))?.slice(7);
    fs.writeFileSync(path.join(out,'actual-child-command.json'),JSON.stringify({command,args,cwd:options.cwd,timeout:options.timeout,wasmSha256:sha(fs.readFileSync(wasm)),canonicalSha256:sha(fs.readFileSync(path.join(options.cwd,'build/wine-assembly.wasm')))},null,2));
  }
  const result = Reflect.apply(originalSpawn,this,arguments);
  if (guest) {
    fs.writeFileSync(path.join(out,'guest.stdout.log'),result.stdout || '');
    fs.writeFileSync(path.join(out,'guest.stderr.log'),result.stderr || '');
    fs.writeFileSync(path.join(out,'actual-child-result.json'),JSON.stringify({status:result.status,signal:result.signal,error:result.error || null},null,2));
  }
  return result;
};
const originalLoad=Module._load;
const observed=new WeakSet();
Module._load=function(request,parent,isMain) {
  const value=Reflect.apply(originalLoad,this,arguments);
  if (request.includes('vfs-host-files') && value.expandIncludePatterns && !observed.has(value)) {
    observed.add(value);
    const original=value.expandIncludePatterns;
    value.expandIncludePatterns=function() {
      const result=Reflect.apply(original,this,arguments);
      fs.writeFileSync(path.join(out,'actual-vfs-resolution.json'),JSON.stringify({exeDir:arguments[0],patterns:arguments[1],files:result.map(f=>({...f,sha256:sha(fs.readFileSync(f.hostPath))}))},null,2));
      return result;
    };
  }
  return value;
};
