set -e
cd /home/user/hock-registered-runtime
test -f evidence/corpus.exit
python3 evidence/identity.py > evidence/final-verification.log
cp intake/recover.py evidence/recover-original.py
python3 - <<'PY'
import pathlib,json,hashlib,tarfile
r=pathlib.Path('.'); e=r/'evidence'
seals={str(p.relative_to(e)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(e.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'}
(e/'SHA256SUMS.json').write_text(json.dumps(seals,indent=2))
with tarfile.open('evidence.tgz','w:gz') as t:t.add(e,arcname='remote-evidence')
b=(r/'evidence.tgz').read_bytes()
print(json.dumps({'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'files':len(seals)}))
PY
