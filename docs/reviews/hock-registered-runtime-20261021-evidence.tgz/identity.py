import pathlib,json,hashlib,subprocess
r=pathlib.Path('/home/user/hock-registered-runtime'); repo=r/'repo'; e=r/'evidence'
def sha(b): return hashlib.sha256(b).hexdigest()
source=json.loads((e/'source-sha256.json').read_text())
assert all(sha((repo/n).read_bytes())==s for n,s in source.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()=='d4ba733fb0d1c9e6d67ff0db715a5c0535307e6f'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo)
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for entry in subprocess.check_output(['git','ls-tree','-rz','HEAD'],cwd=repo).split(b'\0'):
    if not entry:continue
    meta,name=entry.split(b'\t',1); mode,kind,oid=meta.split()
    assert kind==b'blob'
    proc.stdin.write(oid+b'\n');proc.stdin.flush()
    header=proc.stdout.readline().split();data=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n'
    assert sha(data)==source[name.decode()],name
proc.stdin.close();assert proc.wait()==0
canonical=(repo/'build/wine-assembly.wasm').read_bytes()
observed=(r/'candidate-corpus-observed.wasm').read_bytes()
def sections(b):
    def leb(pos):
        v=0;shift=0
        while True:
            x=b[pos];pos+=1;v|=(x&127)<<shift
            if x<128:return v,pos
            shift+=7
    out=[];pos=8
    while pos<len(b):
        start=pos;kind=b[pos];size,body=leb(pos+1);pos=body+size
        name=None
        if kind==0:
            n,p=leb(body);name=b[p:p+n].decode()
        out.append({'id':kind,'customName':name,'size':size,'sha256':sha(b[start:pos])})
    return out
cs=sections(canonical);os=sections(observed)
assert cs[:-1]==os
assert cs[-1]['id']==0 and cs[-1]['customName']=='wine-region-layout'
assert canonical[:len(observed)]==observed
vfs=json.loads((e/'actual-vfs-resolution.json').read_text())
seals=json.loads((e/'accepted-package-seals.json').read_text())
assert len(vfs['files'])==39
for f in vfs['files']:
    assert f['sha256']==seals['game/'+f['guestPath']]
    assert sha(pathlib.Path(f['hostPath']).read_bytes())==f['sha256']
out={'commit':'d4ba733fb0d1c9e6d67ff0db715a5c0535307e6f','trackedFilesVerifiedBeforeAfter':len(source),'trackedDirty':False,'node':subprocess.check_output(['node','--version']).decode().strip(),'canonical':{'size':len(canonical),'sha256':sha(canonical),'sections':cs},'consumer':{'size':len(observed),'sha256':sha(observed),'sections':os},'moduleDifference':'Consumer module is the exact canonical prefix, missing only appended wine-region-layout custom section; all other section bytes identical. No substitution was made.','actualVfsOriginalFilesVerified':39}
out['gitBlobsVerified']=len(source)
compat=(repo/'build/wine-assembly.compat.wasm').read_bytes()
out['compat']={'size':len(compat),'sha256':sha(compat)}
assert out['compat']['sha256']=='25519647def1c2a25f505a81743d21dec55472ede8780f809edf09b6bb231018'
for n,s in seals.items():assert sha((r/'intake'/n).read_bytes())==s,n
out['originalIntakeSealsReverified']=len(seals)
(e/'identity-after.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ['canonical','consumer']},indent=2))
