const fs=require('fs');
const path=require('path');
const root='/home/user/hock-registered-runtime/repo';
const {buildCatalog,launchFor}=require(root+'/ops/emulator-server');
const candidate=require(root+'/test/candidate-corpus/manifest.json').candidates.find(c=>c.id==='hock-a-loogie-1995');
(async()=>{
  const catalog=await buildCatalog(root);
  const launch=launchFor(candidate,catalog,null,{wasmSha256:'728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c'});
  const matches=catalog.routes.filter(r=>/\bhock|loogie/i.test(JSON.stringify(r)));
  const fixture='test/binaries/candidates/hock-a-loogie-1995/';
  const inventory=JSON.parse(fs.readFileSync(path.join(root,fixture,'.wine-assembly-browser.json')));
  const output={candidateId:candidate.id,candidateAppIds:candidate.appIds||null,launch,catalogMatches:matches,inventoryExists:true,inventoryCompanions:inventory.files.length,allowedHockFiles:[...catalog.allowed].filter(f=>f.includes(fixture)),scope:'Existing registered browser catalog only; no app selector or registry edits; no synthetic route.'};
  fs.writeFileSync('/home/user/hock-registered-runtime/evidence/browser-route.json',JSON.stringify(output,null,2));
  console.log(JSON.stringify(output,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
