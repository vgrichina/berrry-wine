# Hock registered-route runtime evidence

Exact tested source: d4ba733fb0d1c9e6d67ff0db715a5c0535307e6f.
Task branch: task/hock-registered-runtime-oct21. Publication receipt gives its
report commit and independently verified remote ref. No merge was performed.

Fetch that branch and extract docs/reviews/hock-registered-runtime-20261021-evidence.tgz
into an empty directory. Verify top-level SHA256SUMS.json and then every entry
of remote-evidence/SHA256SUMS.json. Read the adjacent report, actual-child-command.json,
actual-child-result.json, corpus.log and guest stdout/stderr. No screenshot exists.

Registered smoke failed ETIMEDOUT after its default 120-second SIGTERM failed to
finish the child. The verified owned child alone was killed at 08:50:58 UTC to
release captured logs. This does not authorize a retry, source repair or browser
registration. Browser inventory has 38 original companions but no registered
app association/launch route. Prior explicit-EXE scoring remains separate.

Assigned runtime bx_egnm3u4y is left running; expiry 2026-10-21T10:44:02.530Z.
Coordinator owns lifecycle. Do not create/resume/stop/delete boxes from this recipe.
Remote /home/user/hock-registered-runtime retains repo, intake, evidence and
candidate-corpus-observed.wasm (saved before the runner deleted its temporary copy).
Evidence preserved locally well before expiry. Runtime command access used Boat
exec; one read-only boat info receipt records state/expiry, with no lifecycle action.

For a separately authorized rebuild/reproduction on an assigned runtime:
1. Check out exact d4ba733 and install normal npm dependencies and p7zip-full.
2. Run bash tools/build.sh with all gates; compare canonical and compat hashes
   in the report. Never substitute an inherited module.
3. Copy remote-evidence/recover-original.py to an empty intake as recover.py;
   it retrieves only the pinned original archive and verifies extraction.
4. Follow stage.sh: stage extracted/ as fixture distribution/, then the real
   registered fetcher --prepare. Verify all 44 accepted intake seals and all
   39 fixture originals/38 browser companions. No binary is stored in Git.
5. The exact observed command is in the report. observe.cjs is an external
   observation-only preload. It preserves argv/options/results/VFS resolution
   and records logs. Future runs need new evidence paths and a separately
   authorized outer termination strategy; do not overwrite these artifacts.

Source identity: 7,253 SHA256s independently matched to Git blobs. Observed
consumer module differs from canonical only by the latter's appended 37-byte
wine-region-layout custom section; all executable sections are byte-identical.
identity.py verifies this without modifying either artifact.

Local cap 64 MiB, free floor 2285895680 bytes plus 600 MB transient reserve.
Sparse local repo borrows the existing combined-integration object store;
retain that chain. Commit/remote branch are the report recovery source if
ignored run files are lost. No ignored binaries or runtime are backed up by Git.
