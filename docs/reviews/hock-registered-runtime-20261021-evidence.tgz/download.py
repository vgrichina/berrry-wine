import pathlib,subprocess,json,base64,hashlib,tarfile,io,os
r=pathlib.Path(__file__).resolve().parent
free=os.statvfs(r).f_bavail*os.statvfs(r).f_frsize
assert free>2285895680+600000000+64*1024*1024
p=subprocess.run(['boat','exec','bx_egnm3u4y','--timeout','60','--json','--','base64','-w0','/home/user/hock-registered-runtime/evidence.tgz'],capture_output=True,text=True,check=True)
d=json.loads(p.stdout);assert d['exitCode']==0 and not d['stdoutTruncated']
b=base64.b64decode(d.pop('stdout'))
assert len(b)<8*1024*1024
(r/'download-receipt.json').write_text(json.dumps({**d,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()},indent=2))
with tarfile.open(fileobj=io.BytesIO(b)) as t:
    assert sum(m.size for m in t.getmembers())<16*1024*1024
    t.extractall(r,filter='data')
(r/'remote-evidence.tgz').write_bytes(b)
seals=json.loads((r/'remote-evidence/SHA256SUMS.json').read_text())
for n,h in seals.items():assert hashlib.sha256((r/'remote-evidence'/n).read_bytes()).hexdigest()==h,n
print('Verified preserved files',len(seals),'archive bytes',len(b))
