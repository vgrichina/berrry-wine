const fs=require('fs'),crypto=require('crypto'),cp=require('child_process');
const root='/home/user/hype-browser-fps',repo=root+'/repo',out=root+'/evidence';process.chdir(repo);
const src=JSON.parse(fs.readFileSync(out+'/source-manifest.json')),assets=JSON.parse(fs.readFileSync(out+'/assets.json'));
let sourceOK=0,assetOK=0;
for(const a of src.files){const b=fs.readFileSync(a.path),hash=crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');if(hash!==a.oid)throw Error('source mismatch '+a.path);sourceOK++;}
for(const a of assets){const b=fs.readFileSync(a.path);if(b.length!==a.bytes||crypto.createHash('sha256').update(b).digest('hex')!==a.sha256)throw Error('asset mismatch '+a.path);assetOK++;}
fs.writeFileSync(out+'/identity.json',JSON.stringify({base:src.base,sourceOK,assetOK,at:new Date().toISOString()},null,2));
for(const [name,args] of [['claude-size',['tools/check-claude-size.js']],['wat-manifest',['tools/check-wat-manifest.js']],['wat-fragments',['tools/check-wat-fragments.js']],['callback-census',['tools/callback-ownership-census.js']],['observer-tests',['--test','test/test-hype-glide-emission-observer.js']]]){
const r=cp.spawnSync('node',args,{encoding:'utf8',maxBuffer:8e6});fs.writeFileSync(out+'/'+name+'.log',r.stdout+r.stderr);fs.writeFileSync(out+'/'+name+'.json',JSON.stringify({command:['node',...args],exit:r.status,signal:r.signal},null,2));console.log(name,r.status,(r.stdout+r.stderr).slice(-2200));if(r.status!==0)process.exit(r.status||1);
}
