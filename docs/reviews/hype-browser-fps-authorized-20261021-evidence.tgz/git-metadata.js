const cp=require('child_process'),api=require('./file-api');
(async()=>{const base='b88c818ba3a071877e889e7cc779975a193591ce';const tree=cp.execFileSync('git',['rev-parse',base+'^{tree}']).toString().trim(),srcTree=cp.execFileSync('git',['rev-parse',base+':src']).toString().trim(),blob=cp.execFileSync('git',['rev-parse',base+':src/api_table.json']).toString().trim();
const objects=cp.execFileSync('git',['pack-objects','--stdout'],{input:[base,tree,srcTree,blob].join('\n')+'\n'});await api.upload('/home/user/hype-browser-fps/base-metadata.pack',objects);
console.log(api.exec(['bash','-lc',`cd /home/user/hype-browser-fps/repo && git init -q && git index-pack --stdin < ../base-metadata.pack && git update-ref refs/heads/pinned ${base} && git symbolic-ref HEAD refs/heads/pinned && git rev-parse HEAD && node tools/check-api-table.js`],'git-api-table'));
})().catch(e=>{console.error(e);process.exitCode=1});
