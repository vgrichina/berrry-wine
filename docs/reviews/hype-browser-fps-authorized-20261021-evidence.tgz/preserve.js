const fs=require('fs'),cp=require('child_process'),crypto=require('crypto'),api=require('./file-api');
(async()=>{
const root='/home/user/hype-browser-fps';
const verify=fs.readFileSync(__dirname+'/prerequisites.js','utf8').split("for(const [name,args]")[0].replace("'/identity.json'","'/identity-post.json'");
await api.upload(root+'/verify-post.js',Buffer.from(verify));
console.log(api.exec(['node',root+'/verify-post.js'],'post-source-verify',60));
console.log(api.exec(['bash','-lc',`cd ${root} && cp /home/user/.ascii/processes/21991.log evidence/browser2.log && cp /home/user/.ascii/processes/21991.err.log evidence/browser2.err.log && cp browser.js browser2.js measure-existing.js prerequisites.js verify-post.js evidence/ && tar -czf evidence-recovery.tgz evidence && sha256sum evidence-recovery.tgz`],'remote-preserve',60));
const data=await api.download(root+'/evidence-recovery.tgz');fs.writeFileSync(__dirname+'/evidence-recovery.tgz',data);fs.mkdirSync(__dirname+'/recovered',{recursive:true});cp.execFileSync('tar',['-xzf',__dirname+'/evidence-recovery.tgz','-C',__dirname+'/recovered']);
console.log('recovered',data.length,crypto.createHash('sha256').update(data).digest('hex'));
})().catch(e=>{console.error(e);process.exitCode=1});
