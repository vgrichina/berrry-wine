'use strict';
const fs=require('fs'),cp=require('child_process'),path=require('path'),crypto=require('crypto');
const puppeteer=require('/home/user/hype-browser-fps/deps/node_modules/puppeteer-core');
const root='/home/user/hype-browser-fps/repo',out='/home/user/hype-browser-fps/evidence/attempt2';fs.mkdirSync(out,{recursive:true});fs.mkdirSync(out+'/commands',{recursive:true});
const pause=ms=>new Promise(r=>setTimeout(r,ms)),save=(n,v)=>fs.writeFileSync(out+'/'+n,JSON.stringify(v,null,2));
let browser,page,server,closed=false;const events=[],errors=[],inputs=[];const start=Date.now();
async function state(){return page.evaluate(()=>{const a=runningApps.find(a=>a.name==='hype_glide_demo'),w=a?.wine;return {at:performance.now(),origin:performance.timeOrigin,running:!!w?.running,guestWorker:!!w?.guestWorker,backend:w?.threadManager?.backend,threads:[...(w?.threadManager?.threads||[])].map(([id,t])=>({id,state:t.state,instance:!!t.instance,link:!!t.link})),windows:Object.values(w?.renderer?.windows||{}).map(v=>({title:v.title,w:v.w,h:v.h,visible:v.visible})),endpoints:[...(w?._renderWorkerManager?.ports?.values()||[])].map(p=>({id:p.id,api:p.options.api,backend:p.options.backend,closed:p.closed})),log:document.getElementById('log')?.textContent?.slice(-7000)};});}
async function shot(name){await page.screenshot({path:out+'/'+name+'.png'});save(name+'.json',await state());console.log('shot',name);}
async function close(reason){if(closed)return;closed=true;save('console.json',events);save('errors.json',errors);save('inputs.json',inputs);await browser?.close();server?.kill('SIGTERM');save('cleanup.json',{at:new Date().toISOString(),reason,elapsedMs:Date.now()-start});}
process.on('SIGTERM',()=>close('SIGTERM'));
(async()=>{
server=cp.spawn('node',['tools/dev-server.js','--port=8080','--isolate'],{cwd:root,stdio:['ignore',fs.openSync(out+'/server.log','a'),fs.openSync(out+'/server.log','a')]});await pause(700);
browser=await puppeteer.launch({headless:false,executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--enable-unsafe-swiftshader','--disable-background-timer-throttling','--disable-renderer-backgrounding'],env:{...process.env,DISPLAY:':0'},protocolTimeout:30000,timeout:30000});page=await browser.newPage();await page.setViewport({width:1000,height:760});
page.on('console',m=>{if(events.length<3000)events.push({at:Date.now(),type:m.type(),text:m.text().slice(0,2500)})});page.on('pageerror',e=>errors.push(String(e)));
await page.goto('http://127.0.0.1:8080/index.html?app=hype_glide_demo&debug&glide-renderer=webgl',{waitUntil:'load',timeout:45000});
save('identity.json',{base:'b88c818ba3a071877e889e7cc779975a193591ce',moduleSha256:crypto.createHash('sha256').update(fs.readFileSync(root+'/build/wine-assembly.wasm')).digest('hex'),browser:await browser.version(),node:process.version,route:page.url(),startedAt:new Date(start).toISOString(),pid:process.pid,chromePid:browser.process().pid,deadlineSeconds:600,backendRequested:'webgl',device:'assigned bx_2ghgsv9d; renderer pending inspection'});
save('gpu.json',await (await browser.target().createCDPSession()).send('SystemInfo.getInfo'));await pause(15000);await shot('startup');console.log('ready');let n=0;
while(!closed&&Date.now()-start<600000){const file=out+'/commands/'+n+'.json';if(fs.existsSync(file)){const c=JSON.parse(fs.readFileSync(file));n++;try{
if(c.action==='shot')await shot(c.name);
else if(c.action==='key'){if(!['Enter','Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(c.key)||c.ms<50||c.ms>3000)throw Error('input bounds');inputs.push({at:new Date().toISOString(),...c});await page.keyboard.down(c.key);await pause(c.ms);await page.keyboard.up(c.key);await pause(c.settleMs||1000);await shot(c.name);}
else if(c.action==='inspect'){const rows=[];for(const w of page.workers()){let data;try{data=await w.evaluate(()=>({url:location.href,instance:typeof instance==='undefined'?null:!!instance,exports:typeof instance==='undefined'?[]:Object.keys(instance?.exports||{}).filter(k=>/logical|thread_id/.test(k))}));}catch(e){data={error:String(e)}}rows.push(data);}save(c.name+'.json',{state:await state(),workers:rows});}
else if(c.action==='measure'){
 const candidates=[];for(const w of page.workers()){try{const id=await w.evaluate(()=>typeof instance!=='undefined'&&instance?instance.exports.get_current_thread_id():-1);if(id===1)candidates.push(w);}catch{}}
 if(candidates.length!==1)throw Error('logical owner ambiguity '+candidates.length);const w=candidates[0];
 const code="6804cd7100e856f9020066a102cd7100668b0d00cd710083c4045051e84f7b020083c40885c07540683805000068b4685b0050e8d85c140083c40c8a15d0265b";
 save('counter-arm.json',await w.evaluate(expected=>{
 const ex=instance.exports,original=instance,buf=memory.buffer,read=()=>Array.from(new Uint8Array(memory.buffer,0x43f610-ex.get_image_base()+0x12000,64),x=>x.toString(16).padStart(2,'0')).join('');
 if(read()!==expected)throw Error('live callback authentication failed');
 ex.set_logical_frame(0x43f610,0);
 const record={at:performance.now(),origin:performance.timeOrigin,tid:ex.get_current_thread_id(),slot:workerSlot,code:read(),addr:ex.get_logical_frame_addr(),pace:ex.get_logical_frame_pace()};
 globalThis.__hype={ex,original,read,expected,rows:[],events:[],generation:'attempt2-owner1',timer:null};
 addEventListener('message',ev=>{const m=ev.data;if(m?.t==='callExport'&&m.name==='set_logical_frame')__hype.events.push({at:performance.now(),name:m.name,args:m.args});});return record;
 },code));
 await pause(2000);await shot('world-before-measure');
 await w.evaluate(()=>{const h=__hype;h.sample=()=>{const ex=h.ex;h.rows.push({hostMs:performance.now(),count:ex.get_logical_frame_count()>>>0,enabled:ex.get_logical_frame_addr()===0x43f610&&ex.get_logical_frame_pace()===0,generation:h.generation,owner:{instance:'attempt2-slot'+workerSlot,thread:ex.get_current_thread_id()},clockOrigin:String(performance.timeOrigin),sameInstance:instance===h.original,codeMatches:h.read()===h.expected});};h.sample();h.timer=setInterval(h.sample,100);});
 await pause(3000);inputs.push({action:'key',key:'ArrowUp',ms:600,at:new Date().toISOString(),duringMeasurement:true});await page.keyboard.down('ArrowUp');await pause(600);await page.keyboard.up('ArrowUp');await shot('during-up');
 await pause(3000);inputs.push({action:'key',key:'ArrowDown',ms:600,at:new Date().toISOString(),duringMeasurement:true});await page.keyboard.down('ArrowDown');await pause(600);await page.keyboard.up('ArrowDown');await shot('during-down');await pause(3000);
 save('logical-raw.json',await w.evaluate(()=>{clearInterval(__hype.timer);__hype.sample();return {samples:__hype.rows,events:__hype.events,origin:performance.timeOrigin,end:performance.now(),code:__hype.read()};}));await shot('world-after-measure');
 }
 else if(c.action==='quit'){await close('bounded completion');break;}
else throw Error('unknown command');save('progress.json',{done:n,at:new Date().toISOString()});
}catch(e){errors.push(String(e));save('command-error-'+n+'.json',{error:String(e),command:c});}}
await pause(250);}
await close('deadline');
})().catch(async e=>{errors.push(e.stack||String(e));console.error(e);await close('harness failure');process.exitCode=1});
