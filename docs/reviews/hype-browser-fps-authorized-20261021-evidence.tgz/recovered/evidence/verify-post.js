const fs=require('fs'),crypto=require('crypto'),cp=require('child_process');
const root='/home/user/hype-browser-fps',repo=root+'/repo',out=root+'/evidence';process.chdir(repo);
const src=JSON.parse(fs.readFileSync(out+'/source-manifest.json')),assets=JSON.parse(fs.readFileSync(out+'/assets.json'));
let sourceOK=0,assetOK=0;
for(const a of src.files){const b=fs.readFileSync(a.path),hash=crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');if(hash!==a.oid)throw Error('source mismatch '+a.path);sourceOK++;}
for(const a of assets){const b=fs.readFileSync(a.path);if(b.length!==a.bytes||crypto.createHash('sha256').update(b).digest('hex')!==a.sha256)throw Error('asset mismatch '+a.path);assetOK++;}
fs.writeFileSync(out+'/identity-post.json',JSON.stringify({base:src.base,sourceOK,assetOK,at:new Date().toISOString()},null,2));
