'use strict';
const fs=require('fs'),cp=require('child_process'),crypto=require('crypto'),assert=require('assert/strict'),api=require('./file-api');
const base='b88c818ba3a071877e889e7cc779975a193591ce', remote='/home/user/hype-browser-fps',sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
const tree=cp.execFileSync('git',['ls-tree','-r','--long',base],{maxBuffer:16e6}).toString().trim().split('\n').map(s=>{const m=s.match(/^\d+ blob (\w+)\s+(\d+)\t(.+)$/);return m&&{oid:m[1],bytes:+m[2],path:m[3]}}).filter(Boolean);
const selected=tree.filter(p=>!p.path.includes('/')||/^(src|lib|tools|test|fonts|icons|ops)\//.test(p.path)||p.path.startsWith('docs/')&&!p.path.startsWith('docs/reviews/'));
fs.writeFileSync(__dirname+'/source-manifest.json',JSON.stringify({base,files:selected},null,2));
const archive=cp.execFileSync('git',['archive','--format=tar.gz',base,...selected.map(p=>p.path)],{maxBuffer:256*1024**2});
await api.upload(remote+'/source.tgz',archive);
await api.upload(remote+'/evidence/source-manifest.json',fs.readFileSync(__dirname+'/source-manifest.json'));
console.log('source uploaded',selected.length,archive.length);
const assets=JSON.parse(fs.readFileSync('scratch/runs/20261020-hype-browser-fps/assets.json'));
for(const a of assets){const b=fs.readFileSync(a.path);assert.equal(b.length,a.bytes);assert.equal(sha(b),a.sha256);await api.upload(remote+'/repo/'+a.path,b);}
await api.upload(remote+'/repo/test/binaries/candidates/hype-time-quest-demo/.wine-assembly-browser.json',fs.readFileSync('scratch/runs/20261020-hype-browser-fps/browser-manifest.json'));
fs.writeFileSync(__dirname+'/stage.json',JSON.stringify({base,sourceFiles:selected.length,archiveBytes:archive.length,archiveSha256:sha(archive),originals:assets.length,originalBytes:assets.reduce((s,a)=>s+a.bytes,0),at:new Date().toISOString()},null,2));
console.log('originals uploaded',assets.length);
console.log(api.exec(['bash','-lc','cd /home/user/hype-browser-fps && tar -xzf source.tgz -C repo && node -v && command -v google-chrome && df -B1 .'],'stage-extract'));
})().catch(e=>{console.error(e);process.exitCode=1});
