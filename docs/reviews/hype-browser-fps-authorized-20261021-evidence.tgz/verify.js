'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');process.chdir(__dirname);
const seals=JSON.parse(fs.readFileSync('SHA256SUMS.json'));for(const a of seals){const b=fs.readFileSync(a.path);assert.equal(b.length,a.bytes,a.path);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),a.sha256,a.path);}
const v=JSON.parse(fs.readFileSync('validation.json'));assert.equal(v.accepted,false);assert.equal(v.fps,null);
const p=JSON.parse(fs.readFileSync('recovered/evidence/identity-post.json'));assert.equal(p.sourceOK,6731);assert.equal(p.assetOK,59);
const raw=JSON.parse(fs.readFileSync('logical-raw.json')),arm=JSON.parse(fs.readFileSync('counter-arm.json'));assert.equal(arm.slot,0);assert.equal(raw.samples.length,106);assert(raw.samples.every(s=>s.count===0));
console.log('PASS '+seals.length+' sealed artifacts; 6731 exact source/59 original postchecks; wrong-owner106 samples retained; FPS rejected.');
