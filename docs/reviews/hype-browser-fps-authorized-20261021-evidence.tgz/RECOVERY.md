# Handoff recovery

Read report.md first: gameplay captured, FPS rejected because slot0 was sampled.
Do not claim zero FPS. Both browser attempts consumed; worker stopped.
Coordinator owns running bx_2ghgsv9d until14:01:16.889Z; preserveby13:40UTC.
Remote /home/user/hype-browser-fps retains exact source, canonical build,
59 original assets, both harnesses, evidence and source/recovery archives.
No browser/server remains. Do not stop/resume/create a box from this worker.

Offline: node verify.js; node --test source/test/test-hype-glide-emission-observer.js;
node source/tools/hype-glide-emission-observer.js measurement.json must exit1,
accepted false/fps null. Proprietary originals are not in this evidence bundle;
assets.json inside recovered/evidence records hashes and source paths. Restore
from existing read-only originals and prior20261020 recovery manifest if needed.
Exact code can be recovered from b88c818ba3a071877e889e7cc779975a193591ce.
The first launch timeout and sampler owner mismatch are retained, not erased.
