'use strict';
const fs=require('fs'),crypto=require('crypto'),puppeteer=require('/home/user/hype-browser-fps/deps/node_modules/puppeteer-core');
const out='/home/user/hype-browser-fps/evidence/attempt2',pause=ms=>new Promise(r=>setTimeout(r,ms)),save=(n,v)=>fs.writeFileSync(out+'/'+n,JSON.stringify(v,null,2)),inputs=[];
let browser,page;
async function shot(n){await page.screenshot({path:out+'/'+n+'.png'});save(n+'.json',await page.evaluate(()=>({at:performance.now(),running:runningApps.find(a=>a.name==='hype_glide_demo').wine.running})));}
(async()=>{
const pid=JSON.parse(fs.readFileSync(out+'/identity.json')).chromePid;
const args=fs.readFileSync('/proc/'+pid+'/cmdline','utf8').split('\0'),profile=args.find(x=>x.startsWith('--user-data-dir=')).split('=')[1];
const endpoint=fs.readFileSync(profile+'/DevToolsActivePort','utf8').trim().split('\n');
browser=await puppeteer.connect({browserWSEndpoint:'ws://127.0.0.1:'+endpoint[0]+endpoint[1],protocolTimeout:30000});
page=(await browser.pages()).find(p=>p.url().includes('app=hype_glide_demo'));if(!page)throw Error('exact live page absent');
save('served-module.json',await page.evaluate(()=>{const w=runningApps.find(a=>a.name==='hype_glide_demo').wine;return {resources:performance.getEntriesByType('resource').filter(r=>r.name.includes('wine-assembly')&&r.name.includes('.wasm')).map(r=>({url:r.name,size:r.decodedBodySize,start:r.startTime,duration:r.duration})),identity:globalThis.WINE_WASM_IDENTITY||null,tailCalls:WineAssembly.supportsWasmTailCalls(),liveModule:!!w._wasmModule,layout:Array.from(new Uint8Array(WebAssembly.Module.customSections(w._wasmModule,'wine-region-layout')[0]))};}));

 const candidates=[];for(const w of page.workers()){if(!w.url().includes("/lib/guest-worker.js?"))continue;try{const id=await w.evaluate(()=>typeof instance!=='undefined'&&instance?instance.exports.get_current_thread_id():-1);if(id===1)candidates.push(w);}catch{}}
 if(candidates.length!==1)throw Error('logical owner ambiguity '+candidates.length);const w=candidates[0];
 const code="6804cd7100e856f9020066a102cd7100668b0d00cd710083c4045051e84f7b020083c40885c07540683805000068b4685b0050e8d85c140083c40c8a15d0265b";
 save('counter-arm.json',await w.evaluate(expected=>{
 const ex=instance.exports,original=instance,buf=memory.buffer,read=()=>Array.from(new Uint8Array(memory.buffer,0x43f610-ex.get_image_base()+0x12000,64),x=>x.toString(16).padStart(2,'0')).join('');
 if(read()!==expected)throw Error('live callback authentication failed');
 ex.set_logical_frame(0x43f610,0);
 const record={at:performance.now(),origin:performance.timeOrigin,tid:ex.get_current_thread_id(),slot:workerSlot,code:read(),addr:ex.get_logical_frame_addr(),pace:ex.get_logical_frame_pace()};
 globalThis.__hype={ex,original,read,expected,rows:[],events:[],generation:'attempt2-owner1',timer:null};
 addEventListener('message',ev=>{const m=ev.data;if(m?.t==='callExport'&&m.name==='set_logical_frame')__hype.events.push({at:performance.now(),name:m.name,args:m.args});});return record;
 },code));
 await pause(2000);await shot('world-before-measure');
 await w.evaluate(()=>{const h=__hype;h.sample=()=>{const ex=h.ex;h.rows.push({hostMs:performance.now(),count:ex.get_logical_frame_count()>>>0,enabled:ex.get_logical_frame_addr()===0x43f610&&ex.get_logical_frame_pace()===0,generation:h.generation,owner:{instance:'attempt2-slot'+workerSlot,thread:ex.get_current_thread_id()},clockOrigin:String(performance.timeOrigin),sameInstance:instance===h.original,codeMatches:h.read()===h.expected});};h.sample();h.timer=setInterval(h.sample,100);});
 await pause(3000);inputs.push({action:'key',key:'ArrowUp',ms:600,at:new Date().toISOString(),duringMeasurement:true});await page.keyboard.down('ArrowUp');await pause(600);await page.keyboard.up('ArrowUp');await shot('during-up');
 await pause(3000);inputs.push({action:'key',key:'ArrowDown',ms:600,at:new Date().toISOString(),duringMeasurement:true});await page.keyboard.down('ArrowDown');await pause(600);await page.keyboard.up('ArrowDown');await shot('during-down');await pause(3000);
 save('logical-raw.json',await w.evaluate(()=>{clearInterval(__hype.timer);__hype.sample();return {samples:__hype.rows,events:__hype.events,origin:performance.timeOrigin,end:performance.now(),code:__hype.read()};}));await shot('world-after-measure');
save('measurement-inputs.json',inputs);browser.disconnect();console.log('measurement complete');
})().catch(e=>{save('measurement-error.json',{error:e.stack||String(e)});console.error(e);browser?.disconnect();process.exitCode=1});
