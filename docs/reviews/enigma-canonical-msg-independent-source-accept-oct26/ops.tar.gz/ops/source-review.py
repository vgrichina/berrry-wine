from common import *
import gzip,re,difflib
D=pathlib.Path('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/repo');P=pathlib.Path('/tmp/enigma-msg-boundary-measured-client-implementation-oct26/repo');note=D/'docs/re-notes/enigma-canonical-msg-completion-hook-repair-oct26'
patch=gzip.decompress((note/'completion.patch.gz').read_bytes()).decode();lines=patch.splitlines(keepends=True);i=0;files=[]
partial=json.load(open(note/'source-provenance.json'))['partialFiles']
while i<len(lines):
 assert lines[i].startswith('--- ');old=lines[i][4:].strip();new=lines[i+1][4:].strip();p=new.removeprefix('b/');i+=2
 if old=='/dev/null':base=b'';origin='new-file'
 elif p in partial:base=(P/p).read_bytes();assert sha(base)==partial[p];origin='partialJS40699f72'
 elif p=='lib/host-import-sigs.generated.json':base=pathlib.Path('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/ops/baseline-import-sigs.json').read_bytes();origin='retained-signature-baseline'
 else:base=(SRC/p).read_bytes();origin='source239754c97d3'
 original=base.decode().splitlines(keepends=True);result=[];cursor=0;hunks=0
 while i<len(lines) and lines[i].startswith('@@ '):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert match,lines[i]
  start=int(match[1]);count=int(match[2] or 1);at=start-1 if start else 0;assert at>=cursor;result+=original[cursor:at];cursor=at;i+=1;consumed=0;added=0
  while i<len(lines) and not lines[i].startswith(('@@ ','--- ')):
   l=lines[i];assert l[0] in ' +-'
   if l[0] in ' -':assert cursor<len(original) and original[cursor]==l[1:],(p,cursor);cursor+=1;consumed+=1
   if l[0] in ' +':result.append(l[1:]);added+=1
   i+=1
  assert consumed==count,(p,consumed,count);assert added==int(match[4] or 1);hunks+=1
 result+=original[cursor:];b=''.join(result).encode();assert b==(R/p).read_bytes(),p
 files.append(dict(path=p,baseline=origin,baselineSHA256=sha(base),candidateSHA256=sha(b),hunks=hunks))
assert len(files)==14
# Produce the distinct runner prerequisite as a minimal delta only. It must be reconciled, never whole-file copied onto main.
b=(SRC/'test/run.js').read_bytes();p=(P/'test/run.js').read_bytes();delta=''.join(difflib.unified_diff(b.decode().splitlines(True),p.decode().splitlines(True),fromfile='a/test/run.js',tofile='b/test/run.js')).encode();(O/'partial-runner-prerequisite.patch.gz').write_bytes(gzip.compress(delta,mtime=0))
# Inspect actual default-off export/import and dispatch routing on pinned standing source, not a fabricated runner.
dispatch=(SRC/'src/09b-dispatch.wat').read_text();core=(SRC/'src/06b-core-handlers.wat').read_text();alu=(SRC/'src/05-alu.wat').read_text();exports=(SRC/'src/13-exports.wat').read_text();table=(SRC/'src/09b2-dispatch-table.generated.wat').read_text();decoder=(SRC/'src/07-decoder.wat').read_text()
checks=[('thunk-zone',exports,'(call $win32_dispatch (i32.div_u'),('decoded-call-register',core,'(func $th_call_r'),('decoded-jump-register',core,'(func $th_jmp_r'),('decoded-call-indirect',alu,'(func $th_call_ind'),('decoded-dispatch',core,'(call $win32_dispatch (i32.div_u'),('indirect-dispatch',alu,'(call $win32_dispatch (i32.div_u'),('keyboard-return',dispatch,'(then (call $keyboard_hook_finish) (return))'),('message-return',dispatch,'(then (call $getmessage_hook_continue) (return))')]
for api in ['GetMessageA','GetMessageW','PeekMessageA','PeekMessageW']:checks.append((api,table,'(call $handle_'+api+' '))
controls=[]
for label,s,token in checks:
 assert token in s,label
 bad=s.replace(token,'OMITTED',1)
 try:assert token in bad
 except AssertionError:controls.append(dict(label=label,omittedControlRejected=True))
 else:
  # Dispatch appears at several legitimate entry sites; the relevant actual function must be checked, not a whole-file existence test.
  if label in ['decoded-dispatch','indirect-dispatch']:
   start=s.index('(func $th_call_r' if label=='decoded-dispatch' else '(func $th_call_ind');end=s.index('\n  (func ',start+10);section=s[start:end];assert token in section;assert token not in section.replace(token,'OMITTED',1);controls.append(dict(label=label,omittedControlRejected=True,scope='exact handler'))
  else:raise AssertionError(label)
# Donor provenance and passing receipts are reused by unchanged source identity, with original uncompiled qualification.
partialHash=sha(p)
reused={}
for p in sorted(note.rglob('*')):
 if p.is_file() and p.name!='ops.tar.gz':reused[str(p.relative_to(D))]=dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
save('reused-evidence.json',dict(candidate=REV,files=reused,groups=json.load(open(note/'checkpoint.json'))['completed'],baselineComparisons=96,rerun=False,compiled=False,canonicalRuntimeQualified=False,qualification='Exact donor receipts retained, original interpreter/resource qualifications unchanged; not new runtime evidence'))
save('source-review-result.json',dict(candidate=REV,acceptedSource=True,patchSHA256=sha(patch.encode()),patchBytes=len(patch.encode()),reconstructedFiles=files,controls=controls,partialRunnerBaselineSHA=sha(b),partialRunnerSHA=partialHash,partialRunnerPrerequisitePatchSHA=sha(delta),dispatchProvenance=json.load(open(O/'dispatch-provenance.json')),compiled=False,canonicalRuntimeQualified=False,limits='Source routing checks only. Actual decoder lowering, macro expansion, build imports and runtime dispatch have not executed. Full unchanged dispatcher interpreted only on typed continuation paths.'))
print('PASS minimal14-file delta reconstructed byte-exact; separate prerequisite runner delta;12 source-route omission controls; original96baseline reused')
