from common import *
N=R/'docs/reviews'/H.name
# Missing historical tracked artifacts stay in the index, do not acquire/copy them.
missing=g('ls-files','--deleted','-z');(O/'intentionally-unmaterialized-paths.txt').write_bytes(missing)
if missing:pool(['git','update-index','--skip-worktree','-z','--stdin'],git=True,label='git-mark-absent',inputPath=O/'intentionally-unmaterialized-paths.txt')
save('sparse-absence.json',dict(paths=missing.decode().split('\0')[:-1],action='skip-worktree on existing index entries; no deletion staged or missing blob retried',historicalObjectsNotMaterialized=True));shutil.copyfile(O/'sparse-absence.json',N/'sparse-absence.json')
# Refresh exact accounting after evidence publication copies.
gate('ready-to-commit');shutil.copyfile(O/'admission-ready-to-commit.json',N/'admission-ready-to-commit.json')
print(g('status','--short').decode()[:3000])
g('add','--','test/independent-message-production-boundary.js','test/independent-message-continuations.js','test/independent-message-ownership.js','test/independent-wat-fixture.js','test/fixtures/enigma-independent-dispatch.wat','docs/reviews/'+H.name)
changed=g('diff','--cached','--name-only').decode().splitlines();assert changed and all(p.startswith('docs/reviews/'+H.name+'/') or p.startswith('test/independent-') or p=='test/fixtures/enigma-independent-dispatch.wat' for p in changed)
print(g('diff','--cached','--check').decode())
print(g('diff','--cached','--stat').decode()[-5000:])
g('commit','-m','test: independently accept Enigma canonical message source boundaries')
commit=g('rev-parse','HEAD').decode().strip();tree=g('rev-parse','HEAD^{tree}').decode().strip()
g('push','origin','HEAD:refs/heads/'+BR)
remote=g('ls-remote','--exit-code','origin','refs/heads/'+BR).decode().strip();assert remote.split()[0]==commit
status=g('status','--porcelain').decode();assert not status,status[:8192]
save('publication.json',dict(candidate=REV,commit=commit,tree=tree,branch=BR,remoteRef=remote,remoteVerified=True,mainTouched=False,trustedSSH=SSH,sourceAccepted=True,compiled=False,canonicalRuntimeQualified=False,stagedFiles=changed))
gate('closeout');c=json.load(open(O/'checkpoint.json'));c['publication']=dict(commit=commit,branch=BR,remoteVerified=True);c['remaining']=[x for x in c['remaining'] if 'own branch publication' not in x];save('checkpoint.json',c)
print(json.dumps(dict(commit=commit,branch=BR,remoteVerified=True,clean=True)))
