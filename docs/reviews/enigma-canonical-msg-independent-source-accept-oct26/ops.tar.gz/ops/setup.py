from common import *
import zlib
D=pathlib.Path('/tmp/enigma-canonical-msg-completion-hook-repair-oct26/repo');notes='docs/re-notes/enigma-canonical-msg-completion-hook-repair-oct26'
pins=json.load(open(D/notes/'checkpoint.json'))['candidateFiles']
for p,v in pins.items():assert sha((D/p).read_bytes())==v,p
save('pins.json',dict(candidate=REV,files=pins,source239='754c97d3ff22ce0a0cd06d08ac06dc0446fbcbb2',partialJS='40699f72bef9b5339c5371d9bdc0dd6e0efb8b25',donor=str(D)))
gate('initial')
watch=subprocess.Popen(['tail','-f',str(ROOT/'messageboard.txt')],stdout=open(O/'board-watch.log','ab'),stderr=subprocess.DEVNULL,start_new_session=True);save('watcher.json',dict(pid=watch.pid))
R.mkdir();g('init','-q',str(R),cwd=H)
seen=set()
def recover(oid):
 if oid in seen:return
 seen.add(oid);p=D/'.git/objects'/oid[:2]/oid[2:];b=p.read_bytes();raw=zlib.decompress(b);assert hashlib.sha1(raw).hexdigest()==oid
 header,body=raw.split(b'\0',1);kind,size=header.split();assert len(body)==int(size)
 if kind==b'commit':recover(body.splitlines()[0].split()[1].decode())
 elif kind==b'tree':
  off=0
  while off<len(body):
   end=body.index(b'\0',off);mode=body[off:end].split(b' ',1)[0];child=body[end+1:end+21].hex();off=end+21
   if mode==b'40000':recover(child)
 else:raise AssertionError(kind)
 out=R/'.git/objects'/oid[:2]/oid[2:];out.parent.mkdir(exist_ok=True);out.write_bytes(b)
recover(REV);(R/'.git/shallow').write_text(REV+'\n')
for k,v in [('core.sparseCheckout','true'),('core.sparseCheckoutCone','false'),('core.sshCommand',SSH),('user.name','Wine Ops'),('user.email','wine-ops@local')]:g('config',k,v)
(R/'.git/info/sparse-checkout').write_text('/src/\n/lib/host-imports.js\n/lib/host-import-sigs.generated.json\n/test/\n/docs/\n')
g('update-ref','refs/heads/'+BR,REV);g('symbolic-ref','HEAD','refs/heads/'+BR);g('read-tree','--reset','-i','HEAD');g('remote','add','origin','git@github.com:vgrichina/wine-assembly.git')
paths=list(pins)+[str(p.relative_to(D)) for p in (D/notes).rglob('*') if p.is_file()]
for p in paths:
 b=(D/p).read_bytes();dest=R/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 raw=b'blob '+str(len(b)).encode()+b'\0'+b;oid=hashlib.sha1(raw).hexdigest();dest=R/'.git/objects'/oid[:2]/oid[2:];dest.parent.mkdir(exist_ok=True);dest.write_bytes(zlib.compress(raw))
save('checkout.json',dict(base=REV,branch=BR,metadataObjects=len(seen),files=paths,selective=True,noAlternates=True,verifiedMaterializedFiles=True))
# The runner blob is locally supplied and verified; no absent-blob operation attempted.
startup='const fs=require("fs");console.log(JSON.stringify({execPath:process.execPath,execArgv:process.execArgv,limits:fs.readFileSync("/proc/self/limits","utf8"),env:{TMPDIR:process.env.TMPDIR,NODE_OPTIONS:process.env.NODE_OPTIONS||null}}))'
b=pool([NODE,'--max-old-space-size=64','-e',startup],label='node-startup');print(b[:3500].decode())
save('startup-configuration.json',dict(executable=NODE,sha256=sha(pathlib.Path(NODE).read_bytes()),flags=['--max-old-space-size=64'],environment=dict(TMPDIR=str(O),NODE_OPTIONS=os.environ.get('NODE_OPTIONS')),cpu=90,wall=120,file=25165824,physical=134217728,output=2097152,excerpt=8192,gitDATAOnlyGit=True))
print('SELECTIVE RECOVERY AND NODE STARTUP PASS')
