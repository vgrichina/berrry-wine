from common import *
group=sys.argv[1]
b=pool([NODE,'--max-old-space-size=64',str(R/'test'/('independent-message-'+group+'.js')),str(O)],label=group);print(b[:8192].decode())
completed=[p.name.removesuffix('-result.json') for p in O.glob('*-result.json')]
save('checkpoint.json',dict(candidate=REV,completed=completed,fixtures={str(p.relative_to(R)):sha(p.read_bytes()) for p in (R/'test').glob('independent-message-*.js')},remaining=['independent continuation/ownership challenges','source dispatch wiring review','evidence publication; no main','separate authorized compiled/module/runtime qualification'],compiled=False,canonicalRuntimeQualified=False))
