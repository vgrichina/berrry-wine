from common import *
N=R/'docs/reviews'/H.name
# Preserve missing historical object incident. The exact known parent tree remains unchanged;
# Git's supported --missing-ok writes that sparse index without materializing old artifacts.
save('sparse-commit-incident.json',dict(command='git commit',exit=1,diagnostic='Error building trees: absent historical README blob6631e9f90c112462bd906d76411a3d5aa63577b0',resolution='git write-tree --missing-ok then commit-tree with exact parent; verify only owned new paths; no missing blob lookup/fetch/retry, parent historical tree entries preserved',notAccessPolicyDenial=True))
shutil.copyfile(O/'sparse-commit-incident.json',N/'sparse-commit-incident.json')
g('add','--','docs/reviews/'+H.name+'/sparse-commit-incident.json')
changed=g('diff','--cached','--name-only').decode().splitlines();assert all(p.startswith('docs/reviews/'+H.name+'/') or p.startswith('test/independent-') or p=='test/fixtures/enigma-independent-dispatch.wat' for p in changed)
g('diff','--cached','--check');tree=g('write-tree','--missing-ok').decode().strip();commit=g('commit-tree',tree,'-p',REV,'-m','test: independently accept Enigma canonical message source boundaries').decode().strip();g('update-ref','refs/heads/'+BR,commit,REV)
g('push','origin','HEAD:refs/heads/'+BR)
remote=g('ls-remote','--exit-code','origin','refs/heads/'+BR).decode().strip();assert remote.split()[0]==commit
status=g('status','--porcelain').decode();assert not status,status[:8192]
save('publication.json',dict(candidate=REV,commit=commit,tree=tree,branch=BR,remoteRef=remote,remoteVerified=True,mainTouched=False,trustedSSH=SSH,sourceAccepted=True,compiled=False,canonicalRuntimeQualified=False,stagedFiles=changed))
gate('closeout');c=json.load(open(O/'checkpoint.json'));c['publication']=dict(commit=commit,branch=BR,remoteVerified=True);c['remaining']=[x for x in c['remaining'] if 'own branch publication' not in x];save('checkpoint.json',c)
print(json.dumps(dict(commit=commit,branch=BR,remoteVerified=True,clean=True)))
