from common import *
import tarfile
N=R/'docs/reviews'/H.name;first=json.load(open(O/'publication.json'))
for p,v in json.load(open(O/'pins.json'))['files'].items():assert sha((R/p).read_bytes())==v,p
for name in ['publication.json','checkpoint.json','admission-closeout.json']:
 shutil.copyfile(O/name,N/name)
records=[json.load(open(p)) for p in O.glob('*-execution.json')]
summary=dict(firstPublishedCommit=first['commit'],passingGitPeak=max(x['peakSampledRSS'] for x in records if x['physicalCap']==268435456 and x['exit']==0),passingTestPeak=max(x['peakSampledRSS'] for x in records if x['physicalCap']==134217728 and x['exit']==0),historicalPhysicalStop=134443008,allCandidateFilesUnchanged=True,sourceAccepted=True,compiled=False,canonicalRuntimeQualified=False,noAssignedBox=True,boxState='N/A',expiry='N/A',shutdownOwner='coordinator',model='gpt-6.1-sol',reasoning='medium',totalAutoCompaction=200000,actualSession=os.environ.get('CODEX_THREAD_ID'),liveFlagsEvidence='live-clients.json')
save('closeout-summary.json',summary);shutil.copyfile(O/'closeout-summary.json',N/'closeout-summary.json')
with (N/'README.md').open('a') as f:f.write('\nThe first evidence commit '+first['commit']+' was pushed and its exact remote\nref verified. External ops/publication.json records final closeout commit/ref.\nPassing sampled peaks: tests127348736B/Git71225344B including supervisors.\nFinal pre-closeout projection43278336B/100663296B, projectedfree3223318528B;\nnewest external admission supersedes this timestamped sample. Sparse commit\nError building trees for an intentionally absent historical README was retained;\nsupported write-tree --missing-ok plus exact-parent commit-tree preserved all\nhistorical entries without acquiring/retrying absent blobs. Only owned new paths\nwere reviewed/staged; no deletion/source/main change.\n')
with tarfile.open(N/'ops.tar.gz','w:gz') as t:
 for p in sorted(O.iterdir()):
  if p.is_file() and (p.suffix in ['.py','.js','.log'] or p.name.endswith('execution.json')) and p.name!='board-watch.log':t.add(p,arcname='ops/'+p.name)
g('add','--','docs/reviews/'+H.name)
changed=g('diff','--cached','--name-only').decode().splitlines();assert changed and all(x.startswith('docs/reviews/'+H.name+'/') for x in changed)
g('diff','--cached','--check');tree=g('write-tree','--missing-ok').decode().strip();commit=g('commit-tree',tree,'-p',first['commit'],'-m','docs: finalize Enigma independent source acceptance receipts').decode().strip();g('update-ref','refs/heads/'+BR,commit,first['commit']);g('push','origin','HEAD:refs/heads/'+BR)
remote=g('ls-remote','--exit-code','origin','refs/heads/'+BR).decode().strip();assert remote.split()[0]==commit
assert not g('status','--porcelain').strip()
first.update(commit=commit,tree=tree,firstEvidenceCommit=first['commit'],remoteRef=remote);save('publication.json',first)
gate('final');a=json.load(open(O/'admission-final.json'));c=json.load(open(O/'checkpoint.json'));c['publication']=dict(commit=commit,branch=BR,remoteVerified=True);save('checkpoint.json',c)
save('result.json',dict(outcome='ACCEPT_SOURCE_ONLY',candidate=REV,commit=commit,firstEvidenceCommit=first['firstEvidenceCommit'],branch=BR,remoteVerified=True,evidence=str(N),checkpoint=str(O/'checkpoint.json'),groups=['production-boundary3modes4controls','continuations33cases8controls','ownership396completions5controls','source-review14byteexactdeltas12sourcecontrols'],reusedOriginalBaselineComparisons=96,compiled=False,canonicalRuntimeQualified=False,remaining=c['remaining'],resourceSummary=summary,allocation=a,box=None,mainTouched=False,noWorkersOrRuntime=True))
print(json.dumps({k:first[k] for k in ['commit','firstEvidenceCommit','branch','remoteVerified']}));print(json.dumps({k:a[k] for k in ['projectedBytes','projectedFree','memAvailable','requiredMemory']}))
