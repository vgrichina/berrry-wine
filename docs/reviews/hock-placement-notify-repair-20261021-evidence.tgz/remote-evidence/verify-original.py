import pathlib,json,hashlib,subprocess
r=pathlib.Path('/home/user/hock-placement-loop-repair')
out=pathlib.Path('/home/user/hock-placement-notify-repair');out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((r/'identity.json').read_text())
for f,key in [('source-seals.json','source_seals_sha256'),('package-seals.json','package_seals_sha256')]:
 assert sha(r/f)==identity[key]
sources=json.loads((r/'source-seals.json').read_text())
for f,h in sources.items():assert sha(r/'repo'/f)==h,f
pkg=json.loads((r/'package-seals.json').read_text())
for f,h in pkg.items():assert sha(pathlib.Path('/home/user/hock-accepted-canonical-runtime/intake')/f)==h,f
assert sha(r/'repo/build/wine-assembly.wasm')==identity['wasm_sha256']=='eafeaa142c98fe60c489865c89a676c20afffe51002fe36799f42aa46d19ac2c'
assert sha(r/'repo/build/wine-assembly.compat.wasm')==identity['compat_sha256']
result=dict(sourceFiles=len(sources),packageFiles=len(pkg),module=identity['wasm_sha256'],allMatch=True,node=subprocess.check_output(['node','--version']).decode().strip())
(out/'verified.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
