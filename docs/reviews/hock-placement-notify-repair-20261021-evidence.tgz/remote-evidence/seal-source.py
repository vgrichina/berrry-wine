import pathlib,json,hashlib,shutil
r=pathlib.Path('/home/user/hock-placement-notify-repair');base=pathlib.Path('/home/user/hock-placement-loop-repair')
expected={'src/09a5-handlers-window.wat': 'c475b059665b30f3947ab1694284020b9ce0bc6d86a9108027497d979316559c', 'src/09a5b-handlers-window-late.wat': '2be5ab9368b37f942b326f3f22c089daf2dd0d23e6bf89864438e30f1e489e8f', 'src/09b-dispatch.wat': 'dfefe8f55471313049aabb179424c3268bad6e182de8ed12ee98ef9db23901c5', 'src/13-exports.wat': 'bcfaeafe881cadd3baeb9e6918a8b9b6449fb5c252a7f93096c823133eaf610d', 'tools/callback-ownership-census.json': '9a59dd0feac4662a0347877908b850b4835cd2fd9f3e33a2fd98b8fcbcc63508', 'test/test-window-placement-notify.js': '0e5739cb6dfe448ade0e84af89d12ab9b57561f65806d3f36f6dd8bd2cbfcb22'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((base/'source-seals.json').read_text());candidate={}
for f,h in original.items():
 assert sha(base/'repo'/f)==h,f
 candidate[f]=sha(r/'repo'/f)
 assert candidate[f]==expected.get(f,h),f
for f,h in expected.items():
 assert sha(r/'repo'/f)==h,f
 candidate[f]=h
for f in ['source-seals.json','package-seals.json','identity.json']:shutil.copyfile(base/f,r/f)
(r/'candidate-source-seals.json').write_text(json.dumps(candidate,indent=2)+'\n')
modules={p.name:sha(p) for p in (r/'repo/build').glob('wine-assembly*.wasm')}
result=dict(base='1d8dbd7a44656178d01869f28869be624a59fa39',sourceFiles=len(candidate),changed=expected,modules=modules,originalUnchanged=True)
(r/'candidate-identity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
