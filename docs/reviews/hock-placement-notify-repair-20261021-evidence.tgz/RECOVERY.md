# Recover placement notification repair

Same running bx_3f3x23m3; TTL 2026-10-21T05:56:19.894Z. Coordinator alone owns
lifecycle. This worker made no stop/snapshot/resume/new/fork actions.

Candidate: /home/user/hock-placement-notify-repair/repo
Evidence/scripts: /home/user/hock-placement-notify-repair
Preserved baseline: /home/user/hock-placement-loop-repair/repo
Original assets: /home/user/hock-accepted-canonical-runtime/intake/game
Prior diagnostic: /home/user/hock-clipped-client-repair

Canonical build: cd candidate/repo && bash tools/build.sh
Build receipt cmd_360lgkbtvgt7 exit0; full log build-v2.log.
WASM c62213f22cadd127bdd2dfd4f624d690b2814c18d5fcec7a3442080120f8d0c4
Compat e021407609163bc9fa78d4a4baeabc06a620787bf5df818c7fb9c303f9cc316d

Regression: PLACEMENT_FIXTURE=/home/user/hock-accepted-canonical-runtime/intake/game/BBLOOGIE.EXE node test/test-window-placement-notify.js
Baseline: also set PLACEMENT_BASELINE=/home/user/hock-placement-loop-repair/repo.
Use PLACEMENT_GROUP=ordinary,startup,queued individually (one value at a time).
Rejecting controls: PLACEMENT_CONTROL=late-snapshot with GROUP=snapshot;
PLACEMENT_CONTROL=stale-startup with GROUP=startup. Each must fail an assertion.

Original replay: drive-candidate.py uses same preserved held route and new
canonical module. Change its output directory before rerunning to preserve
original-held. The accepted 45.281s run is cmd_v3rji2gommdc, exit0; full HUD,
client556x434 and cached drawing556x414; no diagnostic resize. Score remains0/20;
audio/scoring/completion/FPS not qualified.

verify-original.py rechecks preserved source/package/module identity.
seal-source.py checks candidate files against original manifest plus exact
expected source delta. source-seals.json, candidate-source-seals.json and
candidate-identity.json retain full hashes. Source/module/package originals
remain separate and unchanged. No local full build or assets were materialized.

Task branch task/hock-placement-notify-repair-oct21; no main merge. See
publication.json for independently verified remote commit(s), and result.json
for final artifact paths. Remote evidence archive excludes repo and binaries.
