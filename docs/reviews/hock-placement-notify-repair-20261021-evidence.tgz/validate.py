from pathlib import Path
import hashlib,json,subprocess,struct
r=Path(__file__).resolve().parent;e=r/'remote-evidence';repo=r/'repo'
sha=lambda b:hashlib.sha256(b).hexdigest()
seals=json.loads((e/'SHA256SUMS.json').read_text())
for p,h in seals.items():assert sha((e/p).read_bytes())==h,p
assert sha((r/'remote-evidence.tgz').read_bytes())=='33a65d0036a45478a41c6e249a841e158e0b43cbb1a69ddb4653ae5e68ce24cc'
manifest=json.loads((e/'candidate-source-seals.json').read_text());commit='c4718fb5204a0f4541c1575e84557cfefad6959d'
p=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for name,h in manifest.items():
 p.stdin.write((commit+':'+name+'\n').encode());p.stdin.flush();head=p.stdout.readline().split();assert len(head)==3,(name,head)
 data=p.stdout.read(int(head[2]));assert p.stdout.read(1)==b'\n';assert sha(data)==h,name
p.stdin.close();assert p.wait()==0
for name in ['regression-v10','build-v2','original-held','related-tests','controls']:
 assert json.loads((r/(name+'.json')).read_text())['exitCode']==0,name
controls=json.loads((e/'controls.json').read_text());assert len(controls)==5
for c in controls:assert c['exit']==c['expected']==1 and 'AssertionError' in (e/(c['name']+'.log')).read_text()
t=json.loads((e/'original-held/held-timings.json').read_text());assert t['exit']==0 and t['wallSeconds']>=45 and len(t['events'])==19
assert not any('resize' in json.dumps(v['command']) for v in t['events'])
pngs={}
for f in e.rglob('*.png'):
 b=f.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';dims=struct.unpack('>II',b[16:24]);assert dims==((564,480) if f.name=='held-back.png' else (640,480)),(f,dims);pngs[str(f.relative_to(e))]=dims
out={'passed':True,'sealedFiles':len(seals),'candidateCommittedSourceFiles':len(manifest),'commit':commit,'negativeControls':controls,'canonicalExit':0,'runtimeSeconds':t['wallSeconds'],'events':19,'pngDimensions':pngs}
(r/'validation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
