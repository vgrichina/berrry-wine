import subprocess as s, pathlib, json, shutil, time
run=pathlib.Path(__file__).resolve().parent
repo=run/'repo'
records=[]
def check(label,args,expected=0,contains=None):
    assert shutil.disk_usage(run).free>=2285895680
    assert int(s.check_output(['du','-s','-B1',str(run)]).split()[0])<67108864
    start=time.time(); p=s.run(args,cwd=repo,stdout=s.PIPE,stderr=s.STDOUT,text=True)
    (run/(label+'.log')).write_text(p.stdout)
    records.append(dict(label=label,command=args,expected=expected,exit=p.returncode,seconds=time.time()-start,log=label+'.log'))
    (run/'tests.json').write_text(json.dumps(records,indent=2)+'\n')
    assert p.returncode==expected,(label,p.stdout[-2000:])
    if contains: assert contains in p.stdout,(label,p.stdout[-2000:])
check('census',['node','tools/aw-census.js','--check'])
check('census-tests',['node','test/test-aw-census.js'])
script='docs/reviews/registerclass-aw-contract-20261021.js'
check('contract',['node',script,'.'])
controls={'wide-flag':'registration owns encoding','ansi-flag':'registration owns encoding',
          'wide-key':'opposite encoding name lookup','copy-size':'all ten WNDCLASS fields retained',
          'atom-collapse':'all ten WNDCLASS fields retained','ex-offset':'all ten WNDCLASS fields retained'}
for mutation,diagnostic in controls.items():
    check('reject-'+mutation,['node',script,'.',mutation],1,'AssertionError [ERR_ASSERTION]: '+diagnostic)
check('fragments',['node','tools/check-wat-fragments.js','src/09a-handlers2-runtime.wat','src/09a5c-handlers-wide.wat','src/09c0-window-table.wat'])
check('esp',['node','tools/check-handler-esp.js'])
check('logical-and',['node','tools/check-wat-logical-and.js'])
check('whitespace',['git','diff','--check'])
# Real CLI controls: disconnect only one W callee at a time, then restore.
target=repo/'src/09a5c-handlers-wide.wat'; original=target.read_text()
try:
    for name in ['RegisterClassW','RegisterClassExW']:
        begin=original.index('(func $handle_'+name+' ')
        end=original.index('\n  (func ',begin+1)
        section=original[begin:end]
        assert section.count('$class_table_register_encoded')==1
        target.write_text(original[:begin]+section.replace('$class_table_register_encoded','$independent_registration')+original[end:])
        base=name[:-1]
        check('cli-reject-'+name,['node','tools/aw-census.js','--check'],1,'NEW DIVERGENT '+base+'A/W')
finally: target.write_text(original)
check('census-restored',['node','tools/aw-census.js','--check'])
check('lifetime',['node',str(run/'lifecycle-current-abi.js'),'.',str(run/'lifecycle.json')])
print(json.dumps({'commands':len(records),'pass':True}))
