#!/usr/bin/env node
'use strict';

// Actual guest CALL/RET through placement, show and DefWindowProc thunks.
// No game, synthetic posted WM_SIZE, or host resize intervention is involved.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const compiler = require('/home/user/hock-final-size-canonical-runtime/repo/test/compile-src');
const compile = compiler.compileSrcWasm;
compiler.compileSrcWasm = (transform, options) => compile((file, source) => {
  const base = process.env.PLACEMENT_BASELINE;
  if (base && ['09a5b-handlers-window-late.wat', '09a5-handlers-window.wat', '09b-dispatch.wat', '13-exports.wat'].includes(file))
    source = fs.readFileSync(path.join(base, 'src', file), 'utf8');
  if (process.env.PLACEMENT_CONTROL === 'late-snapshot' && file === '09a5b-handlers-window-late.wat') {
    const read = '(local.set $show (i32.load offset=8 (local.get $wa)))';
    source = source.replace(read, '').replace(';; showCmd used to be read', read + '\n    ;; showCmd used to be read');
  }
  if (process.env.PLACEMENT_CONTROL === 'stale-startup' && file === '09b-dispatch.wat') {
    const start = source.indexOf(';; CACA0031:');
    const old = source;
    source = source.slice(0, start) + source.slice(start).replace(
      '(local.set $arg0 (call $client_rect_wh_packed (local.get $arg4)))',
      '(local.set $arg0 (global.get $pending_wm_size))');
    assert.notEqual(source, old, 'stale-startup control must change the payload');
  }
  if (file === '09b-dispatch.wat' && ['zero-destruction', 'keep-success'].includes(process.env.PLACEMENT_CONTROL)) {
    const write = '(call $gs32 (i32.add (i32.load offset=16 (global.get $reg_base)) (i32.const 4)) (local.get $arg0))';
    assert(source.includes(write), 'destruction-result control must match');
    source = source.replace(write, process.env.PLACEMENT_CONTROL === 'zero-destruction'
      ? write.replace('(local.get $arg0)', '(i32.const 0)') : '');
  }
  return transform ? transform(file, source) : source;
}, options);
const { bootRenderHarness } = require('/home/user/hock-final-size-canonical-runtime/repo/test/render-helper');
const apis = require('/home/user/hock-final-size-canonical-runtime/repo/src/api_table.json');
const u32 = n => [n & 255, n >>> 8 & 255, n >>> 16 & 255, n >>> 24 & 255];
const pack = (w, h) => ((w & 65535) | h << 16) >>> 0;
const extraWat = String.raw`
  (func (export "pn_thunk") (param $id i32) (result i32)
    (local $p i32)
    (global.set $thunk_guest_base (call $w2g (global.get $THUNK_BASE)))
    (local.set $p (i32.add (global.get $THUNK_BASE) (i32.mul (global.get $num_thunks) (i32.const 8))))
    (i32.store (local.get $p) (i32.const 0)) (i32.store offset=4 (local.get $p) (local.get $id))
    (global.set $num_thunks (i32.add (global.get $num_thunks) (i32.const 1)))
    (call $update_thunk_end) (call $w2g (local.get $p)))
  (func (export "pn_window") (param $proc i32) (param $style i32) (result i32)
    (local $h i32) (local.set $h (global.get $next_hwnd))
    (global.set $next_hwnd (i32.add (local.get $h) (i32.const 1)))
    (call $wnd_table_set (local.get $h) (local.get $proc))
    (drop (call $wnd_set_style (local.get $h) (local.get $style))) (local.get $h))
  (func (export "pn_init") (param $h i32) (call $defwndproc_do_nccalcsize (local.get $h)))
  (func (export "pn_client") (param $h i32) (result i32) (call $client_rect_wh_packed (local.get $h)))
  (func (export "pn_live") (param $h i32) (result i32) (call $wnd_table_find (local.get $h)))
  (func (export "pn_depth") (result i32) (global.get $windowpos_depth))
  (func (export "pn_main") (param $h i32) (param $activated i32) (param $pending i32)
    (global.set $quit_flag (i32.const 0))
    (global.set $main_hwnd (local.get $h))
    (global.set $show_window_activated (local.get $activated))
    (global.set $pending_wm_size (local.get $pending)))
  (func (export "pn_send") (param $h i32) (result i32)
    (call $wnd_send_message (local.get $h) (i32.const 0x8001) (i32.const 0) (i32.const 0)))
  (func (export "pn_fetch") (param $msg i32) (param $peek i32)
    (local $esp i32) (local.set $esp (i32.load offset=16 (global.get $reg_base)))
    (call $post_queue_reset)
    (loop $drain (br_if $drain (call $shared_post_queue_read (local.get $msg) (i32.const 1))))
    (if (local.get $peek)
      (then (call $handle_PeekMessageA (local.get $msg) (i32.const 0) (i32.const 0) (i32.const 0) (i32.const 0) (i32.const 0)))
      (else (call $handle_GetMessageA (local.get $msg) (i32.const 0) (i32.const 0) (i32.const 0) (i32.const 0) (i32.const 0))))
    (i32.store offset=16 (global.get $reg_base) (local.get $esp)))
`;

function procedure(obs, placement, def, destroy, p, opts) {
  const code = [], labels = new Map(), fixups = [];
  const emit = (...bytes) => code.push(...bytes);
  const label = name => labels.set(name, code.length);
  const branch = (op, name) => { emit(...op); fixups.push([code.length, name]); emit(0, 0, 0, 0); };
  const call = addr => emit(0xb8, ...u32(addr), 0xff, 0xd0);
  const place = ptr => { emit(0x68, ...u32(ptr), 0xff, 0x75, 0x08); call(placement); };
  emit(0x55, 0x89, 0xe5); // push ebp; mov ebp,esp
  emit(0x81, 0x7d, 0x0c, ...u32(0x8001)); branch([0x0f, 0x85], 'message');
  if (opts.show) { emit(0xff, 0x35, ...u32(p + 8), 0xff, 0x75, 0x08); call(opts.show); }
  else place(p);
  emit(0xa3, ...u32(obs + 4)); branch([0xe9], 'done');
  label('message');
  emit(0x8b, 0x15, ...u32(obs), 0xc1, 0xe2, 0x04); // edx=count*16
  for (const [src, dst] of [[12, 0], [16, 4], [20, 8]])
    emit(0x8b, 0x45, src, 0x89, 0x82, ...u32(obs + 64 + dst));
  emit(0xff, 0x05, ...u32(obs)); // increment BEFORE nested callbacks
  if (opts.trigger) {
    emit(0x81, 0x7d, 0x0c, ...u32(opts.trigger)); branch([0x0f, 0x85], 'default');
    emit(0x83, 0x3d, ...u32(obs + 8), 0); branch([0x0f, 0x85], 'default');
    emit(0xc7, 0x05, ...u32(obs + 8), ...u32(1));
    if (opts.mutate) emit(0xc7, 0x05, ...u32(p + 8), ...u32(2));
    if (opts.nested) place(opts.nested);
    if (opts.destroy) { emit(0xff, 0x75, 0x08); call(destroy); branch([0xe9], 'done'); }
  }
  label('default');
  // Consuming CHANGED must suppress legacy geometry messages. Never chain
  // CHANGING here: this fixture is testing placement, not min-track limits.
  if (!opts.consume) {
    emit(0x83, 0x7d, 0x0c, 0x47); branch([0x0f, 0x85], 'done');
    emit(0xff, 0x75, 0x14, 0xff, 0x75, 0x10, 0xff, 0x75, 0x0c, 0xff, 0x75, 0x08); call(def);
  }
  label('done'); emit(0x31, 0xc0, 0x89, 0xec, 0x5d, 0xc2, 0x10, 0);
  for (const [at, name] of fixups) code.splice(at, 4, ...u32(labels.get(name) - at - 4));
  return code;
}

(async () => {
  const h = await bootRenderHarness({ extraWat, fonts: 'none' });
  const { exports: e, renderer, memory, instance } = h;
  // A PE is loaded only to initialize guest/thunk memory; none of its code
  // runs. Remote asset-minimal checkouts may name an already-preserved PE.
  const pe = fs.readFileSync(process.env.PLACEMENT_FIXTURE || path.join(__dirname, 'binaries/calc.exe'));
  new Uint8Array(memory.buffer).set(pe, e.get_staging()); assert(e.load_pe(pe.length)); e.init_dx_com_thunks();
  const thunk = name => e.pn_thunk(apis.find(a => a.name === name).id) >>> 0;
  const placement = thunk('SetWindowPlacement'), def = thunk('DefWindowProcA'), destroy = thunk('DestroyWindow');
  const put = (p, v) => e.guest_write32(p, v), get = p => e.guest_read32(p) >>> 0;
  const placementData = (p, w = 300, height = 220, show = 1) =>
    [44, 0, show, 0, 0, 0, 0, 31, 47, 31 + w, 47 + height].forEach((v, i) => put(p + i * 4, v));
  function make(opts = {}) {
    const obs = e.guest_alloc(4096) >>> 0, proc = e.guest_alloc(1024) >>> 0, p = e.guest_alloc(44) >>> 0;
    placementData(p);
    procedure(obs, placement, def, destroy, p, opts).forEach((v, i) => e.guest_write8(proc + i, v));
    const style = opts.hidden ? 0x00cf0000 : 0x10cf0000;
    const hwnd = e.pn_window(proc, style) >>> 0;
    renderer.createWindow(hwnd, style, 11, 17, 400, 300, 'placement notifications', 0, instance, memory);
    e.pn_init(hwnd);
    return { hwnd, obs, p, opts };
  }
  const sentinel = make(); e.pn_main(sentinel.hwnd, 1, 0);
  const messages = f => {
    assert(get(f.obs) < 240, 'bounded callback count');
    return Array.from({ length: get(f.obs) }, (_, i) => [0, 4, 8].map(o => get(f.obs + 64 + i * 16 + o)));
  };
  const run = f => {
    put(f.obs, 0); put(f.obs + 4, 0xdeadbeef);
    const esp = e.get_esp(); e.set_ebx(0x12345678); e.set_esi(0x23456789); e.set_edi(0x3456789a);
    e.pn_send(f.hwnd);
    assert.equal(e.get_esp(), esp, 'outer guest stack restored');
    assert.equal(e.get_ebx() >>> 0, 0x12345678); assert.equal(e.get_esi() >>> 0, 0x23456789); assert.equal(e.get_edi() >>> 0, 0x3456789a);
    assert.equal(e.pn_depth(), 0, 'all nested WINDOWPOS slots released');
    return messages(f);
  };
  const failures=[];
  for (const trigger of [0x1c,6,7,3,5]) {
    const f=make({hidden:true,consume:true,trigger,destroy:true});
    e.pn_main(f.hwnd,0,pack(392,273));
    const ms=run(f);
    assert.equal(e.pn_live(f.hwnd),-1);
    assert.equal(get(f.obs+8),1);
    console.log('OBS startup placement destruction',JSON.stringify({trigger,result:get(f.obs+4),live:e.pn_live(f.hwnd),messages:ms,stackAndNonvolatileAndDepth:'PASS'}));
    if(get(f.obs+4)!==0)failures.push({trigger,result:get(f.obs+4),expected:0});
    e.pn_main(sentinel.hwnd,1,0);
  }
  assert.deepEqual(failures,[],'destroyed startup placement must fail including final WM_SIZE');
})().catch(error => { console.error(error); process.exitCode = 1; });
