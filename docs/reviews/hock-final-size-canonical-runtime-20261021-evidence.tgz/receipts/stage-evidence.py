import pathlib,base64,json,hashlib
from remote import run,REMOTE
r=pathlib.Path(__file__).resolve().parent
old=r.parent/'20261021-hock-final-size-independent/repo/docs/reviews/hock-final-size-independent-20261021-evidence'
seals=json.loads((old/'SHA256SUMS.json').read_text())
for p in old.iterdir():
 if p.name in seals: assert hashlib.sha256(p.read_bytes()).hexdigest()==seals[p.name]
files={'intake/recover.py':(r.parent/'20261021-hock-accepted-canonical-runtime/remote-evidence/intake/recover.py').read_bytes(),'package-seals.json':(r.parent/'20261021-hock-show-return-repair/remote-evidence/package-seals.json').read_bytes()}
s=(old/'independent-final-size-original.js').read_text();assert s.count('/home/user/hock-show-return-repair/repo/')==3
files['independent-final-size.js']=s.replace('/home/user/hock-show-return-repair/repo/',REMOTE+'/repo/').encode()
s=(old/'drive-original.py').read_text().replace('/home/user/hock-show-return-repair',REMOTE).replace('/home/user/hock-accepted-canonical-runtime/intake',REMOTE+'/intake')
files['drive-candidate.py']=s.encode()
for f,b in files.items():
 p=r/f;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(b)
cmd='import pathlib,base64\nr=pathlib.Path('+repr(REMOTE)+')\n'
for f,b in files.items():cmd+='p=r/'+repr(f)+';p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(base64.b64decode('+repr(base64.b64encode(b).decode())+'))\n'
run("python3 - <<'PY2'\n"+cmd+"PY2\npython3 "+REMOTE+'/intake/recover.py','stage-evidence',120)
