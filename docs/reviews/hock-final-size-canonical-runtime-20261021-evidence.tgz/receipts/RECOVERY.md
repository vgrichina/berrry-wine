# Recover the bounded final SIZE runtime qualification

Exact production candidate: 776d37d55d2f749dcb29203e3bd26b8a5e9c05bd,
remote task/hock-final-size-lifetime-fix-oct21. Report/evidence branch:
task/hock-final-size-canonical-runtime-oct21 (commit in publication.json).
Main remains 1d8dbd7a44656178d01869f28869be624a59fa39. No merge authority implied.

Fetch report branch and extract docs/reviews/hock-final-size-canonical-runtime-20261021-evidence.tgz.
Validate SHA256SUMS.json, then remote-evidence/SHA256SUMS.json. The archive
contains exact command receipts and scripts, source/package identities,
all actual guest test logs, eight screenshots and complete original route log.

Assigned bx_c6f3np32 remains RUNNING (API idle/health ok), expiry
2026-10-21T08:14:54.696Z. Coordinator owns shutdown and snapshot decisions.
Remote /home/user/hock-final-size-canonical-runtime contains repo, intake,
normal dependencies, fresh canonical/compat modules and all raw evidence.
Do not automatically resume/create/fork or change this box's lifecycle.

For an authorized new replay, clone exact candidate and npm ci on its assigned
runtime, place the preserved intake/recover.py and package-seals.json together
as in stage-evidence.py, run recovery there and verify all 44 seals. Never
bulk-fetch the intake into the capped local checkout. Run verify-remote.py,
bash tools/build.sh (all gates), and run-tests.py. Its test order/expected
exits follows the independent replay plan. If calc.exe is missing, use the
unchanged sealed BBLOOGIE.EXE as that loader fixture. Run drive-candidate.py
only after gates and tests pass, changing paths and using a NEW output folder.
Compare the canonical and compat identities; inherited modules do not qualify.

Canonical SHA256 728e1de80ec20a284fc41b339895ee8ac29f16e4ded83325b27576cfacd4466c
Compat SHA256 25519647def1c2a25f505a81743d21dec55472ede8780f809edf09b6bb231018
Source manifest SHA256 9918eef5f9b441693bf39f425ab988af7f5883971c451ddea53796bddae07a76

The local report checkout uses shared object-store alternates and sparse scope
configured BEFORE checkout. Only AGENTS.md, CLAUDE.md and this report/evidence
are materialized. Preserve the 64MiB local cap and 2285895680-byte free floor.
Raw binaries/assets/modules are intentionally absent from the Git evidence.
Audio quality, scoring, completion, FPS and Windows parity remain unqualified.
