import subprocess,pathlib,json,os,datetime
r=pathlib.Path('/home/user/hock-final-size-canonical-runtime');repo=r/'repo'
os.environ['PLACEMENT_FIXTURE']=str(r/'intake/game/BBLOOGIE.EXE')
tests=[('census',['node','tools/callback-ownership-census.js'],{},0),('census-test',['node','test/test-callback-ownership-census.js'],{},0),('independent-final-size',['node',str(r/'independent-final-size.js')],{},0),('final-size',['node','test/test-window-placement-notify.js'],{'PLACEMENT_GROUP':'final-size'},0),('show-return',['node','test/test-window-placement-notify.js'],{'PLACEMENT_GROUP':'show-return'},0),('placement-all',['node','test/test-window-placement-notify.js'],{},0)]
for name in ['thread-thunk-sync','window-placement-client','showwindow-child-size','showwindow-secondary-top-size','show-window-async','startup-info-boundaries']:
 tests.append((name,['node','test/test-'+name+'.js'],{},0))
tests.extend([('negative-zero-destruction',['node','test/test-window-placement-notify.js'],{'PLACEMENT_GROUP':'show-return','PLACEMENT_CONTROL':'zero-destruction'},1),('negative-keep-success',['node','test/test-window-placement-notify.js'],{'PLACEMENT_GROUP':'final-size','PLACEMENT_CONTROL':'keep-success'},1)])
records=[]
for name,args,env,expected in tests:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(name+'.log')).open('w') as out:
  p=subprocess.run(args,cwd=repo,env={**os.environ,**env},stdout=out,stderr=subprocess.STDOUT)
 rec=dict(name=name,command=args,env=env,fixture=os.environ['PLACEMENT_FIXTURE'],startedAt=start,exit=p.returncode,expectedExit=expected)
 records.append(rec);(r/'tests.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
 if p.returncode!=expected:
  print((r/(name+'.log')).read_text()[-14000:],flush=True);raise SystemExit(1)
 if expected==1:
  log=(r/(name+'.log')).read_text();assert 'AssertionError' in log;print(log[-3000:],flush=True)
