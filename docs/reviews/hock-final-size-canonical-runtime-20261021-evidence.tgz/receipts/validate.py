import pathlib,json,hashlib,os,subprocess
r=pathlib.Path(__file__).resolve().parent;e=r/'remote-evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
seals=json.loads((e/'SHA256SUMS.json').read_text())
for f,h in seals.items():assert sha(e/f)==h,f
assert len(seals)==36
old=r.parent/'20261021-hock-final-size-independent/repo/docs/reviews/hock-final-size-independent-20261021-evidence'
original=old/'independent-final-size-original.js';assert sha(original)=='4a82983abc0e1316f4580308528d07cf946b0eefaf07382c1638a15acc37eae1'
remote='/home/user/hock-final-size-canonical-runtime'
assert (e/'independent-final-size.js').read_text()==original.read_text().replace('/home/user/hock-show-return-repair/repo/',remote+'/repo/')
assert (e/'drive-candidate.py').read_text()==(old/'drive-original.py').read_text().replace('/home/user/hock-show-return-repair',remote).replace('/home/user/hock-accepted-canonical-runtime/intake',remote+'/intake')
records=json.loads((e/'tests.json').read_text());assert len(records)==14
assert all(t['exit']==t['expectedExit'] for t in records)
assert 'ShowWindow destruction retains entry visibility\n\n0 !== 1' in (e/'negative-zero-destruction.log').read_text()
assert 'placement: final SIZE invocation result\n\n1 !== 0' in (e/'negative-keep-success.log').read_text()
assert (e/'independent-final-size.log').read_text().count('"stackAndNonvolatileAndDepth":"PASS"')==5
identity=json.loads((e/'identity.json').read_text());assert identity['status']=='';assert sha(r/'source-seals.json')==identity['sourceManifestSHA256'];assert sha(e/'source-seals.json')==identity['sourceManifestSHA256']
route=json.loads((e/'original-held/held-timings.json').read_text());assert route['exit']==0;assert len(route['events'])==19
log=(e/'original-held/held.log').read_text();ctl=[json.loads(s.split('[ctl] ',1)[1]) for s in log.splitlines() if s.startswith('[ctl] ')]
assert len(ctl)==19 and all(c['ok'] for c in ctl)
dispatch=[s for s in log.splitlines() if s.startswith('[dispatch-input]')];assert len(dispatch)==9
summary=dict(sealedRemoteFiles=36,pathOnlyReproAndDriver=True,sourceFiles=identity['sourceFiles'],sourceManifestSHA256=identity['sourceManifestSHA256'],positiveCommands=12,intendedAssertionFailures=2,independentDestructionStages=5,routeSeconds=route['wallSeconds'],routeEvents=19,acknowledgedControls=19,guestMouseDispatches=9,screenReview={'hud':'full score and clock visible','clock':[120,112,100,91,86],'player':'left to center to right; input selected game','client':'556x434 at 42,42 inside 564x480 window at 38,0; no top clipping','score':'0/20; scoring unqualified','audio':'waveOut open 22050Hz mono 8bit; no PCM capture/listening, quality unqualified','fps':'unmeasured; batches/s is not FPS','completion':'unqualified','WindowsParity':'unqualified'},modules=identity['modules'])
(r/'validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
