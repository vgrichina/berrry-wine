from common import *
assert time.time()+70<1793009820
assert json.load(open(O/'checkpoint-offline.json'))['passing']
s=json.loads(json.load(open(O/'startup-api.json'))['stdout']);assert s['exit']==0 and s['limits']['RLIMIT_DATA']==[-1,-1] and s['limits']['RLIMIT_AS']==[-1,-1]
j=py('import pathlib,shutil,json;d=pathlib.Path('+repr(str(D))+');n=pathlib.Path('+repr(str(H))+');a=lambda p:max(p.lstat().st_size,p.lstat().st_blocks*512);q=pathlib.Path("/home/user/.ascii/processes");e=a(q)+sum(a(p) for p in q.rglob("*") if p.lstat().st_mtime>1793007420);print(json.dumps(dict(allocated=sum(a(p) for h in [d,n] for p in [h,*h.rglob("*")])+e,memAvailable=int(next(l.split()[1] for l in open("/proc/meminfo") if l.startswith("MemAvailable")))*1024,diskFree=shutil.disk_usage("/tmp").free)))');save('remote-immediate-api.json',j);r=json.loads(j['stdout']);assert r['memAvailable']>=2684354560 and r['diskFree']-1048576>=2982150144
account('immediate-preguest',r['allocated'],524288)
assert not (O/'one-guest-launch.json').exists();save('one-guest-launch.json',dict(at=time.time(),attempt=1,cutoff='2026-10-26T10:17:00Z',box=BOX))
j=remote('python3 '+shlex.quote(str(O/'supervise.py'))+' guest',80);save('guest-api.json',j);r=json.loads(j['stdout']);save('checkpoint-guest-terminal.json',r);assert not r['remainingGroup'];print(json.dumps(r))
