from common import *
import gzip
j=py('import pathlib,json,shutil,os;d=pathlib.Path('+repr(str(D))+');n=pathlib.Path('+repr(str(H))+');a=lambda p:max(p.lstat().st_size,p.lstat().st_blocks*512);q=pathlib.Path("/home/user/.ascii/processes");e=a(q)+sum(a(p) for p in q.rglob("*") if p.lstat().st_mtime>1793007420);print(json.dumps(dict(allocated=sum(a(p) for h in [d,n] for p in [h,*h.rglob("*")])+e,memAvailable=int(next(l.split()[1] for l in open("/proc/meminfo") if l.startswith("MemAvailable")))*1024,diskFree=shutil.disk_usage("/tmp").free,processes={str(pid):pathlib.Path("/proc/"+str(pid)).exists() for pid in [45702,45706]},box="bx_vs4xtsz3",boxState="RUNNING (this successful API exec)",expiry="2026-10-26T10:32:43.299Z",coordinatorOwnsShutdown=True)))');save('box-handback.json',json.loads(j['stdout']));r=json.loads(j['stdout']);assert not any(r['processes'].values());account('before-publication',r['allocated'],524288)
P=H/'publication';P.mkdir(exist_ok=True);payloads=[]
for p in sorted(O.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts:continue
 b=p.read_bytes();rel=p.relative_to(O);dest=P/'evidence'/str(rel);dest=pathlib.Path(str(dest)+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);c=gzip.compress(b,mtime=0);dest.write_bytes(c);payloads.append(dict(path=str(dest.relative_to(P)),bytes=len(c),sha256=sha(c),rawBytes=len(b),rawSHA256=sha(b)))
(P/'manifest.json').write_text(json.dumps(dict(payloads=payloads,donor=str(D),oldCommit='ef30151795e09c1d48a357bffe3dd3b3ff24ccdd',moduleSHA256='fec642f6c711e57e1c4a3dfaeaff0e11be587c56fc64cde394ed7f54147b5988'),indent=2)+'\n')
(P/'README.md').write_text('''# Retained Maelstrom logger capture, 2026-10-26

Original-game acceptance: **false**. Exactly one authentic guest invocation used the unchanged retained 1,884,180-byte module `fec642f6c711e57e1c4a3dfaeaff0e11be587c56fc64cde394ed7f54147b5988`, accepted main `c6279bb936462834ccd9b51ea99a684a5befcda3`, staged original assets and runner. No rebuild, synthetic replay, semantic source change or main integration.

The repaired bootstrap passed offline create/write/fsync/readback/unlink probes for every logger/process-output parent. All 250 manifest inputs were hash verified. The canonical parser enumerated 48 exact original file mappings, including comma-bearing filenames, and rejecting controls passed. Fresh Node startup passed with the new TMPDIR and intended environment/limits. One relocated validator relative import failed before guest execution; its absolute path repair and original error are recorded.

The one guest invocation (supervisor45702, child/group45706) started the native adapter, then rejected at batch0: `native latch status rejection`, status5/event0. Select started1, phase0, entries0, completions0; native/select ownership fields remained zero. The adapter stored the rejection before throwing (adapter lines107–113). `historicalNativeRejection` is null and rejectReason plus other rejection scalars are zero, so the underlying predicate is UNKNOWN. The helper lines153–157 have an awaiting-select UOP mode-switch rejection without a reason code; this is a source-backed possible path, not a measured attribution. There was no select completion, owned native CALL/RET or before-CMP acquisition. **Errno, caller, invocation token/thread/register ownership and select result remain UNKNOWN, not zero.**

Unlike the previous attempt, raw `loaded-before-validation`, `loaded-verified` and `first-latch-rejection` records were persisted. Authentic CRT loaded at0x522000 and SDL_net at0x7a2000. The unchanged pinned CRT `_errno` CALL resolves to loaded `_getptd`0x525857; all64 loaded bytes match the original PE after its own HIGHLOW relocations. These loader checks pass independently of the absent invocation capture. The intact loaded CMP bytes alone do not establish the required boundary. Raw trace, all register snapshots, command/limits and hashes are bound by manifest.json.

Guest exited1 naturally after0.134s; CPU90, wall60, output131072, file25165824, heap512MiB and fixed arena512MiB. DATA/AS were unlimited for Node; Git DATA536870912 applies only to Git subprocesses. Fresh local/remote admissions passed before invocation, including client overhead and full64MiB allocation with metadata, preserved old local/remote/session, new artifacts, positive DB delta, shared WAL/SHM once, future once and8MiB reserve. Publication uses a small docs-only Git object tree with a read-only donor alternate; no full checkout or ancestor recovery/packing. Fresh projection includes512KiB Git transient allowance before push. No histories or evidence were deleted to fit.

The earlier sole guest's ENOENT before verifyLoaded/start and the late transient-packing UNQUALIFIED incident remain preserved under commit ef30151795e09c1d48a357bffe3dd3b3ff24ccdd and the read-only donor. This successful logger control does not retroactively qualify either incident. Guest invocations in this assignment: one; no retry.

Reproduce only under fresh coordinator authorization: `python3 /tmp/maelstrom-retained-logger-original-capture-oct26/ops/supervise.py guest` after fresh offline/admission/startup gates. The retained guest-args.json and configuration receipt bind the exact executable/module/assets/flags, helper3ea873bc5c18283fc6045b55d00a2e957eaff46b4372534dd59fba18354a9f6f and adapter28c1c3249ef488d4b2df1ccb3d0658cc1b02803ca9163f5a2bb24f945ba00551. Existing one-invocation guards intentionally prevent rerunning this owned output tree. Immutable inputs must never be reconstructed or substituted.

Box bx_vs4xtsz3 is left RUNNING, PIDs45702/45706 absent, no remaining group. Coordinator owns handback10:21UTC and shutdown10:25UTC; cutoff10:17UTC, expiry10:32:43.299UTC. No shutdown, SSH/SCP, services, worker spawning or successor selection. Gameplay/performance/other engines remain unqualified. Task stops after publication or a precise publication blocker.
''')
R=H/'repo';R.mkdir(exist_ok=True)
def limits():
 for k,v in [(resource.RLIMIT_DATA,536870912),(resource.RLIMIT_CPU,90),(resource.RLIMIT_FSIZE,25165824)]:resource.setrlimit(k,(v,v))
def git(*args,input=None):
 p=subprocess.run(['git','-c','pack.threads=1','-c','pack.window=0','-c','pack.windowMemory=16m',*args],cwd=R,input=input,capture_output=True,env=dict(os.environ,GIT_SSH_COMMAND=SSH),preexec_fn=limits,timeout=120);assert len(p.stdout)+len(p.stderr)<=131072;assert p.returncode==0,(args,p.returncode,p.stderr[:2000]);return p.stdout
account('before-git-init',r['allocated'],524288)
git('init','--quiet');alt=R/'.git/objects/info/alternates';alt.write_text(str(D/'repo/.git/objects')+'\n');git('config','user.name','Wine Assembly Agent');git('config','user.email','agent@wine-assembly.local');git('remote','add','origin','git@github.com:vgrichina/wine-assembly.git')
parent='ef30151795e09c1d48a357bffe3dd3b3ff24ccdd';base=git('rev-parse',parent+'^{tree}').decode().strip();branch='task/'+H.name;git('symbolic-ref','HEAD','refs/heads/'+branch)
files={str(p.relative_to(P)):p for p in P.rglob('*') if p.is_file()};blobs={path:git('hash-object','-w','--stdin',input=p.read_bytes()).decode().strip() for path,p in files.items()}
def update(tree,parts,oid,mode='100644',typ='blob'):
 entries={}
 if tree:
  for item in git('ls-tree','-z',tree).split(b'\0'):
   if item:
    head,name=item.split(b'\t',1);m,t,o=head.decode().split();entries[name.decode()]=(m,t,o)
 name=parts[0]
 if len(parts)>1:
  child=update(entries.get(name,(None,None,None))[2],parts[1:],oid,mode,typ);entries[name]=('040000','tree',child)
 else:entries[name]=(mode,typ,oid)
 data=b''.join((m+' '+t+' '+o+'\t'+n).encode()+b'\0' for n,(m,t,o) in sorted(entries.items()))
 return git('mktree','-z',input=data).decode().strip()
# One nested tree per evidence directory; avoids repeated ancestor trees.
def localtree(prefix=''):
 entries=[];children={}
 for path,oid in blobs.items():
  if not path.startswith(prefix):continue
  sub=path[len(prefix):];first,sep,rest=sub.partition('/')
  if sep:children[first]=True
  else:entries.append(('100644','blob',oid,first))
 for c in children:entries.append(('040000','tree',localtree(prefix+c+'/'),c))
 return git('mktree','-z',input=b''.join((m+' '+t+' '+o+'\t'+n).encode()+b'\0' for m,t,o,n in sorted(entries,key=lambda e:e[3]))).decode().strip()
tree=update(base,['docs','reviews',H.name],localtree(),mode='040000',typ='tree');commit=git('commit-tree',tree,'-p',parent,input=b'docs: retain corrected Maelstrom logger capture and native rejection\n').decode().strip();git('update-ref','refs/heads/'+branch,commit)
save('publication-local.json',dict(commit=commit,branch=branch,parent=parent,files=len(files),docsOnly=True,noCheckout=True))
# The remote already owns the parent; push sends only these small new objects.
newobjs=size(R/'.git/objects');assert newobjs<524288,newobjs
account('immediate-prepush',r['allocated'],524288)
git('push','origin','HEAD:refs/heads/'+branch);actual=git('ls-remote','--heads','origin','refs/heads/'+branch).decode().strip();assert actual==commit+'\trefs/heads/'+branch
for path,p in files.items():assert git('show',commit+':docs/reviews/'+H.name+'/'+path)==p.read_bytes()
save('publication-verified.json',dict(commit=commit,branch=branch,remote=actual,payloadsVerified=len(files),docsOnly=True,mainUntouched=True));final=account('final',r['allocated'])
result=dict(status='NATIVE_LATCH_REJECTED_BEFORE_SELECT',originalGameAcceptance=False,errno=None,caller=None,guestAttempts=1,commit=commit,branch=branch,remote=actual,verified=True,report='docs/reviews/'+H.name+'/README.md',evidence=str(O),box=json.load(open(O/'box-handback.json')),resource=final)
save('result.json',result);(W/'task-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(commit=commit,remote=actual,files=len(files),peak=final['peak'])))
