from common import *
save('preparation-incident.json',dict(kind='validator relocation MODULE_NOT_FOUND',commandId='cmd_morlqvuftdo0',cause="relative require ./runner/lib/vfs-host-files resolved against new ops directory",guestInvoked=False,repair='absolute require pointing at unchanged staged donor helper'))
p=O/'validate-tree.cjs';s=p.read_text().replace("require('./runner/lib/vfs-host-files')","require("+json.dumps(str(D/'runner/lib/vfs-host-files'))+")");p.write_text(s);put(p)
j=remote('node --max-old-space-size=512 '+shlex.quote(str(p)));save('mount-api.json',j);m=json.loads(j['stdout']);assert m['pass']
save('checkpoint-offline.json',dict(offline=json.loads(json.load(open(O/'offline-control-api.json'))['stdout']),mount=m,guestAttempts=0,passing=True));print('OFFLINE PASS')
j=remote('python3 '+shlex.quote(str(O/'supervise.py'))+' startup');save('startup-api.json',j);r=json.loads(j['stdout']);assert r['exit']==0 and not r['remainingGroup'];print('STARTUP PASS')
