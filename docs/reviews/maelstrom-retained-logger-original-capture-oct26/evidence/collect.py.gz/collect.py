from common import *
import base64
j=py('import pathlib,json,hashlib,base64;h=pathlib.Path('+repr(str(H))+');paths=[h/"guest/native.jsonl",h/"guest/native.jsonl.raw.jsonl",h/"ops/guest/command.json",h/"ops/guest/terminal.json",h/"ops/guest/output.log",h/"ops/guest-invoked.json",h/"ops/offline-control.json",h/"ops/mount-enumeration.json",h/"ops/startup/terminal.json",h/"ops/startup/output.log"];r=[]\nfor p in paths:\n if p.exists():\n  b=p.read_bytes();assert len(b)<=65536;r.append(dict(path=str(p.relative_to(h)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),base64=base64.b64encode(b).decode()))\nprint(json.dumps(r))');rows=json.loads(j['stdout']);manifest=[]
for row in rows:
 b=base64.b64decode(row.pop('base64'));assert sha(b)==row['sha256'];p=O/'collected'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);manifest.append(row)
save('collected-manifest.json',manifest)
print((O/'collected/ops/guest/output.log').read_text()[-6500:]);print((O/'collected/guest/native.jsonl.raw.jsonl').read_text()[:6500])
