from common import *
account('before-script-write',extra=262144)
base=(D/'ops/supervise-corrected.py').read_text();assert sha(base.encode())=='6002a1b0a6ff5a6f4a2a1f89448f090ee3f7e26404aa76058e254f0981747790'
s=base.replace("H=pathlib.Path(__file__).resolve().parent.parent;O=H/'ops';mode=sys.argv[1];cutoff=1793008800.0", "H=pathlib.Path('/tmp/maelstrom-current-uop-original-errno-capture-oct26');N=pathlib.Path('/tmp/maelstrom-retained-logger-original-capture-oct26');O=N/'ops';mode=sys.argv[1];cutoff=1793009820.0")
s=s.replace("assert mode in ['startup','compile','guest']","assert mode in ['startup','guest']")
s=s.replace("MNE_STANDING=str(O),MNE_ANCHORS=str(O/'anchors')","MNE_STANDING=str(H/'ops'),MNE_ANCHORS=str(H/'ops/anchors')")
s=s.replace("argv=json.load(open(H/'guest-args.json'));argv[0]=node;cwd=H/'runner'","argv=json.load(open(N/'guest-args.json'));argv[0]=node;cwd=H/'runner'")
s=s.replace("if mode=='guest':(H/'guest').mkdir(exist_ok=False)","if mode=='guest':\n assert (O/'offline-control.json').exists()\n assert (N/'guest').is_dir() and (H/'guest').is_dir()\n assert not (O/'guest-invoked.json').exists()\n (O/'guest-invoked.json').write_text(json.dumps(dict(at=time.time(),attempt=1,cutoff='2026-10-26T10:17:00Z')))" )
assert '1793008800' not in s;compile(s,'supervise.py','exec');(O/'supervise.py').write_text(s)
a=json.load(open(D/'guest-args.json'));assert a[-1]=='--original-native-record='+str(D/'guest/native.jsonl');a[-1]='--original-native-record='+str(H/'guest/native.jsonl');(H/'guest-args.json').write_text(json.dumps(a,indent=2)+'\n')
# All immutable input mappings are reused. No asset/module reconstruction.
module=D/'ops/errno-latch.wasm';assert module.stat().st_size==1884180 and sha(module.read_bytes())=='fec642f6c711e57e1c4a3dfaeaff0e11be587c56fc64cde394ed7f54147b5988'
save('configuration.json',dict(box=BOX,guestCutoff='2026-10-26T10:17:00Z',handback='2026-10-26T10:21:00Z',shutdown='2026-10-26T10:25:00Z',expiry='2026-10-26T10:32:43.299Z',donor=str(D),moduleSHA256=sha(module.read_bytes()),moduleBytes=module.stat().st_size,supervisorSHA256=sha(s.encode()),oldSupervisorSHA256=sha(base.encode()),argv=a,changes=['new owned ops/TMPDIR and native record paths','create logger parents and writable probes offline','new cutoff; startup receipt for environment change'],priorIncidentsPreserved=['ENOENT before observer start','transient packing UNQUALIFIED'],trustedSSH=SSH))
for p in [O/'supervise.py',H/'guest-args.json']:put(p)
# Canonical parser uses unchanged argv apart from native-record (unparsed by mounts).
validator=(D/'validate-tree.cjs').read_text();validator=validator.replace('const H=__dirname,', 'const H='+json.dumps(str(D))+',').replace("path.join(H,'tree-validation.json')",json.dumps(str(O/'mount-enumeration.json')))
(O/'validate-tree.cjs').write_text(validator);put(O/'validate-tree.cjs')
# Read all exact manifest pins; emit bounded identity summary only.
script='''import pathlib,json,hashlib,os
D=pathlib.Path(%r);N=pathlib.Path(%r);O=N/'ops'
manifest=json.load(open(D/'manifest.json'))
for r in manifest:
 p=D/r['target'];b=p.read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['target']
module=D/'runtime/build/wine-assembly.wasm';assert hashlib.sha256(module.read_bytes()).hexdigest()=='fec642f6c711e57e1c4a3dfaeaff0e11be587c56fc64cde394ed7f54147b5988'
assert hashlib.sha256((D/'runner/tools/maelstrom-original-errno-adapter.cjs').read_bytes()).hexdigest()=='28c1c3249ef488d4b2df1ccb3d0658cc1b02803ca9163f5a2bb24f945ba00551'
assert hashlib.sha256((D/'runner/tools/maelstrom-native-errno-latch.cjs').read_bytes()).hexdigest()=='3ea873bc5c18283fc6045b55d00a2e957eaff46b4372534dd59fba18354a9f6f'
# Historical directory creation is the single authorized donor-tree mutation.
assert not (D/'guest').exists();(D/'guest').mkdir();(N/'guest').mkdir()
parents=[D/'guest',N/'guest',O,O/'startup',O/'guest']
for p in parents:
 p.mkdir(exist_ok=True);f=p/'.write-control';assert not f.exists()
 with f.open('xb') as w:w.write(b'maelstrom-logger-offline-write-control\\n');w.flush();os.fsync(w.fileno())
 assert f.read_bytes()==b'maelstrom-logger-offline-write-control\\n';f.unlink()
# Supervisor creates its process evidence directory itself; remove empty probe parents.
(O/'startup').rmdir();(O/'guest').rmdir()
r=dict(passChecks=True,manifestPins=len(manifest),manifestSHA256=hashlib.sha256((D/'manifest.json').read_bytes()).hexdigest(),parents=[str(p) for p in parents],nativeOutput=str(N/'guest/native.jsonl'),rawOutput=str(N/'guest/native.jsonl.raw.jsonl'),guestInvoked=False,donorOldReceiptsUntouched=True)
(O/'offline-control.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
'''%(str(D),str(H))
(O/'offline-control.py').write_text(script);put(O/'offline-control.py')
j=remote('python3 '+shlex.quote(str(O/'offline-control.py')));save('offline-control-api.json',j)
j=remote('node --max-old-space-size=512 '+shlex.quote(str(O/'validate-tree.cjs')));save('mount-api.json',j)
save('checkpoint-offline.json',dict(offline=json.loads((O/'offline-control-api.json').read_text())['stdout'],mount=json.loads(j['stdout']),guestAttempts=0,passing=True));print('OFFLINE PASS')
j=remote('python3 '+shlex.quote(str(O/'supervise.py'))+' startup');save('startup-api.json',j);r=json.loads(j['stdout']);assert r['exit']==0 and not r['remainingGroup'];print('STARTUP PASS')
