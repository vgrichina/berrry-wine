import pathlib,subprocess,json,os,hashlib,shutil,time,shlex,resource
H=pathlib.Path('/tmp/maelstrom-retained-logger-original-capture-oct26');O=H/'ops';D=pathlib.Path('/tmp/maelstrom-current-uop-original-errno-capture-oct26');ROOT=pathlib.Path('/home/user/wine-assembly');W=ROOT/'scratch/usage-watch'/H.name;C=pathlib.Path('/home/user/.codex');BOX='bx_vs4xtsz3'
SSH='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
def save(n,j):(O/n).write_text(json.dumps(j,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def alloc(p):
 try:s=p.lstat();return max(s.st_size,s.st_blocks*512)
 except FileNotFoundError:return 0
def size(p):return alloc(p)+sum(alloc(q) for q in p.rglob('*')) if p.is_dir() and not p.is_symlink() else alloc(p)
def remote(cmd,timeout=30):
 assert len(cmd.encode())<36000
 p=subprocess.run(['/home/user/.ascii/boat','--no-update','--json','exec','--timeout',str(timeout),BOX,cmd],capture_output=True,text=True,timeout=timeout+15)
 assert len(p.stdout.encode())+len(p.stderr.encode())<=131072
 j=json.loads(p.stdout)
 with (O/'api-history.jsonl').open('a') as f:f.write(json.dumps(dict(at=time.time(),commandSHA256=sha(cmd.encode()),commandId=j.get('commandId'),responseBytes=len(p.stdout)))+'\n')
 assert p.returncode==0 and j.get('exitCode')==0 and not any(j.get(k) for k in ['stdoutTruncated','stderrTruncated','oomKilled','timedOut']),j
 return j
def py(s,timeout=30):return remote('python3 -c '+shlex.quote(s),timeout)
def put(p):
 import base64
 b=p.read_bytes();assert len(b)<24000
 j=py('import pathlib,base64,hashlib;p=pathlib.Path('+repr(str(p))+');p.parent.mkdir(parents=True,exist_ok=True);b=base64.b64decode('+repr(base64.b64encode(b).decode())+');p.write_bytes(b);print(hashlib.sha256(p.read_bytes()).hexdigest())');assert j['stdout'].strip()==sha(b)
 return j
SESSION=next((C/'sessions/2026/10/26').glob('*01a177ac-f897-73c2-be59-3ad4f77a6372.jsonl'))
def account(stage,remoteBytes=18149376,extra=0):
 base=json.load(open(D/'ops/db-baseline.json'));old=next((C/'sessions/2026/10/26').glob('*01a17792-ce1d-7f43-8678-8bcdabd5c979.jsonl'))
 charges=dict(oldLocal=size(D),oldRemote=remoteBytes,oldSession=alloc(old),newLocal=size(H),launcher=size(W),session=alloc(SESSION),DB=sum(max(0,alloc(p)-base.get(str(p),0)) for p in C.glob('*.sqlite')),WALSHMOnce=sum(alloc(p) for p in C.glob('*.sqlite-*')),futurePublicationSessionOnce=2097152,DBFutureOnce=2097152,reserve=8388608,operationPeak=extra)
 mem=int(next(l.split()[1] for l in open('/proc/meminfo') if l.startswith('MemAvailable')))*1024;disk=shutil.disk_usage(H).free;peak=sum(charges.values());j=dict(at=time.time(),charges=charges,peak=peak,cap=67108864,memAvailable=mem,diskFree=disk,passChecks=peak<=67108864 and mem>=1895825408 and disk-4194304-extra>=2982150144);save('resource-'+stage+'.json',j);assert j['passChecks'],j;return j
