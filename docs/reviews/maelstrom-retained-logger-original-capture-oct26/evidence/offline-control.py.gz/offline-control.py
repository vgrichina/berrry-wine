import pathlib,json,hashlib,os
D=pathlib.Path('/tmp/maelstrom-current-uop-original-errno-capture-oct26');N=pathlib.Path('/tmp/maelstrom-retained-logger-original-capture-oct26');O=N/'ops'
manifest=json.load(open(D/'manifest.json'))
for r in manifest:
 p=D/r['target'];b=p.read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['target']
module=D/'runtime/build/wine-assembly.wasm';assert hashlib.sha256(module.read_bytes()).hexdigest()=='fec642f6c711e57e1c4a3dfaeaff0e11be587c56fc64cde394ed7f54147b5988'
assert hashlib.sha256((D/'runner/tools/maelstrom-original-errno-adapter.cjs').read_bytes()).hexdigest()=='28c1c3249ef488d4b2df1ccb3d0658cc1b02803ca9163f5a2bb24f945ba00551'
assert hashlib.sha256((D/'runner/tools/maelstrom-native-errno-latch.cjs').read_bytes()).hexdigest()=='3ea873bc5c18283fc6045b55d00a2e957eaff46b4372534dd59fba18354a9f6f'
# Historical directory creation is the single authorized donor-tree mutation.
assert not (D/'guest').exists();(D/'guest').mkdir();(N/'guest').mkdir()
parents=[D/'guest',N/'guest',O,O/'startup',O/'guest']
for p in parents:
 p.mkdir(exist_ok=True);f=p/'.write-control';assert not f.exists()
 with f.open('xb') as w:w.write(b'maelstrom-logger-offline-write-control\n');w.flush();os.fsync(w.fileno())
 assert f.read_bytes()==b'maelstrom-logger-offline-write-control\n';f.unlink()
# Supervisor creates its process evidence directory itself; remove empty probe parents.
(O/'startup').rmdir();(O/'guest').rmdir()
r=dict(passChecks=True,manifestPins=len(manifest),manifestSHA256=hashlib.sha256((D/'manifest.json').read_bytes()).hexdigest(),parents=[str(p) for p in parents],nativeOutput=str(N/'guest/native.jsonl'),rawOutput=str(N/'guest/native.jsonl.raw.jsonl'),guestInvoked=False,donorOldReceiptsUntouched=True)
(O/'offline-control.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
