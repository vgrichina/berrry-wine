import pathlib,json,hashlib,shutil
O=pathlib.Path('/tmp/ricochet-same-size-version-repair-oct27/ops');R=O.parent/'repo';D=pathlib.Path('/tmp/ricochet-pinned-unlinked-version-repair-oct27');m=json.loads((D/'ops/receipt-manifest.json').read_text());pins=m['sourceTestPins']
for p,pin in pins.items():
 b=(D/'repo'/p).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];t=R/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
assert hashlib.sha256((R/'tools/ricochet/runtime-accounting.py').read_bytes()).hexdigest()=='eda4947b2e96b115fcc92deecf147cb8fdeb03189f4600fdb9be82b45a18dae4'
# Flatten read-only object-store alternates without copying/repacking donor objects.
seen=set();stores=[]
def visit(p):
 p=p.resolve()
 if p in seen:return
 seen.add(p);stores.append(str(p));a=p/'info/alternates'
 if a.exists():
  for line in a.read_text().splitlines():visit(pathlib.Path(line) if line.startswith('/') else p/line)
visit(D/'repo/.git/objects')
(R/'.git/objects/info/alternates').write_text('\n'.join(stores)+'\n')
(R/'.git/info/sparse-checkout').write_text('/tools/ricochet/\n/test/ricochet-*\n/docs/reviews/ricochet-same-size-version-repair-oct27/\n')
config=(D/'repo/.git/config').read_text();import re
url=re.search(r'\[remote "origin"\]\n\s*url = (.+)',config).group(1)
(R/'.git/config').write_text('[core]\n repositoryformatversion = 0\n bare = false\n sparseCheckout = true\n[remote "origin"]\n url = '+url+'\n[user]\n name = Wine Ops\n email = wine-ops@localhost\n[gc]\n auto = 0\n')
(O/'input-pins.json').write_text(json.dumps(dict(candidate='03b1c12fb6edd1ca88ff51658fea811f26c740ec',sourceTestPins=pins,reuse=m.get('reusedReceipts'),donorManifestSHA256=hashlib.sha256((D/'ops/receipt-manifest.json').read_bytes()).hexdigest(),alternates=stores,mounts='none; source-only; no mount argv',rootRefReceipt='/home/user/wine-assembly/scratch/usage-watch/ricochet-same-size-version-repair-oct27/root-ref-digest.json'),indent=2))
print('Pinned source/test closure staged without checkout; immutable read-only alternate stores:',len(stores))
