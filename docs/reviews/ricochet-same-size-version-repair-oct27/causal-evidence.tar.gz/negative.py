import os,sys,runpy
os.environ["RICOCHET_ACCOUNTING_SOURCE"]='/tmp/ricochet-same-size-version-repair-oct27/ops/original-runtime-accounting.py'
sys.argv=['/tmp/ricochet-same-size-version-repair-oct27/repo/test/ricochet-same-size-version.test.py', 'SameSizeTests.test_original_exact_attack', 'SameSizeTests.test_original_write_restore_attack']
runpy.run_path(sys.argv[0],run_name="__main__")
