import pathlib
P=pathlib.Path('/tmp/ricochet-same-size-version-repair-oct27/repo/tools/ricochet/runtime-accounting.py');s=P.read_text().replace('import hashlib\n','import ctypes\nimport hashlib\nimport struct\n')
pos=s.index('\ndef _open_path')
s=s[:pos]+'''
class _ControlChanges:
    """Linux inode events close the unlink/ctime ambiguity, including write/restore.

    Directory watches precede enumeration/open; inode watches precede the first
    version observation and remain attached after unlink. Reading a control or
    consuming it without writing generates no IN_MODIFY. Overflow fails closed.
    No content or event buffer scales with a control's reserved size.
    """
    def __init__(self, controls, bound):
        self.controls, self.bound, self.watches = controls, bound, {}
        self.libc = ctypes.CDLL(None, use_errno=True)
        self.libc.inotify_init1.argtypes = [ctypes.c_int]
        self.libc.inotify_init1.restype = ctypes.c_int
        self.libc.inotify_add_watch.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_uint32]
        self.libc.inotify_add_watch.restype = ctypes.c_int
        self.fd = self.libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
        if self.fd < 0:
            raise AccountingError('control event monitor unavailable')

    def watch(self, fd, p, directory=False):
        if directory and not any(p == q.parent for q in self.controls):
            return
        # IN_MODIFY plus rename events; unlink itself is permitted. Watch the
        # pinned descriptor, never a separately resolved mutable pathname.
        mask = 0x2 | (0x40 | 0x80 if directory else 0x800)
        wd = self.libc.inotify_add_watch(self.fd, os.fsencode('/proc/self/fd/'+str(fd)), mask)
        if wd < 0:
            raise AccountingError('cannot watch control version: '+str(p))
        self.watches.setdefault(wd, set()).add((p, directory))

    def check(self):
        while True:
            self.bound()
            try:
                data = os.read(self.fd, 65536)
            except BlockingIOError:
                return
            if not data:
                raise AccountingError('control event monitor closed')
            offset = 0
            while offset < len(data):
                wd, mask, cookie, length = struct.unpack_from('iIII', data, offset)
                offset += 16
                name = os.fsdecode(data[offset:offset+length].split(b'\\0', 1)[0])
                offset += length
                if mask & 0x4000:
                    raise AccountingError('control event queue overflow')
                if mask & (0x2 | 0x40 | 0x80 | 0x800):
                    for p, directory in self.watches.get(wd, ()):
                        if not directory or p/name in self.controls:
                            raise AccountingError('control modified/moved during scan: '+str(p/name if directory else p))

    def close(self):
        os.close(self.fd)

''' + s[pos:]
s=s.replace('            opened = os.fstat(fd)','            if p in self.ephemeral:\n                self.control_changes.watch(fd, p)\n            opened = os.fstat(fd)')
s=s.replace('        before = os.fstat(fd)\n        self._remember', '        self.control_changes.watch(fd, p, directory=True)\n        before = os.fstat(fd)\n        self._remember')
s=s.replace('        try:\n            self._charge(sum(self.ephemeral.values()))','        self.control_changes = None\n        try:\n            self.control_changes = _ControlChanges(self.ephemeral, self._bound)\n            self._charge(sum(self.ephemeral.values()))')
s=s.replace('            self._bound()\n            self.receipt.update','            self.control_changes.check()\n            self._bound()\n            self.receipt.update')
s=s.replace('            for fd in self.control_fds.values():\n                os.close(fd)','            for fd in self.control_fds.values():\n                os.close(fd)\n            if self.control_changes is not None:\n                self.control_changes.close()')
P.write_text(s)
print('Added bounded inode+parent modification monitor; linked/unlinked version checks unchanged')
