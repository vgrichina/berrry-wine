#!/bin/bash
set -euo pipefail
label=$1
shift
exec python3 /home/user/wine-assembly/scratch/usage-watch/light-execution-pool-oct26.py --slots 2 -- python3 -B -S /tmp/ricochet-same-size-version-repair-oct27/ops/run.py git "$label" git -C /tmp/ricochet-same-size-version-repair-oct27/repo "$@"
