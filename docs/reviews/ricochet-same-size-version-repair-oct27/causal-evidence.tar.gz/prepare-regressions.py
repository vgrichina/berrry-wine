import pathlib,json,hashlib,difflib
O=pathlib.Path('/tmp/ricochet-same-size-version-repair-oct27/ops');R=O.parent/'repo';D=pathlib.Path('/tmp/ricochet-pinned-unlinked-version-repair-oct27')
m=json.loads((D/'ops/input-pins.json').read_text());verified={}
for p,pin in m['sourceTestPins'].items():
 if p=='tools/ricochet/runtime-accounting.py':continue
 b=(D/'repo'/p).read_bytes();assert hashlib.sha256(b).hexdigest()==pin['sha256'];t=R/p;t.parent.mkdir(parents=True,exist_ok=True)
 if t.exists():assert t.read_bytes()==b
 else:t.write_bytes(b)
 verified[p]=pin
(O/'dependency-pins.json').write_text(json.dumps(verified,indent=2))
p=R/'tools/ricochet/runtime-accounting.py';h=hashlib.sha256(p.read_bytes()).hexdigest()
original=(R/'test/ricochet-consumed-independent.test.py').read_text();adapted=original.replace('/tmp/ricochet-consumed-control-accounting-repair-oct27/repo',str(R)).replace('857e30508c1e4db1c943b765a0e7551842973032cc5431eb08235dabda903364',h)
(O/'affected-consumed.py').write_text(adapted);(O/'affected-adaptation.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),adapted.splitlines(True))))
# Historical command arguments only: never execute donor wrappers or write donor evidence.
for label in ('affected-original','affected-consumed'):
 old=json.loads((D/'ops'/ (label+'.command.json')).read_text())['argv'];args=old[4:];script=R/'test/ricochet-runtime-accounting.test.py' if label=='affected-original' else O/'affected-consumed.py'
 (O/(label+'-run.py')).write_text('import sys,runpy\nsys.argv='+repr([str(script),*args])+'\nrunpy.run_path(sys.argv[0],run_name="__main__")\n')
(O/'original-runtime-accounting.py').write_bytes((D/'repo/tools/ricochet/runtime-accounting.py').read_bytes())
print('Verified dependency closure; owned pin-only consumed adaptation; preserved historical argument groups')
