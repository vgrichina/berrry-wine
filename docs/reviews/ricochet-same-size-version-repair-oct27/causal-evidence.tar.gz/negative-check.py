import os,pathlib,importlib.util,unittest,json,hashlib
O=pathlib.Path('/tmp/ricochet-same-size-version-repair-oct27/ops');R=O.parent/'repo';p=O/'original-runtime-accounting.py';assert hashlib.sha256(p.read_bytes()).hexdigest()=='eda4947b2e96b115fcc92deecf147cb8fdeb03189f4600fdb9be82b45a18dae4'
os.environ['RICOCHET_ACCOUNTING_SOURCE']=str(p)
s=importlib.util.spec_from_file_location('negative',R/'test/ricochet-same-size-version.test.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
suite=unittest.TestSuite(m.SameSizeTests(n) for n in ['test_original_exact_attack','test_original_write_restore_attack']);r=unittest.TextTestRunner(verbosity=2).run(suite)
receipt=dict(tests=r.testsRun,failures=len(r.failures),errors=len(r.errors),sourceSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),expected='Two missing AccountingError assertions on unchanged original')
(O/'negative-control.json').write_text(json.dumps(receipt,indent=2));assert r.testsRun==2 and len(r.failures)==2 and not r.errors
assert all('not raised' in trace for test,trace in r.failures)
