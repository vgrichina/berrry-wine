#!/bin/bash
set -euo pipefail
label=$1
shift
exec python3 /home/user/wine-assembly/scratch/usage-watch/light-execution-pool-oct26.py --slots 1 -- python3 -B -S /tmp/ricochet-same-size-version-repair-oct27/ops/run.py python "$label" python3 -B -S "$@"
