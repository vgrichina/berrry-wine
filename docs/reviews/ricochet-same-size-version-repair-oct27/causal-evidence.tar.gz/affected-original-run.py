import sys,runpy
sys.argv=['/tmp/ricochet-same-size-version-repair-oct27/repo/test/ricochet-runtime-accounting.test.py', 'AccountingTests.test_consumption_after_descriptor_open', 'AccountingTests.test_consumption_immediately_after_open', 'AccountingTests.test_control_link_and_replacement_races', 'AccountingTests.test_control_reservation_and_recreation', 'AccountingTests.test_bounds_and_configuration', 'AccountingTests.test_missing_retained_between_enumeration_and_stat_rejects']
runpy.run_path(sys.argv[0],run_name="__main__")
