import pathlib
p=pathlib.Path('/tmp/ricochet-same-size-version-repair-oct27/repo/tools/ricochet/runtime-accounting.py');s=p.read_text().replace('0x40 | 0x80 | 0x100 if directory','0x4 | 0x40 | 0x80 | 0x100 if directory').replace('if mask & (0x2 | 0x40 | 0x80 | 0x800):','if mask & (0x2 | 0x4 | 0x40 | 0x80 | 0x800):');p.write_text(s)
