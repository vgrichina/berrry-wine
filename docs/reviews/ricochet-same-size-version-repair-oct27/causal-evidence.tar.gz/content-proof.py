import pathlib
P=pathlib.Path('/tmp/ricochet-same-size-version-repair-oct27/repo/tools/ricochet/runtime-accounting.py');s=P.read_text()
pos=s.index('    def _file(')
s=s[:pos]+'''    def _control_digest(self, fd, p):
        # inotify does not report mmap writes. Compare bounded content as well,
        # using pread so the pinned/duplicated descriptors' offsets are untouched.
        h, offset = hashlib.sha256(), 0
        while True:
            self._bound()
            b = os.pread(fd, min(65536, self.ephemeral[p]+1-offset), offset)
            if not b:
                return h.digest()
            offset += len(b)
            if offset > self.ephemeral[p]:
                raise AccountingError('control exceeds reservation: '+str(p))
            h.update(b)

''' +s[pos:]
s=s.replace('                    self.control_versions[p] = _version(opened)','                    self.control_versions[p] = _version(opened)\n                    self.control_hashes[p] = self._control_digest(fd, p)')
s=s.replace('        self.control_fds, self.control_versions = {}, {}','        self.control_fds, self.control_versions, self.control_hashes = {}, {}, {}')
s=s.replace('                final = _version(os.fstat(fd))','                content = self._control_digest(fd, p)\n                final = _version(os.fstat(fd))\n                if content != self.control_hashes[p]:\n                    raise AccountingError(\'control content changed during scan: \'+str(p))')
P.write_text(s)
p=P.parents[2]/'test/ricochet-same-size-version.test.py';s=p.read_text().replace('import hashlib\n','import hashlib\nimport mmap\n')
s=s.replace("elif change == 'none':", "elif change == 'mmap':\n                    with mmap.mmap(writer, 2) as view:\n                        view[:] = b'[]'\n                        view.flush()\n                    os.utime(writer, ns=(initial.st_atime_ns, initial.st_mtime_ns))\n                    p.unlink()\n                elif change == 'none':")
s=s.replace("'grow', 'shrink', 'same', 'restore', 'after-unlink', 'rename'", "'grow', 'shrink', 'same', 'restore', 'mmap', 'after-unlink', 'rename'")
p.write_text(s)
print('Bounded content digests supplement inode events for mmap writes, preserve descriptor offsets')
