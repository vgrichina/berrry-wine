set -eu
cd /home/user/army-current-main/repo
python3 - <<'PY'
import json,pathlib,hashlib,subprocess,datetime
e=pathlib.Path('../evidence'); m=json.loads((e/'source-manifest.json').read_text())
for row in m['files']:
 b=pathlib.Path(row['path']).read_bytes(); assert hashlib.sha256(b).hexdigest()==row['sha256'],row['path']
c=json.loads(pathlib.Path('tools/callback-ownership-census.json').read_text())
rows=[]
for p in ['lib/apps.js','lib/browser-shell.js']:
 old=next(x for x in c['entries'] if x['file']==p and x['name']=='host-file')
 rows.append(dict(path=p,censusEntry=old,actualSha256=hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()))
r=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=m['revision'],verifiedSourceFiles=len(m['files']),changedProducers=rows,trackedStatus=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True),moduleExists=pathlib.Path('build/wine-assembly.wasm').exists())
assert r['trackedStatus']==''; assert not r['moduleExists']
(e/'postflight.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
PY
cp tools/build.sh ../evidence/canonical-build.sh
cp tools/callback-ownership-census.js ../evidence/callback-ownership-census.js
tar -czf /home/user/army-current-main/evidence.tgz -C /home/user/army-current-main evidence
