set -eu
cd /home/user/army-current-main/repo
python3 - <<'PY'
import pathlib,subprocess,json,hashlib
r=pathlib.Path('.'); rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert rev=='80f8278a90ed17767ede71f15b5ceff432da5ac4'
assert not subprocess.check_output(['git','status','--porcelain'])
files=[]
for row in subprocess.check_output(['git','ls-tree','-rz','HEAD']).split(b'\0'):
 if not row: continue
 meta,name=row.split(b'\t'); mode,kind,oid=meta.decode().split(); p=name.decode(); b=(r/p).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid,p
 files.append(dict(path=p,oid=oid,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
pathlib.Path('../evidence/source-manifest.json').write_text(json.dumps(dict(revision=rev,files=files),indent=2))
print('Exact source verified:',rev,len(files))
PY
npm ci --omit=dev --ignore-scripts > ../evidence/npm.log 2>&1
node tools/check-claude-size.js
node tools/check-wat-manifest.js
node tools/check-wat-fragments.js
set +e
bash tools/build.sh > ../evidence/build.log 2>&1
code=$?
printf '%s\n' "$code" > ../evidence/build.exit
tail -n 35 ../evidence/build.log
if [ "$code" -eq 0 ]; then sha256sum build/wine-assembly.wasm > ../evidence/module.sha256; fi
exit "$code"
