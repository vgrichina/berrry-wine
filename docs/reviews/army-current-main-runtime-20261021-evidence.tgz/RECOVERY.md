# Recovery

Task branch: `task/army-current-main-runtime-oct21`, parent exact main `80f8278a90ed17767ede71f15b5ceff432da5ac4`. Only report and compact evidence are added. No source changes or main integration.

Extract `docs/reviews/army-current-main-runtime-20261021-evidence.tgz` to a new directory and verify every `SHA256SUMS.json` entry. The adjacent report explains the blocker. Remote checkout remains `/home/user/army-current-main/repo` on `bx_e8a7pw8v`, with `evidence/` and `evidence.tgz` next to it. Never access it after it is stopped without a separate explicit assignment. The coordinator owns shutdown.

`stage-receipt.json` records a clean HTTPS Git clone and exact HEAD. `build.sh` records the complete preflight/build command, run via `python3 remote.py build.sh build-receipt.json`; the API helper uses the single assigned box. `preserve.sh` verifies exact source after failure and packages logs/inventory. `file-api.js` uses the authenticated Boat file download API without retaining credentials or signed URLs in evidence. `remote-evidence.tgz` is the original remote bundle; its expanded contents are also included for inspection.

The build failure is deterministic from the two mismatched census hashes preserved in `evidence/postflight.json`. No module exists to recover. Do not substitute the prior Hock or Army modules. Re-running this exact source without a separately reviewed producer-lifetime correction should fail the same canonical gate. Original asset recovery/closure and runtime qualification still require their own subsequently assigned task.
