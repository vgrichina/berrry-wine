import pathlib,hashlib,json,subprocess
r=pathlib.Path('/home/user/hock-accepted-canonical-runtime');repo=r/'repo'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a])
files=git('ls-files','-z').decode().split('\0');seals={f:sha(repo/f) for f in files if f and (repo/f).is_file()}
(r/'source-seals.json').write_text(json.dumps(seals,indent=2))
pkg={str(p.relative_to(r/'intake')):sha(p) for p in (r/'intake').rglob('*') if p.is_file()}
assert len(list((r/'intake/game').glob('*')))==39
assert pkg['beavislg.zip']=='e10d150131258641af11609249ac7f1c430e67e4138943d175b0365ba64be00b'
assert pkg['game/BBLOOGIE.EXE']=='974f1b5ff82cfdb87f05b9840ae03cd2ed6ceebe2c8ed547253dadaf1a871ef4'
(r/'package-seals.json').write_text(json.dumps(pkg,indent=2))
patch=git('diff','--cached');(r/'tested.patch').write_bytes(patch)
assert git('diff')==b''
(r/'identity.json').write_text(json.dumps(dict(base=git('rev-parse','HEAD').decode().strip(),baseTree=git('rev-parse','HEAD^{tree}').decode().strip(),stagedTree=git('write-tree').decode().strip(),patchSha256=hashlib.sha256(patch).hexdigest(),sourceSealsSha256=sha(r/'source-seals.json'),packageSealsSha256=sha(r/'package-seals.json'),wasmSha256=sha(repo/"build/wine-assembly.wasm") if (repo/"build/wine-assembly.wasm").exists() else None,wasmExists=(repo/'build/wine-assembly.wasm').exists(),node=subprocess.check_output(['node','--version']).decode().strip(),packageCount=39),indent=2))
print((r/'identity.json').read_text())
