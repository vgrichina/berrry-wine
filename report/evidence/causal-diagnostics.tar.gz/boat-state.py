gate('boat-state')
argv=['/home/user/.ascii/boat','info','--no-update','--json',BOX]
with (O/'boat-info.stdout').open('xb') as out,(O/'boat-info.stderr').open('xb') as err:
 p=subprocess.Popen(argv,stdout=out,stderr=err);r=p.wait(timeout=20)
save('boat-info-command.json',dict(argv=argv,exit=r,at=time.time()))
assert (O/'boat-info.stdout').stat().st_size+(O/'boat-info.stderr').stat().st_size<=8192
assert r==0
v=json.loads((O/'boat-info.stdout').read_text());save('boat-state.json',dict(at=time.time(),actual=v,lifecycleMutation=False,leaveRunning=True,coordinatorOwnsShutdown=True))
print(json.dumps(v))
