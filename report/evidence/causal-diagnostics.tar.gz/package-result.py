gate('package-result')
remote=O/'remote-evidence'; launch=remote/'launch'; controller=launch/'controller'
outcome=json.loads((controller/'outcome.json').read_text())
supervisor=json.loads((launch/'supervisor-outcome.json').read_text())
rows=[]
for p in launch.rglob('*.jsonl'):
 for line in p.read_text().splitlines():
  try: rows.append(json.loads(line))
  except json.JSONDecodeError: raise
responses=[r for r in rows if r.get('event')=='response']
steps=[r for r in responses if r.get('request',{}).get('action')=='step']
snapshots=[r for r in responses if r.get('request',{}).get('action')=='snapshot']
inputs=[r for r in responses if r.get('request',{}).get('cmd')]
step_summary=[]
for r in steps:
 a=json.loads(r['originalResponse'])['value'];n=r['request']['n'];expected=r['startingBatch']+n
 assert a['ran']==n and a['steps']==n and a['frozen'] is True and a['batch']==expected and n<=256
 following=next(x for x in responses if x['at']>=r['ended'])
 assert following['request']['action']=='snapshot'
 value=json.loads(following['originalResponse'])['value']
 assert value['batch']==expected and value['frozen']['frozen'] is True and value['frozen']['credits']==0 and value['frozen']['recording'] is False
 step_summary.append(dict(n=n,batch=expected,snapshot=value))
assert not inputs and not outcome['clicked'] and not outcome['pending'] and not outcome['failed']
assert supervisor['remainingOwnedLive']==[]
reviews=[json.loads((O/('review-'+str(i)+'.json')).read_text()) for i in (1,2)]
for i,r in enumerate(reviews,1):
 frame=json.loads((O/('frame-'+str(i)+'.json')).read_text());b=(O/('frame-'+str(i)+'.png')).read_bytes()
 assert sha(b)==frame['sha256']==r['frameSHA256'] and frame['batch']==r['batch'] and r['reviewed'] and not r['safeStartGame']
save('step-evidence-summary.json',dict(steps=len(steps),totalBatches=sum(x['request']['n'] for x in steps),largestStep=max(x['request']['n'] for x in steps),fullACK=True,followingSnapshots=step_summary,inputs=0))
accept=dict(status='ONE_INVOCATION_NO_REVIEWED_MAIN_MENU_NO_INPUT',at=time.time(),guestInvocations=1,source=json.loads((O/'pins.json').read_text()),controller=outcome,supervisor=supervisor,frames=reviews,reviewedActualMenu=False,startGame=False,gameplay=False,ordinaryGuestQuit=False,harnessQuit=True,cleanupQualification='Controller harness quit acknowledged; child exit0 and no survivors. control-listener-identity-changed is retained verbatim; no ordinary in-game Quit claim.',remainingGates=['reviewed actual Main Menu','correlated Start Game','inspected gameplay','ordinary game Quit'],box=BOX,leaveRunning=True,shutdownOwner='coordinator',cutoff='2026-10-27T12:43:00Z',handback='2026-10-27T12:46:00Z',shutdown='2026-10-27T12:48:00Z',expiry='2026-10-27T12:54:04.345Z',replay=False,tests='Accepted exact-revision source checks and independent tests reused; no synthetic tests or compilation repeated.',historicalIncidents=['Old run exhausted cumulative28second review; late menu decision did not authorize input; SIGTERM was not ordinary Quit.','Predecessor e39763d4cecab2bddad8df59d80f8d19e265f2c9 mistakenly validated remote executable on local host, zero guest. Canonical receipt SHA2565b96782d179631c8542932afe37667bd4aaee938f5ba5712d52b66848278bd18.','Accepted integration has two stale mutable late-closeout hashes; principal source/publication/test pins verified, no all-receipt claim.'],incidents=['Initial document display exceeded requested bounded display; original transcript retained.','Readiness started before final staging completed: remote closure FileNotFoundError, API completed normally, zero guest at failure. Final stage completed before closure check continuation.','Readiness continuation passed remote closure, mount and production validation; final local diagnostic print used overwritten variable v and raised KeyError mount after durable passing receipts. No passed check repeated.','Several tiny setup/decision Python helpers ran outside the prescribed pool; no retrospective wrapper-compliance claim. Production preparation/staging/preflight/invocation and publication use bounded supervisors/pool.','First collect pool wait45 expired before operation; no API sent. Further collection only after actual capacity change.'])
save('acceptance.json',accept)
save('transport-accounting.json',dict(responseBytes=sum(p.stat().st_size for p in (O/'responses').iterdir()),cap=8388608,pendingRequests=0,fullWireEnvelopesCounted=True,frameReadbacks=[json.loads((O/('frame-'+str(i)+'.png.receipt.json')).read_text()) for i in (1,2)]))
D=H/'repo/report';E=D/'evidence';E.mkdir(parents=True,exist_ok=True)
(H/'repo/.gitignore').write_text('/runner/\n/modules/\n/system/\n/vfs/\n')
(D/'README.md').write_text('Enigma: one remotely validated invocation, no Main Menu\n\nThe unchanged accepted production gate passed on bx_95a6wxyt with exact Node v24.22.1, filename-bearing canonical mount enumeration, complete runtime pins, exact startup and a measured 26+26-second review plan. One guest invocation ended at batch6913 after two actual full640x480 inspections: uniform teal startup, then an Enigma v1.01 window with black client. Neither frame showed an actual Main Menu. No input or Start Game was authorized, no gameplay accepted, no ordinary game Quit proven. Controller harness quit/child exit0 and original listener-identity cleanup reason are retained. No replay, source repair, build, native rerun, main integration or public deployment.\n\nRuntime is the retained emulator, diagnostic static DLL overlays and accepted current controllers, not a whole current-main emulator. Accepted source checks and independent tests were reused. Historical exhausted-review and zero-guest host-placement incidents remain in acceptance.json. Original sequencing/diagnostic-print failures and pool admission wait are preserved.\n\nReport-only orphan branch: never merge whole tree. Coordinator owns snapshot/stop and watchdog; Boat left running, expiry2026-10-27T12:54:04.345Z. Exact immutable runtime map and compact stage/control recipes enable recovery without publishing bulk base64 commands.\n')
inventory=[]
for p in sorted(O.rglob('*')):
 if p.is_file(): inventory.append(dict(path=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())))
(E/'local-evidence-manifest.json').write_text(json.dumps(inventory,indent=2)+'\n')
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as t:
 for p in sorted(O.rglob('*')):
  if p.is_file() and 'commands' not in p.parts and 'remote-evidence' not in p.parts and p.name!='terminal-evidence.tar.gz' and p.suffix!='.png':t.add(p,arcname=str(p.relative_to(O)))
assert len(buf.getvalue())<8388608
(E/'causal-diagnostics.tar.gz').write_bytes(buf.getvalue())
for n in ['acceptance.json','step-evidence-summary.json','runtime-manifest.json','launch-config.json','control.py','stage.py','runtime.py','remote-launch.py','frame-1.png','frame-2.png','terminal-evidence.tar.gz']:
 shutil.copyfile(O/n,E/n)
shutil.copyfile(ROOT/'scratch/usage-watch'/H.name/'root-ref-digest.json',E/'initial-root-ref-digest.json')
shutil.copyfile(pathlib.Path('/tmp/enigma-published-progressive-startgame-oct27/ops/result.json'),E/'historical-exhausted-review-result.json')
shutil.copyfile(pathlib.Path('/tmp/enigma-full-frame-admitted-runtime-oct27/ops/receipt-manifest.json'),E/'historical-host-placement-receipt.json')
payloads=[dict(path=str(p.relative_to(D)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(D.rglob('*')) if p.is_file()]
(E/'payload-index.json').write_text(json.dumps(payloads,indent=2)+'\n')
assert alloc(D)<16777216
save('publication-validation.json',dict(passGate=True,payloadFiles=len(payloads),bytes=sum(x['bytes'] for x in payloads),reportOnly=True,guestInvocations=1,allPayloadHashes=True))
print(json.dumps(dict(status=accept['status'],steps=len(steps),payloads=len(payloads),bytes=sum(x['bytes'] for x in payloads))))
