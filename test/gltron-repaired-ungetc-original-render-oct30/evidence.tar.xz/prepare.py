from control import *
import tarfile,io,re
O=pathlib.Path('/tmp/gltron-original-main-render-runtime-oct30')
D=pathlib.Path('/tmp/gltron-runner-closure-original-render-oct30')
admission('initial-forecast')
assert git(['rev-parse','HEAD'],'parent').decode().strip()==BASE
conf=json.loads((D/'evidence/launch-configuration.json').read_text())
runner=json.loads((D/'runner-closure-manifest.json').read_text())
assert conf['trustedSSH']==SSH and conf['source']==runner['files']['test/run.js']
assert conf['configuration']['parsed']==dict(app='gltron',mounts=[],trees=[],wasm='build/wine-assembly.wasm')
assert len(conf['configuration']['files'])==92
save('launch-configuration.json',dict(reusedExactReceipt=str(D/'evidence/launch-configuration.json'),receipt=pin((D/'evidence/launch-configuration.json').read_bytes()),trustedSSH=SSH,configuration=conf['configuration'],canonicalParserValidated=True,filenamesEnumerated=92,commaFilenames=[f['url'] for f in conf['configuration']['files'] if ',' in f['url']]))
pins=json.loads((O/'pinned-input-closure.json').read_text())
names=[n for n in pins['files'] if n.startswith(('src/','tools/','lib/'))]
def identities(commit,label):
 b=git(['ls-tree','-r',commit,'--',*names],label)
 return {line.split(b'\t')[1].decode():line.split()[2].decode() for line in b.splitlines()}
old=identities(pins['candidate'],'base-compile-identities');new=identities(BASE,'parent-compile-identities')
assert set(old)==set(new)==set(names)
changed=sorted(n for n in names if old[n]!=new[n])
src=['src/01b-api-hashes.generated.wat','src/09a6-handlers-crt.wat','src/09b2-dispatch-table.generated.wat','src/api_table.json']
assert changed==sorted(src),changed
repair=json.loads(pathlib.Path('/tmp/gltron-ungetc-closed-storage-repair-oct30/completion-receipt.json').read_text())
git(['archive','--format=tar.gz','--output='+str(R/'source-overlay.tar.gz'),BASE,*src],'compressed-four-source-overlay')
with tarfile.open(R/'source-overlay.tar.gz') as t:
 for n in src:assert pin(t.extractfile(n).read())==repair['files'][n],n
 api=json.loads(t.extractfile('src/api_table.json').read());assert api[4595]['name']=='ungetc',api[4595]
with tarfile.open(O/'pinned-source-closure.tar.xz') as t:
 sources={n:t.extractfile(n).read() for n in pins['files'] if n.startswith('src/')}
 seen=set()
 def visit(n):
  assert n in sources,n
  if n in seen:return
  seen.add(n)
  for v in re.findall(rb'\(include\s+"([^"]+)"',sources[n]):visit(str(pathlib.PurePosixPath(n).parent/v.decode()))
 visit('src/main.watx');assert len(seen)==128
save('source-boundary.json',dict(PASS=True,parent=BASE,retainedCandidate=pins['candidate'],compileFiles=len(names),canonicalClosure=sorted(seen),changed=changed,overlay={n:repair['files'][n] for n in src},overlayArchive=pin((R/'source-overlay.tar.gz').read_bytes()),allOtherCompileDependenciesIdentical=True,generatorChangeNotCompileDependency='tools/gen_api_table.js',registration=repair['API']))
save('wrapper-reuse.json',dict(generatedControl=str(D/'evidence/generated-control.json'),overflowControl=str(D/'evidence/overflow-control.json'),FSIZE=12*M,captureEach=524288,aggregateCapture=4*M,priorPassingControlReuse=True,pythonDATAChildOnly=128*M,gitDATAChildOnly=256*M,nodeDATA='unlimited',historicalDeviationsPreserved=True))
native(['info','bx_86wyr4qb'],'donor-info')
source=json.loads((E/'donor-info.stdout').read_text())['sandbox']
assert source['state']=='stopped' and source['snapshotAvailable'] and source['snapshotCompletedAt']=='2026-10-30T13:49:17.641Z'
native(['fork','--help'],'supported-fork-help')
admission('before-fork-forecast')
print(json.dumps(dict(PASS=True,delta=pin((R/'source-overlay.tar.gz').read_bytes()),changed=changed)))
