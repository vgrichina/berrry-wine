from control import *
from objects import commit_changes,path
import tarfile,ast,datetime
PACKAGE='test/'+R.name+'/'
REF='refs/heads/test/'+R.name
life=json.loads((E/'lifecycle-proof.json').read_text());s=life['sandbox']
assert s['state']=='stopped' and s['snapshotAvailable'] and s['stop']['status']=='completed'
i=json.loads((E/'inspection.json').read_text());assert i['reviewed'] and not i['originalRender']
source=json.loads((E/'source-boundary.json').read_text())
d=E/'retrieved';build=json.loads((d/'repaired-ungetc-build.json').read_text());result=json.loads((d/'repaired-ungetc-result.json').read_text())
assert result['guestInvocations']==1 and not result['images']
assert build['source']==source['overlay']['src/09a6-handlers-crt.wat']
assert not build['compile']['violation'] and build['compile']['exit']==0 and not result['guest']['violation']
j=json.loads((E/'api-transfer-journal.json').read_text());assert max(x['responseBytes'] for x in j)<=16384
for p in R.glob('*.py'):ast.parse(p.read_bytes())
report=dict(task=R.name,status=i['status'],parent=BASE,sourceBoundary=source,build=build,actualResult=result,inspection=i,lifecycle=life,deadlines=json.loads((E/'boat-assignment.json').read_text()),actualSessionConfiguration=json.loads((E/'actual-session-configuration.json').read_text()),limits=dict(FSIZE=12*M,captureEach=524288,aggregateCapture=4*M,selectedLogs=8192,selectedJSON=196608,PNG=300000,APIRequestResponse=16384,rawChunk=6000,GitDATAChildOnly=256*M,PythonDATAChildOnly=128*M,NodeDATA='unlimited verified',guestHeapMiB=512,testHeapMiB=256,CPU=60,wall=90,groupRSS=2*1024*M,remotePhysical=256*M,RAMAdmission=False,hostFloor=1536*M,futureGrowth=267292672),compileInvocations=1,guestInvocations=1,originalRender=False,gameplay=False,evidence='evidence.tar.xz',noMainIntegration=True)
(R/'result.json').write_text(json.dumps(report,indent=2))
# Preserve all raw task evidence, recipes and preparation failures losslessly.
members=[p for p in E.rglob('*') if p.is_file()]+[p for p in R.glob('*.py')]+[R/'stores.json',R/'preparation-captures.tar.xz',R/'coordinator-allocation-forecast.json']
pins={p.relative_to(R).as_posix():pin(p.read_bytes()) for p in members}
with tarfile.open(R/'evidence.tar.xz','w:xz') as t:
 for p in members:t.add(p,arcname=p.relative_to(R).as_posix(),recursive=False)
with tarfile.open(R/'evidence.tar.xz') as t:
 assert set(t.getnames())==set(pins)
 for n,w in pins.items():assert pin(t.extractfile(n).read())==w,n
archive=pin((R/'evidence.tar.xz').read_bytes())
assert archive['bytes']<196608
# Reclaim only this task's verified archived raw files; restoration is documented and charged.
for p in [p for p in E.rglob('*') if p.is_file()]:p.unlink()
save('evidence-archive-recovery.json',dict(archive=str(R/'evidence.tar.xz'),pin=archive,files=pins,verifiedBeforeUnlink=True,restorationBytes=sum(v['bytes'] for v in pins.values()),historicalRootsUntouched=True))
changes={PACKAGE+n:(R/n).read_bytes() for n in ['result.json','recipe.txt','evidence.tar.xz']}
for n,b in changes.items():
 p=REPO/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();os.link(R/pathlib.PurePosixPath(n).name,p)
admission('pre-publication-forecast')
watch=subprocess.Popen(['tail','-n','0','-f','/home/user/wine-assembly/messageboard.txt'],stdout=(E/'messageboard-watch.stdout').open('wb'),stderr=(E/'messageboard-watch.stderr').open('wb'))
try:
 commit,tree=commit_changes(BASE,changes,'Record GLTron original guest advancing past ungetc to longjmp blocker')
 changed=git(['diff-tree','--no-commit-id','--name-only','-r',BASE,commit],'publication-changed-paths').decode().splitlines();assert set(changed)==set(changes)
 for n,b in changes.items():assert path(commit,n)[1]==b
 git(['update-ref','refs/heads/task/'+R.name,commit,BASE],'publication-task-ref')
 git(['push','--no-force','--no-thin','origin',commit+':'+REF],'publication-push')
 remote=git(['ls-remote','--exit-code','origin',REF],'publication-remote').decode().strip();assert remote==commit+'\t'+REF
finally:
 watch.terminate();watch.wait(timeout=5)
publication=dict(commit=commit,parent=BASE,tree=tree,ref=REF,remoteSHA=commit,exactRemoteVerified=remote,trustedSSH=SSH,indexFree=True,unrelatedParentEntriesPreserved=True,selectedBytes=sum(map(len,changes.values())),paths={n:pin(b) for n,b in changes.items()})
completion=dict(task=R.name,status=i['status'],sessionID=os.environ.get('CODEX_THREAD_ID'),parent=BASE,commit=commit,branch='task/'+R.name,publication=publication,sourceHashes=source,moduleHashes=build['modules'],actualInvocation=result['guest'],originalOutcome=i,inspectedImage=None,lifecycle=life,deadlines=report['deadlines'],runtimeEvidence=str(REPO/PACKAGE),archiveRecovery=str(E/'evidence-archive-recovery.json'),boardDelivery='Coordinator append messageboard-note.txt; no shared-root edits',resourceControls=report['limits'],historicalResourceDeviationsRetained=True)
(R/'completion-receipt.json').write_text(json.dumps(completion,indent=2))
(R/'messageboard-note.txt').write_text(f"{datetime.datetime.now(datetime.timezone.utc).isoformat()} {R.name}: {i['status']}. Canonical four-source compile PASS, ONE original GLTron0.70 attempt passes ungetc then traps longjmp EIP0x00418c85 return0x00418c9f args0x074ffcd4,1. No PNG/render/gameplay; no second repair. Parent{BASE}; commit{commit}; exact remoteverified{REF}. Evidence{REPO/PACKAGE}; receipt{R/'completion-receipt.json'}. Box{s['id']} snapshot{s['snapshotCompletedAt']} verifiedstopped{s['stoppedAt']} expiry{life['originalExpiry']}; shutdownexplicitlydelegated/complete. Historical resource deviations retained, no retroactive clean-runtime claim. Coordinator append; worker stops. No root edits/main/Telegram/agents/deployment.\n")
v=admission('final-completion-inclusive-forecast')
completion['allocation']=v
(R/'completion-receipt.json').write_text(json.dumps(completion,indent=2))
v=admission('final-bookkeeping-recheck');assert v['PASS']
print(json.dumps(dict(status=i['status'],commit=commit,ref=REF,exactRemoteVerified=True,box=s['id'],state=s['state'],forecast=v['forecast'],cap=v['cap'])))
