from control import *
from objects import commit_changes,path
import tarfile,datetime,io
admission('closeout-start-admission')
branch='refs/heads/task/'+R.name
life=json.loads((E/'lifecycle-proof.json').read_text());assert life['sandbox']['state']=='stopped' and life['sandbox']['snapshotAvailable'] and life['sandbox']['stop']['status']=='completed'
retrieved=E/'retrieved'
build=json.loads((retrieved/'declared-longjmp-build.json').read_text())
result=json.loads((retrieved/'declared-longjmp-result.json').read_text())
focused=json.loads((retrieved/'declared-longjmp-regression.json').read_text());negative=json.loads((retrieved/'declared-longjmp-regression-missing-global.json').read_text())
assert build['parent']==BASE and build['compile']['exit']==0 and not build['compile']['violation']
assert focused['exit']==0 and not focused['violation'] and negative['exit']!=0 and not negative['violation']
assert 'missing production global $API_ID_longjmp' in (retrieved/'declared-longjmp-regression-missing-global.stderr.log').read_text()
assert result['guestInvocations']==1 and result['guest']['exit']==1 and not result['guest']['violation'] and not result['images']
assert 'UNIMPLEMENTED API: remove' in (retrieved/'declared-longjmp-guest.stderr.log').read_text()
assert '[API] longjmp' in (retrieved/'declared-longjmp-guest.stdout.log').read_text()
assert pin((retrieved/'declared-longjmp-source-boundary.json').read_bytes())==pin((E/'source-boundary.json').read_bytes())
startup=json.loads((retrieved/'declared-longjmp-startup-512.stdout.log').read_text());assert startup['execPath']=='/usr/bin/node' and '--max-old-space-size=512' in startup['argv']
assert 'Max data size             unlimited            unlimited' in startup['limits']
sid=json.loads((E/'initial-admission.json').read_text())['sessionID']
report=dict(task=R.name,status='CANONICAL_BUILD_AND_FOCUSED_PASS_ONE_GUEST_BLOCKED_REMOVE',sessionID=sid,parent=BASE,branch=branch,
 source=dict(manifest='evidence/source-boundary.json',manifestPin=pin((E/'source-boundary.json').read_bytes()),overlay=pin((R/'source-overlay.tar.xz').read_bytes()),changed=json.loads((E/'source-boundary.json').read_text())['changed'],canonicalIncludeFragments=128,allCompilerDependenciesHashed=True,noGeneration=True,noSourceRepair=True,APIAgreement=json.loads((E/'api-dispatch-hash-agreement.json').read_text())),
 canonicalCompile=dict(attempted=True,result='PASS',command=build['compile']['argv'],startedAt=build['compile']['startedAt'],wall=build['compile']['wall'],exit=0,modules=build['modules'],peakRSS=build['compile']['peakRSS'],startup=startup,sourceParent=BASE,compiler='tools/build-compile-wat.js canonical vendored WATX'),
 fullFocusedTest=dict(result='PASS',command=focused['argv'],startedAt=focused['startedAt'],exit=0,details=json.loads((retrieved/'declared-longjmp-regression.stdout.log').read_text().splitlines()[-1])),
 missingProductionDeclarationControl=dict(result='PASS_EXPECTED_REJECTION',command=negative['argv'],exit=negative['exit'],message='missing production global $API_ID_longjmp',exactGeneratedFileRestored=True),
 guest=dict(count=1,app='GLTron0.70 original registered media',command=result['guest']['argv'],startedAt=result['guest']['startedAt'],wall=result['guest']['wall'],exit=1,violation=None,wasm=build['modules']['build/wine-assembly.wasm'],outcome='unimplemented remove after longjmp executed and continued',EIP='0x00423b95',returnAddress='0x00423ba0',batch=4,PNG=None,imageInspection='ABSENT; no frame to inspect',gameplayQualified=False,originalRunner=True,noInjectedInput=True,originalMediaFiles=92,rawEvidenceManifest='evidence/retrieved/raw-evidence-manifest.json'),
 blocker=dict(type='UNIMPLEMENTED_API',API='remove',noSecondRun=True,noNextAPIRepair=True),
 lifecycle=life,watchdog=dict(independent=True,armedBeforeFirstExec=True,receipt='evidence/watchdog-armed.json'),
 priorFailureAndDenial=dict(receipt='/tmp/gltron-longjmp-global-compile-repair-oct30/completion-receipt.json',retained=True,deniedDonorResumeNotRetried=True,donorNotMutated=True,selectedDonor='bx_8gxm6tu8',snapshot='2026-10-30T15:21:34.663Z'),
 correctedStagingChecks=['Launch receipt metadata bytes differed; exact normalized filename-bearing configuration matched and canonical parser preflight passed.','Removed erroneous expectation of a named _setjmp3 global; actual API table, dispatch ID, generated hash bytes and required longjmp global agree.'],
 publication=dict(status='PENDING_UNCHANGED_TRUSTED_SSH_PUBLICKEY_DENIAL',attempted=False,remoteVerified=False),
 scope=dict(noOtherWorkers=True,noSharedRootEdits=True,noTelegram=True,noIntegration=True,noDeployment=True),
 rootRefReceipt='/home/user/wine-assembly/scratch/usage-watch/'+R.name+'/root-ref-digest.json',
 controls=dict(localPhysicalCap=64*M,forecastReservesUnchanged=True,RAMAdmission=False,FSIZE=12*M,capture=524288,aggregateCapture=4*M,gitDataChildOnly=256*M,pythonDataChildOnly=128*M,nodeDataUnlimited=True,CPU=60,wall=90,groupRSS=2048*M,remoteCap=256*M,remotePublicationReserve=8*M),
 limitations=['No PNG or gameplay qualification.','Selected logs are bounded tails; full original remote logs, compiler modules and raw archive remain in the verified stopped snapshot.','No remote Git backup: unchanged trusted-SSH publickey denial was not retried.'])
(R/'result.json').write_text(json.dumps(report,indent=2))
(R/'recipe.txt').write_text('Exact parent '+BASE+'; branch '+branch+'. Canonical compile, focused continuation test and missing-production-declaration control passed. Exactly ONE original GLTron run trapped remove at EIP0x00423b95 after longjmp continuation; no PNG. Stop here, do not repair another API or rerun. Source overlay is exact committed seven-file delta; generated WAT transferred, not regenerated. Reconstruct unchanged compiler closure from /tmp/gltron-original-main-render-runtime-oct30/pinned-source-closure.tar.xz and overlay source-overlay.tar.xz after hash verification. Parent exact commit objects/repair source are in /tmp/gltron-longjmp-global-compile-repair-oct30/repair-source-evidence.tar.xz SHA256 de25875ec307fe66ec0f209655013daaf55149cb06dc0930c79382e644560cc7. Original media/runner/data archives and manifests remain at task-provided paths. Remote full logs/archive and compiled modules retained in bx_c7g48f8e completed snapshot 2026-10-30T15:34:29.008Z under /home/user/gltron-render, raw archive declared-longjmp-raw-evidence.tar.xz; identities in raw-evidence-manifest.json and result.json. Box actually stopped with completed snapshot/stop. Never resume denied donor bx_8gxm6tu8. Raw local captures and controllers are in raw-evidence.tar.xz with manifest. No shared-root edits, Telegram, integration/deployment, publication attempt, next worker or next task.\n')
members=[p for p in E.rglob('*') if p.is_file()]+list(R.glob('*.py'))+[R/'preflight.js',R/'stores.json',R/'coordinator-allocation-forecast.json']
pins={p.relative_to(R).as_posix():pin(p.read_bytes()) for p in members}
with tarfile.open(R/'raw-evidence.tar.xz','w:xz') as t:
 for p in members:t.add(p,arcname=p.relative_to(R).as_posix(),recursive=False)
with tarfile.open(R/'raw-evidence.tar.xz') as t:
 for n,w in pins.items():assert pin(t.extractfile(n).read())==w
(R/'raw-evidence-manifest.json').write_text(json.dumps(dict(archive='raw-evidence.tar.xz',pin=pin((R/'raw-evidence.tar.xz').read_bytes()),members=pins,readbackVerified=True),indent=2))
admission('before-commit-admission')
package='test/'+R.name+'/'
changes={package+n:(R/n).read_bytes() for n in ['result.json','recipe.txt','raw-evidence.tar.xz','raw-evidence-manifest.json','source-overlay.tar.xz']}
watch=subprocess.Popen(['tail','-n','0','-f','/home/user/wine-assembly/messageboard.txt'],stdout=(E/'messageboard-watch.stdout').open('wb'),stderr=(E/'messageboard-watch.stderr').open('wb'))
try:
 commit,tree=commit_changes(BASE,changes,'Qualify declared longjmp canonical build; preserve single GLTron remove blocker')
 actual=git(['diff-tree','--no-commit-id','--name-only','-r',BASE,commit],'exact-evidence-changed-paths').decode().splitlines();assert set(actual)==set(changes)
 for n,b in changes.items():assert path(commit,n)[1]==b
 git(['update-ref',branch,commit,BASE],'local-task-ref')
finally:watch.terminate();watch.wait(timeout=5)
with tarfile.open(R/'local-recovery.tar.xz','w:xz') as t:
 for n,b in changes.items():
  m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
 for p in (REPO/'.git/objects').glob('[0-9a-f][0-9a-f]/*'):t.add(p,arcname='git-objects/'+p.parent.name+'/'+p.name,recursive=False)
with tarfile.open(R/'local-recovery.tar.xz') as t:
 for n,b in changes.items():assert t.extractfile(n).read()==b
completion=dict(**report,commit=commit,tree=tree,indexFree=True,unrelatedParentEntriesPreserved=True,recovery=dict(archive=str(R/'local-recovery.tar.xz'),pin=pin((R/'local-recovery.tar.xz').read_bytes()),readbackVerified=True,commitObjectsIncluded=True),evidence=str(R/'raw-evidence.tar.xz'))
(R/'completion-receipt.json').write_text(json.dumps(completion,indent=2))
(R/'messageboard-note.txt').write_text(f"{datetime.datetime.now(datetime.timezone.utc).isoformat()} {R.name} canonical compile PASS (2026-10-30T15:33:48.122488Z, wasm SHA256 {build['modules']['build/wine-assembly.wasm']['sha256']}); full focused continuation PASS and missing production declaration expected rejection PASS. EXACTLY ONE original GLTron0.70 run (15:34:01.445021Z) exited1 at unimplemented remove EIP0x00423b95 ret0x00423ba0 batch4 after longjmp continuation. PNG absent, no image/gameplay acceptance, no next repair/run. Local tested evidence commit {commit}, branch {branch}, parent {BASE}; every unrelated parent entry preserved index-free. Session {sid}. Receipt {R/'completion-receipt.json'}, local recovery {R/'local-recovery.tar.xz'}, raw evidence manifest {R/'raw-evidence-manifest.json'}. bx_c7g48f8e snapshot2026-10-30T15:34:29.008Z and stop15:34:29.098Z verified; original expiry16:01:31.753Z. Donor untouched; prior missing helper/premature stop/resume403 preserved. Publication PENDING unchanged trusted SSH publickey denial; no attempt or false remote verification. No shared root edits/Telegram/workers/integration/deployment. Coordinator append.\n")
v=admission('final-bookkeeping-inclusive-admission');completion['finalAllocation']=v;(R/'completion-receipt.json').write_text(json.dumps(completion,indent=2));admission('final-recheck')
print(json.dumps(dict(commit=commit,branch=branch,status=report['status'],sessionID=sid,box='bx_c7g48f8e',state='stopped',forecast=v['forecast'],cap=v['cap'],recovery=completion['recovery'])))
