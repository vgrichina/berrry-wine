from control import *
import api,base64,traceback
A=json.loads((E/'boat-assignment.json').read_text());api.A=A
def invoke(mode):
 return api.api('import runpy,sys;sys.argv=["declared-longjmp-controller.py",'+repr(mode)+'];runpy.run_path("declared-longjmp-controller.py",run_name="__main__")','execute-'+mode,timeout=110,cwd=api.REMOTE)
def collect():
 code='''import pathlib,json,hashlib,tarfile
r=pathlib.Path('.');d=r/'declared-longjmp-selected';d.mkdir(exist_ok=True)
raw={}
for p in r.glob('declared-longjmp-*'):
 if not p.is_file() or p.suffix not in ['.json','.log']:continue
 b=p.read_bytes();raw[p.name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());(d/p.name).write_bytes(b[-8192:] if p.suffix=='.log' else b)
with tarfile.open(r/'declared-longjmp-raw-evidence.tar.xz','w:xz') as t:
 for n in raw:t.add(r/n,arcname=n,recursive=False)
p=r/'capture/original.png'
if p.is_file():assert p.stat().st_size<=300000;(d/'original.png').write_bytes(p.read_bytes())
(d/'raw-evidence-manifest.json').write_text(json.dumps(dict(files=raw,archive='declared-longjmp-raw-evidence.tar.xz',sha256=hashlib.sha256((r/'declared-longjmp-raw-evidence.tar.xz').read_bytes()).hexdigest())))
print(json.dumps({p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in d.iterdir() if p.is_file()}))
'''
 manifest=json.loads(api.api(code,'select-evidence',cwd=api.REMOTE));save('retrieval-manifest',manifest)
 for n,w in manifest.items():
  assert w['bytes']<=(300000 if n.endswith('.png') else 8192 if n.endswith('.log') else 196608)
  parts=[]
  for off in range(0,w['bytes'],6000):
   b=api.api('import pathlib,base64;f=pathlib.Path('+repr('declared-longjmp-selected/'+n)+').open("rb");f.seek('+str(off)+');print(base64.b64encode(f.read(6000)).decode())','retrieve-'+n+'-'+str(off),cwd=api.REMOTE,record=False);parts.append(base64.b64decode(b.strip(),validate=True))
  b=b''.join(parts);assert pin(b)==w;p=E/'retrieved'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
try:
 assert json.loads((E/'complete-exact-closure-verification-3.json').read_text())['response']['success']
 assert json.loads((E/'wrapper-reuse.json').read_text())['PASS']
 admission('canonical-compile-admission');assert time.time()<A['cutoffEpoch']
 invoke('compile')
 admission('after-canonical-compile-admission')
 invoke('preflight')
 invoke('regression')
 admission('before-one-guest-admission');assert time.time()<A['cutoffEpoch']
 (E/'one-guest.lock').open('x').write(str(time.time()));invoke('guest')
except BaseException as ex:save('first-execution-failure',dict(error=repr(ex),traceback=traceback.format_exc(),at=time.time()))
finally:
 save('execution-api-journal',api.journal)
 try:
  admission('before-retrieval-admission')
  if time.time()<A['retrieveEpoch']:collect()
 except BaseException as ex:save('retrieval-failure',dict(error=repr(ex),traceback=traceback.format_exc()))
 finally:
  save('execution-api-journal',api.journal)
  native(['stop',A['id']],'snapshot-stop',wall=100)
  for n in range(16):
   v=native(['info',A['id']],'stopped-info-'+str(n))[-1]['sandbox']
   if v['state']=='stopped' and v.get('snapshotAvailable') and v.get('lastSnapshotStatus')=='completed' and v.get('stop',{}).get('status')=='completed':break
   time.sleep(2)
  else:raise RuntimeError('snapshot-stop unverified')
  save('lifecycle-proof',dict(sandbox=v,originalExpiry=A['expiry'],shutdownDelegated=True))
 print(json.dumps(dict(box=A['id'],stopped=(E/'lifecycle-proof.json').exists(),failure=(E/'first-execution-failure.json').exists())))
