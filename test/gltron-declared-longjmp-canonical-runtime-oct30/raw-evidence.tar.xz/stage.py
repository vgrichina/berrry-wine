from control import *
import api,base64,ast
api.A=json.loads((E/'boat-assignment.json').read_text())
admission('before-stage-admission')
try:
 raw=b'declared-longjmp-api-smoke'
 assert json.loads(api.api('import pathlib,hashlib,json;p=pathlib.Path("/home/user/declared-longjmp-smoke");b='+repr(raw)+';p.write_bytes(b);assert p.read_bytes()==b;p.unlink();print(json.dumps(dict(sha256=hashlib.sha256(b).hexdigest())))','transfer-smoke'))['sha256']==pin(raw)['sha256']
 save('remote-inventory',json.loads(api.api('import pathlib,json;r=pathlib.Path("/home/user/gltron-render");print(json.dumps(dict(rootExists=r.is_dir(),pins=(r/"pins.json").is_file(),physical=sum(p.lstat().st_blocks*512 for p in [r,*r.rglob("*")]),capture=[p.name for p in (r/"capture").glob("*.png")],manifests={n:(r/n).is_file() for n in ["runner-closure-manifest.json","runtime-data-manifest.json","launch-configuration.json"]})))','inventory')))
 items=[(R/'source-overlay.tar.xz','declared-longjmp-overlay.tar.xz'),(R/'remote-controller.py','declared-longjmp-controller.py'),(R/'preflight.js','declared-longjmp-preflight.js'),(E/'boat-assignment.json','declared-longjmp-assignment.json'),(E/'source-boundary.json','declared-longjmp-source-boundary.json')]
 save('transfer',dict(files=[api.transfer(*x) for x in items]))
 overlay=json.loads((E/'source-boundary.json').read_text())['overlayArchive']
 api.api('import pathlib,hashlib,json,tarfile;r=pathlib.Path(".");p=r/"declared-longjmp-overlay.tar.xz";b=p.read_bytes();assert dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())=='+repr(overlay)+';t=tarfile.open(p);expected=json.loads((r/"declared-longjmp-source-boundary.json").read_text())["changed"];assert set(t.getnames())==set(expected);[(r/n).write_bytes(t.extractfile(n).read()) for n in expected];print(json.dumps(dict(PASS=True,overlay=list(expected))))','extract-exact-overlay',cwd=api.REMOTE)
 manifestPins={}
 for n,p in [('runner-closure-manifest.json','/tmp/gltron-runner-closure-original-render-oct30/runner-closure-manifest.json'),('runtime-data-manifest.json','/tmp/gltron-runtime-data-complete-original-render-oct30/runtime-data-manifest.json'),('launch-configuration.json','/tmp/gltron-runner-closure-original-render-oct30/evidence/launch-configuration.json')]:manifestPins[n]=pin(pathlib.Path(p).read_bytes())
 code='''import pathlib,json,hashlib,re
r=pathlib.Path('.')
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for n,w in MANIFESTS.items():assert pin(r/n)==w,n
s=json.loads((r/'declared-longjmp-source-boundary.json').read_text())
for n,w in s['files'].items():assert pin(r/n)==w,n
for m in ['runner-closure-manifest.json','runtime-data-manifest.json']:
 for n,w in json.loads((r/m).read_text())['files'].items():
  assert n not in s['changed'];assert pin(r/n)==w,n
c=json.loads((r/'launch-configuration.json').read_text())['configuration'];assert len(c['files'])==92
for f in c['files']:assert pin(r/f['url'])==dict(bytes=f['size'],sha256=f['sha256'])
seen=set()
def visit(n):
 if n in seen:return
 seen.add(n)
 for name in re.findall(r'\(include\s+"([^"]+)"',(r/n).read_text()):visit(str(pathlib.PurePosixPath(n).parent/name))
visit('src/main.watx');assert all(n in s['files'] for n in seen)
a=json.loads((r/'src/api_table.json').read_text());d=(r/'src/09b2-dispatch-table.generated.wat').read_text();h=(r/'src/01b-api-hashes.generated.wat').read_text();dispatch=(r/'src/09b-dispatch.wat').read_text()
regs={x['name']:x for x in a if x['name'] in ['longjmp','_setjmp3']}
for name,v in regs.items():
 assert a[v['id']]==v
 assert re.search(r'\(global \$API_ID_'+name+r' i32 \(i32.const '+str(v['id'])+r'\)\)',d)
 assert '$handle_'+name in d
 assert '$API_ID_'+name in dispatch
print(json.dumps(dict(PASS=True,parent=s['parent'],sourceFiles=len(s['files']),includeClosure=sorted(seen),registrations=regs,runnerDataOriginalMedia=True,originalFiles=len(c['files']),commaBearing=[x['url'] for x in c['files'] if ',' in x['url']])))
'''.replace('MANIFESTS',repr(manifestPins))
 api.api(code,'complete-closure-hash-verification',timeout=45,cwd=api.REMOTE)
 def runast(p):return ast.dump(next(x for x in ast.parse(p.read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='run'))
 older=pathlib.Path('/tmp/gltron-longjmp-production-repair-oct30/control.py')
 assert runast(R/'control.py')==runast(older)
 save('wrapper-reuse',dict(PASS=True,unchangedFunctionSHA256=hashlib.sha256(runast(older).encode()).hexdigest(),FSIZE=12*M,capture=524288,largeFileControl=600000,overflowRejected=True,receipts=['reused-wrapper-large-file.json','reused-wrapper-overflow.json','reused-wrapper-overflow-recovery.json']))
 admission('stage-complete-admission')
 print('Staging and complete closure verification PASS')
finally:save('stage-api-journal',api.journal)
