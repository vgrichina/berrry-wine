from control import *
import api,ast
api.A=json.loads((E/'boat-assignment.json').read_text())
admission('before-corrected-staging-check-3')
save('initial-staging-check-failure',dict(stage='complete-closure-hash-verification',commandID='cmd_3pmup6wyosfj',observedExit=1,reason='launch-configuration.json bytes differ; normalized exact configuration independently matches',denial=False,compilerAttempted=False,guestInvocations=0,preservedFrom='shell tool failure output'))
manifestPins={n:pin(pathlib.Path(p).read_bytes()) for n,p in [('runner-closure-manifest.json','/tmp/gltron-runner-closure-original-render-oct30/runner-closure-manifest.json'),('runtime-data-manifest.json','/tmp/gltron-runtime-data-complete-original-render-oct30/runtime-data-manifest.json')]}
s=ast.parse((R/'stage.py').read_text());assign=next(x for x in ast.walk(s) if isinstance(x,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='code' for v in x.targets));code=assign.value.func.value.value.replace('MANIFESTS',repr(manifestPins))
conf=json.loads(pathlib.Path('/tmp/gltron-runner-closure-original-render-oct30/evidence/launch-configuration.json').read_text())
expected=pin(json.dumps(conf['configuration'],sort_keys=True,separators=(',',':')).encode())
code=code.replace("c=json.loads((r/'launch-configuration.json').read_text())['configuration'];assert len(c['files'])==92", "receipt=json.loads((r/'launch-configuration.json').read_text());assert receipt['PASS'] and receipt['trustedSSH']=="+repr(SSH)+";c=receipt['configuration'];b=json.dumps(c,sort_keys=True,separators=(',',':')).encode();assert dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())=="+repr(expected)+";assert len(c['files'])==92")
code=code.replace(" assert re.search(r'\\(global \\$API_ID_'+name+r' i32 \\(i32.const '+str(v['id'])+r'\\)\\)',d)"," if name=='longjmp':assert re.search(r'\\(global \\$API_ID_'+name+r' i32 \\(i32.const '+str(v['id'])+r'\\)\\)',d)")
code=code.replace(" assert '$API_ID_'+name in dispatch", " if name=='longjmp':assert '$API_ID_'+name in dispatch")
try:
 api.api(code,'complete-exact-closure-verification-3',timeout=45,cwd=api.REMOTE)
 def runast(p):return ast.dump(next(x for x in ast.parse(p.read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='run'))
 older=pathlib.Path('/tmp/gltron-longjmp-production-repair-oct30/control.py');assert runast(R/'control.py')==runast(older)
 save('wrapper-reuse',dict(PASS=True,unchangedFunctionSHA256=hashlib.sha256(runast(older).encode()).hexdigest(),FSIZE=12*M,capture=524288,largeFileControl=600000,overflowRejected=True,receipts=['reused-wrapper-large-file.json','reused-wrapper-overflow.json','reused-wrapper-overflow-recovery.json']))
 admission('verified-before-compile-admission')
 print('Complete exact source/runner/data/media and wrapper verification PASS')
finally:save('verification-api-journal',api.journal)
