from control import *
import api,datetime
admission('before-fork-admission')
donor=json.loads((E/'donor-info.stdout').read_text().splitlines()[-1])['sandbox']
assert donor['id']=='bx_8gxm6tu8' and donor['state']=='stopped' and donor['snapshotAvailable'] and donor['snapshotCompletedAt']=='2026-10-30T15:21:34.663Z'
created=native(['fork','--ttl','1800','--no-env','--wait',donor['id']],'fork-task-box',wall=100)
box=next(v['id'] for v in created if v.get('event')=='created')
info=native(['info',box],'task-box-info')[-1]['sandbox'];assert info['state'] in ['running','idle'] and info['ttlSeconds']==1800
now=api.epoch(info['createdAt']);assert api.epoch(info['archiveAfter'])-now<=1801
a=dict(id=box,source=donor['id'],sourceSnapshot=donor['snapshotCompletedAt'],createdAt=info['createdAt'],createdEpoch=now,expiry=info['archiveAfter'],cutoffEpoch=now+1200,retrieveEpoch=now+1320,handbackEpoch=now+1380,shutdownEpoch=now+1500,shutdownDelegated=True,remoteRoot=api.REMOTE)
save('boat-assignment',a)
watch=subprocess.Popen(['/usr/bin/python3','-B',str(R/'watchdog.py')],cwd=R,stdout=(E/'watchdog.stdout').open('wb'),stderr=(E/'watchdog.stderr').open('wb'),start_new_session=True)
assert watch.poll() is None
save('watchdog-armed',dict(pid=watch.pid,box=box,beforeFirstExec=True,allPaths=True,deadline=a['shutdownEpoch']))
print(json.dumps(a))
