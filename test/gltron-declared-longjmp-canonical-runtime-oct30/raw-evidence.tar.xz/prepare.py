from control import *
from objects import path,read,entries
import tarfile,io
admission('prepare-admission-2')
assert git(['rev-parse','HEAD'],'exact-parent-2').decode().strip()==BASE
conf=pathlib.Path('/tmp/gltron-runner-closure-original-render-oct30/evidence/launch-configuration.json')
c=json.loads(conf.read_text());assert c['PASS'] and c['trustedSSH']==SSH and len(c['configuration']['files'])==92
save('launch-configuration-reuse',dict(PASS=True,receipt=str(conf),pin=pin(conf.read_bytes()),unchanged=True,trustedSSH=SSH,canonicalParser=c['canonicalParser'],configuration=c['configuration']))
root=pathlib.Path('/tmp/gltron-original-main-render-runtime-oct30')
p=json.loads((root/'pinned-input-closure.json').read_text());assert p['PASS']
archive=root/'pinned-source-closure.tar.xz';assert pin(archive.read_bytes())=={k:p['sourceArchive'][k] for k in ['bytes','sha256']}
changed={};expected={};absent=[]
def blobid(n):
 oid=read(BASE,'commit').splitlines()[0].split()[1].decode()
 for part in n.split('/'):mode,oid=entries(oid)[part.encode()]
 return oid
with tarfile.open(archive) as t:
 for n,w in p['files'].items():
  b=t.extractfile(n).read();assert pin(b)==w,n
  try: oid=blobid(n)
  except KeyError: absent.append(n);continue
  if oid==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest():expected[n]=w
  else:
   actual=path(BASE,n)[1];expected[n]=pin(actual);changed[n]=actual
assert not absent,absent
repair=pathlib.Path('/tmp/gltron-longjmp-global-compile-repair-oct30/repair-source-evidence.tar.xz')
assert pin(repair.read_bytes())['sha256']=='de25875ec307fe66ec0f209655013daaf55149cb06dc0930c79382e644560cc7'
receipt=json.loads((repair.parent/'completion-receipt.json').read_text());assert receipt['commit']==BASE
with tarfile.open(repair) as t:
 for n,w in receipt['productionRepair'].items():
  b=t.extractfile(n).read();assert pin(b)==w and path(BASE,n)[1]==b,n
  changed[n]=b;expected[n]=w
names=set(n for n in changed if n.startswith('src/'))
assert names==set(json.loads(pathlib.Path('/tmp/gltron-longjmp-preserved-runtime-oct30/completion-receipt.json').read_text())['sourceBoundary']['overlay']),names
with tarfile.open(R/'source-overlay.tar.xz','w:xz') as t:
 for n,b in changed.items():
  info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(R/'source-overlay.tar.xz') as t:
 for n,b in changed.items():assert t.extractfile(n).read()==b
save('source-boundary',dict(PASS=True,parent=BASE,retainedCandidate=p['candidate'],changed={n:pin(b) for n,b in changed.items()},files=expected,sourceArchive=pin(archive.read_bytes()),overlayArchive=pin((R/'source-overlay.tar.xz').read_bytes()),noGeneration=True,allOtherDependenciesIdentical=True))
print(json.dumps(dict(PASS=True,changed=list(changed),files=len(expected),overlayBytes=(R/'source-overlay.tar.xz').stat().st_size)))
admission('prepared-admission')
