from control import *
import tarfile,io,re
admission('source-forecast')
assert git(['rev-parse','HEAD'],'exact-parent').decode().strip()==BASE
conf=pathlib.Path('/tmp/gltron-runner-closure-original-render-oct30/evidence/launch-configuration.json')
c=json.loads(conf.read_text());assert c['PASS'] and c['trustedSSH']==SSH and len(c['configuration']['files'])==92
save('launch-configuration-reuse',dict(PASS=True,receipt=str(conf),pin=pin(conf.read_bytes()),unchanged=True,trustedSSH=SSH))
gen=(E/'read-generator.stdout').read_bytes();test=(E/'read-regression.stdout').read_bytes()
assert gen.count(b"  ['_EH_prolog', 'API_ID__EH_prolog'],")==1
gen=gen.replace(b"  ['_EH_prolog', 'API_ID__EH_prolog'],",b"  ['_EH_prolog', 'API_ID__EH_prolog'],\n  ['longjmp', 'API_ID_longjmp'],")
old=b"  const value=name.startsWith('API_ID_')?(ids[name.slice(7)]??-999):constants[name]??0;"
assert test.count(old)==1
test=test.replace(old,b"""  if (name.startsWith('API_ID_')) {
    // Only the canonical generated declaration can supply a production API ID.
    // Missing declarations must fail here rather than be invented by this fixture.
    const declaration = sources['09b2-dispatch-table.generated'].match(
      new RegExp('\\\\(global \\\\$' + name + ' i32 \\\\(i32.const ([0-9]+)\\\\)\\\\)'));
    assert(declaration, `missing production global ${g}; run tools/gen_dispatch.js`);
    assert.equal(Number(declaration[1]), ids[name.slice(7)], `${g} matches API table`);
    return declaration[0] + ` (export "${name}" (global ${g}))`;
  }
  const value=constants[name]??0;""")
for n,b in [('tools/gen_dispatch.js',gen),('test/test-crt-nonlocal-jump.js',test)]:
 p=REPO/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
save('planned-source',dict(files={n:pin(b) for n,b in [('tools/gen_dispatch.js',gen),('test/test-crt-nonlocal-jump.js',test)]},productionOwner='tools/gen_dispatch.js namedApiIds',noSemanticChanges=True))
print('Prepared generator and regression; generated output will be produced by exact generator on task box.')
