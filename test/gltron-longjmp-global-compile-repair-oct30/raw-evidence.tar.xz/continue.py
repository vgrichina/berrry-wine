from control import *
import control
control.E=control.E/"continuation";control.E.mkdir(exist_ok=True)
from control import *
import api,datetime,traceback,base64,tarfile,io
A=None;watch=None
REMOTE=api.REMOTE
def invoke(mode):
 return api.api('import runpy,sys;sys.argv=["global-repair-controller.py",'+repr(mode)+'];runpy.run_path("global-repair-controller.py",run_name="__main__")','execute-'+mode,timeout=110,cwd=REMOTE)
def collect():
 code="""import pathlib,json,hashlib,gzip
r=pathlib.Path('.');d=r/'global-repair-selected';d.mkdir(exist_ok=True)
for p in r.glob('global-repair-*'):
 if not p.is_file() or p.suffix not in ['.json','.log']:continue
 b=p.read_bytes();(d/p.name).write_bytes(b[-8192:] if p.suffix=='.log' else b)
p=r/'src/09b2-dispatch-table.generated.wat';(d/'generated.wat.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
p=r/'capture/original.png'
if p.is_file():assert p.stat().st_size<=300000;(d/'original.png').write_bytes(p.read_bytes())
print(json.dumps({p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in d.iterdir() if p.is_file()}))
"""
 manifest=json.loads(api.api(code,'select-evidence',cwd=REMOTE));save('retrieval-manifest',manifest)
 for n,w in manifest.items():
  assert w['bytes']<=(300000 if n.endswith('.png') else 8192 if n.endswith('.log') else 196608)
  parts=[]
  for off in range(0,w['bytes'],6000):
   b=api.api('import pathlib,base64;f=pathlib.Path('+repr('global-repair-selected/'+n)+').open("rb");f.seek('+str(off)+');print(base64.b64encode(f.read(6000)).decode())','retrieve-'+n+'-'+str(off),cwd=REMOTE,record=False);parts.append(base64.b64decode(b.strip(),validate=True))
  b=b''.join(parts);assert pin(b)==w;p=E/'retrieved'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
try:
 admission('provision-forecast')
 A=json.loads((R/'evidence/boat-assignment.json').read_text());box=A['id']
 prior=native(['info',box],'before-resume')[-1]['sandbox'];assert prior['state']=='stopped' and prior['snapshotAvailable']
 assert time.time()<A['cutoffEpoch']
 native(['resume',box],'resume-same-task-box',wall=100)
 info=native(['info',box],'resumed-info')[-1]['sandbox'];assert info['state'] in ['running','idle']
 api.A=A;save('boat-assignment',A)
 (R/'evidence/lifecycle-proof.json').rename(R/'evidence/first-lifecycle-proof.json')
 watch=subprocess.Popen(['/usr/bin/python3','-B',str(R/'watchdog.py')],cwd=R,stdout=(E/'watchdog.stdout').open('wb'),stderr=(E/'watchdog.stderr').open('wb'),start_new_session=True)
 assert watch.poll() is None;save('watchdog-armed',dict(pid=watch.pid,box=box,beforeFirstExec=True,allPaths=True,deadline=A['shutdownEpoch']))
 raw=b'gltron-global-repair-smoke'
 assert json.loads(api.api('import pathlib,hashlib,json;p=pathlib.Path("/home/user/global-repair-smoke");b='+repr(raw)+';p.write_bytes(b);assert p.read_bytes()==b;p.unlink();print(json.dumps(dict(sha256=hashlib.sha256(b).hexdigest())))','transfer-smoke'))['sha256']==pin(raw)['sha256']
 prior=json.loads(pathlib.Path('/tmp/gltron-longjmp-preserved-runtime-oct30/completion-receipt.json').read_text())['sourceBoundary']
 code="""import pathlib,json,hashlib
r=pathlib.Path('/home/user/gltron-render')
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
p=json.loads((r/'pins.json').read_text());p['files'].update(CHANGES)
for n,w in p['files'].items():assert pin(r/n)==w,n
for m in ['runner-closure-manifest.json','runtime-data-manifest.json']:
 for n,w in json.loads((r/m).read_text())['files'].items():assert pin(r/n)==w,n
c=json.loads((r/'launch-configuration.json').read_text())['configuration'];assert c==CONFIG
for f in c['files']:assert pin(r/f['url'])==dict(bytes=f['size'],sha256=f['sha256'])
print(json.dumps(dict(PASS=True,allPinnedSourceRunnerDataMediaHashed=True,sourceFiles=len(p['files']),originalFiles=len(c['files']))))
""".replace('CHANGES',repr(prior['overlay'])).replace('CONFIG',repr(json.loads(pathlib.Path('/tmp/gltron-runner-closure-original-render-oct30/evidence/launch-configuration.json').read_text())['configuration']))
 # The complete registry is already pinned in the retained receipt; avoid embedding its >16K contents.
 code=code.replace('assert c=='+repr(json.loads(pathlib.Path('/tmp/gltron-runner-closure-original-render-oct30/evidence/launch-configuration.json').read_text())['configuration']),"assert len(c['files'])==92 and c['args']=="+repr(json.loads(pathlib.Path('/tmp/gltron-runner-closure-original-render-oct30/evidence/launch-configuration.json').read_text())['configuration']['args']))
 api.api(code,'retained-closure-hashes',timeout=40,cwd=REMOTE)
 admission('before-transfer-forecast');(E/'assignment.json').write_text(json.dumps(A))
 items=[*[(REPO/'tools'/n,'tools/'+n) for n in ['d3dim-methods.js','d3d9-methods.js','d3d8-methods.js']],(REPO/'tools/gen_dispatch.js','tools/gen_dispatch.js'),(REPO/'test/test-crt-nonlocal-jump.js','test/test-crt-nonlocal-jump.js'),(R/'remote-controller.py','global-repair-controller.py'),(R/'preflight.js','global-repair-preflight.js'),(E/'assignment.json','global-repair-assignment.json')]
 save('transfer',dict(files=[api.transfer(*x) for x in items]))
 invoke('generate')
 invoke('compile');invoke('preflight');invoke('regression')
 admission('before-guest-forecast');assert time.time()<A['cutoffEpoch'];(E/'one-guest.lock').open('x').write(str(time.time()));invoke('guest')
except BaseException as ex:save('first-failure',dict(error=repr(ex),traceback=traceback.format_exc(),at=time.time()))
finally:
 save('api-transfer-journal',api.journal)
 if A:
  try:
   if time.time()<A['retrieveEpoch']:collect()
  except BaseException as ex:save('retrieval-failure',dict(error=repr(ex),traceback=traceback.format_exc()))
  finally:
   save('api-transfer-journal',api.journal)
   native(['stop',A['id']],'snapshot-stop',wall=100)
   for n in range(16):
    v=native(['info',A['id']],'stopped-info-'+str(n))[-1]['sandbox']
    if v['state']=='stopped' and v.get('snapshotAvailable') and v.get('lastSnapshotStatus')=='completed' and v.get('stop',{}).get('status')=='completed':break
    time.sleep(2)
   else:raise RuntimeError('snapshot-stop unverified')
   save('lifecycle-proof',dict(sandbox=v,originalExpiry=A['expiry'],shutdownDelegated=True));(R/'evidence/lifecycle-proof.json').write_text((E/'lifecycle-proof.json').read_text())
   if watch:watch.wait(timeout=25)
 print(json.dumps(dict(box=A['id'] if A else None,stopped=(E/'lifecycle-proof.json').exists(),failure=(E/'first-failure.json').exists())))
