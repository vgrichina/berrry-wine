const fs=require('fs'),z=require('zlib'),vm=require('vm'),assert=require('assert');
const s=fs.readFileSync('repo/test/test-crt-nonlocal-jump.js','utf8');const body=s.slice(s.indexOf('const globalWat='),s.indexOf('const wat=globalWat'))+';globalThis.result=globalWat;';
const generated=z.gunzipSync(fs.readFileSync('repo/src/09b2-dispatch-table.generated.wat.gz')).toString();
const apis=JSON.parse(z.gunzipSync(fs.readFileSync('repo/src/api_table.json.gz')));const ids=Object.fromEntries(apis.map(a=>[a.name,a.id]));
function check(text){const c={assert,globals:new Set(['$API_ID_longjmp','$API_ID_GetTickCount']),defs:new Set(),constants:{},sources:{'09b2-dispatch-table.generated':text},ids};vm.createContext(c);vm.runInContext(body,c);return c.result;}
assert(check(generated).includes('(global $API_ID_longjmp i32'));
assert.throws(()=>check(generated.replace(/  \(global \$API_ID_longjmp i32 \(i32.const [0-9]+\)\)\n/,'')),/missing production global \$API_ID_longjmp/);
console.log('PASS: exact focused-test declaration selection accepts canonical globals and rejects removed longjmp declaration; full focused module NOT run');
