const fs=require('fs'),z=require('zlib'),path=require('path');
const read=fs.readFileSync.bind(fs),write=fs.writeFileSync.bind(fs);
fs.readFileSync=function(p,o){if(!fs.existsSync(p)&&fs.existsSync(p+'.gz')){const b=z.gunzipSync(read(p+'.gz'));return o?b.toString(typeof o==='string'?o:o.encoding):b;}return read(p,o);};
fs.writeFileSync=function(p,b,o){if(p.endsWith('09b2-dispatch-table.generated.wat'))return write(p+'.gz',z.gzipSync(b,{mtime:0}));return write(p,b,o);};
require('./repo/tools/gen_dispatch.js');
