from control import *
from objects import commit_changes,path
import tarfile,gzip,datetime,io
branch='refs/heads/task/'+R.name
life=json.loads((E/'final-box-state.stdout').read_text().splitlines()[-1])['sandbox']
assert life['state']=='stopped' and life['snapshotAvailable'] and life['stop']['status']=='completed'
sid=json.loads((E/'initial-forecast.json').read_text())['sessionID']
changes={n:(REPO/n).read_bytes() for n in ['tools/gen_dispatch.js','test/test-crt-nonlocal-jump.js']}
changes['src/09b2-dispatch-table.generated.wat']=gzip.decompress((REPO/'src/09b2-dispatch-table.generated.wat.gz').read_bytes())
report=dict(task=R.name,status='BLOCKED_RESUME_403_CANONICAL_COMPILE_AND_GUEST_NOT_ATTEMPTED',sessionID=sid,parent=BASE,branch=branch,productionRepair={n:pin(b) for n,b in changes.items()},semanticsUnchanged=True,validation=dict(productionGenerator='PASS locally with lossless compressed I/O adapter',generatedDelta='Only API_ID_longjmp declaration; derived from API table, no hardcoded ID',declarationRegression='PASS actual test selection; removed canonical declaration rejected',fullFocusedModule='NOT RUN',canonicalCompile=dict(attempted=False,command='/usr/bin/node --max-old-space-size=512 tools/build-compile-wat.js'),guest=dict(attempted=False,invocations=0,app='GLTron0.70',command='/usr/bin/node --max-old-space-size=512 test/run.js --app=gltron --no-build --gl-renderer=software --wasm=build/wine-assembly.wasm --max-seconds=45 --max-batches=100000 --batch-size=10000 --png=capture/original.png',PNG=None,gameplayQualified=False)),blocker=dict(code='api_key_action_forbidden',status=403,action='sandbox.resume',explanation='Task failure handler stopped box after recoverable missing generator helper; same-box resume denied. No denied-action retry or second fork.'),lifecycle=dict(id=life['id'],state=life['state'],snapshotAvailable=life['snapshotAvailable'],snapshotCompletedAt=life['snapshotCompletedAt'],stop=life['stop'],createdAt=life['createdAt'],expiry=json.loads((E/'boat-assignment.json').read_text())['expiry'],shutdownExplicitlyDelegated=True),publication=dict(status='PENDING_UNCHANGED_TRUSTED_SSH_PUBLICKEY_DENIAL',attempted=False,remoteVerified=False),scope=dict(noOtherWorkers=True,noSharedRootEdits=True,noTelegram=True,noIntegration=True,noDeployment=True),limitations=['Unvalidated production candidate; full canonical compile is still required before any guest execution.','Original failure, incomplete remote generator attempt, premature stop, resume denial and stop-on-archived error preserved without retroactive clean-run claim.'])
(R/'result.json').write_text(json.dumps(report,indent=2))
(R/'recipe.txt').write_text('Parent '+BASE+'; task branch '+branch+'. Restore exact files from repair-source-evidence.tar.xz and verify manifests. Three production changes only: namedApiIds adds longjmp; regenerate dispatcher; focused test copies real production API_ID declarations and refuses absent declarations. Local generator used gzip-only read/write adapter because physical allocation is bounded; generated output compared byte-for-byte with parent except one API-table-derived declaration. Full focused test, canonical tools/build-compile-wat.js and ONE original GLTron command remain unrun. Do not use prior wasm. Resume API403 is a platform blocker; no new box/retry without authorization. Do not push/verify remote absent independent authorization change.\n')
# Preserve raw receipts and recipes losslessly before removing only this task's duplicate captures.
members=[p for p in E.rglob('*') if p.is_file()]+[p for p in R.glob('*.py')]+[p for p in R.glob('*.js')]+[R/'stores.json',R/'coordinator-allocation-forecast.json']
pins={p.relative_to(R).as_posix():pin(p.read_bytes()) for p in members}
with tarfile.open(R/'raw-evidence.tar.xz','w:xz') as t:
 for p in members:t.add(p,arcname=p.relative_to(R).as_posix(),recursive=False)
with tarfile.open(R/'raw-evidence.tar.xz') as t:
 for n,w in pins.items():assert pin(t.extractfile(n).read())==w
for p in [p for p in E.rglob('*') if p.is_file()]:p.unlink()
save('raw-evidence-recovery',dict(archive=str(R/'raw-evidence.tar.xz'),pin=pin((R/'raw-evidence.tar.xz').read_bytes()),members=pins,verifiedBeforeUnlink=True))
package='test/'+R.name+'/'
changes.update({package+n:(R/n).read_bytes() for n in ['result.json','recipe.txt','raw-evidence.tar.xz']})
watch=subprocess.Popen(['tail','-n','0','-f','/home/user/wine-assembly/messageboard.txt'],stdout=(E/'messageboard-watch.stdout').open('wb'),stderr=(E/'messageboard-watch.stderr').open('wb'))
try:
 commit,tree=commit_changes(BASE,changes,'Fix generated longjmp API ID declaration; preserve blocked canonical acceptance')
 actual=git(['diff-tree','--no-commit-id','--name-only','-r',BASE,commit],'exact-changed-paths').decode().splitlines();assert set(actual)==set(changes)
 for n,b in changes.items():assert path(commit,n)[1]==b
 git(['update-ref',branch,commit,BASE],'local-task-ref')
finally:watch.terminate();watch.wait(timeout=5)
with tarfile.open(R/'repair-source-evidence.tar.xz','w:xz') as t:
 for n,b in changes.items():
  m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
 for p in (REPO/'.git/objects').glob('[0-9a-f][0-9a-f]/*'):t.add(p,arcname='git-objects/'+p.parent.name+'/'+p.name,recursive=False)
with tarfile.open(R/'repair-source-evidence.tar.xz') as t:
 for n,b in changes.items():assert t.extractfile(n).read()==b
completion=dict(**report,commit=commit,tree=tree,indexFree=True,unrelatedParentEntriesPreserved=True,recovery=dict(archive=str(R/'repair-source-evidence.tar.xz'),pin=pin((R/'repair-source-evidence.tar.xz').read_bytes()),readbackVerified=True,commitObjectsIncluded=True),evidence=str(R/'raw-evidence.tar.xz'))
(R/'completion-receipt.json').write_text(json.dumps(completion,indent=2))
(R/'messageboard-note.txt').write_text(f"{datetime.datetime.now(datetime.timezone.utc).isoformat()} {R.name} BLOCKED sandbox.resume403. Narrow production generator+generated declaration+test candidate local commit {commit}, branch {branch}, parent {BASE}. Generator local PASS and removed-global declaration regression PASS; full canonical compile NOT attempted, guest invocations0, PNG absent, no gameplay qualification. Initial remote generator lacked exact d3dim helper; premature stop preserved; same-box resume403 not retried, no second fork. Box {life['id']} verified stopped snapshot {life['snapshotCompletedAt']}; original expiry {report['lifecycle']['expiry']}. Receipt {R/'completion-receipt.json'}; exact source/evidence/commit-object recovery {R/'repair-source-evidence.tar.xz'}. Publication PENDING unchanged trusted SSH publickey denial, no push or remote verification. No shared edits/Telegram/workers/main/deploy. Coordinator append.\n")
v=admission('final-bookkeeping-inclusive-forecast');completion['allocation']=v;(R/'completion-receipt.json').write_text(json.dumps(completion,indent=2));admission('final-recheck')
print(json.dumps(dict(commit=commit,branch=branch,status=report['status'],recovery=completion['recovery'],physical=v['physical'],forecast=v['forecast'],box=life['id'],state=life['state'])))
