// ═══════════════════════════════════════════════════════════════
// WATX COMPILER — Stage 1: Parser
// S-expression reader with position tracking
// ═══════════════════════════════════════════════════════════════

class ParseError extends Error {
  constructor(msg, line, col, file) {
    super(msg);
    this.line = line;
    this.col = col;
    this.file = file || '<main>';
  }
}

const WATX_DIGIT_RE = /[0-9]/;
// `_` is a WAT digit separator (`1_000`, `0xFFFF_FFFF`), so it has to stay inside
// the number token. Without it `1_000` split into the number `1` and a stray
// symbol `_000`, and the const site quietly compiled the literal as 1. The
// separator's legal POSITION (between digits only) is enforced by the strict
// literal validators in compiler-codegen.js, not here.
const WATX_NUMBER_RE = /[0-9._\-xXa-fA-F]/;
const WATX_SYMBOL_START_RE = /[a-zA-Z_$\-\.{}\+\*\/\<\>\=\!\&\|\^\~\%\?\@\#]/;
const WATX_SYMBOL_RE = /[a-zA-Z0-9_$\-\.{}\+\*\/\<\>\=\!\&\|\^\~\%\?\@\#]/;

// Production parsing classifies ASCII with one table lookup instead of running
// a RegExp for nearly every source character.
const WATX_CHAR_DIGIT = 1;
const WATX_CHAR_NUMBER = 2;
const WATX_CHAR_SYMBOL_START = 4;
const WATX_CHAR_SYMBOL = 8;
const WATX_CHAR_FLAGS = new Uint8Array(128);
for (let code = 48; code <= 57; code++) WATX_CHAR_FLAGS[code] |= WATX_CHAR_DIGIT | WATX_CHAR_NUMBER | WATX_CHAR_SYMBOL;
for (let code = 65; code <= 90; code++) WATX_CHAR_FLAGS[code] |= WATX_CHAR_SYMBOL_START | WATX_CHAR_SYMBOL;
for (let code = 97; code <= 122; code++) WATX_CHAR_FLAGS[code] |= WATX_CHAR_SYMBOL_START | WATX_CHAR_SYMBOL;
for (const ch of '_$-.{}+*/<>=!&|^~%?@#') WATX_CHAR_FLAGS[ch.charCodeAt(0)] |= WATX_CHAR_SYMBOL_START | WATX_CHAR_SYMBOL;
for (const ch of '._-xXabcdefABCDEF') WATX_CHAR_FLAGS[ch.charCodeAt(0)] |= WATX_CHAR_NUMBER;

// ── Float spellings that are not a plain digit run ───────────────────────────
// WAT's float grammar has shapes whose characters fall outside the number class
// above, and each one used to split into TWO atoms at exactly the character the
// scanner stopped on — which surfaced downstream as the const site's arity
// error, "expected exactly one literal operand, got 2":
//
//   inf / -inf / nan / -nan   already arrive as one SYMBOL token; nothing here
//   nan:0x400000              stopped at ':' -> symbol `nan` + number `0x400000`
//   0x1p-149, 0x1.8p+3        stopped at 'p' -> number `0x1` + symbol `p-149`
//   1e+10                     stopped at '+' -> number `1e`  + symbol `+10`
//
// There are two scanners in this file (the legacy `tokenize` and the production
// `parseSource` table walk) and a literal that ends in a different place in each
// is the classic way for one path to compile what the other refuses. Both call
// the two helpers below, so they cannot disagree about where a literal ends.
// Neither helper VALIDATES: the strict literal checkers in compiler-codegen.js
// still own that, exactly as they do for `_` digit separators.

// `nan:0xHEX` as a single number token. Manual character tests rather than a
// RegExp because this runs on every symbol-shaped atom in the tree.
function watxScanNanPayload(source, start, end) {
  let i = start;
  const c0 = source.charCodeAt(i);
  if (c0 === 43 /* + */ || c0 === 45 /* - */) i++;
  if (source.charCodeAt(i) !== 110 /* n */) return -1;
  if (source.charCodeAt(i + 1) !== 97 /* a */) return -1;
  if (source.charCodeAt(i + 2) !== 110 /* n */) return -1;
  if (source.charCodeAt(i + 3) !== 58 /* : */) return -1;
  if (source.charCodeAt(i + 4) !== 48 /* 0 */) return -1;
  if ((source.charCodeAt(i + 5) | 32) !== 120 /* x */) return -1;
  i += 6;
  const digitsStart = i;
  while (i < end) {
    const c = source.charCodeAt(i);
    const lo = c | 32;
    const isHexDigit = (c >= 48 && c <= 57) || (lo >= 97 && lo <= 102) || c === 95 /* _ */;
    if (!isHexDigit) break;
    i++;
  }
  return i > digitsStart ? i : -1;
}

// Where a number token ends, exponent included. The exponent MARKER is the only
// character a sign may follow, and only once: that is what keeps `1-5` from
// reading as an exponent, and what keeps the hex digit 'e' in `0x1e-5` from
// being mistaken for one (a hex float's marker is 'p', a decimal's is 'e').
function watxScanNumberEnd(source, start, end) {
  let i = start;
  const c0 = source.charCodeAt(i);
  if (c0 === 43 /* + */ || c0 === 45 /* - */) i++;
  const isHex = source.charCodeAt(i) === 48 /* 0 */ &&
    ((source.charCodeAt(i + 1) | 32) === 120 /* x */);
  const expMarker = isHex ? 112 /* p */ : 101 /* e */;
  let seenExp = false;
  while (i < end) {
    const c = source.charCodeAt(i);
    if (!seenExp && i > start && (c | 32) === expMarker) {
      seenExp = true;
      i++;
      const s = source.charCodeAt(i);
      if (s === 43 /* + */ || s === 45 /* - */) i++;
      continue;
    }
    if (((WATX_CHAR_FLAGS[c] || 0) & WATX_CHAR_NUMBER) !== 0) { i++; continue; }
    break;
  }
  return i;
}

// ── Source bytes → source text ───────────────────────────────────────────────
// A host reads a source file as UTF-8 bytes and the compiler wants a string, so
// somebody has to decode. WHICH string it gets is worth 9.7 MB of live heap on
// the Wine closure, because of a V8 representation rule: a string whose every
// code point is < 256 is stored one byte per character, and one code point over
// that stores the WHOLE string two bytes per character. Wine's sources are
// ASCII apart from the box-drawing characters in their banner comments — 21,289
// such bytes across 29 of 62 files — and those 21 KB of decoration were doubling
// 10.85 MB of source into 20.53 MB of heap (measured: 1.89 bytes per character).
//
// So: replace non-ASCII bytes that lie inside a `;;` comment with `?` before
// decoding. One byte in, one character out, and the compiler never sees the
// difference — the tokenizer skips comment text, and every source offset stays
// exactly the byte offset it already was.
//
// It is deliberately conservative about what "inside a comment" means. The scan
// tracks the same two constructs the reader does (`;;` to end of line, `"…"`
// with backslash escapes) and BAILS OUT — decoding the untouched bytes as UTF-8,
// i.e. exactly what a host used to do — the moment a non-ASCII byte turns up
// anywhere else. A literal high byte in a data string or a symbol therefore
// keeps its present meaning; it just costs what it always cost.
const WATX_SOURCE_DECODER = typeof TextDecoder !== 'undefined' ? new TextDecoder('utf-8') : null;

function watxSourceTextFromBytes(bytes) {
  if (typeof bytes === 'string') return bytes;
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const decode = () => (WATX_SOURCE_DECODER
    ? WATX_SOURCE_DECODER.decode(u8)
    : Buffer.from(u8).toString('utf8'));
  const n = u8.length;
  let cleaned = null;
  let i = 0;
  while (i < n) {
    const c = u8[i];
    if (c >= 0x80) return decode();          // high byte in code position
    if (c === 0x3b /* ; */ && u8[i + 1] === 0x3b) {
      i += 2;
      while (i < n && u8[i] !== 0x0a /* \n */) {
        if (u8[i] >= 0x80) {
          if (cleaned === null) cleaned = u8.slice();
          cleaned[i] = 0x3f /* ? */;
        }
        i++;
      }
      continue;
    }
    if (c === 0x22 /* " */) {
      i++;
      while (i < n && u8[i] !== 0x22) {
        if (u8[i] >= 0x80) return decode();   // high byte inside a string literal
        if (u8[i] === 0x5c /* \ */) i++;      // escape: the next byte is data
        i++;
      }
      i++;
      continue;
    }
    i++;
  }
  if (cleaned === null) return decode();
  return WATX_SOURCE_DECODER
    ? WATX_SOURCE_DECODER.decode(cleaned)
    : Buffer.from(cleaned).toString('utf8');
}

// Successful production builds used to allocate a separate { line, col, file }
// object for every list and repeat those three properties on every atom. The
// Android tree has ~310k lists and ~540k atoms, so source locations alone
// accounted for hundreds of thousands of objects. Pack file/line/column into a
// single safe integer and decode it only on diagnostic paths.
// Eight file bits and a 22-bit source offset fit the non-negative 30-bit
// Smi range: 256 distinct filenames, each strictly below 4 MiB characters.
// The canonical closure now has 128 fragments plus its root. Keep the packed
// representation and its allocation behavior, with explicit bounds on both
// dimensions. Offsets index JavaScript source strings (UTF-16 code units).
const WATX_LOC_FILE_BITS = 8;
const WATX_LOC_MAX_FILES = 1 << WATX_LOC_FILE_BITS;   // 256
const WATX_LOC_FILE_BASE = 0x40000000 / WATX_LOC_MAX_FILES;  // 4 MiB
const WATX_LOCATION_FILES = [];
const WATX_LOCATION_SOURCES = [];
const WATX_LOCATION_FILE_IDS = new Map();

function watxFileId(filename, source = '') {
  // Validate before allocating: a rejected source must not consume an ID.
  if (source.length >= WATX_LOC_FILE_BASE) {
    throw new Error(
      `WATX source '${filename}' is ${source.length} code units, past the ` +
      `${WATX_LOC_FILE_BASE / 1048576} MB location-offset limit`);
  }

  let id = WATX_LOCATION_FILE_IDS.get(filename);
  if (id === undefined) {
    id = WATX_LOCATION_FILES.length;
    if (id >= WATX_LOC_MAX_FILES) {
      throw new Error(
        `WATX location encoding supports at most ${WATX_LOC_MAX_FILES} source files ` +
        `(adding '${filename}' would be number ${id + 1})`);
    }
    WATX_LOCATION_FILES.push(filename);
    WATX_LOCATION_FILE_IDS.set(filename, id);
  }
  WATX_LOCATION_SOURCES[id] = source;
  return id;
}

function packWatxLocBase(fileBase, offset) {
  return fileBase + offset;
}

function watxLocFile(loc) {
  return WATX_LOCATION_FILES[Math.floor(loc / WATX_LOC_FILE_BASE)] || '<main>';
}

function watxLocLine(loc) {
  const source = WATX_LOCATION_SOURCES[Math.floor(loc / WATX_LOC_FILE_BASE)] || '';
  const offset = loc % WATX_LOC_FILE_BASE;
  let line = 1;
  for (let i = 0; i < offset; i++) if (source.charCodeAt(i) === 10) line++;
  return line;
}

function watxLocCol(loc) {
  const source = WATX_LOCATION_SOURCES[Math.floor(loc / WATX_LOC_FILE_BASE)] || '';
  const offset = loc % WATX_LOC_FILE_BASE;
  let lineStart = 0;
  for (let i = offset - 1; i >= 0; i--) {
    if (source.charCodeAt(i) === 10) { lineStart = i + 1; break; }
  }
  return offset - lineStart + 1;
}

function watxAt(form, index) {
  return form?.[index + 1];
}

function watxFormLength(form) {
  return form.length - 1;
}

function watxFormSlice(form, start, end) {
  return form.slice(start + 1, end === undefined ? undefined : end + 1);
}

function watxFormLoc(form) {
  return Array.isArray(form) ? form[0] : undefined;
}

// Atoms are interned primitive strings, so they intentionally carry no source
// metadata. On the rare diagnostic path, recover an atom's packed location by
// scanning forward from its containing form instead of retaining an object per
// token for every successful build.
function watxTokenLoc(form, value) {
  const formLoc = watxFormLoc(form);
  if (formLoc === undefined || typeof value !== 'string') return formLoc;
  const fileId = Math.floor(formLoc / WATX_LOC_FILE_BASE);
  const source = WATX_LOCATION_SOURCES[fileId] || '';
  const formOffset = formLoc % WATX_LOC_FILE_BASE;
  const tokenOffset = source.indexOf(value, formOffset);
  return tokenOffset < 0 ? formLoc : fileId * WATX_LOC_FILE_BASE + tokenOffset;
}

function watxNodeLine(node) {
  const loc = typeof node === 'number' ? node : watxFormLoc(node);
  return loc !== undefined ? watxLocLine(loc) : (node?.line || 0);
}

function watxNodeCol(node) {
  const loc = typeof node === 'number' ? node : watxFormLoc(node);
  return loc !== undefined ? watxLocCol(loc) : (node?.col || 0);
}

function watxNodeFile(node) {
  const loc = typeof node === 'number' ? node : watxFormLoc(node);
  return loc !== undefined ? watxLocFile(loc) : node?.file;
}

function watxValue(node) {
  return typeof node === 'string' ? node : node?.value;
}

// ── The `.memarg` layout-access modifier ───────────────────────────────────
//
// A layout accessor lowers the field offset one of two ways, and WHICH ONE is a
// property of the SITE, not of the layout:
//
//   (load.field        L f p)   ->  p; i32.const OFF; i32.add; i32.load align=2 offset=0
//   (load.field.memarg L f p)   ->  p;                         i32.load align=2 offset=OFF
//
// Both address the same byte and the second is three bytes shorter, but they are
// DIFFERENT wasm, and that is the point: the source tree spells the same records
// both ways (6,547 sites carry an `offset=` memarg, the rest an explicit
// `i32.add`), and a migration wave is gated on producing a byte-identical
// build/wine-assembly.wasm. One lowering per site keeps that oracle total for
// both populations — see §3.4 of docs/watx-layout-migration-design.md for why
// this is per-site and NOT the per-layout attribute that section first proposed
// (DxObject alone has 497 add-spelled and 40 memarg-spelled sites; a per-layout
// flag would have silently re-encoded the 367 already converted).
//
// Declared here, in stage 1, because all four stage files share one global
// scope and BOTH the checker (compiler-stages.js) and the code generator
// (compiler-codegen.js) must strip the modifier the same way. A head normalized
// in one and not the other is a head whose type is inferred for a spelling that
// is not the one being emitted.
const WATX_LAYOUT_MEMARG_OPS = new Set([
  'load.field', 'store.field',
  'load.elem', 'store.elem',
  'load.field-elem', 'store.field-elem',
]);

// Layout ops that compute an ADDRESS or a CONSTANT rather than performing a
// memory access. They have no memarg to put an offset in, so `.memarg` on one of
// them is a hard error rather than a silently-ignored suffix.
const WATX_LAYOUT_NO_MEMARG_OPS = new Set(['elem-addr', 'size-of', 'offset-of']);

// Returns { head, memarg, noMemarg }: the base op, whether the site asked for
// the memarg lowering, and whether it asked for one on an op that HAS no memory
// access. A head that is not a layout accessor comes back untouched, so this is
// safe to call on every form head.
//
// It never throws: it is called from the checker, from needsAutoDrop and from
// the code generator, and only the last of those can attach a source location to
// a diagnostic. `noMemarg` is reported there.
function watxLayoutMemargHead(head) {
  if (typeof head !== 'string' || !head.endsWith('.memarg')) return { head, memarg: false, noMemarg: false };
  const base = head.slice(0, -'.memarg'.length);
  if (WATX_LAYOUT_MEMARG_OPS.has(base)) return { head: base, memarg: true, noMemarg: false };
  if (WATX_LAYOUT_NO_MEMARG_OPS.has(base)) return { head, memarg: false, noMemarg: true };
  // Not a layout op at all (`i32.load.memarg`, a typo, a macro name). Left
  // alone so the unknown-head diagnostic names the head the author wrote.
  return { head, memarg: false, noMemarg: false };
}

function watxType(node) {
  if (typeof node !== 'string') return node?.type;
  if (node.charCodeAt(0) === 34) return 'string';
  const first = node.charCodeAt(0);
  const second = node.charCodeAt(1);
  if ((first >= 48 && first <= 57) ||
      (first === 45 && second >= 48 && second <= 57)) return 'number';
  return 'symbol';
}

function makeWatxAtom(type, value, loc) {
  return value;
}

function cloneWatxAtomValue(atom, value) {
  return value;
}

function createParseContext(options = {}) {
  const internValues = options.internValues !== false;
  const internSymbols = internValues || options.internSymbols === true;
  return {
    symbols: internSymbols ? new Map() : null,
    numbers: internValues ? new Map() : null,
    strings: internValues ? new Map() : null,
    listPool: options.reuseLists ? [] : null,
    recyclePending: options.reuseLists ? [] : null,
  };
}

function internWatxValue(parseContext, type, value) {
  if (!parseContext) return value;
  const pool = type === 'symbol' ? parseContext.symbols :
    type === 'number' ? parseContext.numbers : parseContext.strings;
  if (!pool) return value;
  const existing = pool.get(value);
  if (existing !== undefined) return existing;
  pool.set(value, value);
  return value;
}

function tokenize(source, filename) {
  const tokens = [];
  let i = 0, line = 1, col = 1;
  while (i < source.length) {
    const ch = source[i];
    if (ch === '\n') { line++; col = 1; i++; continue; }
    if (ch === ' ' || ch === '\t' || ch === '\r') { col++; i++; continue; }
    if (ch === ';' && source[i+1] === ';') {
      while (i < source.length && source[i] !== '\n') i++;
      continue;
    }
    if (ch === '(') { tokens.push({ type: 'lparen', value: '(', line, col, file: filename }); i++; col++; continue; }
    if (ch === ')') { tokens.push({ type: 'rparen', value: ')', line, col, file: filename }); i++; col++; continue; }
    if (ch === '"') {
      const start = i;
      const startCol = col;
      i++; col++;
      while (i < source.length && source[i] !== '"') {
        if (source[i] === '\\') { i++; col++; }
        i++; col++;
      }
      if (i < source.length) { i++; col++; }
      tokens.push({ type: 'string', value: source.slice(start, i), line, col: startCol, file: filename });
      continue;
    }
    if (WATX_DIGIT_RE.test(ch) || (ch === '-' && WATX_DIGIT_RE.test(source[i+1]))) {
      const start = i;
      const startCol = col;
      const stop = watxScanNumberEnd(source, i, source.length);
      col += stop - i;
      i = stop;
      tokens.push({ type: 'number', value: source.slice(start, i), line, col: startCol, file: filename });
      continue;
    }
    {
      const nanEnd = watxScanNanPayload(source, i, source.length);
      if (nanEnd > 0) {
        const start = i;
        const startCol = col;
        col += nanEnd - i;
        i = nanEnd;
        tokens.push({ type: 'number', value: source.slice(start, i), line, col: startCol, file: filename });
        continue;
      }
    }
    if (WATX_SYMBOL_START_RE.test(ch)) {
      const start = i;
      const startCol = col;
      while (i < source.length && WATX_SYMBOL_RE.test(source[i])) { i++; col++; }
      tokens.push({ type: 'symbol', value: source.slice(start, i), line, col: startCol, file: filename });
      continue;
    }
    i++; col++;
  }
  return tokens;
}

// Production parser: scan directly into an AST without materializing comment or
// parenthesis tokens. An explicit list stack also removes parser call-stack use.
// `startOffset`/`endOffset` let the production compiler parse one indexed
// top-level form without slicing or losing source locations.
function parseSource(source, filename = '<main>', parseContext = null, startOffset = 0, endOffset = source.length) {
  const forms = [];
  const stack = [];
  const fileBase = watxFileId(filename, source) * WATX_LOC_FILE_BASE;
  let i = startOffset;

  function errorAt(message, offset) {
    const loc = packWatxLocBase(fileBase, offset);
    return new ParseError(message, watxLocLine(loc), watxLocCol(loc), filename);
  }

  function append(node) {
    if (stack.length) stack[stack.length - 1].push(node);
    else forms.push(node);
  }

  while (i < endOffset) {
    const ch = source[i];
    const flags = WATX_CHAR_FLAGS[source.charCodeAt(i)] || 0;
    if (ch === '\n' || ch === ' ' || ch === '\t' || ch === '\r') { i++; continue; }
    if (ch === ';' && source[i + 1] === ';') {
      while (i < endOffset && source[i] !== '\n') i++;
      continue;
    }
    if (ch === '(') {
      const list = parseContext?.listPool?.pop() || [];
      if (parseContext?.listPool) list._watxInPool = false;
      list.push(packWatxLocBase(fileBase, i));
      append(list);
      stack.push(list);
      i++;
      continue;
    }
    if (ch === ')') {
      if (!stack.length) throw errorAt('Unexpected ) — extra closing paren', i);
      stack.pop();
      i++;
      continue;
    }
    if (ch === '"') {
      const start = i;
      i++;
      while (i < endOffset && source[i] !== '"') {
        if (source[i] === '\\' && i + 1 < endOffset) { i += 2; continue; }
        i++;
      }
      if (i >= endOffset) throw errorAt('Unterminated string literal', start);
      i++;
      const value = internWatxValue(parseContext, 'string', source.slice(start, i));
      append(makeWatxAtom('string', value, packWatxLocBase(fileBase, start)));
      continue;
    }

    const start = i;
    const isNumber = (flags & WATX_CHAR_DIGIT) !== 0 ||
      (ch === '-' && ((WATX_CHAR_FLAGS[source.charCodeAt(i + 1)] || 0) & WATX_CHAR_DIGIT) !== 0);
    if (isNumber) {
      i = watxScanNumberEnd(source, i, endOffset);
      const value = internWatxValue(parseContext, 'number', source.slice(start, i));
      append(makeWatxAtom('number', value, packWatxLocBase(fileBase, start)));
      continue;
    }
    {
      const nanEnd = watxScanNanPayload(source, i, endOffset);
      if (nanEnd > 0) {
        i = nanEnd;
        const value = internWatxValue(parseContext, 'number', source.slice(start, i));
        append(makeWatxAtom('number', value, packWatxLocBase(fileBase, start)));
        continue;
      }
    }
    if ((flags & WATX_CHAR_SYMBOL_START) !== 0) {
      while (i < endOffset && ((WATX_CHAR_FLAGS[source.charCodeAt(i)] || 0) & WATX_CHAR_SYMBOL) !== 0) i++;
      const value = internWatxValue(parseContext, 'symbol', source.slice(start, i));
      append(makeWatxAtom('symbol', value, packWatxLocBase(fileBase, start)));
      continue;
    }
    // Preserve the legacy reader's treatment of punctuation outside its atom
    // alphabet. Strict-token diagnostics can be added as an explicit mode once
    // the existing WATX tree has been normalized.
    i++;
  }

  if (stack.length) {
    const loc = stack[stack.length - 1][0];
    const meta = { line: watxLocLine(loc), col: watxLocCol(loc) };
    const scan = preScanParenBalance(source, filename);
    throw new ParseError(
      `Unmatched ( at line ${meta.line}, col ${meta.col}; ${scan.depth} unclosed paren(s) at EOF`,
      meta.line, meta.col, filename);
  }
  return forms;
}

function recycleWatxTree(root, parseContext) {
  const pool = parseContext?.listPool;
  if (!pool || !Array.isArray(root)) return;
  const pending = parseContext.recyclePending;
  pending.push(root);
  while (pending.length) {
    const form = pending.pop();
    // Macro substitution may put the same argument subtree in more than one
    // place. Keep a stable arena marker on parser arrays: changing its boolean
    // value avoids both an identity table and per-function hidden-class churn.
    if (form._watxInPool) continue;
    form._watxInPool = true;
    for (let i = 1; i < form.length; i++) if (Array.isArray(form[i])) pending.push(form[i]);
    form.length = 0;
    delete form._isBegin;
    pool.push(form);
  }
}

// Index balanced top-level forms without building their ASTs. This is the
// lightweight first half of production's two-pass compiler: sources stay in
// the VFS and function bodies are represented by byte ranges.
function scanWatxTopLevelForms(source, filename = '<main>') {
  const forms = [];
  let depth = 0;
  let start = -1;
  let i = 0;

  function fail(message, offset) {
    const fileBase = watxFileId(filename, source) * WATX_LOC_FILE_BASE;
    const loc = packWatxLocBase(fileBase, offset);
    throw new ParseError(message, watxLocLine(loc), watxLocCol(loc), filename);
  }

  while (i < source.length) {
    const ch = source[i];
    if (ch === ';' && source[i + 1] === ';') {
      while (i < source.length && source[i] !== '\n') i++;
      continue;
    }
    if (ch === '"') {
      const stringStart = i++;
      while (i < source.length && source[i] !== '"') {
        if (source[i] === '\\' && i + 1 < source.length) i += 2;
        else i++;
      }
      if (i >= source.length) fail('Unterminated string literal', stringStart);
      i++;
      continue;
    }
    if (ch === '(') {
      if (depth++ === 0) start = i;
      i++;
      continue;
    }
    if (ch === ')') {
      if (depth === 0) fail('Unexpected ) — extra closing paren', i);
      depth--;
      i++;
      if (depth === 0) forms.push({ start, end: i });
      continue;
    }
    i++;
  }
  if (depth !== 0) fail('Unmatched ( at end of input', start < 0 ? source.length : start);
  return forms;
}

function watxTopLevelHead(source, start, end) {
  let i = start + 1;
  while (i < end) {
    const ch = source[i];
    if (ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n') { i++; continue; }
    if (ch === ';' && source[i + 1] === ';') {
      while (i < end && source[i] !== '\n') i++;
      continue;
    }
    const tokenStart = i;
    while (i < end) {
      const code = source.charCodeAt(i);
      if (((WATX_CHAR_FLAGS[code] || 0) & WATX_CHAR_SYMBOL) === 0) break;
      i++;
    }
    return source.slice(tokenStart, i);
  }
  return '';
}

// Return the head atom of every list in a source range without materializing
// list bodies. Pass 1 uses this to find which macro templates a function can
// expand, including transitive macro calls.
function scanWatxListHeads(source, start = 0, end = source.length) {
  const heads = [];
  let i = start;
  while (i < end) {
    const ch = source[i];
    if (ch === ';' && source[i + 1] === ';') {
      while (i < end && source[i] !== '\n') i++;
      continue;
    }
    if (ch === '"') {
      i++;
      while (i < end && source[i] !== '"') {
        if (source[i] === '\\' && i + 1 < end) i += 2;
        else i++;
      }
      i++;
      continue;
    }
    if (ch !== '(') { i++; continue; }
    i++;
    while (i < end) {
      const next = source[i];
      if (next === ' ' || next === '\t' || next === '\r' || next === '\n') { i++; continue; }
      if (next === ';' && source[i + 1] === ';') {
        while (i < end && source[i] !== '\n') i++;
        continue;
      }
      break;
    }
    while (i < end && ((WATX_CHAR_FLAGS[source.charCodeAt(i)] || 0) & WATX_CHAR_SYMBOL_START) === 0) i++;
    const headStart = i;
    while (i < end && ((WATX_CHAR_FLAGS[source.charCodeAt(i)] || 0) & WATX_CHAR_SYMBOL) !== 0) i++;
    if (i > headStart) heads.push(source.slice(headStart, i));
  }
  return heads;
}

function scanWatxFunctionHeader(source, filename, start, end, parseContext = null, macroForms = [], macroNames = null) {
  const fileBase = watxFileId(filename, source) * WATX_LOC_FILE_BASE;
  const header = [packWatxLocBase(fileBase, start), 'func'];
  let i = start + 1;
  let sawHead = false;
  let sawName = false;

  function skipSpaceAndComments() {
    while (i < end) {
      const ch = source[i];
      if (ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n') { i++; continue; }
      if (ch === ';' && source[i + 1] === ';') {
        while (i < end && source[i] !== '\n') i++;
        continue;
      }
      break;
    }
  }

  function findListEnd(listStart) {
    let depth = 0;
    let p = listStart;
    while (p < end) {
      const ch = source[p];
      if (ch === ';' && source[p + 1] === ';') {
        while (p < end && source[p] !== '\n') p++;
        continue;
      }
      if (ch === '"') {
        p++;
        while (p < end && source[p] !== '"') {
          if (source[p] === '\\' && p + 1 < end) p += 2;
          else p++;
        }
        p++;
        continue;
      }
      if (ch === '(') depth++;
      else if (ch === ')' && --depth === 0) return p + 1;
      p++;
    }
    return end;
  }

  while (i < end - 1) {
    skipSpaceAndComments();
    if (i >= end - 1 || source[i] === ')') break;
    if (source[i] === '(') {
      const childStart = i;
      const childEnd = findListEnd(childStart);
      const childHead = watxTopLevelHead(source, childStart, childEnd);
      if (childHead === 'param' || childHead === 'result' || childHead === 'effects' || childHead === 'export') {
        const child = parseSource(source, filename, parseContext, childStart, childEnd)[0];
        header.push(child);
      } else if (macroNames?.has(childHead)) {
        // Header clauses may themselves come from a forward-defined macro.
        // Parse only the immediate invocation, then retain only header output.
        const child = parseSource(source, filename, parseContext, childStart, childEnd)[0];
        for (const expanded of expandMacros([...macroForms, child])) {
          const expandedHead = Array.isArray(expanded) ? watxValue(expanded[1]) : null;
          if (expandedHead === 'param' || expandedHead === 'result' ||
              expandedHead === 'effects' || expandedHead === 'export') header.push(expanded);
        }
      }
      i = childEnd;
      continue;
    }
    if (((WATX_CHAR_FLAGS[source.charCodeAt(i)] || 0) & WATX_CHAR_SYMBOL_START) === 0) {
      // Match parseSource's compatibility behavior: punctuation outside the
      // atom alphabet (notably legacy `\$name`) is ignored.
      i++;
      continue;
    }
    const tokenStart = i;
    while (i < end && ((WATX_CHAR_FLAGS[source.charCodeAt(i)] || 0) & WATX_CHAR_SYMBOL) !== 0) i++;
    const token = source.slice(tokenStart, i);
    if (!sawHead) {
      sawHead = true;
      if (token !== 'func') throw new Error(`Expected func at ${filename}:${watxLocLine(header[0])}`);
    } else if (!sawName && token.startsWith('$')) {
      header.push(internWatxValue(parseContext, 'symbol', token));
      sawName = true;
    }
  }
  return header;
}

// Collect only nested `(type ...)` annotations. Anonymous indirect-call types
// must be registered before the Wasm type section is written, but retaining the
// rest of the function body in pass 1 is unnecessary.
function scanWatxTypeForms(source, filename, start = 0, end = source.length, parseContext = null) {
  const found = [];
  const stack = [];
  let i = start;
  while (i < end) {
    const ch = source[i];
    if (ch === ';' && source[i + 1] === ';') {
      while (i < end && source[i] !== '\n') i++;
      continue;
    }
    if (ch === '"') {
      i++;
      while (i < end && source[i] !== '"') {
        if (source[i] === '\\' && i + 1 < end) i += 2;
        else i++;
      }
      i++;
      continue;
    }
    if (ch === '(') {
      stack.push(i++);
      continue;
    }
    if (ch === ')') {
      const listStart = stack.pop();
      i++;
      if (listStart !== undefined && watxTopLevelHead(source, listStart, i) === 'type') {
        const form = parseSource(source, filename, parseContext, listStart, i)[0];
        if (form) found.push(form);
      }
      continue;
    }
    i++;
  }
  return found;
}

// Pre-scan source for paren balance and return diagnostic info
function preScanParenBalance(source, filename) {
  let depth = 0;
  let maxDepth = 0;
  let maxDepthLine = 0;
  let i = 0, line = 1;
  let inComment = false;
  const lineInfo = [];
  let lineOpens = 0, lineCloses = 0, lineDepthStart = 0;
  
  lineDepthStart = 0;
  
  while (i < source.length) {
    const ch = source[i];
    
    if (ch === '\n') {
      lineInfo.push({ line, depthStart: lineDepthStart, depthEnd: depth, opens: lineOpens, closes: lineCloses });
      line++;
      lineOpens = 0;
      lineCloses = 0;
      lineDepthStart = depth;
      inComment = false;
      i++;
      continue;
    }
    
    if (inComment) { i++; continue; }
    
    if (ch === ';' && i + 1 < source.length && source[i + 1] === ';') {
      inComment = true;
      i++;
      continue;
    }
    
    if (ch === '"' && !inComment) {
      i++;
      while (i < source.length && source[i] !== '"') {
        if (source[i] === '\\') i++;
        i++;
      }
      if (i < source.length) i++;
      continue;
    }
    
    if (ch === '(') {
      depth++;
      lineOpens++;
      if (depth > maxDepth) { maxDepth = depth; maxDepthLine = line; }
    } else if (ch === ')') {
      depth--;
      lineCloses++;
      if (depth < 0) {
        return { balanced: false, extraClose: true, line, depth, lineInfo };
      }
    }
    
    i++;
  }
  lineInfo.push({ line, depthStart: lineDepthStart, depthEnd: depth, opens: lineOpens, closes: lineCloses });
  
  return { balanced: depth === 0, depth, maxDepth, maxDepthLine, lineInfo };
}

// originalSource is optional — pass it for better diagnostics on paren errors
function parseSexpr(tokens, originalSource) {
  let pos = 0;
  function parseOne() {
    if (pos >= tokens.length) throw new ParseError('Unexpected end of input', 0, 0);
    const tok = tokens[pos];
    if (tok.type === 'comment') { pos++; return parseOne(); }
    if (tok.type === 'lparen') {
      pos++;
      const list = [];
      list._meta = { line: tok.line, col: tok.col, file: tok.file };
      while (pos < tokens.length && tokens[pos].type !== 'rparen') {
        if (tokens[pos].type === 'comment') { pos++; continue; }
        list.push(parseOne());
      }
      if (pos >= tokens.length) {
        let diagMsg = 'Unmatched (';
        try {
          const errorLine = tok.line;
          if (originalSource) {
            const scan = preScanParenBalance(originalSource, tok.file || '<main>');
            const li = scan.lineInfo;
            const sourceLines = originalSource.split('\n');
            
            diagMsg += ' at line ' + errorLine + ', col ' + tok.col;
            diagMsg += '\n' + scan.depth + ' unclosed paren(s) at EOF';
            diagMsg += '\nMax nesting depth: ' + scan.maxDepth + ' at line ' + scan.maxDepthLine;
            
            const topLevelEnds = [];
            for (let j = 0; j < li.length; j++) {
              if (li[j].depthEnd === 0 && li[j].depthStart > 0) {
                topLevelEnds.push(li[j].line);
              }
            }
            const lastClosed = topLevelEnds.length > 0 ? topLevelEnds[topLevelEnds.length - 1] : 0;
            diagMsg += '\nLast closed top-level form ends at line: ' + lastClosed;
            
            diagMsg += '\n\n=== Paren depth trace (from line ' + errorLine + ') ===\n';
            diagMsg += 'D=depth_before → depth_after | Line# | Source\n\n';
            let shown = 0;
            for (let j = 0; j < li.length && shown < 100; j++) {
              if (li[j].line >= errorLine) {
                const srcLine = sourceLines[li[j].line - 1] || '';
                const truncSrc = srcLine.length > 70 ? srcLine.substring(0, 67) + '...' : srcLine;
                let flag = '';
                if (li[j].depthEnd === 0) flag = ' ◄◄ TOP-LEVEL (depth=0)';
                else if (li[j].depthEnd === 1 && li[j].depthStart > 1) flag = ' ◄ back to func-level';
                else if (li[j].opens > 0 && li[j].closes === 0 && li[j].opens > 1) flag = ' ⚠ opens only (+' + li[j].opens + ')';
                diagMsg += 'D' + String(li[j].depthStart).padStart(2) + '→' + String(li[j].depthEnd).padStart(2) + ' L' + String(li[j].line).padStart(5) + ' │ ' + truncSrc + flag + '\n';
                shown++;
              }
            }
            
            diagMsg += '\n=== Last 30 lines of file ===\n';
            const startIdx = Math.max(0, li.length - 30);
            for (let j = startIdx; j < li.length; j++) {
              const srcLine = sourceLines[li[j].line - 1] || '';
              const truncSrc = srcLine.length > 70 ? srcLine.substring(0, 67) + '...' : srcLine;
              let flag = '';
              if (li[j].depthEnd === 0) flag = ' ◄◄ TOP-LEVEL';
              diagMsg += 'D' + String(li[j].depthStart).padStart(2) + '→' + String(li[j].depthEnd).padStart(2) + ' L' + String(li[j].line).padStart(5) + ' │ ' + truncSrc + flag + '\n';
            }
            
            diagMsg += '\nFinal depth: ' + scan.depth + ' (need ' + scan.depth + ' more closing parens)\n';
          } else {
            diagMsg += ' (opened at line ' + errorLine + ', col ' + tok.col + ')';
            let d = 0;
            const allTokenLines = [];
            let curLine = 1, lineOpen = 0, lineClose = 0;
            for (let ti = 0; ti < tokens.length; ti++) {
              const t = tokens[ti];
              while (curLine < t.line) {
                allTokenLines.push({ line: curLine, open: lineOpen, close: lineClose, depth: d });
                curLine++; lineOpen = 0; lineClose = 0;
              }
              if (t.type === 'lparen') { d++; lineOpen++; }
              else if (t.type === 'rparen') { d--; lineClose++; }
            }
            allTokenLines.push({ line: curLine, open: lineOpen, close: lineClose, depth: d });
            
            diagMsg += '\n\n=== Last 100 lines with paren depth ===\n';
            const startShow = Math.max(0, allTokenLines.length - 100);
            for (let li = startShow; li < allTokenLines.length; li++) {
              const info = allTokenLines[li];
              const depthBefore = info.depth - info.open + info.close;
              const marker = (info.line === errorLine) ? ' <<<< UNMATCHED' : '';
              diagMsg += 'D=' + String(depthBefore).padStart(3) + ' →D' + String(info.depth).padStart(3) + ' | L' + String(info.line).padStart(5) + marker + '\n';
            }
            diagMsg += '\nFinal depth: ' + d + '\n';
          }
        } catch(diagErr) {
          diagMsg += ' (diagnostic generation failed: ' + diagErr.message + ')';
        }
        throw new ParseError(diagMsg, tok.line, tok.col);
      }
      pos++;
      return list;
    }
    if (tok.type === 'rparen') throw new ParseError('Unexpected ) — extra closing paren', tok.line, tok.col);
    pos++;
    return { type: tok.type, value: tok.value, line: tok.line, col: tok.col, file: tok.file };
  }
  const forms = [];
  while (pos < tokens.length) {
    if (tokens[pos].type === 'comment') { pos++; continue; }
    forms.push(parseOne());
  }
  return forms;
}
