import subprocess,time,pathlib,json
h=pathlib.Path(__file__).parent;start=time.monotonic()
for n in range(40,331,40):
 assert time.monotonic()-start<900
 r=subprocess.run(['python3',str(h/'run.py'),'stage'+str(n),'python',str(h.parent/'repo'),'python3','-B',str(h/'task.py'),'stage',str(n)])
 if r.returncode:raise SystemExit(r.returncode)
