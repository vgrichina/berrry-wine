import pathlib,json,shutil
h=pathlib.Path(__file__).parent;r=h.parent/'repo';g=r/'.git';d=pathlib.Path('/tmp/gta2-accepted-raw-exit-main-integrate-oct27/repo/.git')
a=json.loads((h/'retained/startup-supervision.json').read_text());assert a['exit']==0 and a['cleanupComplete'] and not a['stopReason']
for n in ('objects/info','refs/heads/task','info'):(g/n).mkdir(parents=True,exist_ok=True)
(g/'objects/info/alternates').write_text(str(d/'objects')+'\n'+(d/'objects/info/alternates').read_text())
(g/'config').write_text((d/'config').read_text())
(g/'HEAD').write_text('ref: refs/heads/task/airstrike-observed-space-consumption-oct27\n')
(g/'refs/heads/task/airstrike-observed-space-consumption-oct27').write_text('3370a4e72a72ef54ebcbcde5264b768a47e98590\n')
(g/'info/sparse-checkout').write_text('/reports/airstrike-observed-space-consumption-oct27/\n')
shutil.copyfile('/home/user/wine-assembly/scratch/usage-watch/airstrike-observed-space-consumption-oct27/root-ref-digest.json',h/'initial-root-ref-digest.json')
print('isolated sparse report repository prepared; root and donor refs untouched')
