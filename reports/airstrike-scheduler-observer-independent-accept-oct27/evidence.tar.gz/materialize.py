import pathlib,os,subprocess,resource,json,hashlib
ops=pathlib.Path(__file__).parent; repo=ops.parent/'repo'; repo.mkdir(exist_ok=True)
d=pathlib.Path('/tmp/airstrike-scheduler-decision-observer-oct27/repo/.git'); g=repo/'.git'
for x in ('objects/info','refs/heads/task','info'): (g/x).mkdir(parents=True,exist_ok=True)
stores=[str(d/'objects'),*(d/'objects/info/alternates').read_text().splitlines()]
(g/'objects/info/alternates').write_text('\n'.join(dict.fromkeys(stores))+'\n')
(g/'config').write_text((d/'config').read_text())
branch='task/airstrike-scheduler-observer-independent-accept-oct27';rev='3a2cae66a6a32b3cebe05880564815062873b390'
(g/'HEAD').write_text('ref: refs/heads/'+branch+'\n');(g/'refs/heads'/branch).write_text(rev+'\n')
paths=['test/run.js','lib/thread-manager.js','test/input-consumption-trace.js','test/main-scheduler-observer.js','test/test-main-scheduler-observer.js','test/fixtures/main-scheduler-original.json','docs/tracing.md']
(g/'info/sparse-checkout').write_text(''.join('/'+p+'\n' for p in paths)+'/reports/airstrike-scheduler-observer-independent-accept-oct27/\n')
def lim(): resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
def git(*a):
 r=subprocess.run(['flock','/tmp/wine-ops-production-git.lock','git',*a],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=lim)
 if r.returncode: raise RuntimeError(r.stderr.decode()[:1000])
 return r.stdout
assert hashlib.sha256(pathlib.Path('/tmp/airstrike-scheduler-decision-observer-oct27/ops/receipt-manifest.json').read_bytes()).hexdigest()=='66a7737a8e17027bf0ae193b75b23a3cd88efebd8cc3aed6454f67ce1a602da9'
(ops/'mount-checkpoint.json').write_text(json.dumps(dict(mountArgv=[],files=[],execution='not applicable: no mounts or guest authorized',ssh=os.environ['GIT_SSH_COMMAND'],fetchBytes=0),indent=2))
pins=[]
for p in paths:
 b=git('show',rev+':'+p); dest=repo/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 pins.append(dict(path=p,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),blob=git('rev-parse',rev+':'+p).decode().strip()))
expected={'test/run.js':'a8187d18402d223e1f411008620bf13b611c3e703739594a9b7abb80749942c7','lib/thread-manager.js':'f4ba190b2dbf5e2cf2dac82398577bedfb13aa26d332fb7480b4d9d7e4ea2f78','test/input-consumption-trace.js':'c8c85b12cfb76825ed64d2bc7a4a0afaea453ac5f3d1ba68f3db181ab4b146fe'}
for row in pins:
 if row['path'] in expected: assert row['sha256']==expected[row['path']]
git('read-tree',rev)
(ops/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('PASS exact candidate and immutable source pins, isolated sparse index, SSH checkpoint, no mounts/fetch')
