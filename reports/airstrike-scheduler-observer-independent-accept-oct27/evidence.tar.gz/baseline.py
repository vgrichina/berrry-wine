import pathlib,subprocess,resource,hashlib,json
p=pathlib.Path(__file__).parent;repo=p.parent/'repo';rev='3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3'
def lim():resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
for f in ('test/run.js','lib/thread-manager.js'):
 r=subprocess.run(['flock','/tmp/wine-ops-production-git.lock','git','show',rev+':'+f],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=lim);assert r.returncode==0,r.stderr
 dest=p/'baseline'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(r.stdout)
print('baseline immutable objects materialized, no fetch')
