'use strict';
// Reuse only the candidate's VM scaffolding, never its acceptance assertions.
// All execution slices are selected by its pinned extraction function from the
// actual runner; independently compare the baseline slices to immutable main.
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const crypto = require('node:crypto');
const repo = path.resolve(__dirname, '../repo');
const filename = path.join(repo, 'test/test-main-scheduler-observer.js');
const original = fs.readFileSync(filename, 'utf8');
const prefix = original.slice(0, original.indexOf('async function acceptance(parts)'));
assert(prefix.endsWith('\n'));
const mod = new Module(filename, module);
mod.filename = filename; mod.paths = Module._nodeModulePaths(path.dirname(filename));
mod._compile(prefix + '\nmodule.exports={harness,extract,production,baseline,records};', filename);
const { harness, extract, production: P, baseline, records } = mod.exports;
const hash = s => crypto.createHash('sha256').update(s).digest('hex');
const br = fs.readFileSync(path.join(__dirname, 'baseline/test/run.js'), 'utf8');
const bt = fs.readFileSync(path.join(__dirname, 'baseline/lib/thread-manager.js'), 'utf8');
assert.equal(hash(br), '1655b299c95be6b2cd2ca8c951b880b0b8fbed81a0cd785300d3bed5f24ae39c');
assert.equal(hash(bt), 'f0a2f006b0eb992bcdb904f10128167b06bfe143ac05661b82f9586d9755bf40');
// Candidate-specific extraction anchors changed in main; extract each original
// contiguous interval using the candidate fixture's literal bytes and uniqueness.
for (const [name, text] of Object.entries(baseline.parts)) {
  const source = ['sleep','live','note'].includes(name) ? bt : br;
  assert(source.includes(text), 'original interval absent: ' + name);
  assert.equal(source.indexOf(text), source.lastIndexOf(text), 'ambiguous original interval: '+name);
}
const events = h => records(h.logs);
const inputRows = h => events(h).filter(r => r.event === 'host-check-input');
const first = [];
const checks = [];
async function entry(parts) {
  for (const mode of ['ordinary','worker','cooperative']) {
    const off = harness(parts, { mode, now:25025 });
    const on = harness(parts, { mode, now:25025, enabled:true });
    await off.dispatch(); await on.dispatch();
    assert.equal(off.factoryCalls(),0,'default-off factory');
    assert.equal(off.observer(),null,'default-off init');
    assert.equal(off.wh.check_input,off.h.check_input,'default-off worker hook');
    assert.deepEqual(off.logs,[],'default-off output');
    assert.deepEqual(on.calls,off.calls,'entry semantics');
    assert.equal(on.factoryCalls(),1,'enabled factory');
    const rows = events(on), admissions = rows.filter(r=>r.event==='decision');
    const runs = rows.filter(r=>r.event==='main-run');
    assert(runs.length>0,'run wiring');
    for (const r of runs) {
      const d=admissions.find(d=>d.id===r.decisionId);
      assert(d && !d.suspended && d.path===r.path,'matching admitted run');
      assert(inputRows(on).some(i=>i.decisionId===d.id && i.scope==='admitted-main-run'),'matching input wiring');
    }
    first.push({mode,offFactory:off.factoryCalls(),enabledRows:rows.length});
  }
}
async function differential(parts, config, configure=()=>{}) {
  const a = harness(baseline.parts,{...config,baselineMode:true});
  const b = harness(parts,config);
  const c = harness(parts,{...config,enabled:true});
  for (const h of [a,b,c]) configure(h);
  const outcomes=[];
  for(const h of [a,b,c]) outcomes.push(await h.dispatch().then(()=> 'pass',e=>e.message));
  assert.deepEqual(outcomes,[outcomes[0],outcomes[0],outcomes[0]],'dispatch outcome');
  assert.deepEqual(b.calls,a.calls,'disabled observable calls/order');
  assert.deepEqual(c.calls,a.calls,'enabled observable calls/order');
  assert.deepEqual(c.dequeues,a.dequeues,'FIFO and consumption observation');
  assert.deepEqual(c.logs.filter(x=>!x.startsWith('[main-scheduler]')),a.logs,'legacy output');
  return c;
}
async function adversarial(parts) {
  // Sequential decisions with state transitions, rather than the candidate's
  // independent fixed-state cases; one consuming flag per reached decision.
  for (const mode of ['ordinary','worker','cooperative']) {
    const setYield = h => {
      let n=0; h.ex.get_yield_reason=()=>{const v=[0,10,0,0,16,0][n++]||0;h.calls.push(['dynamic-yield',v]);return v;};
    };
    await differential(parts,{mode,now:25025},setYield);
    checks.push('changing-yield-short-circuits:'+mode);
    const clockCases = [
      {clockReads:[25021,25020,25022,25021,25023,25024],live:true},
      {clockReads:[25020,25021,25022,25023,25024,25025],live:false},
      {clockReads:[25020,25022,25021,25025],real:true,live:false},
      {deadline:0,sleepFlag:1,sleepTimeout:6,live:true},
      {deadline:0,sleepFlag:1,sleepTimeout:6,live:false},
    ];
    for(const config of clockCases) {
      // Arrays must not be shared by the three differential harnesses.
      const values=config.clockReads; delete config.clockReads;
      await differential(parts,{mode,...config},h=>{
        if(values){let n=0;h.tm._waitNow=()=>{const v=values[n++]??25025;h.calls.push(['changing-clock',v]);return v;};}
      });
    }
    checks.push('clock-live-no-live-real-and-consuming-flag:'+mode);
    // Force a sibling to terminate after the first slice and a queued input to
    // survive an initially parked main until a later dispatch in the same VM.
    const event={msg:256,wParam:41,lParam:0,hwnd:0};
    const h=harness(parts,{mode,enabled:true,buttons:[event]});
    await h.dispatch(); assert.equal(h.dequeues.length,0,'parked FIFO untouched');
    h.tm._waitNow=()=>25025; await h.dispatch();
    assert.equal(h.dequeues.length,1,'single eventual FIFO dequeue');
    assert.equal(h.dequeues[0][0].wParam,41);
    checks.push('same-invocation-park-to-run-FIFO:'+mode);
  }
  // Verify each captured operand is the actual clock read, even if it changes
  // the plain production deadline during that read.
  const side = await differential(parts,{now:25025},h=>{
    let n=0;h.tm._waitNow=()=>{h.tm._mainSleepUntil=++n===1?25030:25000;h.calls.push(['deadline-changing-clock',25025]);return 25025;};
  });
  assert.deepEqual(events(side)[0].sleepChecks.map(x=>[x.now,x.deadline,x.sleeping]),[[25025,25030,true],[25025,25000,false]],'actual comparison operands');
  checks.push('clock-side-effect-deadline-operands');
  // Probe admissions must not supply the identity for a direct run. Path
  // mismatch, thrown input and queued asynchronous callbacks release identity.
  const h=harness(parts,{enabled:true,now:25025});
  h.gate(); h.observer().run('ordinary',()=>h.h.check_input());
  assert.equal(inputRows(h).at(-1).decisionId,null,'probe cannot admit ordinary run');
  await h.dispatch();
  h.wh.check_input(); assert.equal(inputRows(h).at(-1).scope,'worker');
  h.h.check_input(); assert.equal(inputRows(h).at(-1).decisionId,null,'outside poll after run');
  let pending;
  const asyncH=harness(parts,{enabled:true,now:25025,callback:({h})=>{pending=Promise.resolve().then(()=>h.check_input());}});
  await asyncH.dispatch(); await pending;
  assert.equal(inputRows(asyncH).at(-1).decisionId,null,'microtask not synchronous main execution');
  const thrown=harness(parts,{enabled:true,now:25025,callback:({h,wh})=>{
    const original=thrown.h.check_input;
    thrown.h.check_input=()=>{original();throw Error('worker input sentinel');};
    try {wh.check_input();} catch(e){assert.equal(e.message,'worker input sentinel');}
    thrown.h.check_input=original; h.check_input();throw Error('main sentinel');
  }});
  await assert.rejects(thrown.dispatch(),/main sentinel/);
  assert.equal(inputRows(thrown)[0].scope,'worker');
  assert.equal(inputRows(thrown)[1].scope,'admitted-main-run','worker exception releases worker identity');
  thrown.h.check_input();assert.equal(inputRows(thrown).at(-1).decisionId,null,'main exception releases identity');
  checks.push('probe-worker-throw-main-throw-microtask-correlation');
  const late=harness(parts,{enabled:true,now:25025,extra:'--trace-from=5000 --trace-to=5001'});
  vm.runInContext('traceGateBatch=0',late.context);
  for(let n=0;n<5000;n++)await late.dispatch();
  assert.equal(late.logs.length,0,'no budget before late window');
  vm.runInContext('traceGateBatch=5000',late.context);await late.dispatch();
  assert.equal(events(late)[0].id,1,'late first ID');
  vm.runInContext('traceGateBatch=5002',late.context);await late.dispatch();
  assert.equal(late.logs.length,3,'closed window');
  vm.runInContext('traceGateBatch=5001',late.context);await late.dispatch();
  assert.equal(events(late).at(-1).decisionId,2,'reopened window retains own budget');
  const flood=harness(parts,{enabled:true,now:25025,callback:({h})=>{for(let i=0;i<1000;i++)h.check_input();}});
  await flood.dispatch(); const count=flood.logs.length;
  await flood.dispatch();
  assert.equal(count,257,'256 rows plus one suppression');assert.equal(flood.logs.length,count,'flood remains bounded');
  assert.equal(events(flood).length,256);assert(flood.logs.at(-1).includes('limit reached'));
  const reset=harness(parts,{enabled:true,now:25025});await reset.dispatch();assert.equal(events(reset)[0].id,1);
  checks.push('5000-early-decisions-late-window-reentry-flood-reset');
}
(async()=>{
  if (!process.argv.includes('--controls-only')) {
  await entry(P); // mandatory first behavior: real default-off/enabled boundaries
  fs.writeFileSync(path.join(__dirname,'checkpoint.json'),JSON.stringify({candidate:'3a2cae66a6a32b3cebe05880564815062873b390',first,phase:'entry PASS; independent adversarial pending'}));
  await adversarial(P);
  } else { first.push(...JSON.parse(fs.readFileSync(path.join(__dirname,'groups-checkpoint.json'))).entry.first); }
  const controls=[
    ['worker-run-hook-removed',{...P,worker:P.worker.replace("mainSchedulerObserver.run('worker-interleaved', () => instance.exports.run(BATCH_SIZE))",'instance.exports.run(BATCH_SIZE)')},entry,/run wiring|matching input wiring/],
    ['cooperative-consuming-flag-added',{...P,cooperative:P.cooperative.replace('const sliceStats =','instance.exports.get_sleep_yielded(); const sliceStats =')},adversarial,/observable calls\/order/],
    ['worker-extra-clock',{...P,worker:P.worker.replace('const workerSlices =','threadManager._waitNow(); const workerSlices =')},adversarial,/observable calls\/order/],
    ['enabled-sleep-comparison-reversed',{...P,sleep:P.sleep.replace('(now = this._waitNow()) <','(now = this._waitNow()) >')},adversarial,/observable calls\/order|dispatch outcome|FIFO/],
  ];
  const rejected=[];
  for(const [name,parts,test,intended] of controls){let error;try{await test(parts);}catch(e){error=e;}assert(error,'escaped mutation '+name);assert.match(error.message,intended,'wrong mutation rejection '+name);rejected.push({name,assertion:error.message.slice(0,240)});}
  const result={verdict:'BOUNDED_SOURCE_ACCEPTANCE',candidate:'3a2cae66a6a32b3cebe05880564815062873b390',first:first.slice(0,3),checks:[...new Set(checks)],reusedPassingGroups:'groups-checkpoint.json (original entry/adversarial; not rerun)' ,rejected,
    extraction:Object.fromEntries(Object.entries(P).map(([name,text])=>[name,{bytes:Buffer.byteLength(text),sha256:hash(text)}])),
    scaffoldSHA256:hash(prefix),scaffold:'pinned candidate VM setup reused; no candidate acceptance assertions executed',
    limits:'Exact contiguous production slices and immutable main comparison with stub exports; no complete CLI invocation, guest/initializer execution, gameplay, or source scheduler-cause proof.'};
  fs.writeFileSync(path.join(__dirname,'independent-result.json'),JSON.stringify(result,null,2)+'\n');
  fs.writeFileSync(path.join(__dirname,'checkpoint.json'),JSON.stringify({candidate:result.candidate,phase:'independent acceptance PASS',remaining:'review and evidence publication',result:'independent-result.json'},null,2));
  console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
