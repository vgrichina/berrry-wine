import subprocess,pathlib,json,hashlib,shutil
r=pathlib.Path('/tmp/generally-cursor-preflight-integrity-repair-oct27/repo')
m=json.loads(pathlib.Path('/tmp/generally-mailbox-repair-independent-accept-oct27/ops/receipt-manifest.json').read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=r).decode().strip()
git('init'); (r/'.git/objects/info/alternates').write_text('/tmp/generally-mailbox-repair-independent-accept-oct27/repo/.git/objects\n/tmp/generally-mailbox-retained-publication-oct27/repo/.git/objects\n')
git('config','user.name','Wine Ops');git('config','user.email','wine-ops@localhost');git('config','remote.origin.url','git@github.com:dingusdingus/wine-assembly.git')
git('config','core.sparseCheckout','true')
paths=list(m['sourcePins'])+list(m['independentFixturePins'])
(r/'.git/info/sparse-checkout').write_text(''.join('/'+x+'\n' for x in paths))
git('checkout','-b','task/generally-cursor-preflight-integrity-repair-oct27','c899719fc153570ab19311b9b5a88bf5ffdd865a')
for k,v in m['sourcePins'].items():
 src=pathlib.Path(v['path']);assert hashlib.sha256(src.read_bytes()).hexdigest()==v['sha256'];dst=r/k;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
for k,v in m['independentFixturePins'].items():assert hashlib.sha256((r/k).read_bytes()).hexdigest()==v
print(json.dumps(dict(base=git('rev-parse','HEAD'),sourcePins=m['sourcePins'],fixturePins=m['independentFixturePins'],ssh='exact trusted configuration in run.py',mountArgv=[],mounts='none: no guest authorized'),indent=2))
