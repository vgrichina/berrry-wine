from pathlib import Path
import sys,unittest
p=Path('/tmp/generally-cursor-preflight-integrity-repair-oct27/repo/test/test-generally-loading-controller.py')
s=p.read_text();prefix=s[:s.index('\nsuite = ')]
sys.argv=[str(p),'--evidence','/tmp/generally-cursor-preflight-integrity-repair-oct27/ops/stdio-selected','--group','acceptance']
c=dict(__file__=str(p),__name__='selected');exec(compile(prefix,str(p),'exec'),c)
names=['test_04_rejected_acks_stop','test_05_global_deadline_is_not_reset_per_chunk','test_07_cannot_expand_original_timeout']
r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(c['Acceptance'](n) for n in names))
raise SystemExit(0 if r.wasSuccessful() else 1)
