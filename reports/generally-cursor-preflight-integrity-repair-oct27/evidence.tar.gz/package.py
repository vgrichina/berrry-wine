from pathlib import Path
import json,hashlib,tarfile,gzip,os,time
R=Path('/tmp/generally-cursor-preflight-integrity-repair-oct27');O=R/'ops';repo=R/'repo';out=repo/'reports/generally-cursor-preflight-integrity-repair-oct27';out.mkdir(parents=True,exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=Path('/tmp/generally-mailbox-repair-independent-accept-oct27/ops/receipt-manifest.json')
assert h(prior)=='aeb3944e872eff0eb7fb3dbfae3c62cadc063c31d2d59bc9da2282febaa7541e'
p=json.loads(prior.read_text())
source={k:dict(sha256=h(repo/k),bytes=(repo/k).stat().st_size,originalSHA256=v['sha256']) for k,v in p['sourcePins'].items()}
for k,v in source.items():
 if k not in ('tools/generally-loading-controller.py','docs/generally-mailbox-ownership-repair.md'):assert v['sha256']==v['originalSHA256']
fixtures={k:h(repo/k) for k in p['independentFixturePins']}
for k,v in fixtures.items():
 if k!='test/independent-generally-no-advance-oct27.py':assert v==p['independentFixturePins'][k]
transform=json.loads((O/'identity-transformation.json').read_text())
old=(Path('/tmp/generally-mailbox-repair-independent-accept-oct27/repo/test/independent-generally-no-advance-oct27.py')).read_text()
expected=old.replace('e41251b8e976a28957cb44c9b5398bf90aa9cd74b6fcb504301e6dbc89bbbe2b',source['tools/generally-loading-controller.py']['sha256']).replace("candidate='4616ccf2e6ce700114c8c6db3642f4aac3065827'", "candidate='helper-sha256:"+source['tools/generally-loading-controller.py']['sha256']+"'")
assert (repo/'test/independent-generally-no-advance-oct27.py').read_text()==expected
names=['node-startup','no-advance','no-advance-identity','transaction-owned','guard-omission','old-ordering-control','loading-mailbox','stdio-selected','ownership','handoff','history','whitespace']
results={}
for name in names:
 x=json.loads((O/(name+'.json')).read_text());want=1 if name in ('guard-omission','old-ordering-control') else 0
 assert x['exit']==want and x['cleanupComplete'] and x['stopReason'] is None,(name,x)
 results[name]=dict(exit=x['exit'],cleanupComplete=True,receiptSHA256=h(O/(name+'.json')),stdout=x['stdout'],stderr=x['stderr'])
# Retain a compact complete snapshot of new evidence, not predecessor payloads.
paths=sorted(x for x in O.rglob('*') if x.is_file() or x.is_symlink())
rows=[]
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=6,dereference=False) as t:
 for path in paths:
  name=str(path.relative_to(O));stat=path.lstat()
  if path.is_symlink():row=dict(path=name,type='symlink',target=os.readlink(path))
  else:row=dict(path=name,bytes=stat.st_size,sha256=h(path))
  rows.append(row);t.add(path,arcname=name,recursive=False)
raw=json.dumps(rows,separators=(',',':')).encode();(out/'payload-index.json.gz').write_bytes(gzip.compress(raw,mtime=0))
manifest=dict(at=time.time(),decision='REPAIR_TESTED_READY_FOR_INDEPENDENT_ACCEPTANCE',branch='task/generally-cursor-preflight-integrity-repair-oct27',base='c899719fc153570ab19311b9b5a88bf5ffdd865a',rejectedCandidate=p['candidate'],sourcePins=source,fixturePins=fixtures,newTest=dict(path='test/test-generally-cursor-transaction.py',sha256=h(repo/'test/test-generally-cursor-transaction.py')),identityTransformation=transform,productionBinding=p['productionBinding'],cause='transport integrity was checked only after cursor reservation; no63 dispatch',repair='bound transport exchange validates before reservation and after durable writes; abort before attempted dispatch retains last ACK/next and terminal pending+failed; attempted dispatch retains new durable pending',positive='consumed ACK61 mutation after ACK62: next63, pending+failed, last62; only requests61,62; journal poisoned',raceBoundary='cooperating owner flock plus final integrity observations; arbitrary external writers cannot be made atomic with publication. Mutation during cursor/journal writes abandons tentative ID, post-publication uncertainty retains pending ID.',results=results,reuse=dict(canonicalManifest=str(prior),sha256=h(prior),coordinatorVerifiedPayloads=8535,readiness='/tmp/generally-cursor-integrity-readiness-oct27/ops',blanketAuditRepeated=False,baselineExecutionReplayed=False,reusedPassing=['original liveowner12/alternate13 collision and omission','independent durable19/inventory/bounds','exact production stdio total3 and original total100000','predecessor broad groups as catalogued by canonical receipt'],changedChecks='only affected loading/stdio faults, ownership, handoff/history and new boundary tests'),evidence=dict(archive='evidence.tar.gz',sha256=h(out/'evidence.tar.gz'),index='payload-index.json.gz',indexSHA256=h(out/'payload-index.json.gz'),rawIndexSHA256=hashlib.sha256(raw).hexdigest(),payloads=len(rows),portability='read archive without following absolute history alias symlinks; replay --reproduce with a fresh owned root; update only oracle source identity for another candidate'),resources=dict(admissionReceipts='per-operation *.admission.json in archive',latest=json.loads((O/'whitespace.admission.json').read_text()),allocation=256*1024**2,future=152*1024**2,gitData='512MiB Git child only after initial setup incident',node='v24.18.1 heap512MiB DATA/AS unlimited aggregate768MiB',supervision='CPU90 wall120 file24MiB output2MiB; pool1 tests/pool2+flock Git'),incidents=json.loads((O/'incidents.json').read_text()),publication='final commit/exactremote/cleanup bound by external publication-closeout.json; task branch only',historicalRequest12='untouched: no replay or inferred completion; new synthetic fixtures only',cleanup='all retained operations supervised cleanupComplete; own watcher closed at publication closeout',lifecycle='no box assigned; coordinator lifecycle untouched',remainingGate='fresh independent acceptance; no main integration or runtime authorization',guestInvocations=0,compilerInvocations=0,downloads=0,fetchBytes=0)
(O/'receipt-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'receipt-manifest.json').write_bytes((O/'receipt-manifest.json').read_bytes())
(out/'README.md').write_text('''# GeneRally cursor integrity repair

Transport integrity now runs before cursor reservation inside the exchange boundary,
with checks after durable cursor/journal writes. Refusal before attempted dispatch
abandons the tentative new ID but leaves terminal failure; attempted dispatch keeps
its durable pending record. Exclusive ownership and poisoned handoff remain closed.

The unchanged production-boundary oracle (only helper/source identity bindings
updated) passes with ACK62, next63, requests61/62 only. Old ordering mutant fails
with next64 and no request63 dispatch. Five deterministic boundary tests pass;
rollback omission fails reservation/journal races. Affected loading, stdio faults,
ownership, handoff and history regressions pass. Broader unchanged groups and the
original rejection are reused from canonical aeb3944e; no blanket payload audit.

See receipt-manifest.json and indexed evidence.tar.gz for pins, transformation,
causal diagnostics, resources, cleanup and controls. Archive history aliases are
absolute symlinks: inspect without following/extracting them. Fresh portable replay:
`python3 -B test/independent-generally-no-advance-oct27.py --reproduce /OWNED/new-history`.
Focused boundary tests require `--evidence /OWNED/new-controls`. Use the prescribed
supervisor, pool, qualified Node and fresh resource admission.

Source-only repair, ready for independent acceptance. No main integration, runtime,
guest, compiler, Boat or deployment. Historical uncertain request12 is untouched.
Final exact remote commit and watcher cleanup are in worker ops/publication-closeout.json.
''')
print(json.dumps(dict(manifestSHA256=h(O/'receipt-manifest.json'),payloads=len(rows),archiveBytes=(out/'evidence.tar.gz').stat().st_size)))
