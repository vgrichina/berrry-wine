import json,shlex,pathlib,time
from api import api
O=pathlib.Path(__file__).parent
code="""import pathlib,shutil,json,time,resource,os
H=pathlib.Path('/home/user/wineops-gta2-accepted-raw-return-causal-trace-oct27');assert not H.exists();(H/'repo').mkdir(parents=True);(H/'ops').mkdir()
n=shutil.which('node');assert n
mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
assert mem>5*1024**3 and shutil.disk_usage(H).free>1073741824
print(json.dumps(dict(node=str(pathlib.Path(n).resolve()),at=time.time(),memory=mem,disk=shutil.disk_usage(H).free,limits=pathlib.Path('/proc/self/limits').read_text(),cwd=os.getcwd(),mounts=pathlib.Path('/proc/self/mountinfo').read_text()[:2000])))"""
j=api('python3 -c '+shlex.quote(code));v=json.loads(j['stdout']);(O/'boat-preflight.json').write_text(json.dumps(v,indent=2));print(json.dumps(v))
