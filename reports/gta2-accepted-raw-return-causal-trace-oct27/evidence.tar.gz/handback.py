import pathlib,json,shlex,time
from api import api
O=pathlib.Path(__file__).parent
code="""import pathlib,json,time
H=pathlib.Path('/home/user/wineops-gta2-accepted-raw-return-causal-trace-oct27');rows=[]
for p in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  c=(p/'cmdline').read_bytes().replace(bytes([0]),b' ')
  if b'remote-trace.py' in c and b'python3 -c' not in c and b'boat exec' not in c:rows.append(int(p.name))
 except OSError:pass
assert not rows,rows
print(json.dumps(dict(at=time.time(),ownedGuestProcesses=rows,guestLaunched=False,sourceGroupsStaged=120,stagedAllocated=sum(p.lstat().st_blocks*512 for p in H.rglob('*') if p.is_file()),box='bx_w99qrvz9',state='RUNNING (supported exec succeeded)',expiry='2026-10-27T15:47:01.657Z',expirySource='assigned finiteTTL receipt, no lifecycle mutations',shutdownOwner='coordinator',watcherUntouched=True,lifecycleMutations=0)))"""
j=api('python3 -c '+shlex.quote(code));(O/'handback-receipt.json').write_text(j['stdout']);print(j['stdout'])
