import pathlib,json,hashlib,time
O=pathlib.Path(__file__).parent;D=pathlib.Path('/tmp/gta2-streamed-estimate-directdraw-trace-oct27/ops')
p=json.loads((O/'transfer-plan.json').read_text());receipts=[]
for g in p['groups']:
 name='group-'+str(g['index'])+'.tar.gz';h=hashlib.sha256()
 with (D/name).open('rb') as src,(O/name).open('xb') as dst:
  while b:=src.read(65536):h.update(b);dst.write(b)
 assert h.hexdigest()==g['gzipSHA256'] and (O/name).stat().st_size==g['gzipBytes']
 receipts.append(dict(name=name,bytes=g['gzipBytes'],sha256=h.hexdigest()))
(O/'stream-copy.json').write_text(json.dumps(dict(at=time.time(),chunkBytes=65536,estimatorReplay=False,source=str(D),groups=receipts)))
print('copied verified groups',len(receipts),sum(r['bytes'] for r in receipts))
