import pathlib,json,hashlib,tarfile,gzip,time
O=pathlib.Path(__file__).parent;R=O.parent/'repo';D=R/'reports'/O.parent.name;D.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
transfers=[json.loads((O/f'transfer-{i}.json').read_text()) for i in range(120)]
(O/'staging-summary.json').write_text(json.dumps(dict(groups=120,requests=sum(r['requests'] for r in transfers),seconds=sum(r['seconds'] for r in transfers),groupReceipts=transfers,helperTransferred=False,guestInvocations=0)))
commands=[]
for p in sorted((O/'commands').glob('*.json')):
 j=json.loads(p.read_text());commands.append(dict(id=p.stem,sha256=j['sha256'],bytes=len(j['command'].encode())))
(O/'command-identities.json').write_text(json.dumps(commands))
files=[]
for p in O.iterdir():
 if p.is_file() and p.suffix in ['.py','.js','.json','.stdout','.stderr','.log','.supervisor-output'] and not p.name.startswith('group-'):files.append(p)
files+=list((O/'responses').glob('*'))
files=[p for p in files if p.name!='receipt-manifest.json']
index=[dict(path=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(files)]
with (D/'evidence.tar.gz').open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w|',bufsize=65536) as t:
   for p in sorted(files):t.add(p,arcname=str(p.relative_to(O)),recursive=False)
assert (D/'evidence.tar.gz').stat().st_size<24*1024**2
(D/'evidence-index.json').write_text(json.dumps(index,indent=2))
v=dict(status='BLOCKED_BEFORE_GUEST',outcome='first blocker',guestInvocations=0,compiledRevision='1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba',plannedRunnerRevision='3370a4e72a72ef54ebcbcde5264b768a47e98590',result=json.loads((O/'diagnostic-result.json').read_text()),handback=json.loads((O/'handback-receipt.json').read_text()),archive=dict(path='evidence.tar.gz',bytes=(D/'evidence.tar.gz').stat().st_size,sha256=sha(D/'evidence.tar.gz')),indexSHA256=sha(D/'evidence-index.json'),reused=dict(sourcePlan='/tmp/gta2-streamed-estimate-directdraw-trace-oct27/ops/transfer-plan.json',sourcePlanSHA256=sha(O/'transfer-plan.json'),acceptedIntegration='/tmp/gta2-accepted-raw-exit-main-integrate-oct27/ops/receipt-manifest.json',acceptedIntegrationSHA256='228f4b3bad86f0e62425b8a8f36aadbdc169728a025e3394e762875543ee4483'),rootRefReceipt='/home/user/wine-assembly/scratch/usage-watch/'+O.parent.name+'/root-ref-digest.json',publication='External ops/publication-closeout.json binds commit and exact remote task ref after commit; no main mutation',limitations=['No actual raw EAX/HRESULT or new DDSCAPS input bytes observed','Base source archives extracted, actual staged-file hash/preflight validation not reached','No helper overlay transfer or Node startup or guest launch','No gameplay/fullscreen/input/normalQuit acceptance'],incidents=['Initial sparse Git wrapper used one light pool slot while holding Git flock; DATA applied to each Git child, aggregate128MiB stricter than256MiB; no concurrent owned Git','Handback first request failed Popen locally on embedded-null command before transmission; corrected to bytes([0]) and sent once; original stderr retained'],checks='Archive hashes verified while streaming;120 extraction receipts; new guest/acceptance tests intentionally not run')
(D/'receipt-manifest.json').write_text(json.dumps(v,indent=2));(O/'receipt-manifest.json').write_text(json.dumps(v,indent=2))
(D/'README.md').write_text("""# GTA2 accepted raw-return causal trace — first blocker

No GTA2 invocation occurred. Raw EAX/HRESULT and fresh DDSCAPS bytes remain unknown.

The helper-transfer admission rejected a conservative projected task footprint of339,529,728bytes against335,544,320bytes (3,985,408over). Measured task files107,466,752, launcher307,200 and session/full-current-WAL30,429,184bytes plus201,326,592 reserved future bytes caused the rejection. Host memory and projected host disk passed. This is a remaining-growth projection rejection, not a claim that measured files exhausted320MiB. Runtime/staging stopped at that first blocker without reducing caps or replaying requests.

All120 unchanged base streaming groups were transferred and extracted with archive SHA256 checks. The explicit accepted runner/helper overlay was prepared locally but never transferred. Actual remote staged-file verification, startup/preflight and controller launch were not reached. There are no new API/controller receipts because no guest existed. The accepted callback would enable raw EAX through --trace-api; its production acceptance is reused, not repeated. Planned runner3370a4e and retained compiled1e4fdb06 are distinct identities.

The evidence archive preserves original local stdout/stderr, API responses, resource admissions, transfer receipts, source/module/game pin manifest, prepared overlay pins, scripts and command digests. Base64 source-transfer commands remain in owned ops with digests in the archive; source payloads are recoverable from pinned immutable donors. No PNG, gameplay, fullscreen fix or ordinary game-quit claim.

Boat bx_w99qrvz9 remains RUNNING, assigned expiry2026-10-27T15:47:01.657Z. No guest process was launched; no remote-trace process remains. Staged source is retained. Coordinator owns handback15:34UTC and shutdown15:39UTC; watcher untouched. No stop/delete/resume operation.
""")
print(json.dumps(dict(files=len(index),archiveBytes=(D/'evidence.tar.gz').stat().st_size,manifestSHA256=sha(D/'receipt-manifest.json'))))
