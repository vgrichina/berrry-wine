from pathlib import Path
import hashlib,json,difflib
R=Path('/tmp/generally-accepted-cursor-main-integration-oct27');O=R/'ops';main=(R/'repo/test/run.js').read_text();old=Path('/tmp/generally-cursor-preflight-independent-accept-oct27/repo/test/run.js').read_text()
def cut(s):
 a=s.index('  const liveOutstanding = new Map();');b=s.index('\n\n  // A rejected async loader/yield',a);return s[a:b]
a,b=cut(old),cut(main)
(O/'production-boundary.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='accepted-production-boundary',tofile='current-main-production-boundary')))
plan=json.loads(Path('/tmp/generally-cursor-integration-readiness-oct27/ops/integration-plan.json').read_text());pins=[]
for x in plan['changedFiles']:
 p=R/'repo'/x['path'];actual=hashlib.sha256(p.read_bytes()).hexdigest();pins.append(dict(x,actualSHA256=actual,match=actual==x['sha256']))
v=dict(baseline=plan['currentMain'],candidate=plan['acceptedCommit'],paths=pins,all13PinsPass=all(x['match'] for x in pins),sourceBytes=sum(x['bytes'] for x in pins),runnerSHA256=hashlib.sha256(main.encode()).hexdigest(),acceptedRunnerSHA256=hashlib.sha256(old.encode()).hexdigest(),acceptedBoundarySHA256=hashlib.sha256(a.encode()).hexdigest(),currentBoundarySHA256=hashlib.sha256(b.encode()).hexdigest(),acceptedBoundaryBytes=len(a.encode()),currentBoundaryBytes=len(b.encode()),diff='production-boundary.diff',decision='BLOCKED_CHANGED_PRODUCTION_ACK_BOUNDARY',requiredPrerequisite='Coordinator review and independent acceptance of actual current-main production boundary with unchanged transaction/refusal assertions before integration may resume',transformations=[],behavioralExecutions=0)
(O/'boundary-blocker.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({k:v[k] for k in ('decision','all13PinsPass','runnerSHA256','acceptedBoundarySHA256','currentBoundarySHA256')}))
