import ast,pathlib,json,types
H=pathlib.Path(__file__).parent;s=(H/'remote.py').read_text();tree=ast.parse(s)
f=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='observation');f.col_offset=0
code=compile(ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[])),'actual-observation','exec')
class Stop(Exception):pass
saved={};env={'b':types.SimpleNamespace(Stop=Stop),'save':lambda n,v:saved.update({n:v})};exec(code,env)
class Mock:
 bootstrapped=True;space_released=True
 def __init__(self):self.calls=[];self.batch=5003
 def request_ack(self,a,**kw):
  self.calls.append((a,kw))
  if a=='step':
   assert kw=={'n':3};self.batch+=3
   return {'value':{'ran':3,'steps':3,'batch':self.batch,'frozen':True}}
  return {'value':{'batch':self.batch,'frozen':{'frozen':True,'credits':0}}}
 def state(self,l):assert self.batch==5006;self.calls.append(('state',l))
 def capture(self,l):assert self.batch==5006;self.calls.append(('capture',l));return {'batch':self.batch}
 def event(self,*a,**k):pass
m=Mock()
try:env['observation'](m)
except Stop as e:assert 'post-deadline diagnostic complete' in str(e)
else:raise AssertionError('missing stop')
assert m.batch==5006 and m.calls[1]==('step',{'n':3})
assert 'for i in range(10)' not in s and s.count("n=5000")==1
assert '58.962178' not in s and '68.740196' not in s
assert "cpu_limit=(90 if label=='startup' else 33.635447)" in s
assert "wall_limit=(120 if label=='startup' else 43.168643807)" in s
assert 'sum(self.cpu_peaks.values())>=33.635447' in s
assert 'guest_seconds=43.168643807,wall_seconds=43.168643807' in s
assert 'RLIMIT_CPU,34' in s and '--cpu=34' in s
q=dict(pass_=True,calls=m.calls,finalBatch=m.batch,supervisorCPU=33.635447,bridgeCPU=33.635447,supervisorWall=43.168643807,bridgeWall=43.168643807,childCPU=34,bootstrapSteps=1)
(H/'local-preflight.json').write_text(json.dumps(q,indent=2));print('actual modified stop condition and exact aggregate limits PASS')
