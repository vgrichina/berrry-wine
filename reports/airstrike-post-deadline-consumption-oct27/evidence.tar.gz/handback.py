import task as t,json,time
code="""import pathlib,json,sys,time,os,shutil
R=pathlib.Path(sys.argv[1]);H=R/'trace-ops';sup=json.loads((H/'guest-supervision.json').read_text());cleanup=json.loads((H/'game-evidence/owned-cleanup.json').read_text());assert sup['cleanupComplete'] and not cleanup['remaining']
identities=[]
for pid,start in sup['owned']:
 p=pathlib.Path('/proc')/str(pid)/'stat';actual=None
 if p.exists():
  x=p.read_text();actual=x[x.rindex(')')+2:].split()[19]
 identities.append(dict(pid=pid,start=start,currentStart=actual,ownedIdentityAlive=actual==start))
assert not any(x['ownedIdentityAlive'] for x in identities)
logical=sum(p.stat().st_size for p in R.rglob('*') if p.is_file());allocated=sum(p.stat().st_blocks*512 for p in R.rglob('*') if p.is_file());print(json.dumps(dict(at=time.time(),box='bx_ms3j5waq',state='RUNNING',stateEvidence='successful supported API exec on assigned Boat',expiry='2026-10-27T17:10:43.934Z',shutdownOwner='coordinator',shutdown='2026-10-27T17:07:00Z',logicalBytes=logical,allocatedBytes=allocated,freeDisk=shutil.disk_usage(R).free,guestIdentities=identities,ownedCleanup=cleanup,supervisorCleanupComplete=sup['cleanupComplete'],survivors=[],lifecycleOperations=0)))"""
t.c.dump('boat-handback.json',json.loads(t.api(code,'boat-handback',[t.REMOTE],terminal=True)))
print('Boat RUNNING; all exact guest descendant identities absent; coordinator lifecycle retained')
