import pathlib,json,hashlib,struct,tarfile,time,re
H=pathlib.Path(__file__).parent;R=H.parent/'repo';D=H/'retained';E=D/'game-evidence';P=R/'reports/airstrike-post-deadline-consumption-oct27';P.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,q):p.write_text(json.dumps(q,indent=2)+'\n')
lines=(E/'runner.stdout').read_text().splitlines();rows=[json.loads(x[len('[main-scheduler] '):]) for x in lines if x.startswith('[main-scheduler] {')]
decisions=[x for x in rows if x['event']=='decision'];runs=[x for x in rows if x['event']=='main-run'];polls=[x for x in rows if x['event']=='host-check-input']
assert len(rows)==37 and len(decisions)==24 and [x['id'] for x in decisions]==list(range(1,25))
assert len(runs)==4 and len(polls)==9 and not any('limit reached' in x for x in lines)
for batch in range(5000,5006):
 xs=[x for x in decisions if x['batch']==batch];assert len(xs)==4
 assert [x['path'] for x in xs]==['ordinary']+['cooperative-interleaved']*3
 for x in xs:
  sleeping=batch<5005
  assert x['yieldReason']==0 and x['suspended']==sleeping and not x['fastForward']
  assert x['reason']==('sleep' if sleeping else 'runnable')
  assert x['sleepChecks']==[dict(now=batch*5,deadline=25021,sleeping=sleeping)]*2
for x in runs+polls:
 decision=decisions[x['decisionId']-1];assert decision['suspended'] is False and x['path']==decision['path'] and x['batch']==decision['batch']==5005
 if x['event']=='host-check-input':assert x['scope']=='admitted-main-run' and x['workerTid'] is None
assert [x['decisionId'] for x in runs]==[21,22,23,24]
# Dequeues occur inside decision21's admitted ordinary run, after its matching poll,
# before the next decision. Retain line-order proof, without inventing enqueue IDs.
start=next(i for i,x in enumerate(lines) if x.startswith('[main-scheduler] ') and '"event":"main-run","decisionId":21,' in x)
end=next(i for i,x in enumerate(lines) if x.startswith('[main-scheduler] ') and '"event":"decision","id":22,' in x)
span=lines[start:end];dequeues=[x for x in span if x.startswith('[input-dequeue] ')];routes=[x for x in span if x.startswith('[input-dequeue-route] ')];dispatches=[x for x in span if x.startswith('[dispatch-input] ')]
assert len(dequeues)==3 and len(routes)==3 and len(dispatches)==2
for i,(msg,wp) in enumerate(((15,0),(256,32),(257,32)),1):
 x=dequeues[i-1];assert f'dequeueId={i} ' in x and f'msg=0x{msg:x} ' in x and f'wParam=0x{wp:x} ' in x and 'batch=5005 ' in x
 at=span.index(x);assert span[at-1].startswith('[main-scheduler] ') and json.loads(span[at-1][17:])['decisionId']==21
 assert f'dequeueId={i} ' in routes[i-1] and 'focusHwnd=0x10001 hwnd=0x10001 ' in routes[i-1]
for x,msg in zip(dispatches,(256,257)):assert f'msg=0x{msg:x} wParam=0x20 ' in x and 'batch=5005 ' in x
before=read(D/'input-state-after-airstrike-3.json')['value'];last=read(D/'input-state-deadline5006.json')['value']
assert before['batch']==5003 and before['credits']==0 and before['counters']['dequeued']==0
assert [(x['msg'],x['wParam']) for x in before['queues']['renderer']['head']]==[(15,0),(256,32),(257,32)]
assert last['batch']==5006 and last['frozen'] is True and last['credits']==0
assert last['counters']==dict(scheduled=3,enqueued=0,dequeued=3,routed=3,dispatched=2) and last['queues']['renderer']['count']==0
assert last['sdlConsumption']=='unknown' and last['threads']['main']['sleepUntil']==0
step=read(D/'deadline-step3.json');after=read(D/'deadline-after.json');assert step['id']=='corrected-bridge-30' and step['value']==dict(batch=5006,ran=3,steps=3,frozen=True)
assert after['id']=='corrected-bridge-31' and after['value']['batch']==5006 and after['value']['frozen']['credits']==0
assert '[input] keydown vk=32 at batch 5001' in lines and '[input] keyup vk=32 at batch 5002' in lines
events=read(E/'events.json');commands=[x['command'] for x in events if x['kind']=='dispatch'];acks=[json.loads(x[6:]) for x in lines if x.startswith('[ctl] ')]
assert [x['id'] for x in commands]==[x['id'] for x in acks] and len({x['id'] for x in commands})==len(commands) and all(x['ok'] is True for x in acks)
assert len([x for x in commands if x.get('action')=='step' and x.get('n')==5000])==1
assert [x for x in commands if x.get('action')=='step'][-1]==dict(id='corrected-bridge-30',action='step',n=3)
completions=[x for x in events if x['kind']=='frozen-input-complete'];assert len(completions)==3
for x,batch,ident in zip(completions,(5000,5001,5002),('airstrike-1','airstrike-2','airstrike-3')):
 assert x['inputId']==ident and x['inputAck']['id']==ident and x['inputAck']['value']['batch']==batch
 assert x['step']['value']['ran']==x['step']['value']['steps']==1 and x['snapshot']['value']['batch']==batch+1 and x['snapshot']['value']['frozen']['credits']==0
frames=[]
for x in read(D/'remote-inventory.json'):
 if not x['path'].endswith('.png'):continue
 p=D/x['path'];b=p.read_bytes();assert sha(p)==x['sha256'] and b[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',b[16:24])==(800,600) and len(b)<=2097152
 frames.append(dict(path='retained/'+x['path'],sha256=sha(p),bytes=len(b),dimensions=[800,600],review='full800x600 inspected; fresh frame byte-identical to reviewed counterpart',content='Console obscures startup' if x['sha256'].startswith('a0d213') else 'Airstrike frontmost; Press any key to start; gameplay unproven'))
assert len(frames)==5 and sum(x['bytes'] for x in frames)<=16777216
sup=read(D/'guest-supervision.json');assert sup['exit']==0 and sup['stopReason'] is None and sup['cleanupComplete'];assert sup['cpuSeconds']<33.635447 and sup['wallSeconds']<43.168643807
allowance=dict(originalCPU=90,originalWall=120,priorCPU=56.364553,priorWall=76.831356193,authorizedRemainingCPU=33.635447,authorizedRemainingWall=43.168643807,newCPU=sup['cpuSeconds'],newWall=sup['wallSeconds'],cumulativeCPU=56.364553+sup['cpuSeconds'],cumulativeWall=76.831356193+sup['wallSeconds'],remainingCPU=33.635447-sup['cpuSeconds'],remainingWall=43.168643807-sup['wallSeconds'],charge='trusted supervisor conservative own+waited high-water may double-charge; not exact physical CPU',newGuestInvocations=1,noReplay=True,invocationConsumed=True)
save(H/'cumulative-allowance.json',allowance)
findings=dict(status='POST_DEADLINE_ADMITTED_MAIN_RUN_AND_SPACE_DEQUEUE_OBSERVED',schedulerRecords=rows,matchedRequests=len(commands),allACKsMatched=True,serialFrozenInputs=completions,deadlineStep=step,deadlineSnapshot=after,matchedExecution=dict(decisionId=21,path='ordinary',batch=5005,now=25025,deadline=25021,reason='runnable',mainRun=True,hostInputPolls=6,lineStart=start+1,lineEnd=end,orderedEvidence=span,enqueueIdentity='unavailable; no invented identity'),dequeueCount=3,routeCount=3,dispatchCount=2,observerSuppressed=False,finalState=last,causalConclusion='At5004 now25020<25021 so all main admissions sleep. At5005 now25025>=25021 actual decision21 becomes runnable and admits main execution. Matching main polls dequeue WM_PAINT and Space down/up, route both keys to0x10001 and DispatchMessageA both at5005. Frozen5006 has empty renderer FIFO, zero credits, sleepUntil0. Scheduler admission and host dequeue are demonstrated.',remainingBranch='SDL event translation and application startup handling after DispatchMessageA are unobserved. Snapshot explicitly reports sdlConsumption=unknown; the inspected full frozen5006 frame remains Press any key to start. No source defect or gameplay conclusion is established, and no further execution is authorized.',correlationLimits='Observer invocation IDs match decision/main-run/host-input. FIFO dequeue IDs1-3 and log order bind host polls and routes; enqueueId and DispatchMessageA correlation are explicitly unavailable.',frames=frames,allowance=allowance,boatHandback=read(H/'boat-handback.json'))
save(H/'findings.json',findings);save(P/'findings.json',findings)
inc=[dict(incident='local mock preflight had a Python quote SyntaxError',action='retained failed stdout/stderr; corrected only owned preflight; actual modified observation then passed before guest'),dict(incident='initial read-only policy/donor/rg display exceeded8192B target',action='retained tool output; later bounded. API envelope guard unchanged; total terminal under1MiB'),dict(incident='claim board line manually timestamped16:47 before actual clock16:44',action='this receipt records actual initial task time and timestamped API evidence; board correction appended at closeout')]
save(H/'operational-incidents.json',inc)
save(H/'recovery-links.json',dict(reuse=read(H/'reuse.json'),runtimeMap='runtime-map.json',prelaunch='compact-prelaunch.json',localChangedStopPreflight='local-preflight.json',priorCanonical='/tmp/airstrike-integrated-scheduler-trace-oct27/ops/receipt-manifest.json',recovery='Exact332file pins/canonical module retained; no rebuild. Single invocation consumed; no replay or budget reset. Coordinator owns bx_ms3j5waq shutdown17:07Z, expiry17:10:43.934Z.'))
(P/'README.md').write_text('''# Airstrike ordinary post-deadline input consumption

Actual scheduler decision21 at batch5005 records now25025>=sleep deadline25021, suspended=false, reason=runnable. Its matching ordinary main-run and six admitted-main-run host polls contain renderer dequeues1-3: WM_PAINT, Space down and Space up. Both keys route to Airstrike0x10001 and reach DispatchMessageA at5005. The final frozen5006 snapshot has zero credits, empty renderer FIFO and counters dequeued3/routed3/dispatched2. At5004, now25020<25021 still suspended all four ordinary/cooperative admissions. The observer produced24 decisions,4 main runs and9 host polls, with no suppression.

The controller confirmed Space release frozen5003, issued one serial step n=3, matched ran3/steps3/batch5006, then matched a frozen-zero snapshot and stopped. No forced wake, clock mutation, scheduler repair or additional controls. All38 control requests and responses match. Invocation IDs link scheduler decisions, admitted execution and host polls; dequeue IDs and ordering link poll/dequeue/route. Historical enqueue identities and DispatchMessageA correlation are explicitly unavailable.

The full800x600 post-deadline frame still shows Press any key to start. SDL event translation and application handling after DispatchMessageA remain unobserved; sdlConsumption is explicitly unknown. This diagnostic establishes scheduler admission and host FIFO consumption, not gameplay or a source defect.

Exact main be0eb25fc33f3b057847d6c4e2c4fe5a6a9a426c, runner a8187d18/thread manager f4ba190b/observer93775a00, unchanged helper c8c85b12 and canonical module bf707aa4(compiled1e4fdb06). All332 staged pins/18913957B, canonical89-file mount, helper frozenState contract and exact Nodev24.22.1 heap512/environment/inherited limits passed. Independent12groups/4controls and merged-tree checks reused unchanged. No build, source repair, main integration or public deployment.

One guest only; conservative new CPU23.451084s/wall23.374853223s fits authorized33.635447/43.168643807. Cumulative CPU79.815637s/wall100.206209416s fits original90/120; unused time grants no replay. Five captures fit the eight-capture cap. Distinct setup/guest/runner stdout and stderr, exact argv/start/terminal states, control IDs, scheduler operands, FIFO snapshots and reviewed frames are retained in the NEW evidence archive. Prior verified payloads are referenced, not recopied or rehashed.

Boat bx_ms3j5waq remains RUNNING with all exact guest descendant identities absent. Coordinator owns shutdown17:07Z and expiry17:10:43.934Z. Evidence branch task/airstrike-post-deadline-consumption-oct27; final ops/receipt-manifest.json binds exact remote commit/ref verification, package integrity, limits and cleanup.
''')
# Ensure prose count is derived from actual events.
p=P/'README.md';p.write_text(p.read_text().replace('All38 control',f'All{len(commands)} control'))
files=sorted(p for p in H.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='receipt-manifest.json')
index=[dict(path=str(p.relative_to(H)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
save(P/'evidence-index.json',dict(payloads=index,scope='NEW task-owned evidence only; historic manifests referenced',count=len(index)))
with tarfile.open(P/'evidence.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(H)),recursive=False)
assert (P/'evidence.tar.gz').stat().st_size<24*1024**2
save(H/'publication-payload.json',dict(report=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(P.iterdir())],portablePayloads=len(index),archiveBytes=(P/'evidence.tar.gz').stat().st_size,archiveSHA256=sha(P/'evidence.tar.gz'),finding=findings['status']))
print(json.dumps(dict(status=findings['status'],decisions=len(decisions),mainRuns=len(runs),polls=len(polls),requests=len(commands),frames=len(frames),payloads=len(index),archiveBytes=(P/'evidence.tar.gz').stat().st_size,allowance=allowance)))
