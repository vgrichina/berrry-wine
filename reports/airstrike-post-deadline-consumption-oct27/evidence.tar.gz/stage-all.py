import task,time,json
start=time.monotonic()
for n in range(0,332,40):
 assert time.monotonic()-start<600 and time.time()<1793120580
 print(n,flush=True);task.main_args=None
 import sys;sys.argv=['task.py','stage',str(n)];task.main()
