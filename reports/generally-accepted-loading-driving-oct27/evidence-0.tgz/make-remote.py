import pathlib,json,hashlib
O=pathlib.Path(__file__).parent;OLD='/tmp/generally-census-cleared-driving-oct27';NEW=str(O.parent)
source=pathlib.Path(OLD+'/ops/remote-v7.py').read_text()
source=source.replace(OLD,NEW).replace('1793106480','1793117640').replace('guest cutoff13:08UTC','guest cutoff16:14UTC')
# No compile mode will be invoked. Keep original source as provenance, remove
# unauthorized branches from the actual execution wrapper.
a=source.index("if mode=='prebuild':");b=source.index("elif mode=='preguest':",a)
source=source[:a]+"if mode=='preguest':"+source[b+len("elif mode=='preguest':"):]
source=source.replace("save('guest-attempt.json',dict(at=time.time(),argv=argv))","save('guest-attempt.json',dict(at=time.time(),argv=argv,environmentSHA256=hashlib.sha256(json.dumps(sorted(ENV.items())).encode()).hexdigest()))")
(O/'remote.py').write_text(source)
startup=pathlib.Path(OLD+'/ops/remote-startup-v5.cjs').read_text().replace(OLD,NEW)
# Use current runner canonical parser and enumerate all filenames, not only count.
startup=startup.replace("const files=require(root+'/lib/vfs-host-files').expandIncludePatterns(game,['**/*']);","const files=require(root+'/lib/vfs-host-files').expandIncludePatterns(game,['**/*']);fs.writeFileSync(R+'/ops/mount-files.json',JSON.stringify(files));")
startup += "\nconst abi=require(root+'/tools/wasm-abi-diff').decodeWasm(fs.readFileSync(root+'/build/wine-assembly.wasm'));fs.writeFileSync(R+'/ops/module-abi.json',JSON.stringify({imports:abi.imports,types:abi.types}));const signatures=JSON.parse(fs.readFileSync(root+'/lib/host-import-sigs.generated.json')).sigs;for(const entry of abi.imports){if(entry.module==='host'&&entry.kind==='func'){assert.deepStrictEqual(abi.types[entry.typeIndex],signatures[entry.name],entry.name);}}console.log('module ABI/import signature equality PASS');\n"
(O/'startup.cjs').write_text(startup)
# The exact launch argv is shared between startup and guest.
namespace={};a=source.index('argv=');b=source.index('\nos.environ.clear()',a)
prefix="import pathlib\nR=pathlib.Path("+repr(NEW)+");N='/home/user/.nvm/versions/node/v24.22.1/bin/node'\n"
exec(prefix+source[a:b],namespace)
plan=dict(argv=namespace['argv'],source='3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3')
(O/'plan.json').write_text(json.dumps(plan))
rows=json.loads((O/'stage-manifest.json').read_text())
for f,t in [('remote.py','ops/remote.py'),('startup.cjs','ops/remote-startup-v5.cjs'),('plan.json','ops/plan.json'),('stage-manifest.json','ops/stage-manifest.json'),('controller.py','ops/controller.py')]:
 p=O/f;b=p.read_bytes();rows.append(dict(source=str(p),target=t,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(O/'helper-manifest.json').write_text(json.dumps(rows[-5:],indent=2))
print('Prepared exact remote runtime/startup helpers; no build modes')
