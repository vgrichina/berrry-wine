import os,pathlib,subprocess,json,fcntl
O=pathlib.Path(__file__).parent;R=O.parent/'repo';D='/tmp/generally-current-boundary-accept-integrate-oct27/repo';PIN='3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3'
def git(label,args):
 with (O/('git-fixed-'+label+'.stdout')).open('xb') as out,(O/('git-fixed-'+label+'.stderr')).open('xb') as err:
  p=subprocess.run(['/usr/bin/prlimit','--data=536870912:536870912','--','git','-c','gc.auto=0','-c','pack.threads=1',*args],stdout=out,stderr=err)
 assert p.returncode==0,(label,p.returncode)
with open('/tmp/wine-ops-production-git.lock','a') as lk:
 fcntl.flock(lk,fcntl.LOCK_EX)
 git('init',['init',str(R)]);(R/'.git/objects/info/alternates').write_text(D+'/.git/objects\n')
 git('sparse',['-C',str(R),'config','core.sparseCheckout','true']);(R/'.git/info/sparse-checkout').write_text('/reports/'+O.parent.name+'/\n')
 git('checkout',['-C',str(R),'checkout','-b','task/'+O.parent.name,PIN])
 git('remote',['-C',str(R),'remote','add','origin','git@github.com:vgrichina/wine-assembly.git'])
 git('name',['-C',str(R),'config','user.name','Wine Ops Worker']);git('email',['-C',str(R),'config','user.email','wine-ops@local'])
print('PASS sparse report repository')
