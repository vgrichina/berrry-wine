import json,pathlib,hashlib,shutil,time
O=pathlib.Path(__file__).parent
ready=json.loads(pathlib.Path('/tmp/completions-1526-readiness-oct27/ops/gene-ready.json').read_text());rows=json.loads(pathlib.Path(ready['stageManifest']).read_text());D=O/'current'
def row(p,t):
 b=p.read_bytes();return dict(source=str(p),target=t,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
changes={x['path'] for x in ready['changedSource']}
for i,x in enumerate(rows):
 path=x['target'].removeprefix('runner/')
 if path in changes:rows[i]=row(D/path,x['target'])
targets={x['target'] for x in rows}
for x in ready['acceptedPins']:
 p=D/x['path'];assert p.is_file(),p
 b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'],str(p)
 target='runner/'+x['path']
 if target not in targets:rows.append(row(p,target));targets.add(target)
for x in ready['modules']:
 target='runner/build/'+pathlib.Path(x['path']).name
 rows=[r for r in rows if r['target']!=target];rows.append(dict(source=x['path'],target=target,bytes=x['bytes'],sha256=x['sha256']))
sup=pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo/test/helpers/palette-browser-supervisor.py');rows.append(row(sup,'ops/supervisor-original.py'))
(O/'stage-manifest.json').write_text(json.dumps(rows,indent=2))
plan=dict(at=time.time(),source=ready['currentMain'],files=len(rows),stageBytes=sum(x['bytes'] for x in rows),local=dict(allocation=512*1048576,reserve=32*1048576,staging=4*1048576,captures=16*1048576,wire=8*1048576,gitReportPublication=32*1048576,sessionEventsGrowth=256*1048576),remote=dict(allocation=1024*1048576,reserve=64*1048576,staging=sum(x['bytes'] for x in rows),tempArchives=32*1048576,modulesAlreadyIncluded=True,captures=16*1048576,logs=8*1048576,publication=24*1048576,growth=128*1048576),captures=dict(fullCount=4,width=800,height=600,perImage=4*1048576,purpose=['intro or menu','race before driving','race after released Up','Quit or contingency'],wire=8*1048576,terminalReserve=1048576,chunkRaw=4096,maxEnvelope=8192),runtime=dict(cpu=180,wall=240,rss=4*1024**3,heap=2048*1048576,attempts=1,file=24*1048576,output=2*1048576),mount='--vfs-tree='+str(O.parent/'runner/test/binaries/candidates/generally'),reuse='/tmp/completions-1526-readiness-oct27/ops/verification.json',incidents=['Initial read-only instruction inspection exceeded8192B display/operation; limitation retained.','Initial nested flock interrupted before checkout; erroneous Git DATA applied to Python wrapper, corrected to Git subprocess only.','First corrected init exclusive diagnostic-file collision; no guest or network attempt.'])
assert sum(v for k,v in plan['remote'].items() if k not in ('allocation','modulesAlreadyIncluded'))<1024*1048576
(O/'readiness.json').write_text(json.dumps(plan,indent=2));print(json.dumps(dict(files=len(rows),bytes=plan['stageBytes'])))
