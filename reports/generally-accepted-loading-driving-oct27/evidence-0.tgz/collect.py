from api import *
import base64
code='''import pathlib,tarfile,json,hashlib
R=pathlib.Path(HERE);O=R/'ops';p=R/'remote-evidence.tgz'
with tarfile.open(p,'w:gz') as t:
 for f in sorted(O.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(R)),recursive=False)
size=p.stat().st_size;assert size<=24*1048576
print(json.dumps(dict(bytes=size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),path=str(p))))
'''.replace('HERE',repr(REMOTE))
meta=json.loads(py('collect-create',code,terminal=True)['stdout']);(O/'remote-evidence-meta.json').write_text(json.dumps(meta))
used=sum(p.stat().st_size for p in (O/'responses').iterdir() if p.suffix in ('.stdout','.stderr'));envelopes=((meta['bytes']+4095)//4096)*6400
assert used+envelopes<=8388608
h=hashlib.sha256();n=0
with (O/'remote-evidence.tgz').open('xb') as f:
 for off in range(0,meta['bytes'],4096):
  r=py('collect-'+str(off),'import pathlib,base64;f=pathlib.Path('+repr(meta['path'])+').open("rb");f.seek('+str(off)+');print(base64.b64encode(f.read(4096)).decode())',terminal=True)
  b=base64.b64decode(r['stdout'].strip(),validate=True);f.write(b);h.update(b);n+=len(b)
assert n==meta['bytes'] and h.hexdigest()==meta['sha256']
print(json.dumps(dict(collected=n,sha256=h.hexdigest(),wireBefore=used,envelopes=envelopes)))
