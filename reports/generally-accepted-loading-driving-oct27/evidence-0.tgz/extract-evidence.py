import pathlib,tarfile,json,hashlib
O=pathlib.Path(__file__).parent;P=O/'remote-evidence.tgz';D=O/'remote-evidence';D.mkdir(exist_ok=False)
with tarfile.open(P) as t:t.extractall(D,filter='data')
S=D/'ops';result={}
for name in ['guest-supervision.json','terminal.json','launch.json','guest-attempt.json','startup-preguest-v5-supervision.json']:
 p=S/name
 if p.exists():result[name]=json.loads(p.read_text())
(O/'execution-summary.json').write_text(json.dumps(result,indent=2))
for name in ['launch.stdout','launch.stderr','guest.stderr','run-wrapper.stderr']:
 p=S/name
 if p.exists():
  lines=p.read_text(errors='replace').splitlines();selected=[s for s in lines if 'input]' in s or 'input-dispatch]' in s or 'Error' in s or 'keydown' in s or 'keyup' in s or 'ExitProcess' in s or 'WM_QUIT' in s]
  (O/(name+'.selected')).write_text('\n'.join(selected)+'\n')
print(json.dumps({k:v for k,v in result.get('guest-supervision.json',{}).items() if k in ('exit','stopReason','cpuSeconds','wallSeconds','peakRSS','cleanupComplete')}))
