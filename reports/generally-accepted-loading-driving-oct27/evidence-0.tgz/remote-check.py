from api import *
code='''import pathlib,json,hashlib,os,resource,shutil
R=pathlib.Path(REMOTE);O=R/'ops';O.mkdir(parents=True,exist_ok=True)
with (O/'bootstrap-append.log').open('a') as f:f.write('bootstrap append verified\\n')
rows=json.loads((O/'stage-manifest.json').read_text())
for x in rows:
 p=R/x['target'];assert p.is_file() and p.stat().st_size==x['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],x['target']
used=sum(p.stat().st_blocks*512 for p in R.rglob('*') if p.is_file());assert used+64*1048576+16*1048576+160*1048576<=1073741824
print(json.dumps(dict(files=len(rows),bytes=sum(x['bytes'] for x in rows),allocated=used,cwd=os.getcwd(),limits={str(k):resource.getrlimit(k) for k in (0,1,2,9)},disk=shutil.disk_usage(R).free,passGate=True)))
'''.replace('REMOTE',repr(REMOTE))
r=py('staged-check',code);(O/'staged-check.json').write_text(json.dumps(r));print(r['stdout'])
