import importlib.util,pathlib,sys,time,json,fcntl,hashlib
O=pathlib.Path(__file__).parent;R=O.parent
p=R/'runner/tools/generally-loading-controller.py';assert hashlib.sha256(p.read_bytes()).hexdigest()=='2da5e423b9c18b90463a2bf4f3dce8e35780e5d6452b43a5771d575c5dbf95c5'
s=importlib.util.spec_from_file_location('accepted',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
label,mode,*args=sys.argv[1:];lock=(O/'cursor.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
channel=m.Mailbox(O);c=None
try:
 remaining=1793117640-time.time();start=json.loads((O/'guest-attempt.json').read_text())['at'];remaining=min(remaining,235-(time.time()-start))
 c=m.LoadingController(channel,O/'cursor',deadline=time.monotonic()+remaining)
 if mode=='step':
  result=c.run(int(args[0]),chunk=1000)
 else:
  batch=c.frozen()
  if mode=='frame':
   count=len(list(O.glob('acceptance-*.png')));assert count<4
   result=c.request(dict(action='png',path=str(O/('acceptance-'+label+'.png'))));assert result['bytes']<=4194304
  elif mode=='cmd':result=c.request(dict(cmd=args[0]))
  elif mode=='quit':result=c.request(dict(action='quit'))
  else:raise RuntimeError('unsupported operation')
 if mode!='quit':channel.finish(c.cursor)
 m.atomic(O/(label+'.controller.json'),dict(ok=True,result=result,events=c.events))
 print(json.dumps(dict(ok=True,label=label,mode=mode,result=({k:v for k,v in result.items() if k!='events'} if isinstance(result,dict) else result))))
except Exception as e:
 channel.poison();m.atomic(O/(label+'.controller.json'),dict(ok=False,error=repr(e),events=c.events if c else []));raise
finally:channel.close();lock.close()
