#!/bin/bash
set -e
for start in $(seq 10 10 90); do
 python3 /home/user/wine-assembly/scratch/usage-watch/light-execution-pool-oct26.py --slots 1 -- python3 /tmp/generally-accepted-loading-driving-oct27/ops/run.py stage-$start python /tmp/generally-accepted-loading-driving-oct27/ops python3 -B /tmp/generally-accepted-loading-driving-oct27/ops/stage.py "$start" "$((start+10))"
done
