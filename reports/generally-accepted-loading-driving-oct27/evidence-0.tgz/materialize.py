import pathlib,json,subprocess,fcntl
O=pathlib.Path(__file__).parent;J=json.loads(pathlib.Path('/tmp/completions-1526-readiness-oct27/ops/gene-ready.json').read_text());D=J['currentDonor'];P=J['currentMain']
with open('/tmp/wine-ops-production-git.lock','a') as lk:
 fcntl.flock(lk,fcntl.LOCK_EX)
 for i,x in enumerate(J['changedSource']+J['acceptedPins']):
  target=O/'current'/x['path'];target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():continue
  with target.open('xb') as out,(O/('materialize-'+str(i)+'.stderr')).open('xb') as err:
   p=subprocess.run(['prlimit','--data=536870912:536870912','--','git','-C',D,'show',P+':'+x['path']],stdout=out,stderr=err)
  assert p.returncode==0,x
print('PASS exact immutable current sources materialized')
