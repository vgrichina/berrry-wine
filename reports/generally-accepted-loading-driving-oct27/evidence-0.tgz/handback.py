from api import *
code='''import pathlib,json,os
O=pathlib.Path(HERE);launch=json.loads((O/'launch.json').read_text());pids=[launch['pid']];receipt=json.loads((O/'guest-supervision.json').read_text());pids.extend(int(x[0]) for x in receipt['owned']);survivors=[]
for pid in set(pids):
 p=pathlib.Path('/proc')/str(pid)
 if p.exists():survivors.append(dict(pid=pid,stat=(p/'stat').read_text(),cmdline=(p/'cmdline').read_bytes().replace(bytes([0]),b' ').decode(errors='replace')))
out=dict(box='bx_eggqardq',supportedExecAlive=True,guestSupervision=receipt,ownedSurvivors=survivors,terminalPresent=(O/'terminal.json').exists(),boxLeftRunning=True,shutdownOwner='coordinator',shutdown='2026-10-27T16:20:00Z',expiry='2026-10-27T16:31:01.612Z');assert not survivors;print(json.dumps(out))
'''.replace('HERE',repr(REMOTE+'/ops'))
r=py('handback',code,terminal=True);(O/'handback.json').write_text(json.dumps(json.loads(r['stdout']),indent=2));print('PASS assigned Boat API alive; zero owned guest survivors; box left running for coordinator')
