from api import *
import base64
prefix=sys.argv[1] if len(sys.argv)>1 else 'helper'
for i,x in enumerate(json.loads((O/'helper-manifest.json').read_text())):
 b=pathlib.Path(x['source']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256']
 target=REMOTE+'/'+x['target']
 for off in range(0,len(b),24000):
  py(prefix+'-'+str(i)+'-'+str(off),'import pathlib,base64;p=pathlib.Path('+repr(target)+');p.parent.mkdir(parents=True,exist_ok=True);f=p.open('+repr('wb' if off==0 else 'ab')+');f.write(base64.b64decode('+repr(base64.b64encode(b[off:off+24000]).decode())+'));f.close();print("stored")')
print('Helpers transferred')
