from api import *
rows=json.loads((O/'helper-manifest.json').read_text())
code='import pathlib,hashlib,json;R=pathlib.Path('+repr(REMOTE)+');rows='+repr(rows)+';result=[dict(path=x["target"],match=hashlib.sha256((R/x["target"]).read_bytes()).hexdigest()==x["sha256"]) for x in rows];assert all(x["match"] for x in result);print(json.dumps(result))'
r=py('overlay-check',code);(O/'overlay-check.json').write_text(json.dumps(r));print(r['stdout'])
