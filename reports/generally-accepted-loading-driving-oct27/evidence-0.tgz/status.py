from api import *
label=sys.argv[1]
code='''import pathlib,json
O=pathlib.Path(HERE);out={}
for name in ['startup-preguest-v5-supervision.json','startup-preguest-v5.stderr','preguest-wrapper.stderr','guest-supervision.json','terminal.json','launch.json','guest-attempt.json']:
 p=O/name
 if p.exists():out[name]=p.read_text()[:4000]
print(json.dumps(out))
'''.replace('HERE',repr(REMOTE+'/ops'))
r=py('status-'+label,code,terminal=True);(O/(label+'-status.json')).write_text(json.dumps(r));print(r['stdout'][:7000])
