from api import *
import io,tarfile,base64
rows=json.loads((O/'stage-manifest.json').read_text())
start,end=map(int,sys.argv[1:])
deadline=time.monotonic()+85
for group in range(start,end):
 if time.monotonic()>deadline:break
 batch=rows[group*40:(group+1)*40]
 if not batch:break
 buf=io.BytesIO()
 with tarfile.open(fileobj=buf,mode='w:gz') as t:
  for x in batch:
   b=pathlib.Path(x['source']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'],x['target']
   info=tarfile.TarInfo(x['target']);info.size=len(b);t.addfile(info,io.BytesIO(b))
 b=buf.getvalue();target=REMOTE+'/stage-'+str(group)+'.tgz'
 for off in range(0,len(b),24000):
  py('stage-'+str(group)+'-'+str(off),'import pathlib,base64;p=pathlib.Path('+repr(target)+');p.parent.mkdir(parents=True,exist_ok=True);f=p.open('+repr('wb' if off==0 else 'ab')+');f.write(base64.b64decode('+repr(base64.b64encode(b[off:off+24000]).decode())+'));f.close();print("stored")')
 py('extract-'+str(group),'import pathlib,tarfile,hashlib;p=pathlib.Path('+repr(target)+');assert hashlib.sha256(p.read_bytes()).hexdigest()=='+repr(hashlib.sha256(b).hexdigest())+';t=tarfile.open(p);t.extractall('+repr(REMOTE)+',filter="data");t.close();p.unlink();print("extracted")')
 (O/('stage-group-'+str(group)+'.json')).write_text(json.dumps(dict(files=len(batch),compressed=len(b))))
 print('staged',group,len(batch),len(b),flush=True)
