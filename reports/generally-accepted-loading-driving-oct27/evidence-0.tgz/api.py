import pathlib,subprocess,time,json,sys,hashlib,shlex
O=pathlib.Path(__file__).parent;REMOTE='/tmp/generally-accepted-loading-driving-oct27';BOX='bx_eggqardq';M=1048576
def api(label,command,detach=False,timeout=30,terminal=False):
 assert len(command.encode())<=36000
 d=O/'responses';d.mkdir(exist_ok=True);c=O/'commands';c.mkdir(exist_ok=True)
 used=sum(p.stat().st_size for p in d.iterdir() if p.suffix in ('.stdout','.stderr'))
 assert used+8192+(0 if terminal else M)<=8*M
 pfx=d/label;assert not pfx.with_suffix('.stdout').exists()
 argv=['/home/user/.ascii/boat','exec','--no-update','--json']+(['--detach'] if detach else ['--timeout',str(timeout)])+[BOX,'--','bash','-lc',command]
 (c/(label+'.json')).write_text(json.dumps(dict(argv=argv,commandSHA256=hashlib.sha256(command.encode()).hexdigest(),at=time.time())))
 start=time.monotonic()
 with (d/(label+'.stdout')).open('xb') as out,(d/(label+'.stderr')).open('xb') as err:
  p=subprocess.Popen(argv,stdout=out,stderr=err)
  (d/(label+'.start.json')).write_text(json.dumps(dict(pid=p.pid,pending=True)))
  try:r=p.wait(timeout=timeout+15)
  except subprocess.TimeoutExpired:
   p.terminate();p.wait();(d/(label+'.uncertain.json')).write_text('{}');raise
 raw=(d/(label+'.stdout')).read_bytes();e=(d/(label+'.stderr')).read_bytes()
 (d/(label+'.terminal.json')).write_text(json.dumps(dict(exit=r,seconds=time.monotonic()-start,bytes=len(raw)+len(e))))
 assert r==0 and len(raw)+len(e)<=8192,(label,r,e[:1000])
 j=json.loads(raw);assert (detach or j.get('exitCode')==0) and not j.get('stdoutTruncated') and not j.get('stderrTruncated'),(label,j)
 return j
def py(label,code,**kw):return api(label,'python3 -B -c '+shlex.quote(code),**kw)
if __name__=='__main__':print(json.dumps(py('probe','import os,pathlib,resource,json,shutil;print(json.dumps(dict(cwd=os.getcwd(),nodePaths=[str(p) for p in pathlib.Path("/home/user/.nvm/versions/node").glob("*/bin/node")],limits={str(k):resource.getrlimit(k) for k in (0,1,2,9)},free=shutil.disk_usage("/tmp").free,memAvailable=pathlib.Path("/proc/meminfo").read_text().split("MemAvailable:")[1].split()[0])))')))
