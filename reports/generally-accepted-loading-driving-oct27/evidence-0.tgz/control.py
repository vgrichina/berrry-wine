from api import *
import base64
label,mode,*args=sys.argv[1:]
cmd=shlex.join(['python3','-B',REMOTE+'/ops/controller.py',label,mode,*args])
r=api('ctl-'+label,cmd,timeout=42);(O/(label+'.result.json')).write_text(json.dumps(r));print(r['stdout'])
if mode=='frame':
 path=REMOTE+'/ops/acceptance-'+label+'.png'
 meta=json.loads(py('meta-'+label,'import pathlib,hashlib,json;p=pathlib.Path('+repr(path)+');print(json.dumps(dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())))')['stdout'])
 used=sum(p.stat().st_size for p in (O/'responses').iterdir() if p.suffix in ('.stdout','.stderr'))
 envelopes=((meta['bytes']+4095)//4096)*6400
 assert used+envelopes+1048576<=8388608
 (O/(label+'.transfer.json')).write_text(json.dumps(dict(meta=meta,used=used,envelopes=envelopes,terminalReserve=1048576)))
 h=hashlib.sha256();size=0;started=time.monotonic()
 with (O/('acceptance-'+label+'.png')).open('xb') as f:
  for off in range(0,meta['bytes'],4096):
   response=py('frame-'+label+'-'+str(off),'import pathlib,base64;f=pathlib.Path('+repr(path)+').open("rb");f.seek('+str(off)+');print(base64.b64encode(f.read(4096)).decode())')
   b=base64.b64decode(response['stdout'].strip(),validate=True);f.write(b);h.update(b);size+=len(b)
 assert size==meta['bytes'] and h.hexdigest()==meta['sha256']
 print(json.dumps(dict(frame=label,bytes=size,sha256=h.hexdigest(),transferSeconds=time.monotonic()-started)))
