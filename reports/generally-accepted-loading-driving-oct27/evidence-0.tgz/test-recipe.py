import pathlib,json,hashlib
O=pathlib.Path(__file__).parent
for p in O.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
remote=(O/'remote.py').read_text();assert "mode=='compile'" not in remote and "mode=='prebuild'" not in remote and "mode=='continue-build-two'" not in remote
assert '1793117640' in remote and "'--no-build'" in remote and "'--control-stdin'" in remote
assert "'--max-old-space-size=2048'" in remote and "'--tick-ms-per-batch=2'" in remote
assert "out=open(H/'launch.stdout','wb');err=open(H/'launch.stderr','wb')" in remote
assert 'lower_limit(resource.RLIMIT_CPU, 180)' in remote
controller=(O/'controller.py').read_text();assert "c.frozen()" in controller and 'LoadingController' in controller and 'channel.poison()' in controller
assert hashlib.sha256((O/'current/tools/generally-loading-controller.py').read_bytes()).hexdigest()=='2da5e423b9c18b90463a2bf4f3dce8e35780e5d6452b43a5771d575c5dbf95c5'
print('PASS Python syntax, no compile modes, pinned controller, exact serial/frozen launch, diagnostics and limits')
