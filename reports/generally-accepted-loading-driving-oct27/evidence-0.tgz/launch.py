from api import *
mode=sys.argv[1]
assert mode in ('preguest','run')
if mode=='run':assert time.time()+240<1793117640
label=sys.argv[2] if len(sys.argv)>2 else mode
command=shlex.join(['python3','-B',REMOTE+'/ops/remote.py',mode])+' >'+shlex.quote(REMOTE+'/ops/'+label+'-wrapper.stdout')+' 2>'+shlex.quote(REMOTE+'/ops/'+label+'-wrapper.stderr')
r=api('launch-'+label,command,detach=(mode=='run'))
(O/(mode+'-launch.json')).write_text(json.dumps(r));print(json.dumps(r))
