import pathlib,json,time,zlib,struct
O=pathlib.Path(__file__).parent;rows=json.loads((O/'stage-manifest.json').read_text());groups=[]
for n in range((len(rows)+39)//40):
 batch=rows[n*40:n*40+40];groups.append(dict(group=n,files=len(batch),raw=sum(x['bytes'] for x in batch)))
captures=[]
for p in pathlib.Path('/tmp/generally-census-cleared-driving-oct27/ops').glob('*.png'):
 captures.append(dict(path=str(p),bytes=p.stat().st_size))
receipts=list((O/'responses').glob('*.terminal.json'));a=[json.loads(p.read_text()) for p in receipts]
result=dict(at=time.time(),groups=groups,sourceGroupMaxRaw=max(x['raw'] for x in groups),commandMaxBytes=36000,tarFilesMax=40,chunkRaw=24000,localBufferMax=32*1048576,requestsCompleted=len(a),measuredSeconds=sum(x['seconds'] for x in a),responseBytes=sum(x['bytes'] for x in a),priorProfileCaptures=captures,captureReservation=dict(remote=4*4194304,wire=8388608,terminal=1048576,perFrameEnvelopeAllowance=1572864,frameMetaMeasuredBeforeTransfer=True,largeImageStopsBeforeTransfer=True),timePlan=dict(guestWall=240,loading=145,frameReviewTransfer=55,inputAndCountdown=25,cleanup=15),guestCutoff='2026-10-27T16:14:00Z',handback='2026-10-27T16:17:00Z',shutdown='2026-10-27T16:20:00Z',expiry='2026-10-27T16:31:01.612Z',shutdownOwner='coordinator')
result['capturePurposes']=['current Main Menu before selecting driver/track','race intro overlay before ordinary Enter','after countdown before Up driving','after dispatched and released Up driving']
result['historicalGuideOnly']='/tmp/generally-census-cleared-driving-oct27/ops/intro.png reviewed as historical menu guide, never new acceptance'
(O/'transfer-plan.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ('groups','priorProfileCaptures')}))
