import pathlib,json,hashlib,tarfile,shutil,time,struct
O=pathlib.Path(__file__).parent;D=O.parent/'repo/reports'/O.parent.name;D.mkdir(parents=True,exist_ok=True);E=O/'remote-evidence/ops'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
supervision=json.loads((E/'guest-supervision.json').read_text());cursor=json.loads((E/'cursor').read_text());replies=sorted((E/'replies').glob('*.json'));last=json.loads(replies[-1].read_text());startup=(E/'startup-preguest-v5.stdout').read_text()
assert supervision['stopReason']=='aggregate CPU limit' and supervision['cleanupComplete']
assert cursor['pending'] and cursor['request']['id']==226
assert 'module ABI/import signature equality PASS' in startup
launch=(E/'launch.stdout').read_text();assert '[input] keydown vk=38' not in launch and '[input] keyup vk=38' not in launch
intro=json.loads((E/'intro.controller.json').read_text());assert intro['events']==[] and not intro['ok']
png=O/'acceptance-menu.png';assert struct.unpack('>II',png.read_bytes()[16:24])==(800,600)
handback=json.loads(json.loads((O/'responses/handback.stdout').read_text())['stdout']);assert not handback['ownedSurvivors']
(O/'handback-disposition.json').write_text(json.dumps(handback,indent=2))
responses=list((O/'responses').glob('*.stdout'))+list((O/'responses').glob('*.stderr'));wire=sum(p.stat().st_size for p in responses);assert wire<=8388608
result=dict(at=time.time(),outcome='BLOCKED_GUEST_CPU_GUARD_DURING_LOADING',source='3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3',runnerSHA256='1655b299c95be6b2cd2ca8c951b880b0b8fbed81a0cd785300d3bed5f24ae39c',controllerSHA256='2da5e423b9c18b90463a2bf4f3dce8e35780e5d6452b43a5771d575c5dbf95c5',compiledSource='1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba',moduleSHA256='bf707aa41e2883e1407c71810a15fd5f1816961938c1103c8d1d5bd40cb701d9',guest=supervision,lastACK=last,cursor=cursor,guestInvocations=1,captures=dict(actual=1,reserved=4,menu=dict(path='acceptance-menu.png',bytes=png.stat().st_size,sha256=sha(png),visuallyReviewed=True,dimensions=[800,600]),beforeDriving=None,afterDriving=None),wire=dict(actual=wire,ceiling=8388608,terminalReserve=1048576),gates=dict(sourceStage=True,actualFilenameParser=True,moduleABIImports=True,nodeStartup=True,currentMenuInspected=True,driverTrackStartDispatched=True,raceIntroReviewed=False,EnterAcknowledged=False,countdownQualified=False,UpDispatched=False,UpReleased=False,drivingQualified=False,ordinaryQuit=False,FPS=None),cleanup=handback,incidents=['Read-only initial instruction inspection exceeded8192B per operation; no gate raised.','Initial init wrapped Python in Git DATA and nested flock; interrupted cleanly before checkout; fixed Git DATA child-only in gitbatch.','Exclusive output/source collisions corrected with original diagnostics preserved.','Sparse report checkout preceded actual filename parser check; parser passed before Node guest, ordering limitation retained.','Initial remote preflight used overwritten predecessor wrapper and failed CWD; no Node/guest; final overlay hash-checked then startup passed.','Intro frame operation was submitted after loading command failure in a tool batch; accepted controller refused pending cursor with zero events, no frame or new guest request.'],cpuInterpretation='Configured180 CPU, final conservative charged297.470117 after cleanup; supervisor may double-charge own/waited CPU. Do not treat charged value as measured physical guest CPU.',startupInterpretation='Same Node executable/heap/environment/physical cap180CPU24MiBfile2MiBoutput; startup used stricter30s wall versus guest240s. Inherited DATA/AS unlimited.',publication=dict(branch='refs/heads/task/'+O.parent.name,mainOwnership=False,publicDeployment=False,exactVerification='external canonical receipt after publication'),remaining=['Fresh authorized runtime with a demonstrated CPU-budget readiness solution; no retry/reset authorized here.','Review actual race intro then ordinary Enter, countdown, before/after Up dispatch and release.','Ordinary Quit remains unqualified.'])
(O/'finding.json').write_text(json.dumps(result,indent=2));shutil.copyfile(O/'finding.json',D/'finding.json');shutil.copyfile(png,D/png.name)
readme='''# GeneRally current-production driving qualification

**Blocked during loading by the configured guest CPU guard. Driving is not qualified.**

One guest invocation used current main `3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3`, the independently accepted loading controller, and unchanged retained compiled modules. No rebuild, source repair, main change, public deployment, or second guest attempt occurred.

The complete staged closure, actual production tree-mount parser including comma-bearing filenames, compiled module import signatures, and Node startup passed. The newly captured 800×600 Main Menu was visually inspected. Ordinary driver, Agari track, and Start clicks were dispatched. Serial loading steps used exact completion ACKs followed by frozen-zero snapshots.

The physical supervisor stopped the guest during loading with `aggregate CPU limit`: configured180 CPU seconds; final conservative charged297.470117; wall184.234794s; peak RSS282480640B. The trusted accounting explicitly permits double-counting own/waited CPU, so the charge is not an assertion of actual physical guest CPU. Request226 (`step`,1000) remains pending. An accidentally submitted subsequent intro capture was refused locally by the accepted controller with zero events; no replay or additional guest request occurred.

Only one of four reserved frames was consumed. No race intro/countdown/Up driving input, before/after movement pair, ordinary Quit, or FPS acceptance exists. Prior race proof is unchanged and is not presented as this attempt's result. The guest supervisor completed cleanup and a supported API handback found no owned guest survivors. Boat `bx_eggqardq` remains running, expiry2026-10-27T16:31:01.612Z; coordinator owns16:20 shutdown.

`finding.json` records exact pins, last ACK/cursor, resource measurements, limitations and remaining gates. Portable evidence archives retain causal stdout/stderr, commands and safe hashes, helper source, staging identities, startup/parser/ABI evidence, inspected PNG, and original failed setup. Each archive is independently hashed in `evidence-index.json`. Local source/module recovery uses the immutable pins and stage manifest; unchanged compiled modules remain in the retained predecessor ops path. Recipe tests verify source syntax, compile prohibition, exact serial controls, PNG dimensions, no Up dispatch, refusal/no new events, guard result, cleanup, and archive integrity. Existing accepted offline groups were reused.
'''
(D/'README.md').write_text(readme)
# Archive bounded groups; source payloads in command receipts compress well.
commands=[]
for p in sorted((O/'commands').glob('*.json')):
 x=json.loads(p.read_text());argv=x['argv'];commands.append(dict(name=p.name,argvPrefix=argv[:-1],commandSHA256=x['commandSHA256'],argvSHA256=hashlib.sha256(json.dumps(argv).encode()).hexdigest(),commandBytes=len(argv[-1].encode()),originalReceiptSHA256=sha(p),retainedExactReceipt=str(p),recovery='stage.py deterministic tar/chunk reconstruction from stage-manifest immutable source/game pins; game payload bytes deliberately not published'))
(O/'command-hash-index.json').write_text(json.dumps(commands,indent=2))
files=[p for p in O.rglob('*') if p.is_file() and not any(x in p.relative_to(O).parts for x in ('current','remote-evidence','commands')) and not p.name.startswith('evidence-')]
groups=[];group=[];size=0
for p in sorted(files):
 if group and size+p.stat().st_size>16*1048576:groups.append(group);group=[];size=0
 assert p.stat().st_size<=24*1048576
 group.append(p);size+=p.stat().st_size
if group:groups.append(group)
index=[]
for n,group in enumerate(groups):
 target=D/('evidence-'+str(n)+'.tgz')
 with tarfile.open(target,'w:gz') as t:
  for p in group:t.add(p,arcname=str(p.relative_to(O)),recursive=False)
 assert target.stat().st_size<=24*1048576
 with tarfile.open(target) as t:
  assert len(t.getmembers())==len(group)
  for member,p in zip(t.getmembers(),group):assert hashlib.sha256(t.extractfile(member).read()).hexdigest()==sha(p)
 index.append(dict(file=target.name,bytes=target.stat().st_size,sha256=sha(target),payloads=len(group)))
(D/'evidence-index.json').write_text(json.dumps(index,indent=2));(O/'package-result.json').write_text(json.dumps(dict(report=str(D),index=index,passTests=True),indent=2));print(json.dumps(dict(report=str(D),archives=len(index),bytes=sum(x['bytes'] for x in index),payloads=sum(x['payloads'] for x in index),lastACK=last['reply']['value'].get('batch'),wire=wire)))
