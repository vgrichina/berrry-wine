import pathlib,subprocess,json,fcntl,sys,hashlib,time
O=pathlib.Path(__file__).parent;R=O.parent/'repo';B='task/'+O.parent.name
def git(label,args):
 with (O/('pub-'+label+'.stdout')).open('xb') as out,(O/('pub-'+label+'.stderr')).open('xb') as err:
  p=subprocess.run(['prlimit','--data=536870912:536870912','--','git','-c','gc.auto=0','-c','pack.threads=1','-C',str(R),*args],stdout=out,stderr=err)
 assert p.returncode==0,(label,p.returncode)
 return (O/('pub-'+label+'.stdout')).read_text().strip()
with open('/tmp/wine-ops-production-git.lock','a') as lk:
 fcntl.flock(lk,fcntl.LOCK_EX)
 git('diff-check',['diff','--check']);git('add',['add','reports/'+O.parent.name]);git('staged-check',['diff','--cached','--check'])
 changed=git('names',['diff','--cached','--name-only']).splitlines();assert changed and all(x.startswith('reports/'+O.parent.name+'/') for x in changed)
 git('commit',['commit','-m','Report one pinned GeneRally gameplay qualification attempt'])
 commit=git('head',['rev-parse','HEAD']);git('push',['push','origin','HEAD:refs/heads/'+B])
 remote=git('verify',['ls-remote','--exit-code','origin','refs/heads/'+B]);assert remote.split()==[commit,'refs/heads/'+B]
 result=dict(at=time.time(),commit=commit,remoteBranch='refs/heads/'+B,exactRemoteVerified=True,changed=changed,force=False)
 (O/'publication.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
