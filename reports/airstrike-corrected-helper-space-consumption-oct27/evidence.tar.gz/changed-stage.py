import task as t,json,hashlib
rows=json.loads((t.H/'runtime-map.json').read_text())['files'];x=next(x for x in rows if x['target']=='runner/test/input-consumption-trace.js');b=t.source(x);assert hashlib.sha256(b).hexdigest()==x['sha256'];print(t.sendfiles([t.payload(x['target'],b)],'corrected-helper-only'))
