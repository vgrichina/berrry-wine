import pathlib,json,hashlib,tarfile,io,time
R=pathlib.Path('/tmp/generally-bounded-loading-dispatch-repair-oct27');O=R/'ops';repo=R/'repo'
dest=repo/'reports/generally-bounded-loading-dispatch-repair-oct27';dest.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=sorted(p for p in O.rglob('*') if p.is_file())
with tarfile.open(dest/'diagnostics.tar.gz','w:gz') as tar:
    for p in files:tar.add(p,arcname=str(p.relative_to(O)),recursive=False)
evidence=dict(status='SOURCE_PROTOCOL_REPAIR_PASS_RUNTIME_UNKNOWN',source='1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba',
 productionAuthority=dict(path='test/run.js',sha256=sha(repo/'test/run.js'),blob=(O/'git-source-identity.stdout').read_text().strip()),
 sourcePins={str(p.relative_to(repo)):sha(p) for p in [repo/'tools/generally-loading-controller.py',repo/'test/fixtures/generally-loading-protocol.cjs',repo/'test/test-generally-loading-controller.py',repo/'docs/generally-bounded-loading-controller.md']},
 groups=[json.loads((O/x/'group.json').read_text()) for x in ['repro','acceptance','hardening','final/acceptance','final/hardening','positive-total-recovery']],
 currentAcceptance=json.loads((O/'acceptance-reconciliation.json').read_text()),
 historicalFailure=dict(request=dict(id=12,action='step',n=100000),receiptSHA256='931290508de71df0dd3fd9cc6402286ed152c50cbc004bb27a7aadf2801cbdd8',originals='retained/',timeout='caller38s/bridge40s; uncertain request MUST NOT be replayed'),
 results=dict(oversizedReproducer=True,bounded100000=True,nonmultiple2501=True,exactIDs=True,oneOutstanding=True,frozenZeroBeforeEveryDispatch=True,globalDeadlineNeverReset=True,rejected=['missing','delayed','duplicate','wrong-ID','negative','wrong-ran','wrong-steps','wrong-batch','not-frozen','nonzero-credits','quit','snapshot-batch','guest-exit','deadline','pending-original-id12','expanded-response-timeout'],restartRefusedForAllPoisonedCursors=True),
 limits=dict(pythonRSS=128*1048576,nodeAggregateRSS=768*1048576,nodeHeap=512*1048576,cpu=90,wall=120,file=24*1048576,output=2*1048576,display=8192,cumulativeDiagnostic=1048576),
 cleanup=dict(supervision=['repro.json','acceptance.json','hardening.json','acceptance-final.json','hardening-final.json','positive-total-recovery.json','reconcile.json'],perScenario='*/cleanup.json',noGuestOrBoat=True,box='none assigned; no lifecycle operations; coordinator owns all boxes'),
 runtimeGate='Independent acceptance, fresh assigned box/admission, full capture/time/staging plan, exact canonical mount argv and verified cursor handoff. No real GeneRally execution, compiler, emulator changes or gameplay claim.',
 preservedModules='Both passed predecessor modules remain at original retained paths, not copied/rebuilt/touched.',
 archive=dict(path='diagnostics.tar.gz',sha256=sha(dest/'diagnostics.tar.gz'),payloads=[dict(path=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]),
 canonicalCompletionReceipt=str(O/'receipt-manifest.json'),publication='Own task branch only; final verified remote commit and publication/cleanup receipts are bound by the canonical completion receipt after push.')
(dest/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps(dict(files=len(files),archiveBytes=(dest/'diagnostics.tar.gz').stat().st_size,evidenceBytes=(dest/'evidence.json').stat().st_size)))
