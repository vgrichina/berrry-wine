import pathlib,json,hashlib
R=pathlib.Path('/tmp/generally-bounded-loading-dispatch-repair-oct27');O=R/'ops';repo=R/'repo'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
groups={name:read(O/name/'group.json') for name in ['repro','acceptance','hardening','final/acceptance','final/hardening','positive-total-recovery']}
helper=sha(repo/'tools/generally-loading-controller.py');fixture=sha(repo/'test/fixtures/generally-loading-protocol.cjs')
for name in ['final/acceptance','final/hardening','positive-total-recovery']:
 assert groups[name]['pins']['tools/generally-loading-controller.py']==helper
 assert groups[name]['pins']['test/fixtures/generally-loading-protocol.cjs']==fixture
assert groups['repro']['pass_'] and groups['repro']['pins']['test/fixtures/generally-loading-protocol.cjs']==fixture
assert groups['final/acceptance']['tests']==6 and groups['final/acceptance']['failures']==1 and groups['final/acceptance']['errors']==0
err=(O/'acceptance-final.stderr').read_text();assert 'FAIL: test_03_stdio_preserves_original_requested_total100000' in err and err.count('FAIL: ')==1
assert groups['final/hardening']['pass_'] and groups['positive-total-recovery']['pass_']
trace=[json.loads(x) for x in (O/'positive-total-recovery/total100000/fixture.jsonl').read_text().splitlines()]
pending=None;steps=[]
for x in trace:
 if 'request' in x:
  assert pending is None;pending=x['request']['id']
  assert x['before']['frozen']['frozen'] is True and x['before']['frozen']['credits']==0
  if x['request']['action']=='step':steps.append(x['request']['n'])
 if 'ack' in x:
  assert x['ack']['id']==pending;pending=None
assert pending is None and sum(steps)==100000 and max(steps)<=1000
receipt=read(O/'positive-total-recovery/total100000/receipt.json');assert receipt['ok'] and receipt['completed']==100000
for p in O.rglob('cleanup.json'):assert all(not x['alive'] for x in read(p))
# Preserve the exact intermediate test driver used by the earlier hardening.
text=(O/'test-driver-final-acceptance.py').read_text();a=text.index('    def test_08a_mailbox_terminal_blocks_dispatch');b=text.index('    def test_08_rejected_cursors_forbid_restart_and_later_input',a);text=text[:a]+text[b:]
p=O/'test-driver-hardening-v1.py';p.write_text(text);assert sha(p)==groups['hardening']['pins']['test/test-generally-loading-controller.py']
node=pathlib.Path('/usr/local/bin/node').resolve();h=hashlib.sha256()
with node.open('rb') as f:
 while chunk:=f.read(65536):h.update(chunk)
result=dict(pass_=True,helperSHA256=helper,fixtureSHA256=fixture,productionSource=groups['repro']['source'],groups=groups,
 effectiveCoverage=dict(repro='repro/group.json unchanged production boundary',acceptedCurrentHelper='final/acceptance/group.json cases02,04..07 plus final/hardening/group.json cases08,08a,09',correctedPositive='positive-total-recovery/group.json case03; real38s response allowance/global20s test allowance, same userCPU90/wall120/RSS/output caps',preservedFailure='final/acceptance total100000 stopped uncertain snapshot20 under synthetic0.5s per-ACK; no replay or input; all descendants reaped',oneOutstandingAndFrozenZeroFull100000Trace=True,allOwnedScenarioChildrenReaped=True),
 installedNode=dict(path=str(node),sha256=h.hexdigest(),bytes=node.stat().st_size,startupReceipt='node-startup-installed.json',startupStdout='node-startup-installed.stdout',heapMiB=512,AS='unlimited inherited',DATA='unlimited inherited',standingInputNotCopied=True),
 interpretation='Repair meets bounded controller protocol; no real game, emulator or module execution. Synthetic success limit corrected within imposed user guards; failed evidence retained; only affected positive case repeated.')
(O/'acceptance-reconciliation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(pass_=True,effectiveTests=10,stepTotal=sum(steps),stepChunks=len(steps),allScenarioChildrenReaped=True)))
