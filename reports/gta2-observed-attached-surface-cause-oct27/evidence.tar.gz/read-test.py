exec((__import__('pathlib').Path(__file__).parent/'init-repo.py').read_text().split("with open('/tmp/wine-ops-production-git.lock'")[0])
with open('/tmp/wine-ops-production-git.lock','a') as lk:
 fcntl.flock(lk,fcntl.LOCK_EX)
 for path in ['test/test-directdraw-surface47-abi-candidate.js','test/helpers/wat-fragment-harness.js']:
  try:git('test-'+path.replace('/','_'),['-C',str(R),'show',COMPILED+':'+path])
  except AssertionError:print('optional helper absent',path)
print('PASS existing pinned test read only')
