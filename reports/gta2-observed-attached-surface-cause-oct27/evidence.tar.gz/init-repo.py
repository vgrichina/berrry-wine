import pathlib,os,subprocess,json,hashlib,fcntl
O=pathlib.Path(__file__).parent;R=O.parent/'repo';D=pathlib.Path('/tmp/gta2-retained-allocation-raw-return-oct27/repo');PIN='3370a4e72a72ef54ebcbcde5264b768a47e98590';COMPILED='1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba'
def git(label,args):
 with (O/('git-'+label+'.stdout')).open('xb') as out,(O/('git-'+label+'.stderr')).open('xb') as err:
  r=subprocess.run(['/usr/bin/prlimit','--data=536870912:536870912','--','git','-c','gc.auto=0','-c','pack.threads=1',*args],stdout=out,stderr=err)
 assert r.returncode==0,(label,r.returncode)
 return (O/('git-'+label+'.stdout')).read_bytes()
with open('/tmp/wine-ops-production-git.lock','a') as lk:
 fcntl.flock(lk,fcntl.LOCK_EX)
 git('init',['init',str(R)])
 leaves=(D/'.git/objects/info/alternates').read_text().splitlines()
 leaves=[str(D/'.git/objects')]+leaves
 assert all(pathlib.Path(x).is_dir() for x in leaves)
 (R/'.git/objects/info/alternates').write_text('\n'.join(dict.fromkeys(leaves))+'\n')
 git('sparse',['-C',str(R),'config','core.sparseCheckout','true'])
 (R/'.git/info/sparse-checkout').write_text('/reports/'+O.parent.name+'/\n')
 git('checkout',['-C',str(R),'checkout','-b','task/'+O.parent.name,PIN])
 git('remote',['-C',str(R),'remote','add','origin','git@github.com:vgrichina/wine-assembly.git'])
 git('name',['-C',str(R),'config','user.name','Wine Ops Worker']);git('email',['-C',str(R),'config','user.email','wine-ops@local'])
 identities=[]
 for label,pin,path in [('compiled-directx',COMPILED,'src/09a8-handlers-directx.wat'),('current-directx',PIN,'src/09a8-handlers-directx.wat'),('compiled-main',COMPILED,'src/main.watx')]:
  b=git(label,['-C',str(R),'show',pin+':'+path]);identities.append(dict(label=label,revision=pin,path=path,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 (O/'source-pins.json').write_text(json.dumps(identities,indent=2)+'\n')
print('PASS sparse own checkout + exact compiled source available; no fetch')
