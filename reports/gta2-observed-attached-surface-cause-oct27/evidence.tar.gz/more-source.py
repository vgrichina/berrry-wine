exec((__import__('pathlib').Path(__file__).parent/'init-repo.py').read_text().split("with open('/tmp/wine-ops-production-git.lock'")[0])
with open('/tmp/wine-ops-production-git.lock','a') as lk:
 fcntl.flock(lk,fcntl.LOCK_EX)
 paths=['src/09b2-dispatch-table.generated.wat','tools/gen_dispatch.js','lib/region-map.generated.js','src/00-regions.wat','test/helpers/production-wat.js']
 pins=[]
 for path in paths:
  label='source-'+path.replace('/','_')
  try:b=git(label,['-C',str(R),'show',COMPILED+':'+path])
  except AssertionError:
   print('MISSING',path);continue
  pins.append(dict(path=path,revision=COMPILED,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),stored='git-'+label+'.stdout'))
 git('test-names',['-C',str(R),'ls-tree','-r','--name-only',COMPILED,'test'])
 (O/'more-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('PASS additional exact-source objects read; missing optional helper retained')
