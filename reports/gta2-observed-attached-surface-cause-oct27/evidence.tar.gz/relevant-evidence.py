import tarfile,json,pathlib,hashlib
O=pathlib.Path(__file__).parent;D=pathlib.Path('/tmp/gta2-retained-allocation-raw-return-oct27/repo/reports/gta2-retained-allocation-raw-return-oct27')
index={x['path']:x for x in json.loads((D/'evidence-index.json').read_text())}
names=['retrieved/guest.stdout','retrieved/guest.stderr','retrieved/preflight-result.json','causal-result.json']
receipts=[]
with tarfile.open(D/'evidence.tar.gz','r|gz') as tf:
 for m in tf:
  n=m.name.removeprefix('./')
  if n not in names:continue
  assert m.isfile(); b=tf.extractfile(m).read(); e=index[n]
  assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
  p=O/'relevant'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  receipts.append(e)
assert len(receipts)==len(names)
(O/'relevant-evidence.json').write_text(json.dumps({'reusedCoordinatorVerification':'/tmp/gta2-raw-return-cause-readiness-oct27/ops/verification.json','archiveExpectedSHA256':'419d13a63f4bf9f395796cdddd05e372527659398c65a9fe418fe8070639abe6','members':receipts,'fullArchiveExtraction':False,'archivePayloadReaudit':False},indent=2)+'\n')
print('PASS four relevant members streamed and verified')
