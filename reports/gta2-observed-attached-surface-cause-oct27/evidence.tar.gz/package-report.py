import pathlib,json,hashlib,tarfile,time
O=pathlib.Path(__file__).parent;P=O.parent/'repo/reports'/O.parent.name
sha=lambda b:hashlib.sha256(b).hexdigest()
s=(O/'git-compiled-directx.stdout').read_bytes();pins=json.loads((O/'source-pins.json').read_text())
assert sha(s)==pins[0]['sha256']=='d5fb8b951707ffef055ba46eddcabc812b2b4ea8660956122c1e6da34cf2ef4e'
assert s==(O/'git-current-directx.stdout').read_bytes()
ss=s.decode();forms=(P/'exact-handler.wat').read_text();ex=json.loads((O/'extraction.json').read_text())
for e in ex['forms']:
 start=ss.index(e['form']); assert start>=0
 assert e['line']==ss[:start].count('\n')+1
 # Every exact extracted form occurs byte-for-byte in the pinned source.
for part in forms.strip().split('\n\n'):
 # Blank lines inside the handler are possible; its whole form hash is also bound below.
 assert part in ss
assert sha(forms.encode())=='82be9fcfda340f32a31bb8d3c96a743652a68c913bf19c0f73eae8c3b6df4410'
probe=json.loads((O/'branch-probe-final.stdout').read_text());assert probe['status']=='PASS_SOURCE_BRANCH_PROBE' and len(probe['rows'])==9
r=json.loads((O/'branch-probe-final.json').read_text());assert r['exit']==0 and r['cleanupComplete'] and not r['stopReason']
log=(O/'relevant/retrieved/guest.stdout').read_text()
for token in ['[API #668] IDirectDraw_QueryInterface','riid={9c59509a-39bd-11d1-8c4a-00c04fd930c5}','out: ppv=&0x08332028','[API #671] IDirectDraw_CreateSurface(0x08332028','sz=124 fl=0x00000021','back=1','0x08221038: fc d7 6f 00 07 00 00 00 cc b9 6f 00 08 00 00 00','0x074ffe34: 04 00 00 00 01 00 01 00 30 e1 95 00 00 00 8f 08','=> 0x887600ff (raw EAX; IDirectDrawSurface_GetAttachedSurface)']:assert token in log,token
assert ss.index('(local.set $child (load.field DxObject misc0',ss.index('(func $handle_IDirectDrawSurface_GetAttachedSurface'))>ss.index('(i32.const 12))))) (then',ss.index('(func $handle_IDirectDrawSurface_GetAttachedSurface'))
f=json.loads((P/'finding.json').read_text());assert not f['repair']['implemented'] and f['runtime']['newGuestInvocations']==0
check={'at':time.time(),'pass':True,'sourceSHA256':sha(s),'exactExtractedFormsSHA256':sha(forms.encode()),'probeJS_SHA256':sha((P/'source-branch-probe.js').read_bytes()),'probeCases':9,'observationsCrossChecked':True,'sourceCreationCaps':{'root':'0x6238','back':'0x601c','backMatches4':True},'runtime':False,'independentAcceptance':False}
(O/'report-validation.json').write_text(json.dumps(check,indent=2)+'\n')
index=[]
for p in sorted(O.rglob('*')):
 if p.is_file() and p.name not in ['package.stdout','package.stderr','package.supervisor-output','package.json','receipt-manifest.json','publication-closeout.json']:
  b=p.read_bytes(); index.append(dict(path=str(p.relative_to(O)),bytes=len(b),sha256=sha(b)))
(P/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(P/'evidence.tar.gz','w:gz') as tf:
 for e in index:tf.add(O/e['path'],arcname=e['path'],recursive=False)
# Only this task's new portable payloads are checked, not reused donor inventories.
with tarfile.open(P/'evidence.tar.gz','r:gz') as tf:
 for e in index:
  b=tf.extractfile(e['path']).read();assert len(b)==e['bytes'] and sha(b)==e['sha256']
summary={'payloads':len(index),'archiveBytes':(P/'evidence.tar.gz').stat().st_size,'archiveSHA256':sha((P/'evidence.tar.gz').read_bytes()),'indexSHA256':sha((P/'evidence-index.json').read_bytes()),'checks':check}
(O/'package-result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['payloads','archiveBytes','archiveSHA256']}))
