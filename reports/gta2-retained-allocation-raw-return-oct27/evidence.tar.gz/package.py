import pathlib,json,hashlib,tarfile,gzip,time,re,struct
O=pathlib.Path(__file__).parent; D=O.parent/'repo'/'reports'/O.parent.name
D.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
G=O/'retrieved'; text=(G/'guest.stdout').read_text()
pattern=r'\[API #672\] IDirectDrawSurface_GetAttachedSurface\(0x08221038, 0x074ffe34, 0x0087addc\).*?ret=0x00953275\].*?=> 0x887600ff \(raw EAX; IDirectDrawSurface_GetAttachedSurface\)'
assert re.search(pattern,text,re.S)
assert '[api-mem] IDirectDrawSurface_GetAttachedSurface arg1=0x074ffe34 len=16\n  0x074ffe34: 04 00 00 00 01 00 01 00 30 e1 95 00 00 00 8f 08' in text
mods=json.loads((G/'terminal-modules.json').read_text());assert mods['dmavideo']==dict(loadAddr=0x951000,origBase=0x1000000)
controls=json.loads((G/'controls.json').read_text());assert len(controls)==7
for c in controls:assert c['request']['id']==c['reply']['id'] and c['reply']['ok']
assert controls[2]['request']==dict(id=3,action='step',n=250)
assert controls[2]['reply']['value']==dict(batch=250,ran=250,steps=250,frozen=True)
assert controls[3]['reply']['value']['frozen']['credits']==0
guest=json.loads((G/'guest-supervisor.json').read_text());assert guest['cleanupComplete'] and guest['exit']==0 and guest['stopReason'] is None
cleanup=json.loads((O/'cleanup-remote.stdout').read_text());assert not cleanup['ownedSurvivors'] and cleanup['controllerPending'] is None
caps='040000000100010030e1950000008f08'
v=dict(status='CAUSAL_RAW_RETURN_OBSERVED',at=time.time(),guestInvocations=1,rawEAX='0x887600ff',rawUnsigned=0x887600ff,rawSigned=0x887600ff-2**32,apiSequence=672,api='IDirectDrawSurface_GetAttachedSurface',thisPointer='0x08221038',vtable='0x006fd7fc',capsPointer='0x074ffe34',capsBytes16=caps,capsLittleEndianDwords=[f'0x{x:08x}' for x in struct.unpack('<4I',bytes.fromhex(caps))],outPointer='0x0087addc',callerReturn='0x00953275',actualModuleBase='0x00951000',preferredModuleBase='0x01000000',moduleOffset='0x2275',preferredCallerReturn='0x01002275',observation='entry-time memory dump plus raw log_api_exit EAX before guest caller resumes; correlated by uninterrupted API entry/exit pair',laterModeCheck='TRACE-AT batch165 EAX1 ESI2 is separate and earlier in buffered output; displayed2 is requested mode, not HRESULT',runnerRevision='3370a4e72a72ef54ebcbcde5264b768a47e98590',runnerSHA256='1655b299c95be6b2cd2ca8c951b880b0b8fbed81a0cd785300d3bed5f24ae39c',compiledRevision='1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba',guestSupervisor=guest,remainingGuestAllowance=dict(cpuSeconds=180-guest['cpuSeconds'],wallSeconds=240-guest['wallSeconds'],invocations=0),cleanup=cleanup,limitations=['No gameplay acceptance','No fullscreen semantic repair','Controller quit acknowledged; no ordinary in-game Quit claim','Caps tail bytes are exact input, no initialized-field assumption','stderr missing optional PE DLL warnings preserved; exact registered71-file closure passed'])
(O/'causal-result.json').write_text(json.dumps(v,indent=2)+'\n')
commands=[]
for p in sorted((O/'commands').glob('*.json')):
 j=json.loads(p.read_text());commands.append(dict(id=p.stem,sha256=j['sha256'],bytes=len(j['command'].encode())))
(O/'command-identities.json').write_text(json.dumps(commands,indent=2))
used=json.loads((O/'api-inherited.json').read_text())['actualResponseBytes']+sum(p.stat().st_size for p in (O/'responses').iterdir())
(O/'api-ledger.json').write_text(json.dumps(dict(chargedBytes=used,limit=8388608,terminalReserve=1048576,remainingIncludingReserve=8388608-used,inherited=723213,accounting='all response files conservatively includes envelopes/start/terminal metadata; raw wire is lower'),indent=2))
files=[p for p in O.rglob('*') if p.is_file() and not any(n in p.parts for n in ['commands','__pycache__']) and p.name not in ['receipt-manifest.json','messageboard-watch.log','package.json','package.stdout','package.stderr','package.supervisor-output']]
index=[dict(path=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(files)]
with (D/'evidence.tar.gz').open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w|') as t:
   for p in sorted(files):t.add(p,arcname=str(p.relative_to(O)),recursive=False)
(D/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
manifest=dict(result=v,archive=dict(path='evidence.tar.gz',bytes=(D/'evidence.tar.gz').stat().st_size,sha256=sha(D/'evidence.tar.gz')),indexSHA256=sha(D/'evidence-index.json'),payloads=len(index),reused=dict(predecessorManifest='/tmp/gta2-accepted-raw-return-causal-trace-oct27/ops/receipt-manifest.json',predecessorManifestSHA256='5a962a91f17e69f35ba8c3cad99a53b6c3eec039cb684f4640adc7aeb1e40552',coordinatorVerification='/tmp/gta2-allocation-recovery-readiness-oct27/ops/verification.json',payloadsAlreadyVerified=6793,stagedBaseGroups=120,baseRetransfers=0,helperClosure=33),historicalAllocationIncident=dict(projected=339529728,allocation=335544320,shortfall=3985408,meaning='conservative future projection before helpers/preflight/guest; not real disk/RAM exhaustion or observed HRESULT'),continuationAllocation=536870912,reserve=33554432,apiLedger=json.loads((O/'api-ledger.json').read_text()),resources=json.loads((O/'package.admission.json').read_text()),rootRefReceipt='/home/user/wine-assembly/scratch/usage-watch/'+O.parent.name+'/root-ref-digest.json',publication='ops/publication-closeout.json binds final exact commit/remote ref after commit',incidents=['Initial inspection matched node substring in Avahi hostname; exact executable-name correction passed, no guest existed','Initial helper archive-name check omitted path normalization; corrected locally, no transfer occurred before verification','Initial instruction reading exceeded8192B display; bounded excerpts used thereafter','Sparse repository initialization used stricter128MiB aggregate supervision and one light pool slot with child-only Git DATA plus Git flock; no concurrent owned Git'])
manifest['incidents'].append('Initial donor Git alternates caused nested-store warnings; corrected own alternate configuration to267 verified read-only leaf stores; no fetch/repack or donor changes. Original diagnostics retained.')
(D/'receipt-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(O/'receipt-manifest.json').write_bytes((D/'receipt-manifest.json').read_bytes())
(D/'README.md').write_text('''# GTA2 raw-return causal result

Observed raw EAX/HRESULT **0x887600ff** at IDirectDrawSurface_GetAttachedSurface API sequence **672**, in the accepted log_api_exit callback before the guest caller resumes. Entry-time DDSCAPS at **0x074ffe34** was **040000000100010030e1950000008f08** (little-endian dwords 0x00000004, 0x00010001, 0x0095e130, 0x088f0000). No initialized-tail assumption is made.

The call used this=0x08221038, vtable=0x006fd7fc, out=0x0087addc, caller return=0x00953275. This invocation resolved Dmavideo at 0x00951000, preferred base0x01000000: offset0x2275, preferred return0x01002275. Raw return is directly observed; the earlier inference is no longer the sole evidence. Displayed mode2 and the separate Vid_SetMode EAX1 are not HRESULT.

Reused all120 staged base groups without retransferring/rebuilding. Verified33 helper pins, actual3828 staged pins, registered71 game files, production runner3370a4e SHA1655b299, compiled1e4fdb06 base module SHA bf707aa4, region9a3bc9149d58209c, imports and exact Node24.22.1 startup. See archived preflight-result.json for full pins, canonical filename parser and comma-bearing filename enumeration. Prior6793 evidence payload checks are reused through coordinator verification.

One invocation, initial frozenzero, serial step250 matched ACKall250 then frozenzero; seven matched controller requests. No input or gameplay acceptance. Controller quit was acknowledged; this is not ordinary in-game Quit. Original stdout/stderr and optional missing-PE warnings are preserved. Guest CPU1.488856s, wall0.403081s, supervised peak168697856B; no owned survivors.

Historical predecessor339529728B projection exceeded335544320B by3985408B before helper transfer, preflight or guest. This was not actual host exhaustion. The explicitly authorized512MiB aggregate continuation charges retained donor once, full WAL once, fresh session/events/Git/control/publication and reserve32MiB. See admissions and API ledger for measurements.

Boat bx_w99qrvz9 remains RUNNING with staged files preserved and zero owned survivors. Expiry2026-10-27T15:47:01.657Z; cutoff15:30, handback15:34, coordinator shutdown15:39 and watcher226049 untouched. No lifecycle mutation. No main/root/index/ref/source changes, rebuild, accepted-test replay, deployment or media acquisition.
''')
print(json.dumps(dict(payloads=len(index),archiveBytes=(D/'evidence.tar.gz').stat().st_size,manifestSHA256=sha(O/'receipt-manifest.json'),apiCharged=used)))
