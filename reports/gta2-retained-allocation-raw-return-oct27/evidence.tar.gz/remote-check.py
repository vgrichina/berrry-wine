import pathlib,json,shlex,sys
from api import api
O=pathlib.Path(__file__).parent;mode=sys.argv[1]
if mode in ['startup','preflight']:
 command='python3 /home/user/wineops-gta2-accepted-raw-return-causal-trace-oct27/ops/remote-trace.py '+mode
else:raise RuntimeError(mode)
j=api(command);(O/(mode+'-response.json')).write_text(json.dumps(j,indent=2));print(json.dumps(j))
