import json,pathlib,shlex,time
from api import api
O=pathlib.Path(__file__).parent
code="""import pathlib,json,hashlib,time
H=pathlib.Path('/home/user/wineops-gta2-accepted-raw-return-causal-trace-oct27');R=H/'repo';O=H/'ops';pins=json.loads((O/'staged-pins.json').read_text());rows=[]
for n,(size,want) in pins.items():
 p=R/n;h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(65536):h.update(b)
 assert p.stat().st_size==size and h.hexdigest()==want,n
 rows.append(n)
v=dict(ok=True,count=len(rows),pinsSHA256=hashlib.sha256((O/'staged-pins.json').read_bytes()).hexdigest(),at=time.time());(O/'staged-verification.json').write_text(json.dumps(v));print(json.dumps(v))"""
j=api('python3 -c '+shlex.quote(code));(O/'staged-verification.json').write_text(j['stdout']);print(j['stdout'])
