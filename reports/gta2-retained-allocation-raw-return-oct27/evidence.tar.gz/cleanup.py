import pathlib,json,time,shlex
from api import api
O=pathlib.Path(__file__).parent
code='''import pathlib,json,time
O=pathlib.Path("/home/user/wineops-gta2-accepted-raw-return-causal-trace-oct27/ops");r=json.loads((O/"guest-supervisor.json").read_text());survivors=[]
for pid,start in r["owned"]:
 try:
  s=pathlib.Path("/proc",str(pid),"stat").read_text().split(") ")[1].split()
  if s[19]==start:survivors.append(dict(pid=pid,start=start,state=s[0]))
 except FileNotFoundError:pass
c=json.loads((O/"controller-terminal.json").read_text());assert not survivors and r["cleanupComplete"] and c["pending"] is None
H=O.parent;used=sum(p.lstat().st_blocks*512 for p in H.rglob("*") if p.is_file())
print(json.dumps(dict(at=time.time(),ownedSurvivors=survivors,supervisor=r,controllerPending=c["pending"],guestExit=json.loads((O/"guest-exit.json").read_text()),remoteUsed=used,box="bx_w99qrvz9",state="RUNNING: supported exec succeeded",lifecycleMutations=0,expiry="2026-10-27T15:47:01.657Z",shutdownOwner="coordinator",cutoff="15:30Z",handback="15:34Z",shutdown="15:39Z")))
'''
j=api('python3 -c '+shlex.quote(code));v=json.loads(j['stdout']);(O/'cleanup-remote.json').write_text(json.dumps(v,indent=2));print(json.dumps(v))
