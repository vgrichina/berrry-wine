import os,pathlib,subprocess,json,hashlib,fcntl
O=pathlib.Path(__file__).parent;R=O.parent/'repo';D='/tmp/gta2-accepted-raw-exit-main-integrate-oct27/repo';PIN='3370a4e72a72ef54ebcbcde5264b768a47e98590'
def git(label,args):
 with (O/('git-'+label+'.stdout')).open('xb') as out,(O/('git-'+label+'.stderr')).open('xb') as err:
  r=subprocess.run(['/usr/bin/prlimit','--data=536870912:536870912','--','git','-c','gc.auto=0','-c','pack.threads=1',*args],stdout=out,stderr=err)
 assert r.returncode==0,(label,r.returncode)
with open('/tmp/wine-ops-production-git.lock','a') as lk:
 fcntl.flock(lk,fcntl.LOCK_EX)
 git('runner',['-C',D,'show',PIN+':test/run.js'])
 h=hashlib.sha256((O/'git-runner.stdout').read_bytes()).hexdigest();assert h=='1655b299c95be6b2cd2ca8c951b880b0b8fbed81a0cd785300d3bed5f24ae39c'
 assert os.environ['GIT_SSH_COMMAND']=='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
 git('init',['init',str(R)]);(R/'.git/objects/info/alternates').write_text(D+'/.git/objects\n')
 git('sparse',['-C',str(R),'config','core.sparseCheckout','true']);(R/'.git/info/sparse-checkout').write_text('/reports/'+O.parent.name+'/\n')
 git('checkout',['-C',str(R),'checkout','-b','task/'+O.parent.name,PIN])
 git('remote',['-C',str(R),'remote','add','origin','git@github.com:vgrichina/wine-assembly.git'])
 git('name',['-C',str(R),'config','user.name','Wine Ops Worker']);git('email',['-C',str(R),'config','user.email','wine-ops@local'])
(O/'launch-identity.json').write_text(json.dumps(dict(source=PIN,runnerSHA256=h,ssh=os.environ['GIT_SSH_COMMAND'],rootRefReceipt='/home/user/wine-assembly/scratch/usage-watch/'+O.parent.name+'/root-ref-digest.json',parser='parser-check.execution.json',box='bx_w99qrvz9',cutoff='2026-10-27T15:30Z',handback='15:34Z',shutdown='15:39Z',expiry='2026-10-27T15:47:01.657Z'),indent=2))
print('PASS pinned sparse report checkout; Git DATA on Git child only')