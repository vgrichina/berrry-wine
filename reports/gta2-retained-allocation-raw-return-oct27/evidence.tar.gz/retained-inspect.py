import pathlib,json,shlex,time
from api import api
O=pathlib.Path(__file__).parent
code="""import pathlib,shutil,json,time,os
H=pathlib.Path('/home/user/wineops-gta2-accepted-raw-return-causal-trace-oct27');assert (H/'repo').is_dir() and (H/'ops').is_dir()
rows=[]
for p in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  a=(p/'cmdline').read_bytes().split(bytes([0]));c=b' '.join(a)
  if pathlib.Path(a[0].decode()).name=='node' or (b'remote-trace.py' in c and b'-c' not in a):rows.append(dict(pid=int(p.name),argv=[x.decode() for x in a[:4]]))
 except (OSError,IndexError):pass
assert not rows,rows
assert not (H/'ops/guest-start.json').exists()
mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
assert mem>5*1024**3 and shutil.disk_usage(H).free>1073741824
print(json.dumps(dict(at=time.time(),state='RUNNING supported exec',node=shutil.which('node'),memory=mem,disk=shutil.disk_usage(H).free,guestProcesses=rows,allocated=sum(p.lstat().st_blocks*512 for p in H.rglob('*') if p.is_file()),root=str(H),groups=len(list((H/'ops').glob('*'))),opsFiles=[p.name for p in (H/'ops').iterdir()][:12],limits=pathlib.Path('/proc/self/limits').read_text())))"""
j=api('python3 -c '+shlex.quote(code));(O/'retained-inspect.json').write_text(j['stdout']);print(j['stdout'])
