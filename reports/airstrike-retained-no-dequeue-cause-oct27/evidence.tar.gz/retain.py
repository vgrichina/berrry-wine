import pathlib,json,tarfile,hashlib
o=pathlib.Path(__file__).parent
donor=pathlib.Path('/tmp/airstrike-corrected-helper-space-consumption-oct27')
d=json.loads((donor/'ops/receipt-manifest.json').read_text())
names=['runtime-map.json','source-evidence/excerpts.json','source-evidence/runner-boundaries.txt','source-evidence/renderer-key-path.txt','retained/game-evidence/runner.stdout','retained/game-evidence/events.json','retained/input-state-startup.json','retained/input-state-after-airstrike-3.json','retained/planned-argv.json']
expected={x['path']:x for x in d['payloads']}
with tarfile.open(donor/'repo/reports/airstrike-corrected-helper-space-consumption-oct27/evidence.tar.gz','r:gz') as t:
 for m in t:
  n=m.name.removeprefix('./')
  if n not in names: continue
  b=t.extractfile(m).read();assert len(b)==expected[n]['bytes'] and hashlib.sha256(b).hexdigest()==expected[n]['sha256']
  p=o/'retained'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for n in names: assert (o/'retained'/n).is_file()
for n in ['verify.json','verify.stdout','remote.json','remote.stdout']:
 (o/('reused-'+n)).write_bytes((pathlib.Path('/tmp/airstrike-space-cause-readiness-oct27/ops')/n).read_bytes())
(o/'retained-selection.json').write_text(json.dumps([expected[n] for n in names],indent=2))
print('Retained only',len(names),'selected records; reused full verification, no payload scan')
