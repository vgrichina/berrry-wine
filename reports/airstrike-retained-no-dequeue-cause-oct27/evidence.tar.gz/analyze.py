import pathlib,json,hashlib,re,math
o=pathlib.Path(__file__).parent
def read(p):return (o/p).read_text()
pins=json.loads(read('source-pins.json'))+json.loads(read('clock-source-pins.json'))
for x in pins:assert hashlib.sha256((o/'source'/x['path']).read_bytes()).hexdigest()==x['sha256']
runner=read('source/test/run.js');tm=read('source/lib/thread-manager.js');helper=read('source/test/input-consumption-trace.js');wat=read('source/src/13-exports.wat')
log=read('retained/retained/game-evidence/runner.stdout')
schedules=[]
for l in log.splitlines():
 if l.startswith('[input-schedule]'):
  schedules.append(dict(line=l,**{k:(int(v) if re.fullmatch(r'-?\d+',v) else v) for k,v in re.findall(r'(\w+)=([^ ]+)',l)}))
assert [(x['batch'],x['guestMs']) for x in schedules]==[(5000,25000),(5001,25005),(5002,25010)]
assert all(x['clock']=='batch' for x in schedules)
acks=[json.loads(l[6:]) for l in log.splitlines() if l.startswith('[ctl] ')]
steps=[x['value'] for x in acks if isinstance(x.get('value'),dict) and 'ran' in x['value']]
assert [(x['batch'],x['ran']) for x in steps]==[(5000,5000),(5001,1),(5002,1),(5003,1)]
snap=json.loads(read('retained/retained/input-state-after-airstrike-3.json'))['value']
start=json.loads(read('retained/retained/input-state-startup.json'))['value']
assert snap['batch']==5003 and snap['credits']==0 and snap['threads']['main']['sleepUntil']==25021
assert start['threads']['main']['sleepUntil']==25021
assert snap['threads']['main']['yieldReason']==0 and snap['threads']['head'][0]['yieldReason']==1
assert snap['threads']['main']['sleepActive']=='unknown'
assert snap['counters']['dequeued']==0 and snap['queues']['renderer']['count']==3
assert 'return !!this._mainSleepUntil && this._waitNow() < this._mainSleepUntil;' in tm
assert 'if (threadManager.isMainSleeping()) return true;' in runner
assert '!threadManager.hasLiveThreads()' in runner
assert 'if (!mainExecutionSuspended()) instance.exports.run(BATCH_SIZE);' in runner
assert runner.index('tickState.batch = batch;',runner.index('const executionStartedAt'))<runner.index('await waitForControlBatch();',runner.index('const executionStartedAt'))
assert 'sleepUntil: scalar(sleepUntil), sleepActive: unknown' in helper
assert '(global.set $sleep_yielded (i32.const 0))' in wat[wat.index('(func (export "get_sleep_yielded")'):]
argv=json.loads(read('retained/retained/planned-argv.json'))
assert '--tick-ms-per-batch=5' in argv and '--no-threads' in argv
assert not any(x.startswith(('--real-ticks','--app=','--startup-clock','--gameplay-bench','--dx-lock-pause','--async-mm-timer')) for x in argv)
result=dict(status='CAUSE_NOT_ESTABLISHED_NO_FIX',newFinding='Retained input steps never test the ordinary batch-clock main run path at or beyond its recorded sleep deadline. Scheduler admission was not observed; sleep causality is not asserted.',
 sourcePinCount=len(pins),sourceBytes=sum(x['bytes'] for x in pins),
 retainedWindow=dict(executedInputBatches=[5000,5001,5002],frozenBoundary=5003,observedScheduleClockMs=[25000,25005,25010],normalBatchClockAtFrozen=25015,recordedMainSleepUntil=25021,firstOrdinaryBatchBaseAtOrAfterDeadline=5005,firstOrdinaryBaseMs=25025,firstCompletingBoundary=5006,arithmeticQualification='Source-derived ordinary clock arithmetic, not an observed wake, a request to step, or proof no other guest callback ran. lastGuestTick is last observed guest clock import, not scheduler now.'),
 schedules=schedules,
 proven=dict(mainWaitFieldsInactiveAtYieldZero=True,threadOneWaitIsActiveButObjectResultUnknown=True,sleepYieldGetterConsumesFlag=True,renderQueueEnqueueEstablishedByOriginalEvidence=True),
 unresolved=dict(firstBranch='test/run.js mainExecutionSuspended(): noteMainSleep(); no-live-thread fast-forward guard; isMainSleeping() return -> skip instance.exports.run(BATCH_SIZE), including interleaved main slices.',
  missing='Invocation-owned actual scheduler gate decision and numeric clock/deadline at that decision; no retained record proves whether main entered guest run or reached the WAT input poll during these steps.',
  smallestObservation='Retain the actual decision already made at the ordinary main run gate: batch, decision/reason, numeric scheduler now used, _mainSleepUntil, hasLiveThreads, yieldReason; include a run-entry and host_check_input-entry marker for that same permitted slice. Do not call get_sleep_yielded/get_ticks for diagnostics. Observe an ordinary due slice before diagnosing a stalled poll.',
  nextIfGateAllowsButNoPoll='Identify guest main run entry and Get/PeekMessage fetch entry versus pending_input_packed cache; retained guestPostQueue and cached pending input were not sampled. Thread1 wait needs waitSingle result/object state only if it becomes the blocker.'),
 implementationChanged=False,runtimeAuthorized=False,newGuestInvocations=0,compileInvocations=0,nodeInvocations=0,behavioralAcceptanceRun=False,
 checks='Exact source hashes, retained schedule/step/snapshot consistency, source gate and destructive getter checks; static evidence audit only, no emulator regression or runtime acceptance.')
(o/'finding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],sourcePins=len(pins),inputBatches=[5000,5001,5002],normalFirstDueBatch=5005,staticAudit='PASS',implementationChanged=False)))
