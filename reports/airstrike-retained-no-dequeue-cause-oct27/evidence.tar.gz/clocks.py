import pathlib,json,hashlib,os,subprocess,resource
o=pathlib.Path(__file__).parent;r=o.parent/'repo';d=pathlib.Path('/tmp/airstrike-corrected-helper-space-consumption-oct27/repo/.git')
def lim():resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
def git(*args):
 p=subprocess.run(['flock','/tmp/wine-ops-production-git.lock','git',*args],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=lim)
 if p.returncode:raise RuntimeError(p.stderr.decode()[:1500])
 return p.stdout
m=json.loads((o/'retained/runtime-map.json').read_text());maps={x['target'].removeprefix('runner/'):x for x in m['files'] if x['target'].startswith('runner/')}
paths=['lib/batch-clock.js','lib/guest-clock.js']
rows=[]
for path in paths:
 rev='1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba' if path.startswith('src/') else '3370a4e72a72ef54ebcbcde5264b768a47e98590'
 if path=='test/input-consumption-trace.js':
  row=maps[path];b=pathlib.Path(row['source']).read_bytes();origin=row['source']
 else:b=git('show',rev+':'+path);origin=rev+':'+path
 sha=hashlib.sha256(b).hexdigest()
 if path in maps:assert sha==maps[path]['sha256'],(path,sha,maps[path]['sha256'])
 p=o/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 rows.append(dict(path=path,origin=origin,bytes=len(b),sha256=sha,runtimeMapMatches=path in maps))
(o/'clock-source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
(o/'mount-checkpoint.json').write_text(json.dumps(dict(action='source-only: no mount or runtime command',mountArgv=[],reuse='unchanged predecessor canonical mount parser startup; retained planned-argv.json and startup receipt in original verified archive',ssh=os.environ['GIT_SSH_COMMAND'],fetchBytes=0),indent=2))
print('Exact source pins materialized',len(rows),'files',sum(x['bytes'] for x in rows),'bytes; no fetch/checkout/runtime')
