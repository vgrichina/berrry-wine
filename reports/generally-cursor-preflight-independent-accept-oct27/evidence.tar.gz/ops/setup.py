from pathlib import Path
import json,hashlib
R=Path('/tmp/generally-cursor-preflight-independent-accept-oct27');D=Path('/tmp/generally-cursor-preflight-integrity-repair-oct27')
m=D/'ops/receipt-manifest.json';assert hashlib.sha256(m.read_bytes()).hexdigest()=='abf53f32d598564e2912704b481b5481e5641371b6fc6e9d6c780871a6a5243f'
v=json.loads(m.read_text()); pins={k:x['sha256'] for k,x in v['sourcePins'].items()};pins.update(v['fixturePins']);pins[v['newTest']['path']]=v['newTest']['sha256']
for name,h in pins.items():
 s=D/'repo'/name;b=s.read_bytes();assert hashlib.sha256(b).hexdigest()==h,name
 p=R/'repo'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
(R/'ops/input-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
g=R/'repo/.git';(g/'objects/info/alternates').write_text(str(D/'repo/.git/objects')+'\n');(g/'config').write_text('[core]\n repositoryformatversion = 0\n filemode = true\n bare = false\n logallrefupdates = true\n[user]\n name = Wine Ops\n email = wine-ops@localhost\n[remote "origin"]\n url = git@github.com:vgrichina/wine-assembly.git\n[gc]\n auto = 0\n')
s=(R/'repo/test/run.js').read_text();a=s.index('  const liveOutstanding = new Map();');b=s.index('\n\n  // A rejected async loader/yield',a);span=s[a:b].encode();assert hashlib.sha256(span).hexdigest()=='96de2e3dbd35b5059e05e7a346a65f2926d643acf03b7af5cd9760255d1e2bf7'
(R/'ops/production-binding.json').write_text(json.dumps(dict(authority='1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba',candidate='742baebdcde0b0261e6d29818751d9f0866707e9',start=a,end=b,bytes=len(span),sha256=hashlib.sha256(span).hexdigest(),oracleTransformation='none; producer helper identity literals already bind candidate; behavioral assertions unchanged',mountArgv=[],mountValidation='no mount or runtime command authorized or issued',ssh='exact configured identity/trust in run.py',rootRefReceipt='/home/user/wine-assembly/scratch/usage-watch/generally-cursor-preflight-independent-accept-oct27/root-ref-digest.json'),indent=2)+'\n')
