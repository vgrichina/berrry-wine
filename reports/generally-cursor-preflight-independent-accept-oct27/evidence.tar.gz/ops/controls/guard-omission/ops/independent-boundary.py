import sys,json,subprocess,threading,time,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent.parent;O=R/'ops';repo=R/'repo';mode=sys.argv[1];d=O/('race-'+mode);d.mkdir()
box=d/'mailbox';(box/'requests').mkdir(parents=True);(box/'replies').mkdir()
(d/'cursor').write_text(json.dumps(dict(next=61,pending=False)))
node='/home/user/.nvm/versions/node/v24.18.1/bin/node';children=[];stop=threading.Event();errors=[]
with (d/'fixture.stderr').open('wb') as err:
 fixture=subprocess.Popen([node,'--max-old-space-size=512',str(repo/'test/fixtures/generally-loading-protocol.cjs'),str(repo/'test/run.js'),'normal',str(d/'fixture.jsonl')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
children.append(fixture)
def forward():
 seen=set()
 try:
  while not stop.is_set():
   for p in sorted((box/'requests').glob('*.json')):
    if p.name in seen:continue
    seen.add(p.name)
    # Retain uncertain dispatch63, deliberately do not acknowledge it.
    if p.stem=='0063' and mode=='after-dispatch':continue
    fixture.stdin.write(p.read_bytes()+b'\n');fixture.stdin.flush()
   stop.wait(.002)
 except Exception as e:errors.append(repr(e))
def receive():
 try:
  for line in fixture.stdout:
   ack=json.loads(line[6:]);name=f"{ack['id']:04}.json";req=json.loads((box/'requests'/name).read_text());p=box/'replies'/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(dict(request=req,reply=ack)));t.replace(p)
 except Exception as e:errors.append(repr(e))
threads=[threading.Thread(target=f,daemon=True) for f in (forward,receive)]
for t in threads:t.start()
cleanup=[]
try:
 cmd=[sys.executable,'-B',str(O/'cli-race-entry.py'),str(repo/'tools/generally-loading-controller.py'),mode,str(d),'--mailbox',str(box),'--state',str(d/'cursor'),'--receipt',str(d/'receipt.json'),'--total','2','--deadline-seconds','5','--timeout-seconds','.2']
 with (d/'controller.stdout').open('wb') as out,(d/'controller.stderr').open('wb') as err:c=subprocess.Popen(cmd,stdout=out,stderr=err)
 children.append(c);code=c.wait(timeout=8)
 receipt=json.loads((d/'receipt.json').read_text());cursor=json.loads((d/'cursor').read_text());journal=json.loads(next(box.glob('*.journal')).read_text())
 hook=json.loads((d/'hook.json').read_text());after=mode=='after-dispatch'
 diagnostic=dict(mode=mode,exit=code,cursor=cursor,receipt=receipt,journal=journal,requests=sorted(p.name for p in (box/'requests').iterdir()),hook=hook,source=hashlib.sha256((repo/'tools/generally-loading-controller.py').read_bytes()).hexdigest())
 (d/'observation.json').write_text(json.dumps(diagnostic,indent=2)+'\n')
 assert code==1 and receipt['ok'] is False
 assert [e['request']['id'] for e in receipt['events']]==[61,62]
 assert cursor['next']==(64 if after else 63),diagnostic
 assert cursor['failed'] is True and cursor['pending'] is True
 assert (cursor.get('request',{}).get('id')==63) if after else (cursor['last']['id']==62 and 'request' not in cursor)
 assert journal['status']=='poisoned'
 assert diagnostic['requests']==['0061.json','0062.json']+(['0063.json'] if after else [])
 assert ('timeout' if after else 'consumed ACK changed') in receipt['error']
 before={str(p.relative_to(d)):p.read_bytes() for p in [d/'cursor',*box.rglob('*.json'),next(box.glob('*.journal'))]}
 for name,state in [('same-state',d/'cursor'),('alternate-state',d/'competing.cursor')]:
  cmd=[sys.executable,'-B',str(repo/'tools/generally-loading-controller.py'),'--mailbox',str(box),'--state',str(state),'--receipt',str(d/(name+'.receipt')),'--total','1','--deadline-seconds','1']
  with (d/(name+'.stdout')).open('wb') as out,(d/(name+'.stderr')).open('wb') as err:r=subprocess.run(cmd,stdout=out,stderr=err,timeout=3)
  assert r.returncode==1 and json.loads((d/(name+'.receipt')).read_text())['events']==[]
 assert before=={k:(d/k).read_bytes() for k in before}
 print('PASS actual CLI production transport',mode,'competing owner and durable no-replay')
finally:
 stop.set()
 for c in children:
  if c.poll() is None:c.terminate()
  try:c.wait(timeout=2)
  except subprocess.TimeoutExpired:c.kill();c.wait(timeout=2)
  cleanup.append(dict(pid=c.pid,exit=c.returncode,alive=c.poll() is None))
 for t in threads:t.join(timeout=2)
 (d/'cleanup.json').write_text(json.dumps(dict(children=cleanup,threadsAlive=[t.is_alive() for t in threads],errors=errors)))
 assert not errors and not any(t.is_alive() for t in threads)
