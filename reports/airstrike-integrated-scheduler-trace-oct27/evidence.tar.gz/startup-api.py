import task as t
print(t.api('import os;os.execv("/usr/bin/python3",["python3","-B",'+repr(t.REMOTE+'/trace-ops/remote.py')+',"startup"])','startup'))
