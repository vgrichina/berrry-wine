import task as t,json,time,pathlib,hashlib
D=t.H/'retained'
code="""import pathlib,json,time,shutil,resource,sys
R=pathlib.Path(sys.argv[1]);H=R/'trace-ops';c=json.loads((H/'startup-accepted.json').read_text());a=json.loads((H/'helper-contract.json').read_text());e=(H/'startup.stderr').read_text();assert not e;assert a['pass'];assert c['observerSHA256']=='93775a00c7df506e4d5ad6f77349375a11a797b35c09aab9e0909115df3e7b20'
mem=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024;logical=sum(p.stat().st_size for p in R.rglob('*') if p.is_file());free=shutil.disk_usage(R).free
q=dict(at=time.time(),memAvailable=mem,requiredRAM=2147483648+134217728+805306368,logical=logical,remoteAllocation=268435456,projection=logical+16777216+25165824+33554432,freeDisk=free,projectedDisk=free-268435456,freeFloor=2982150144,helper=a,startupStderr=e,startupCPU59=True,startupFile2097152=True)
q['pass']=mem>=q['requiredRAM'] and q['projection']<=q['remoteAllocation'] and q['projectedDisk']>=q['freeFloor'];assert q['pass'];print(json.dumps(q))"""
q=json.loads(t.api(code,'prelaunch',[t.REMOTE]));t.c.dump('prelaunch.json',dict(at=time.time(),remote=q,startup='retained/startup-supervision.json',closure='retained/remote-closure.json',reuse='reuse.json',CPUremaining=58.962178,wallRemaining=68.740196,originalCPU90=True,originalWall120=True,guestNotYetInvoked=True,stageDeadlinePassed=True,api=json.loads((t.H/'api-ledger.json').read_text())))
print('compact prelaunch PASS')
