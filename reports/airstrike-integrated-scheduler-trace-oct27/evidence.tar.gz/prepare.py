import pathlib,json,subprocess,resource,fcntl,os
H=pathlib.Path(__file__).parent;R=H.parent/'repo';D=pathlib.Path('/tmp/airstrike-accepted-scheduler-main-integration-oct27/repo');M='be0eb25fc33f3b057847d6c4e2c4fe5a6a9a426c';branch='task/airstrike-integrated-scheduler-trace-oct27'
assert json.loads((H/'compact-prelaunch.json').read_text())['remote']['pass']
assert json.loads((H/'retained/startup-supervision.json').read_text())['exit']==0
assert os.environ['GIT_SSH_COMMAND']=='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
R.mkdir(exist_ok=False);g=R/'.git'
for p in ('objects/info','refs/heads/task','info'):(g/p).mkdir(parents=True,exist_ok=True)
stores=[str(D/'.git/objects')]+(D/'.git/objects/info/alternates').read_text().splitlines()
(g/'objects/info/alternates').write_text('\n'.join(dict.fromkeys(stores))+'\n')
(g/'HEAD').write_text('ref: refs/heads/'+branch+'\n');(g/'refs/heads'/branch).write_text(M+'\n')
(g/'config').write_text('[core]\n repositoryformatversion = 0\n bare = false\n sparseCheckout = true\n[remote "origin"]\n url = git@github.com:vgrichina/wine-assembly.git\n[user]\n name = Wine Ops\n email = wine-ops@localhost\n')
(g/'info/sparse-checkout').write_text('/CLAUDE.md\n/reports/airstrike-integrated-scheduler-trace-oct27/\n')
def lim():resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
with open('/tmp/wine-ops-production-git.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 with (H/'checkout-git.stdout').open('wb') as out,(H/'checkout-git.stderr').open('wb') as err:
  p=subprocess.run(['git','-C',str(R),'read-tree','-m','-u',M],stdout=out,stderr=err,preexec_fn=lim)
assert p.returncode==0,p.returncode
(H/'checkout-configuration.json').write_text(json.dumps(dict(base=M,branch=branch,ssh=os.environ['GIT_SSH_COMMAND'],alternates=stores,fetchBytes=0,sparse=['CLAUDE.md','reports/airstrike-integrated-scheduler-trace-oct27'],mountValidation='retained/startup.stdout; actual canonical parser enumerated all89files before checkout',dataLimitGitOnly=True),indent=2))
print('evidence-only sparse task repository ready; base accepted be0eb25f')
