import pathlib,json,hashlib,struct,tarfile
H=pathlib.Path(__file__).parent;R=H.parent/'repo';D=H/'retained';E=D/'game-evidence';P=R/'reports/airstrike-integrated-scheduler-trace-oct27';P.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,q):p.write_text(json.dumps(q,indent=2)+'\n')
lines=(E/'runner.stdout').read_text().splitlines();rows=[json.loads(x[len('[main-scheduler] '):]) for x in lines if x.startswith('[main-scheduler] {')]
assert len(rows)==12 and [x['id'] for x in rows]==list(range(1,13))
assert all(x['event']=='decision' and x['suspended'] is True and x['reason']=='sleep' and x['yieldReason']==0 and x['liveThreads'] is True and not x['fastForward'] for x in rows)
for batch in (5000,5001,5002):
 xs=[x for x in rows if x['batch']==batch];assert len(xs)==4
 assert [x['path'] for x in xs]==['ordinary']+['cooperative-interleaved']*3
 assert all(x['sleepChecks']==[dict(now=batch*5,deadline=25021,sleeping=True)]*2 for x in xs)
assert not any('limit reached' in x for x in lines)
events=json.loads((E/'events.json').read_text());commands=[x['command'] for x in events if x['kind']=='dispatch'];acks=[json.loads(x[6:]) for x in lines if x.startswith('[ctl] ')]
assert len({x['id'] for x in commands})==len(commands)
assert [x['id'] for x in commands]==[x['id'] for x in acks] and all(x['ok'] is True for x in acks)
completions=[x for x in events if x['kind']=='frozen-input-complete'];assert len(completions)==3
for x,batch,ident in zip(completions,(5000,5001,5002),('airstrike-1','airstrike-2','airstrike-3')):
 assert x['inputId']==ident and x['inputAck']['id']==ident and x['inputAck']['value']['batch']==batch
 assert x['step']['value']['ran']==1 and x['step']['value']['steps']==1
 assert x['snapshot']['value']['batch']==batch+1 and x['snapshot']['value']['frozen']['credits']==0
 assert len({ident,x['step']['id'],x['snapshot']['id']})==3
assert '[input] keydown vk=32 at batch 5001' in lines and '[input] keyup vk=32 at batch 5002' in lines
last=json.loads((D/'input-state-after-airstrike-3.json').read_text())['value'];assert last['batch']==5003 and last['credits']==0
assert last['counters']==dict(scheduled=3,enqueued=0,dequeued=0,routed=0,dispatched=0)
assert [(x['msg'],x['wParam']) for x in last['queues']['renderer']['head']]==[(15,0),(256,32),(257,32)]
assert len([x for x in commands if 'cmd' in x])==3
frames=[]
for x in json.loads((D/'remote-inventory.json').read_text()):
 if not x['path'].endswith('.png'):continue
 p=D/x['path'];assert sha(p)==x['sha256'];b=p.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';dims=struct.unpack('>II',b[16:24]);assert dims==(800,600) and len(b)<=2097152
 frames.append(dict(path='retained/'+x['path'],sha256=sha(p),bytes=len(b),dimensions=dims,review='full800x600 manually inspected; identical fresh captures share review',content='Console obscures startup' if x['sha256'].startswith('a0d213') else 'Airstrike frontmost, Press any key to start; no gameplay'))
assert len(frames)==5 and sum(x['bytes'] for x in frames)<=16777216
sup=json.loads((D/'guest-supervision.json').read_text());assert sup['exit']==0 and sup['stopReason'] is None and sup['cleanupComplete'];assert sup['cpuSeconds']<58.962178 and sup['wallSeconds']<68.740196
allowance=dict(originalCPU=90,originalWall=120,priorCPU=31.037822,priorWall=51.259804,newCPU=sup['cpuSeconds'],newWall=sup['wallSeconds'],CPUCharge='trusted supervisor conservative own+waited high-water; may double-charge; not exact physical CPU',cumulativeCPU=31.037822+sup['cpuSeconds'],cumulativeWall=51.259804+sup['wallSeconds'],remainingCPU=90-31.037822-sup['cpuSeconds'],remainingWall=120-51.259804-sup['wallSeconds'],newGuestInvocations=1,invocationAllowanceConsumed=True,noReplay=True)
save(H/'cumulative-allowance.json',allowance)
findings=dict(status='SCHEDULER_SLEEP_BRANCH_OBSERVED_NO_ADMITTED_MAIN_RUN',observedDecisions=rows,matchedControlRequests=len(commands),allACKsMatched=True,serialFrozenInputs=completions,mainRunRecords=0,hostCheckInputRecords=0,observerSuppressed=False,finalState=last,causalConclusion='Every actual ordinary/cooperative admission at5000-5002 returned suspended=true reason=sleep: now25000/25005/25010<deadline25021; liveThreads=true prevents fast-forward. No main run was admitted, so matching main execution/host-input dequeue cannot exist in this window. Space remains in renderer FIFO.',remainingBranch='Actual runnable admission at/after25021ms, matching main-run/host-check-input decisionId and FIFO dequeue remain unobserved. Earliest ordinary5ms boundary is5005(25025ms), not frozen5003. No further step authorized.',limitsOfConclusion='No scheduler defect, gameplay, ordinary Quit or later SDL consumption established. Diagnostic completion intentionally stopped runtime.',frames=frames,allowance=allowance,boatHandback=json.loads((H/'boat-handback.json').read_text()))
save(H/'findings.json',findings);save(P/'findings.json',findings)
inc=json.loads((H/'operational-incidents.json').read_text())
inc.extend([dict(incident='initial read-only policy/donor displays exceeded8192B per-operation target',action='preserved honestly; later summaries bounded; API8192B gate never raised; total display below1MiB'),dict(incident='report-generator construction Python triple-quote SyntaxError',action='no file mutation or runtime; corrected generator using apply_patch')])
save(H/'operational-incidents.json',inc)
save(H/'recovery-links.json',dict(reuse=json.loads((H/'reuse.json').read_text()),readiness='/tmp/completions-1526-readiness-oct27/ops/air-runtime-dispatch-plan.json',stage='runtime-map.json',freshAdmission='compact-prelaunch.json',trustedSupervisor='/tmp/gl-required-version-independent-integrate-oct26/repo/test/helpers/palette-browser-supervisor.py',recovery='Exact332file map plus canonical module; no rebuild. Task invocation consumed: no guest replay without new coordinator assignment. Coordinator shutdown16:44Z.'))
(P/'README.md').write_text('''# Airstrike scheduler observation at Space5001/5002

The newly accepted production observer recorded the actual sleep admission branch: guest times25000/25005/25010ms were below the25021ms deadline. Every ordinary and cooperative admission in the trace was suspended; liveThreads=true prevented fast-forward. The12 bounded records contain no admitted main-run or host-check-input event, with no suppression.

Caption activation used the reviewed ordinary click656,33. Space down5001 and up5002 each have matched input ACK, one-step completion and frozen-zero snapshot. At frozen5003 the renderer FIFO retains WM_PAINT, WM_KEYDOWN32 and WM_KEYUP32; dequeue/route/dispatch counters are zero. The full800x600 post-release frame still shows Press any key to start. This establishes the cause of no main execution in this bounded window; no scheduler defect or gameplay success is established. Actual admission/run/dequeue after the deadline remains unobserved; earliest ordinary due boundary is5005.

Exact main be0eb25fc33f3b057847d6c4e2c4fe5a6a9a426c runner a8187d18, thread manager f4ba190b and required observer93775a00 were staged with unchanged helper c8c85b12 and module bf707aa4(compiled1e4fdb06). All332 staged hashes, canonical89-file tree mount, helper frozenState contract, Node v24.22.1 executable/environment/heap512 and inherited limits passed before the single guest. Independent12groups/4controls and affected merged-tree acceptance are reused unchanged; no build or acceptance replay.

The guest stopped after Space release with complete exact descendant cleanup. Conservative supervisor charge25.326731CPU/25.571552193wall seconds fits remaining58.962178/68.740196. Cumulative charge56.364553CPU/76.831356193wall fits original90/120; unused time does not authorize another invocation. Five full frames fit the eight-capture cap. Distinct process/runner stdout and stderr, matched requests/responses, timestamps, scheduler logs, FIFO snapshots, operational incidents and recovery links are preserved in the new archive.

Boat bx_k3hacj25 was verified RUNNING with zero owned guest survivors and handed back to the coordinator; shutdown16:44Z, expiry16:47:38.097Z. No lifecycle operation, source repair, main integration or public deployment. Evidence-only task branch task/airstrike-integrated-scheduler-trace-oct27; final canonical ops/receipt-manifest.json and append-only messageboard bind exact commit/ref verification.

evidence-index.json hashes NEW payloads in evidence.tar.gz. Historic canonical receipts are referenced in recovery-links.json; already verified payloads were neither recopied nor replayed.
''')
files=sorted(p for p in H.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='receipt-manifest.json')
index=[dict(path=str(p.relative_to(H)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
save(P/'evidence-index.json',dict(payloads=index,scope='NEW task-owned evidence only; historic manifests referenced',count=len(index)))
with tarfile.open(P/'evidence.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(H)),recursive=False)
assert (P/'evidence.tar.gz').stat().st_size<24*1024**2
save(H/'publication-payload.json',dict(report=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(P.iterdir())],portablePayloads=len(index),archiveBytes=(P/'evidence.tar.gz').stat().st_size,archiveSHA256=sha(P/'evidence.tar.gz'),finding=findings['status']))
print(json.dumps(dict(status=findings['status'],decisions=12,matchedRequests=len(commands),frames=len(frames),payloads=len(index),archiveBytes=(P/'evidence.tar.gz').stat().st_size,allowance=allowance)))
