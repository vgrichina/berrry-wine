import subprocess,sys,pathlib,time
H=pathlib.Path(__file__).parent
for i in (120,160,200,240,280,320):
 assert time.time()<1793118840,'15minute staging deadline'
 p=subprocess.run([sys.executable,str(H/'run.py'),'stage'+str(i),'python',str(H),sys.executable,'-B',str(H/'task.py'),'stage',str(i)])
 if p.returncode:sys.exit(p.returncode)
