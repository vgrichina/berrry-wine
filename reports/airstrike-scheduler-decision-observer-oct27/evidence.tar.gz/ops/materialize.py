import pathlib,os,subprocess,resource,json,hashlib
ops=pathlib.Path(__file__).parent;repo=ops.parent/'repo'
d=pathlib.Path('/tmp/generally-current-boundary-accept-integrate-oct27/repo/.git');g=repo/'.git'
for x in ('objects/info','refs/heads/task','info'): (g/x).mkdir(parents=True,exist_ok=True)
stores=[str(d/'objects'),*(d/'objects/info/alternates').read_text().splitlines()]
(g/'objects/info/alternates').write_text('\n'.join(dict.fromkeys(stores))+'\n')
(g/'config').write_text((d/'config').read_text())
branch='task/airstrike-scheduler-decision-observer-oct27';base='3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3'
(g/'HEAD').write_text('ref: refs/heads/'+branch+'\n');(g/'refs/heads'/branch).write_text(base+'\n')
paths=['test/run.js','lib/thread-manager.js','test/input-consumption-trace.js','lib/startup-clock.js','lib/renderer-input.js','docs/tracing.md']
(g/'info/sparse-checkout').write_text(''.join('/'+p+'\n' for p in paths)+'/test/main-scheduler-observer.js\n/test/test-main-scheduler-observer.js\n/reports/airstrike-scheduler-decision-observer-oct27/\n')
def lim():resource.setrlimit(resource.RLIMIT_DATA,(512*1024**2,512*1024**2))
def git(*a):
 p=subprocess.run(['flock','/tmp/wine-ops-production-git.lock','git',*a],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=lim)
 if p.returncode:raise RuntimeError(p.stderr.decode()[:1000])
 return p.stdout
# No filename-bearing mount or runtime command exists for this source-only task.
(ops/'mount-checkpoint.json').write_text(json.dumps(dict(mountArgv=[],mounts=[],action='source-only sparse source materialization, no mount invocation',ssh=os.environ['GIT_SSH_COMMAND'],fetchBytes=0),indent=2)+'\n')
pins=[]
old={x['path']:x for x in json.loads(pathlib.Path('/tmp/airstrike-retained-no-dequeue-cause-oct27/ops/source-pins.json').read_text())}
for p in paths:
 b=git('show',base+':'+p);sha=hashlib.sha256(b).hexdigest()
 if p in old:assert sha==old[p]['sha256'],(p,sha)
 dest=repo/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 pins.append(dict(path=p,rev=base,sha256=sha,bytes=len(b),blob=git('rev-parse',base+':'+p).decode().strip()))
assert hashlib.sha256(pathlib.Path('/tmp/airstrike-retained-no-dequeue-cause-oct27/ops/receipt-manifest.json').read_bytes()).hexdigest()=='0b8e2e6736f9db7392d4f02eb0c14e0dbe1baffb14bd0800a7b813e142c3f953'
git('read-tree',base)
(ops/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('PASS: pinned production sources, sparse isolated index; no fetch, runtime or donor mutation')
