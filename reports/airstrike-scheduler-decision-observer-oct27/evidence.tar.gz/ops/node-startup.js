const fs = require('node:fs');
const text = fs.readFileSync('/proc/self/limits', 'utf8');
if (!/^Max data size\s+unlimited\s+unlimited/m.test(text) || !/^Max address space\s+unlimited\s+unlimited/m.test(text)) throw Error('Node data/address limit conflict');
console.log(JSON.stringify({ executable: process.execPath, version: process.version, argv: process.execArgv, limits: text, env: Object.keys(process.env).sort(), cwd: process.cwd(), startup: 'PASS' }));
