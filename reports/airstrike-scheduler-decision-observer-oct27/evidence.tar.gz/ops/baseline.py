import pathlib,json,hashlib
ops=pathlib.Path(__file__).parent;repo=ops.parent/'repo';original=pathlib.Path('/tmp/airstrike-retained-no-dequeue-cause-oct27/ops/source')
run=(original/'test/run.js').read_text();tm=(original/'lib/thread-manager.js').read_text()
def cut(s,a,b):
 i=s.index(a);return s[i:s.index(b,i)]
parts={
 'gate':cut(run,'  const mainExecutionSuspended =','\n\n  // A main thread parked'),
 'ordinary':cut(run,'      if (!mainExecutionSuspended()', '\n    } catch (e) {'),
 'worker':cut(run,'      let ran = 0;', '\n      if (TRACE_BATCH_TIMING)'),
 'cooperative':cut(run,'      for (let s = 0; s < slices; s++) {','\n      if (TRACE_BATCH_TIMING)'),
 'input':cut(run,'  let lastInputEvent = null;', '\n  // Default hwnd routing:'),
 'workerInput':'    wh.check_input = h.check_input;',
 'sleep':cut(tm,'  isMainSleeping()', '\n  hasLiveThreads()'),
 'live':cut(tm,'  hasLiveThreads()', '\n  // Sleep is a slice yield'),
 'note':cut(tm,'  noteMainSleep()', '\n  checkMainYield()'),
}
p=repo/'test/fixtures/main-scheduler-original.json';p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(json.dumps(dict(revision='3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3',runnerSHA256=hashlib.sha256(run.encode()).hexdigest(),threadManagerSHA256=hashlib.sha256(tm.encode()).hexdigest(),parts=parts),indent=2)+'\n')
print('Pinned unchanged-production baseline excerpts',len(parts))
