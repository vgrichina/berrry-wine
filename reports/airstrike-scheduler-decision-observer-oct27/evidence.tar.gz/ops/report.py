import pathlib,json,hashlib,tarfile
ops=pathlib.Path(__file__).parent;repo=ops.parent/'repo';report=repo/'reports/airstrike-scheduler-decision-observer-oct27';report.mkdir(parents=True,exist_ok=True)
readme='''# Airstrike main scheduler decision observer candidate

Source-only candidate for independent acceptance, based on main3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3. Original runner SHA2561655b299c95be6b2cd2ca8c951b880b0b8fbed81a0cd785300d3bed5f24ae39c is unchanged from3370a4e. Original compiled source1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba is the interpretation pin, not a newly compiled artifact.

## Observation contract

Explicit CLI `--trace-main-scheduler` initializes one invocation-owned observer. Without that exact token there is no require/factory invocation, observer output or worker-input wrapper; existing input-consumption observer remains byte-for-byte unchanged. Existing `--trace-from` and `--trace-to` select a batch interval without consuming the record budget during earlier batches. For example, a future independently accepted diagnostic could use `--trace-main-scheduler --trace-from=5000 --trace-to=5006`; this report does not authorize executing it.

The actual ordinary, worker-interleaved and cooperative-interleaved main gates record decision ID, path, batch, suspended result/reason, existing yield-reason return and existing live-thread predicate. Sleep comparison operands are captured inside ThreadManager.isMainSleeping from the exact `_waitNow()` already used; both pre-fast-forward and final checks are retained. A null time means no-deadline short circuit; null yield/live fields mean the respective branch did not evaluate them. Existing fast-forward is labeled, never introduced. No second get_sleep_yielded/get_ticks, clock probe, forced wake, FIFO mutation or scheduling repair is added.

Actual main run entry and host_check_input entry share the decision ID only within that synchronous admitted run, with finally cleanup on exceptions. Worker imports are explicitly labeled with tid and no main decision ID, including synchronous worker input during main execution. Host polls outside these runs are labeled outside-observed-main-run. These records establish host entry, not guest Get/PeekMessage cache use, SDL consumption or gameplay readiness. Output stops after256 JSON rows plus at most one suppression notice; state is bounded and reset with each CLI invocation.

## Targeted verification

Run `/usr/bin/node --max-old-space-size=512 test/test-main-scheduler-observer.js`. The first behavioral checkpoint executes exact contiguous production CLI initialization/gate/ordinary-run/host-import source excerpts, first default-off then enabled. The suite also executes actual cooperative and worker dispatch loops and ThreadManager sleep/note methods with stub guest exports, without constructing a ThreadManager or starting a guest. Full-source and every excerpt byte count/SHA256 are recorded. The unchanged original excerpts in test/fixtures/main-scheduler-original.json are pinned comparison inputs, not the candidate runner.

57 dispatch comparisons across three paths preserve call order/count/values, clocks, consuming sleep flag, blocked/live waiting siblings, no-deadline short circuit, exact-deadline admission, existing no-live fast-forward, real ticks, named/render/send/suspend/timer gates, serial/stopped/inactive paths and exceptions. Additional changing-clock comparison crosses25020 to25021 and retains each actual comparison value. Six FIFO/input-consumption comparisons preserve pending/cross-thread/button/renderer priority and results, including empty and installer-deferral entries. Invocation reset, finally cleanup, worker provenance, real CLI extra-args/exact opt-in parsing, late trace-window budget and400-dispatch bounded output checks pass. Seven production-contract mutations reject: default-on, lost run wiring, extra consuming sleep getter, extra clock, forced wake, lost worker provenance and missing host entry. Full runner syntax check passes. No broad regression, build or guest execution was performed; this is targeted candidate verification, not independent acceptance or full CLI launch acceptance.

## Cause and next decision

The observation gap has changed: a future admitted run can distinguish a skipped main slice from an admitted main run with or without host input entry, using actual decision time. The retained no-dequeue source finding is unchanged: boundary5003 precedes ordinary deadline25021; no scheduler defect or wake/SDL outcome was established. This candidate alone does not justify another runtime attempt. It first needs independent acceptance of exact production wiring/default-off behavior. A coordinator may then decide whether a bounded diagnostic runtime is useful and authorize its resources/lifecycle separately. No runtime allowance is acquired here.

Canonical predecessor manifest /tmp/airstrike-retained-no-dequeue-cause-oct27/ops/receipt-manifest.json SHA2560b8e2e6736f9db7392d4f02eb0c14e0dbe1baffb14bd0800a7b813e142c3f953, published39e044718f8a88d3ca834ee4f4460d8f0d7f7dbc, and /tmp/completions-1526-readiness-oct27/ops/verification.json provide the original63 verified payloads; no archive rehash/replay. Root ref initial receipt is scratch/usage-watch/airstrike-scheduler-decision-observer-oct27/root-ref-digest.json. Root tracked files/index/refs and donor repositories remain read-only. Recover source via pinned Git objects and this branch, tests via the committed fixture and extraction recipe; no binary is required.

## Operations and preservation

Owned ops evidence archive and evidence-index.json bind source pins, Node startup/limits, exact acceptance/negative controls, review, resources and diagnostics. External canonical /tmp/airstrike-scheduler-decision-observer-oct27/ops/receipt-manifest.json adds exact remote ref/commit and cleanup without a self-referential commit. Every bounded child has distinct stdout/stderr and cleanup receipts. Trusted strict SSH identity/configuration, Git-only512MiB DATA,256MiB Git physical cap, Node768MiB aggregate/512MiB heap with DATA/AS unlimited, Python128MiB,90CPU/120wall/24MiBfile/2MiBoutput and light-pool1slot are retained. Task allocation512MiB includes32MiB reserve, source/Git/evidence/session/launcher/WAL growth and donor retention counted once. Final admission also retains aggregate future disk projection1610612736B and2982150144B host floor.

First test failed before behavioral execution because a class-method excerpt was parsed as an object; corrected the harness to parse an anonymous class, leaving production forms unchanged. An unrestricted Git diff over a sparse index hit the enforced aggregate256MiB RSS cap and was terminated/cleaned; changed to explicit owned-path diff with preload disabled (67MiB measured), with no limit increase or unchanged retry. Early read-only policy displays exceeded8192B/op; later source views were bounded and no capture gate was raised. Initial resource receipts omitted the explicit retained-donor row and used the predecessor872415232B future-disk projection; final publication admissions correct these within the same512MiB allocation and preserve the originals.

Initial staging refused the original-excerpt fixture outside the sparse definition; the owned sparse definition was extended to include that exact fixture before staging. No shared index/ref changed.

Source-only lifecycle: no assigned running box, no Boat/API operations. Airstrike bx_hqd5add8 was snapshot-verified/stopped15:20:01.513 by coordinator (inherited authoritative receipt); no fresh state query. Coordinator retains all box lifecycle ownership; Claude idle, no workers spawned, no main integration. Owned watcher is released at final handback.
'''
(report/'README.md').write_text(readme)
# Portable selected evidence. Publication and watcher cleanup are added by final external manifest.
files=[p for p in ops.iterdir() if p.is_file() and p.suffix not in ('.gz',) and not p.name.startswith('report-final.') and p.name not in ('receipt-manifest.json','report.stdout','report.stderr','report.json','report.supervisor-output')]
index=[]
with tarfile.open(report/'evidence.tar.gz','w:gz',compresslevel=6) as tar:
 for p in sorted(files):
  b=p.read_bytes();tar.add(p,arcname='ops/'+p.name,recursive=False);index.append(dict(path='ops/'+p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(report/'evidence-index.json').write_text(json.dumps(dict(payloads=index,archiveSHA256=hashlib.sha256((report/'evidence.tar.gz').read_bytes()).hexdigest(),predecessorVerification='/tmp/completions-1526-readiness-oct27/ops/verification.json'),indent=2)+'\n')
print('Report/evidence archive prepared',len(index),'new payloads')
