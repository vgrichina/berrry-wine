import pathlib,json,hashlib
ops=pathlib.Path(__file__).parent;r=ops.parent/'repo';old=pathlib.Path('/tmp/airstrike-retained-no-dequeue-cause-oct27/ops/source')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(r/'test/input-consumption-trace.js')=='c8c85b12cfb76825ed64d2bc7a4a0afaea453ac5f3d1ba68f3db181ab4b146fe'
base=json.loads((r/'test/fixtures/main-scheduler-original.json').read_text())
assert base['runnerSHA256']==sha(old/'test/run.js')=='1655b299c95be6b2cd2ca8c951b880b0b8fbed81a0cd785300d3bed5f24ae39c'
assert base['threadManagerSHA256']==sha(old/'lib/thread-manager.js')=='f0a2f006b0eb992bcdb904f10128167b06bfe143ac05661b82f9586d9755bf40'
a=json.loads((ops/'acceptance-window.stdout').read_text());assert len(a['rejected'])==7
assert a['source']['runnerSHA256']==sha(r/'test/run.js')
assert a['source']['threadManagerSHA256']==sha(r/'lib/thread-manager.js')
assert (r/'test/run.js').read_text().count('threadManager.noteMainSleep();')==(old/'test/run.js').read_text().count('threadManager.noteMainSleep();')
assert (r/'lib/thread-manager.js').read_text().count('get_sleep_yielded()')==(old/'lib/thread-manager.js').read_text().count('get_sleep_yielded()')
assert (r/'test/run.js').read_text().count('get_ticks()')==(old/'test/run.js').read_text().count('get_ticks()')
# Naming conventions place this new fast in-process test in unit, with no central edit.
assert 'test-main-scheduler-observer.js'.startswith('test-')
result=dict(passAll=True,productionBase='3afff4f4e7fd50ee8ba25e01b01bd3c6c4b11af3',originalCompiled='1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba',inputObserverUnchanged=True,noNewConsumingProbe=True,acceptance=a,sourceOnly=True)
(ops/'review-result.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS pinned production/excerpt identity; original input observer intact; no additional consuming probe; seven controls reject')
