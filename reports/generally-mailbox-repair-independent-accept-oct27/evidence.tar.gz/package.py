import gzip
import hashlib
import json
import pathlib
import tarfile
import time

R = pathlib.Path('/tmp/generally-mailbox-repair-independent-accept-oct27')
O = R / 'ops'
repo = R / 'repo'
report = repo / 'reports/generally-mailbox-repair-independent-accept-oct27'
report.mkdir(parents=True, exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
A = json.loads((O / 'admission.json').read_text())
for name, pin in A['pins'].items():
    assert sha((repo / name).read_bytes()) == pin['sha256']
expected = {'original-cli-collision': 0, 'node-startup': 0, 'independent-stdio': 0,
            'independent-durable': 0, 'independent-history': 0,
            'ownership-omission': 1, 'no-advance-rejection': 1}
results = {}
for label, code in expected.items():
    result = json.loads((O / (label + '.json')).read_text())
    assert result['exit'] == code and result['stopReason'] is None and result['cleanupComplete']
    results[label] = result
assert json.loads((O / 'no-advance-rejection.stdout').read_text())['accepted'] is False
assert json.loads((O / 'ownership-omission.stdout').read_text())['accepted'] is False
payloads = []
# Explicitly selected new owned evidence only; no donor/run trees are copied.
selected = ['original-cli-collision', 'stdio', 'durable', 'history', 'ownership-omission', 'ownership-omitted']
files = [p for p in O.iterdir() if p.is_file() and p.name != 'receipt-manifest.json']
for name in selected:
    files.extend((O / name).rglob('*'))
archive = report / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6, dereference=False) as tar:
    for path in sorted(set(files)):
        if path.is_dir() and not path.is_symlink():
            continue
        name = str(path.relative_to(O))
        tar.add(path, arcname=name, recursive=False)
        if path.is_symlink():
            payloads.append(dict(path=name, type='symlink', target=path.readlink().as_posix()))
        else:
            b = path.read_bytes()
            payloads.append(dict(path=name, type='file', bytes=len(b), sha256=sha(b)))
index = json.dumps(payloads, indent=2).encode()
with gzip.GzipFile(filename='', mode='wb', fileobj=(report / 'payload-index.json.gz').open('wb'), mtime=0) as f:
    f.write(index)
source = {str(p.relative_to(repo)): sha(p.read_bytes()) for p in (repo / 'test').glob('independent-generally-*-oct27.py')}
canonical = dict(
    at=time.time(), decision='REJECTED_NO_CURSOR_ADVANCE_CONTRACT',
    candidate='4616ccf2e6ce700114c8c6db3642f4aac3065827',
    branch='task/generally-mailbox-repair-independent-accept-oct27',
    acceptanceScope='exact published candidate; source/protocol only; no main integration',
    sourcePins=A['pins'], independentFixturePins=source,
    productionBinding=dict(path='production-binding.json', sha256=sha((O / 'production-binding.json').read_bytes()),
                           authority='1e4fdb06f64e5f14ddec582111dfe7ecb71df6ba',
                           runnerBlob='f52b03a096a9a614b681cdf0f912ce20ca19fcba',
                           boundarySHA256='96de2e3dbd35b5059e05e7a346a65f2926d643acf03b7af5cd9760255d1e2bf7'),
    results=results,
    defect=dict(cause='LoadingController.request atomically reserves cursor ID before Mailbox.exchange calls check; consumed-history integrity failure is detected after reserving the following request',
                observed='consumed reply61 mutated while pending62; ACK62 valid; no request63 file; cursor next64/pending63/failed; journal next63 poisoned',
                requirement='no request/cursor advance after uncertainty',
                expected='on discovering history uncertainty before any63 dispatch, do not reserve63 or advance next beyond63',
                safetyPreserved='no63 dispatch or clean handoff; poisoned mailbox refuses all later cursors; original ownership collision is closed',
                failureReceipt='no-advance-rejection.json', failureStdout='no-advance-rejection.stdout', failureStderr='no-advance-rejection.stderr',
                adjudication='reuses fresh same-task exact-source causal execution; no unchanged Node group replay',
                smallestRepairScope='coordinator-owned followup: arrange pre-dispatch transport integrity validation before subsequent cursor reservation, while preserving durable pre-dispatch pending and terminal legacy semantics; no repair made here'),
    reuse=dict(publicationManifest='/tmp/generally-mailbox-retained-publication-oct27/ops/receipt-manifest.json',
               sha256='9aacd349c098076ffae5b0c7f3bcdb4905bfd450e24eaf94a2a57cb3f4020267',
               coordinatorVerifiedOriginalPayloads=1409, coordinatorVerifiedNewPayloads=52,
               compressionPairs=5, repeatedPayloadAudit=False,
               producerPassingGroups=['attack-published', 'attack-variants-published', 'ownership-published', 'protocol-published', 'handoff-published'],
               protocolIncludes='partial/stale/malformed ACK, exact bounded steps/frozen-zero/global deadline, clean alternate/same-state history, terminal and oversized journal'),
    evidence=dict(archive=str(archive.relative_to(repo)), archiveSHA256=sha(archive.read_bytes()),
                  index='payload-index.json.gz', indexSHA256=sha((report / 'payload-index.json.gz').read_bytes()),
                  rawIndexSHA256=sha(index), payloads=len(payloads),
                  extraction='Extract to a fresh owned ops path; archived absolute symlinks preserve original identities. For portable replay use --reproduce /OWNED/new-history; it regenerates aliases at the new location.'),
    resources=json.loads((O / 'resources-before-publication.stdout').read_text()),
    launchIncident='Initial aggregate admission assertion failed before measurement receipt; setup wrapper then absent, no Git started. Material increase from coordinator dispatch2.69GB to measured3.70GB allowed admission; provisional blocker corrected, original incident retained. No behavioral guard exhausted.',
    remainingGate='REJECTED: no source integration/runtime. Coordinator must assign bounded repair then independent acceptance/current-main reconciliation/fresh runtime readiness.',
    historicalRequest12='untouched, no replay and no assumed completion',
    lifecycle='no assigned Boat; coordinator owns existing lifecycle, none changed',
    cleanup='all actual supervised operations cleanupComplete; watcher closed separately before handoff',
    sourceSemanticsChanged=False, guestInvocations=0, compilerInvocations=0,
    downloads=0, fetchBytes=0, publication='report/test artifacts only; commit and exact remote ref in publication-closeout.json')
data = json.dumps(canonical, indent=2)
(O / 'receipt-manifest.json').write_text(data)
(report / 'receipt-manifest.json').write_text(data)
print(json.dumps(dict(decision=canonical['decision'], payloads=len(payloads), archiveBytes=archive.stat().st_size,
                      manifestSHA256=sha(data.encode()))))
