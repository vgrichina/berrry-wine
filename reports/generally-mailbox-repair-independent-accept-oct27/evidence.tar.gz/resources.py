import os,pathlib,json,time
R=pathlib.Path('/tmp/generally-mailbox-repair-independent-accept-oct27');O=R/'ops';M=1048576
A=json.loads((O/'admission.json').read_text())
roots=[R,pathlib.Path('/home/user/wine-assembly/scratch/usage-watch/generally-mailbox-repair-independent-accept-oct27')]
roots+=list(pathlib.Path('/home/user/.codex/sessions/2026/10/27').glob('*01a17db7-9748-75a0-bca9-823015c9664c.jsonl'))
def allocated(p):
 if p.is_symlink() or not p.is_dir():return p.lstat().st_blocks*512
 return p.lstat().st_blocks*512+sum(allocated(q) for q in p.iterdir())
usage={str(p):allocated(p) for p in roots}
wal={p:max(0,pathlib.Path(p).stat().st_blocks*512-n) for p,n in A['walBaseline'].items() if pathlib.Path(p).exists()}
clients=[]
for p in pathlib.Path('/proc').iterdir():
 try:
  if p.name.isdigit() and pathlib.Path(os.readlink(p/'exe')).name=='codex':
   s=(p/'stat').read_text().split(') ',1)[1].split();clients.append(dict(pid=int(p.name),rss=int(s[21])*4096))
 except (OSError,ValueError):pass
avail=int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
remaining=sum(max(0,320*M-c['rss']) for c in clients)
free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
reserves=dict(publication=24*M,sessionEventsWAL=64*M,growth=32*M,reserve=8*M)
projected=sum(usage.values())+sum(wal.values())+sum(reserves.values())
r=dict(at=time.time(),roots=usage,positiveWALChargedOnce=wal,projected=projected,allocation=256*M,reserves=reserves,clients=clients,remainingClientGrowth=remaining,requiredAdditionalRAM=remaining+768*M+805306368,memAvailable=avail,freeDisk=free,projectedHostFree=free-872415232,diskFloor=2982150144,sourceLogical=sum(q.stat().st_size for folder in ['test','tools','docs'] for q in (R/'repo'/folder).rglob('*') if q.is_file()))
r['pass_']=projected<=256*M and r['projectedHostFree']>=2982150144 and avail>=r['requiredAdditionalRAM'] and r['sourceLogical']<=M
print(json.dumps(r,indent=2))
assert r['pass_']
