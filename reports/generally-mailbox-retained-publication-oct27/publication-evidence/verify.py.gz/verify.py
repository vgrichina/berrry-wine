from pathlib import Path
import json,hashlib,gzip,os,time,shutil
R=Path('/tmp/generally-mailbox-retained-publication-oct27');O=R/'ops';repo=R/'repo';M=1048576
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((O/'predecessor-manifest.json').read_text());a=json.loads((O/'admission.json').read_text())
for name,pin in m['sourceAndTestFiles'].items():
 p=(Path('/tmp/generally-mailbox-ownership-repair-oct27/repo') if name=='test/run.js' else repo)/name
 assert sha(p)==pin,name
ix=json.loads((repo/'reports/generally-mailbox-ownership-repair-oct27/evidence-index.json').read_text())
for row in ix['payloads']:
 p=repo/row['published'];assert sha(p)==row['publishedSHA256']
 raw=gzip.decompress(p.read_bytes()) if row['encoding']=='gzip exact bytes' else p.read_bytes()
 assert hashlib.sha256(raw).hexdigest()==row['originalSHA256'] and len(raw)==row['bytes']
session=Path('/home/user/.codex/sessions/2026/10/27/rollout-2026-10-27T14-08-54-01a17db1-4de2-7f32-a96d-79417fa324d9.jsonl')
roots=[R,Path('/home/user/wine-assembly/scratch/usage-watch/generally-mailbox-retained-publication-oct27'),session]
measures={str(r):sum(p.lstat().st_blocks*512 for p in ([r]+list(r.rglob('*')) if r.is_dir() else [r])) for r in roots}
wal={n:max(0,Path(n).stat().st_blocks*512-baseline) for n,baseline in a['walBaseline'].items()}
measured=sum(measures.values())+sum(wal.values());reserves=dict(publication=16*M,sessionEventsWAL=48*M,growth=32*M,reserve=8*M)
avail=int(Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
clients=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if Path(os.readlink(p/'exe')).name=='codex':
   s=(p/'stat').read_text().split(') ',1)[1].split();clients.append(dict(pid=int(p.name),rss=max(0,int(s[21]))*4096))
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
needed=sum(max(0,320*M-c['rss']) for c in clients)+256*M+768*M
free=shutil.disk_usage(R).free;projected=measured+sum(reserves.values())
assert projected<=256*M and free-576*M>=2982150144 and avail>=needed
result=dict(at=time.time(),payloadsVerified=len(ix['payloads']),sourcePins=m['sourceAndTestFiles'],unchangedDependencyOnly='test/run.js',roots=measures,positiveWALChargedOnce=wal,measured=measured,reserves=reserves,projected=projected,allocation=256*M,memAvailable=avail,aggregateClients=clients,requiredAdditionalRAM=needed,freeDisk=free,projectedHostFree=free-576*M,diskFloor=2982150144,behavioralReruns=0,pass_=True)
(O/('integrity-resources-'+str(len(list(O.glob('integrity-resources-*.json'))))+'.json')).write_text(json.dumps(result,indent=2))
print(json.dumps({k:result[k] for k in ('payloadsVerified','measured','projected','memAvailable','pass_')}))
