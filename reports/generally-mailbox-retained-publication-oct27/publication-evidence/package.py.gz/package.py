from pathlib import Path
import hashlib,json,gzip,os,shutil
R=Path('/tmp/generally-mailbox-retained-publication-oct27');O=R/'ops';P=R/'repo/reports/generally-mailbox-retained-publication-oct27'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((O/'predecessor-manifest.json').read_text())
seen=[]
for line in (O/'git-staged-pins.stdout').read_text().splitlines():
 meta,name=line.split('\t');blob=meta.split()[1];data=((Path('/tmp/generally-mailbox-ownership-repair-oct27/repo') if name=='test/run.js' else R/'repo')/name).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob,name
 seen.append(name)
assert set(seen)==set(old['sourceAndTestFiles'])
for name in ('git-whitespace','git-scope','git-staged-pins'):
 r=json.loads((O/(name+'.json')).read_text());assert r['exit']==0 and r['stopReason'] is None and r['cleanupComplete']
payloads=[]
if (P/'publication-evidence').exists():shutil.rmtree(P/'publication-evidence')
for p in sorted(O.iterdir()):
 if not p.is_file() or p.name in ('board-watcher.log','receipt-manifest.json') or (p.name.startswith('package') and p.name!='package.py'):continue
 target=P/'publication-evidence'/(p.name+'.gz');target.parent.mkdir(exist_ok=True);target.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 payloads.append(dict(original=str(p),published=str(target.relative_to(R/'repo')),rawSHA256=sha(p),compressedSHA256=sha(target),rawBytes=p.stat().st_size,encoding='gzip exact bytes'))
manifest=dict(task='generally-mailbox-retained-publication-oct27',status='READY_TESTED_PUBLICATION_ONLY',base='e954f74d815795fbb715f54a312746f47f8e7157',branch='task/generally-mailbox-retained-publication-oct27',sourcePins=old['sourceAndTestFiles'],unchangedDependencyOnly='test/run.js',originalManifestSHA256='0976530173c6ec5a3e9f2baa42e45db562d139fd3d24c9125363b5822a3767d5',originalIndexSHA256=old['payloadIndexSHA256'],coordinatorVerifiedOriginalPayloads=1409,passingReceiptsReused=old['finalPassingReceipts'],nodeFixtureBindingsReused=21,behavioralTestsRerun=0,originalExhaustedPhase=old['publicationBlocker'],compression=json.loads((O/'compression.json').read_text()),newPhase=dict(cumulativeOutputAllowance=131072,perOperationDisplay=8192,perOperationOutput=2097152,resources='Git physical256MiB/DATA512MiB child only; Python physical128MiB; CPU90 wall120 file24MiB; Git two permits+flock; Python one permit; trusted supervisor unchanged',accounting=json.loads((O/'integrity-resources-0.json').read_text())),evidence=payloads,loadingCause='unknown',runtimeJustified=False,sourceAcceptance='UNACCEPTED independent acceptance remains required',mainIntegration=False,guestCompilerBoatInvocations=0,boatsAssigned=[],lifecycle='No boxes assigned/touched; coordinator owns existing boxes',cleanup='All completed supervised child trees cleanupComplete; own board watcher cleanup recorded at external final closeout',publication='External canonical manifest updated with exact commit/remote and final receipts after push; this committed manifest is prepublication snapshot')
(O/'receipt-manifest.json').write_text(json.dumps(manifest,indent=2));(P/'prepublication-manifest.json').write_text(json.dumps(manifest,indent=2))
(P/'README.md').write_text('Publication-only recovery of the completed GeneRally mailbox ownership repair. Source and tests are byte-exact to the retained final pins; passing behavioral receipts and 21 Node bindings are reused without rerun. Source repair remains UNACCEPTED pending independent acceptance; loading cause unknown and runtime not justified. No main integration or public deployment.\n\nThe original exhausted 1 MiB guard and both failed Git receipts remain preserved. evidence-index.json in the predecessor report maps portable payloads to exact raw bytes. For gzip entries, decompress into a bounded file and verify originalSHA256 and byte count; do not print fault payloads. recovery.json binds changed raw/compressed hashes. publication-evidence contains this fresh phase diagnostics with raw/compressed hashes in prepublication-manifest.json. The final external canonical manifest is /tmp/generally-mailbox-retained-publication-oct27/ops/receipt-manifest.json.\n')
print(json.dumps(dict(stagedSourcePins=len(seen),phasePayloads=len(payloads),outputBytes=sum(p.stat().st_size for pat in ('*.stdout','*.stderr') for p in O.glob(pat)))))
