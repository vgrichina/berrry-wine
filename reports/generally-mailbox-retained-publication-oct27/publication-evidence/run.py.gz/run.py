import os,sys,json,pathlib,hashlib,resource,importlib.util,shlex,time
R=pathlib.Path('/tmp/generally-mailbox-retained-publication-oct27'); O=R/'ops'; M=1048576
S=pathlib.Path('/tmp/gl-required-version-independent-integrate-oct26/repo/test/helpers/palette-browser-supervisor.py')
assert hashlib.sha256(S.read_bytes()).hexdigest()=='9d10f7c8c75b5f0dfebff2299eef8ddc27988cf112e0e9c255e89f772c2cee85'
s=importlib.util.spec_from_file_location('sup',S);sup=importlib.util.module_from_spec(s);s.loader.exec_module(sup)
SSH='ssh -i /home/user/.ssh/wine_github_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes -o UserKnownHostsFile=/home/user/.ssh/wine_github_known_hosts -o StrictHostKeyChecking=yes'
os.environ.clear();os.environ.update(PATH='/usr/local/bin:/usr/bin:/bin',HOME='/home/user',LANG='C.UTF-8',TZ='UTC',GIT_SSH_COMMAND=SSH,GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1')
label,kind=sys.argv[1:3];cmd=sys.argv[3:];assert kind in ('git','python')
assert not (O/(label+'.json')).exists()
out=O/(label+'.stdout');err=O/(label+'.stderr');out.touch(exist_ok=False);err.touch(exist_ok=False)
original=cmd[:]
if kind=='git':
 cmd=['/usr/bin/flock','/tmp/wine-ops-production-git.lock','/usr/bin/python3','-B','-c',"import os,resource,sys;resource.setrlimit(resource.RLIMIT_DATA,(536870912,536870912));os.execvp(sys.argv[1],sys.argv[1:])",*cmd]
def check():
 sizes=[p.stat().st_size for pattern in ('*.stdout','*.stderr') for p in O.glob(pattern)]
 if out.stat().st_size+err.stat().st_size>2*M:return 'operation output guard'
 if sum(sizes)>131072:return 'fresh publication cumulative output guard'
 if os.statvfs(R).f_bavail*os.statvfs(R).f_frsize<2982150144:return 'disk floor'
 if int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024<768*M:return 'memory remainder'
result=sup.supervise(['/bin/bash','-c','exec '+shlex.join(cmd)+' >'+shlex.quote(str(out))+' 2>'+shlex.quote(str(err))],rss_limit=(256 if kind=='git' else 128)*M,cpu_limit=90,wall_limit=120,output_limit=2*M,check=check)
(O/(label+'.supervisor-output')).write_bytes(result.pop('output'))
result.update(command=original,wrappedCommand=cmd,environmentSHA256=hashlib.sha256(json.dumps(dict(os.environ),sort_keys=True).encode()).hexdigest(),environment=dict(os.environ),supervisorSHA256=hashlib.sha256(S.read_bytes()).hexdigest(),inheritedLimits={str(k):resource.getrlimit(k) for k in (resource.RLIMIT_AS,resource.RLIMIT_DATA,resource.RLIMIT_CPU,resource.RLIMIT_FSIZE)},gitChildDATA=512*M if kind=='git' else None,stdout=str(out),stderr=str(err),displayLimit=8192,cumulativeAllowance=131072)
(O/(label+'.json')).write_text(json.dumps(result,indent=2))
print(json.dumps(dict(operation=label,**{k:result[k] for k in ('exit','stopReason','cleanupComplete','peakRSS')})))
sys.exit(0 if result['exit']==0 and result['stopReason'] is None and result['cleanupComplete'] else 1)
