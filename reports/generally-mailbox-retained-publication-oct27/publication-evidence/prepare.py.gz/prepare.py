from pathlib import Path
import os,json,hashlib,gzip,shutil,time,resource
R=Path('/tmp/generally-mailbox-retained-publication-oct27');O=R/'ops';D=Path('/tmp/generally-mailbox-ownership-repair-oct27');M=1048576
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=D/'ops/receipt-manifest.json'; index=D/'repo/reports/generally-mailbox-ownership-repair-oct27/evidence-index.json'
assert sha(manifest)=='0976530173c6ec5a3e9f2baa42e45db562d139fd3d24c9125363b5822a3767d5'
assert sha(index)=='2275c2ff748e878b6c956562a56c2dbaa6978b7693366a145ab37fbe7ad476fb'
m=json.loads(manifest.read_text());ix=json.loads(index.read_text())
for name,pin in m['sourceAndTestFiles'].items(): assert sha(D/'repo'/name)==pin,name
files=[D/'repo'/n for n in m['sourceAndTestFiles'] if n!='test/run.js']+list((index.parent).rglob('*'))+[manifest,D/'ops/git-diffcheck.json',D/'ops/git-diffcheck.stdout',D/'ops/git-diffcheck.stderr',D/'ops/git-scope.json']
files=[p for p in files if p.is_file()];size=sum(p.stat().st_size for p in files);allocated=sum(p.stat().st_blocks*512 for p in files)
assert size<=64*M and allocated<=64*M
avail=int(Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])*1024
clients=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if Path(os.readlink(p/'exe')).name=='codex':
   s=(p/'stat').read_text().split(') ',1)[1].split();clients.append(dict(pid=int(p.name),rss=max(0,int(s[21]))*4096))
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
needed=sum(max(0,320*M-c['rss']) for c in clients)+256*M+768*M
free=shutil.disk_usage(R).free;assert avail>=needed and free-576*M>=2982150144
ad=dict(at=time.time(),copyBytes=size,copyAllocated=allocated,copyCeiling=64*M,memAvailable=avail,clients=clients,requiredAdditional=needed,freeDisk=free,aggregateFuture=576*M,allocation=256*M,reserve=8*M,fetchBytes=0,sourcePins=m['sourceAndTestFiles'],manifestSHA256=sha(manifest),indexSHA256=sha(index),walBaseline={str(p):p.stat().st_blocks*512 for p in Path('/home/user/.codex').glob('*-wal')},inheritedLimits={str(k):resource.getrlimit(k) for k in (resource.RLIMIT_AS,resource.RLIMIT_DATA,resource.RLIMIT_CPU,resource.RLIMIT_FSIZE)},ssh=os.environ['GIT_SSH_COMMAND'],mountValidation='not applicable: no guest/runtime/mount argv',initialRootRefReceipt='/home/user/wine-assembly/scratch/usage-watch/generally-mailbox-retained-publication-oct27/root-ref-digest.json')
(O/'admission.json').write_text(json.dumps(ad,indent=2));(O/'predecessor-manifest.json').write_bytes(manifest.read_bytes())
for name in m['sourceAndTestFiles']:
 if name=='test/run.js':continue
 target=R/'repo'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(D/'repo'/name,target)
P=R/'repo'/index.parent.relative_to(D/'repo');shutil.copytree(index.parent,P)
changes=[]
for row in ix['payloads']:
 p=R/'repo'/row['published'];data=p.read_bytes()
 assert hashlib.sha256(data).hexdigest()==row['publishedSHA256']
 if row['encoding']=='exact' and any(line.rstrip(b'\r\n').endswith((b' ',b'\t')) for line in data.splitlines(keepends=True)):
  rawhash=hashlib.sha256(data).hexdigest();assert rawhash==row['originalSHA256']
  compressed=gzip.compress(data,mtime=0);new=p.with_name(p.name+'.gz');new.write_bytes(compressed);p.unlink()
  changes.append(dict(rawPath=row['published'],compressedPath=str(new.relative_to(R/'repo')),rawSHA256=rawhash,compressedSHA256=sha(new),rawBytes=len(data),compressedBytes=len(compressed)))
  row.update(published=str(new.relative_to(R/'repo')),publishedSHA256=sha(new),encoding='gzip exact bytes')
ix['retainedPublicationRecovery']=dict(originalIndexSHA256=sha(index),originalCanonicalManifestSHA256=sha(manifest),compression=changes,recipe='gzip.decompress(Path(published).read_bytes()); verify SHA256 equals originalSHA256 and length equals bytes',behavioralTests='reused unchanged, no reruns')
(P/'evidence-index.json').write_text(json.dumps(ix,indent=2))
H=R/'repo/reports/generally-mailbox-retained-publication-oct27';H.mkdir(parents=True)
for name in ('git-diffcheck.json','git-diffcheck.stdout','git-diffcheck.stderr','git-scope.json','receipt-manifest.json'):
 p=D/'ops'/name;(H/(name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
(O/'compression.json').write_text(json.dumps(changes,indent=2))
(H/'recovery.json').write_text(json.dumps(dict(admission=ad,compression=changes,originalBlocker=m['publicationBlocker'],sourcePins=m['sourceAndTestFiles'],reusedPassingReceipts=m['finalPassingReceipts'],fixtureBindings=21,acceptance='UNACCEPTED pending independent acceptance',loadingCause='unknown',runtimeJustified=False,originalFailedReceipts='lossless gzip files beside this receipt; decompress only into bounded files, never print fault payloads',recipe=ix['retainedPublicationRecovery']['recipe']),indent=2))
print(json.dumps(dict(copyBytes=size,copyAllocated=allocated,payloads=len(ix['payloads']),compressed=len(changes),admitted=True)))
